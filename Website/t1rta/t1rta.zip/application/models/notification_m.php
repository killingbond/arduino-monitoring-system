<?php
/**
 * Created by PhpStorm.
 * User: jokopurnomoa
 * Date: 9/9/15
 * Time: 7:28 AM
 */

class Notification_m extends MX_Model {

    
}