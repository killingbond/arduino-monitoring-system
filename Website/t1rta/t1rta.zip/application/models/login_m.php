<?php
/**
 * Created by PhpStorm.
 * User: jokopurnomoa
 * Date: 9/9/15
 * Time: 7:28 AM
 */

class Login_m extends MX_Model {

    public function auth($username, $password){

        $data_login = $this->get_first('user', array('username' => $username, 'password' => $password));
        if($data_login != ''){
            if($data_login->username == $username && $data_login->password == $password){
                $this->session->set_userdata('is_login', true);
                $this->session->set_userdata('user_id', $data_login->user_id);
                $this->session->set_userdata('username', $data_login->username);
                $this->session->set_userdata('name', $data_login->name);
                $this->session->set_userdata('level', $data_login->level);

                return true;
            }
        }
        return false;
    }

    public function save_profile($user_id, $data){
        return $this->update('user', 'user_id', $user_id, $data);
    }

}