<?php
class Debit extends MX_Controller {

    public function __construct(){
        parent::__construct();
        $this->load->model('debit_m');
    }

    public function index()
	{
        $this->data['max'] = 10;
        $this->data['page'] = 1;
        $this->data['search'] = '';
        $this->data['order'] = 'A1';
        

        if($this->uri->segment(3) != ''){
            $this->data['page'] = $this->uri->segment(3);
        }

        if($this->uri->segment(4) != ''){
            $this->data['order'] = $this->uri->segment(4);
        }

        if($this->uri->segment(5) != ''){
            $this->data['max'] = $this->uri->segment(5);
        }

        if($this->uri->segment(6) != ''){
            $this->data['search'] = str_replace('%20', ' ', $this->uri->segment(6));
        }
        


        $this->data['start'] = (($this->data['page'] - 1) * $this->data['max']) + 1;
        $this->data['stop'] = ($this->data['page'] * $this->data['max']);

        $this->data['data_table'] = $this->debit_m->get_all($this->data['start']-1, $this->data['stop'], $this->data['order'], $this->data['search']);
        $this->data['max_row'] = $this->debit_m->max_row();

        if($this->data['max_row'] == 0){
            $this->data['start'] = 0;
        }

        if($this->data['stop'] > $this->data['max_row']){
            $this->data['stop'] = $this->data['max_row'];
        }

        $this->data['max_page'] = ceil($this->data['max_row'] / $this->data['max']);

         if(($this->session->userdata('is_login') != '')&&($this->session->userdata('level')==1)) {

          
            $this->load->view('slices/head', $this->data);
            $this->load->view('slices/header', $this->data);
            $this->load->view('product/product', $this->data);
            $this->load->view('slices/footer', $this->data);
        } else if(($this->session->userdata('is_login') != '')&&($this->session->userdata('level')==2)){
            header('location:'.base_url("homeuser"));
        }else{
            $this->load->view('login', $this->data);
        }
        
	}

    public function add(){
        $this->data['category'] = $this->debit_m->get_all_category();
        $this->data['sub_category'] = $this->debit_m->get_all_sub_category();

        $this->load->view('slices/head', $this->data);
        $this->load->view('slices/header', $this->data);
        $this->load->view('product/add_product', $this->data);
        $this->load->view('slices/footer', $this->data);
    }

    public function update(){
        $this->data['category'] = $this->debit_m->get_all_category();
        $this->data['sub_category'] = $this->debit_m->get_all_sub_category();
        $this->data['collection'] = $this->debit_m->get_all_collection();
        $this->data['size'] = $this->debit_m->get_all_size();
        $this->data['product_detail'] = $this->debit_m->get_stock($this->uri->segment(3));
        $this->data['product_image'] = $this->debit_m->get_all_image($this->uri->segment(3));
        $this->data['product_image2'] = $this->debit_m->get_all_image2($this->uri->segment(3));
        $this->data['product_image3'] = $this->debit_m->get_all_image3($this->uri->segment(3));
        $this->data['product_image4'] = $this->debit_m->get_all_image4($this->uri->segment(3));
        $this->data['product_image5'] = $this->debit_m->get_all_image5($this->uri->segment(3));


        $this->data['data_update'] = $this->debit_m->get_by_id($this->uri->segment(3));

        $this->load->view('slices/head', $this->data);
        $this->load->view('slices/header', $this->data);
        $this->load->view('product/edit_product', $this->data);
        $this->load->view('slices/footer', $this->data);
    }

    public function add_product(){
        $data = array(
            'name' => clean_str($this->input->post('name')),
            'deskripsi' =>  clean_str($this->input->post('deskripsi')),
            'price' => clean_str($this->input->post('price')),
            'special_price' => clean_str($this->input->post('special_price')),
            'weight' => clean_str($this->input->post('berat')),
            'category_id' => clean_str($this->input->post('select_category')),
            'sub_category_id' => clean_str($this->input->post('select_sub_category'))
            
        );
        
        $res = $this->debit_m->insert($data);
        header('location:'.base_url().'product?'.($res ? 'sa' : 'fa'));
    }

    public function add_product_stock(){
        $data = array(
            'product_id' => clean_str($this->input->post('product_id')),
            'size_id' => clean_str($this->input->post('size_id')),
            'stock' => clean_str($this->input->post('stock')),
        );

        if($data['size_id'] != ''){
            $res = $this->debit_m->insert_stock($data);
        } else {
            $res = false;
        }

        header('location:'.base_url().'product/update/'.$data['product_id'].'?'.($res ? 'sa' : 'fa'));
    }

    public function add_image(){

        $product_id = $this->input->post('product_id');

        $filename = 'img'.auto_id();

        $config['upload_path'] = '../files/images/product';
        $config['file_name'] = $filename;
        $config['allowed_types'] = 'jpeg|jpg|png';
        $config['max_size']	= '2048';
        $config['max_width']  = '3000';
        $config['max_height']  = '3000';

        $this->load->library('upload', $config);

        if ($this->upload->do_upload())
        {
            $upload_data = $this->upload->data();

            $this->data['image'] = $upload_data['file_name'];

            $config = null;
            $config['image_library'] = 'gd2';
            $config['source_image']	= '../files/images/product/'.$upload_data['file_name'];
            $config['create_thumb'] = FALSE;
            $config['maintain_ratio'] = TRUE;
            $config['width']	 = 800;
            $config['height']	= 800;

            $this->load->library('image_lib');
            $this->image_lib->initialize($config);
            $this->image_lib->resize();

            $config = null;
            $config['image_library'] = 'gd2';
            $config['source_image']	= '../files/images/product/'.$upload_data['file_name'];
            $config['new_image'] = '../files/images/product/thumb/'.$upload_data['file_name'];
            $config['create_thumb'] = FALSE;
            $config['maintain_ratio'] = TRUE;
            $config['width']	 = 200;
            $config['height']	= 200;

            $this->image_lib->initialize($config);
            $this->image_lib->resize();

            $data = array(
                'image1' => $upload_data['file_name']
            );

            
            if($this->debit_m->adding_image($data,$product_id))
                header('location:'.base_url().'product/update/'.$product_id.'?sai');
            else
                header('location:'.base_url().'product/update/'.$product_id.'?fai');
        } else {
            header('location:'.base_url().'product/update/'.$product_id.'?fai');
        }
    }

     public function add_image2(){

        $product_id = $this->input->post('product_id');

        $filename = 'img'.auto_id();

        $config['upload_path'] = '../files/images/product';
        $config['file_name'] = $filename;
        $config['allowed_types'] = 'jpeg|jpg|png';
        $config['max_size'] = '2048';
        $config['max_width']  = '3000';
        $config['max_height']  = '3000';

        $this->load->library('upload', $config);

        if ($this->upload->do_upload())
        {
            $upload_data = $this->upload->data();

            $this->data['image'] = $upload_data['file_name'];

            $config = null;
            $config['image_library'] = 'gd2';
            $config['source_image'] = '../files/images/product/'.$upload_data['file_name'];
            $config['create_thumb'] = FALSE;
            $config['maintain_ratio'] = TRUE;
            $config['width']     = 800;
            $config['height']   = 800;

            $this->load->library('image_lib');
            $this->image_lib->initialize($config);
            $this->image_lib->resize();

            $config = null;
            $config['image_library'] = 'gd2';
            $config['source_image'] = '../files/images/product/'.$upload_data['file_name'];
            $config['new_image'] = '../files/images/product/thumb/'.$upload_data['file_name'];
            $config['create_thumb'] = FALSE;
            $config['maintain_ratio'] = TRUE;
            $config['width']     = 200;
            $config['height']   = 200;

            $this->image_lib->initialize($config);
            $this->image_lib->resize();

            $data = array(
                'image2' => $upload_data['file_name']
            );

            
            if($this->debit_m->adding_image($data,$product_id))
                header('location:'.base_url().'product/update/'.$product_id.'?sai');
            else
                header('location:'.base_url().'product/update/'.$product_id.'?fai');
        } else {
            header('location:'.base_url().'product/update/'.$product_id.'?fai');
        }
    }

      public function add_image3(){

        $product_id = $this->input->post('product_id');

        $filename = 'img'.auto_id();

        $config['upload_path'] = '../files/images/product';
        $config['file_name'] = $filename;
        $config['allowed_types'] = 'jpeg|jpg|png';
        $config['max_size'] = '2048';
        $config['max_width']  = '3000';
        $config['max_height']  = '3000';

        $this->load->library('upload', $config);

        if ($this->upload->do_upload())
        {
            $upload_data = $this->upload->data();

            $this->data['image'] = $upload_data['file_name'];

            $config = null;
            $config['image_library'] = 'gd2';
            $config['source_image'] = '../files/images/product/'.$upload_data['file_name'];
            $config['create_thumb'] = FALSE;
            $config['maintain_ratio'] = TRUE;
            $config['width']     = 800;
            $config['height']   = 800;

            $this->load->library('image_lib');
            $this->image_lib->initialize($config);
            $this->image_lib->resize();

            $config = null;
            $config['image_library'] = 'gd2';
            $config['source_image'] = '../files/images/product/'.$upload_data['file_name'];
            $config['new_image'] = '../files/images/product/thumb/'.$upload_data['file_name'];
            $config['create_thumb'] = FALSE;
            $config['maintain_ratio'] = TRUE;
            $config['width']     = 200;
            $config['height']   = 200;

            $this->image_lib->initialize($config);
            $this->image_lib->resize();

            $data = array(
                'image3' => $upload_data['file_name']
            );

            
            if($this->debit_m->adding_image($data,$product_id))
                header('location:'.base_url().'product/update/'.$product_id.'?sai');
            else
                header('location:'.base_url().'product/update/'.$product_id.'?fai');
        } else {
            header('location:'.base_url().'product/update/'.$product_id.'?fai');
        }
    }

      public function add_image4(){

        $product_id = $this->input->post('product_id');

        $filename = 'img'.auto_id();

        $config['upload_path'] = '../files/images/product';
        $config['file_name'] = $filename;
        $config['allowed_types'] = 'jpeg|jpg|png';
        $config['max_size'] = '2048';
        $config['max_width']  = '3000';
        $config['max_height']  = '3000';

        $this->load->library('upload', $config);

        if ($this->upload->do_upload())
        {
            $upload_data = $this->upload->data();

            $this->data['image'] = $upload_data['file_name'];

            $config = null;
            $config['image_library'] = 'gd2';
            $config['source_image'] = '../files/images/product/'.$upload_data['file_name'];
            $config['create_thumb'] = FALSE;
            $config['maintain_ratio'] = TRUE;
            $config['width']     = 800;
            $config['height']   = 800;

            $this->load->library('image_lib');
            $this->image_lib->initialize($config);
            $this->image_lib->resize();

            $config = null;
            $config['image_library'] = 'gd2';
            $config['source_image'] = '../files/images/product/'.$upload_data['file_name'];
            $config['new_image'] = '../files/images/product/thumb/'.$upload_data['file_name'];
            $config['create_thumb'] = FALSE;
            $config['maintain_ratio'] = TRUE;
            $config['width']     = 200;
            $config['height']   = 200;

            $this->image_lib->initialize($config);
            $this->image_lib->resize();

            $data = array(
                'image4' => $upload_data['file_name']
            );

            
            if($this->debit_m->adding_image($data,$product_id))
                header('location:'.base_url().'product/update/'.$product_id.'?sai');
            else
                header('location:'.base_url().'product/update/'.$product_id.'?fai');
        } else {
            header('location:'.base_url().'product/update/'.$product_id.'?fai');
        }
    }

       public function add_image5(){

        $product_id = $this->input->post('product_id');

        $filename = 'img'.auto_id();

        $config['upload_path'] = '../files/images/product';
        $config['file_name'] = $filename;
        $config['allowed_types'] = 'jpeg|jpg|png';
        $config['max_size'] = '2048';
        $config['max_width']  = '3000';
        $config['max_height']  = '3000';

        $this->load->library('upload', $config);

        if ($this->upload->do_upload())
        {
            $upload_data = $this->upload->data();

            $this->data['image'] = $upload_data['file_name'];

            $config = null;
            $config['image_library'] = 'gd2';
            $config['source_image'] = '../files/images/product/'.$upload_data['file_name'];
            $config['create_thumb'] = FALSE;
            $config['maintain_ratio'] = TRUE;
            $config['width']     = 800;
            $config['height']   = 800;

            $this->load->library('image_lib');
            $this->image_lib->initialize($config);
            $this->image_lib->resize();

            $config = null;
            $config['image_library'] = 'gd2';
            $config['source_image'] = '../files/images/product/'.$upload_data['file_name'];
            $config['new_image'] = '../files/images/product/thumb/'.$upload_data['file_name'];
            $config['create_thumb'] = FALSE;
            $config['maintain_ratio'] = TRUE;
            $config['width']     = 200;
            $config['height']   = 200;

            $this->image_lib->initialize($config);
            $this->image_lib->resize();

            $data = array(
                'image5' => $upload_data['file_name']
            );

            
            if($this->debit_m->adding_image($data,$product_id))
                header('location:'.base_url().'product/update/'.$product_id.'?sai');
            else
                header('location:'.base_url().'product/update/'.$product_id.'?fai');
        } else {
            header('location:'.base_url().'product/update/'.$product_id.'?fai');
        }
    }

    public function save_change(){
        $data = array(
            'name' => clean_str($this->input->post('name')),
            'deskripsi' =>  clean_str($this->input->post('deskripsi')),
            'price' => clean_str($this->input->post('price')),
            'special_price' => clean_str($this->input->post('special_price')),
            'weight' => clean_str($this->input->post('berat')),
            'category_id' => clean_str($this->input->post('select_category')),
            'sub_category_id' => clean_str($this->input->post('select_sub_category')),
            'collection' => clean_str($this->input->post('collection'))
            
        );

        $id = clean_str($this->input->post('product_id'));
        $res = $this->debit_m->change($id, $data);
        header('location:'.base_url().'product?'.($res ? 'su' : 'fu'));
    }

    public function update_stock(){
        $product_id = clean_str($this->input->post('product_id'));

        $product_detail = $this->debit_m->get_stock($product_id);
        $res = true;
        if($product_detail != ''){
            foreach($product_detail as $row){
                $stock = $this->input->post('s_'.$row->pdetail_id);
                if($stock != $row->stock) {
                    if(!$this->debit_m->change_stock($row->pdetail_id, array('stock' => $stock))){
                        $res = false;
                    }
                }
            }
        }
        header('location:'.base_url().'product/update/'.$product_id.'?'.($res ? 'su' : 'fu'));
    }

    public function drop(){
        $data_delete = $this->input->post('data_delete');

        $data_delete = explode(',', $data_delete);
        $res = true;
        foreach($data_delete as $id){
            if(!$this->debit_m->del($id)){
                $res = false;
            }
        }
        header('location:'.base_url().'product?'.($res ? 'sd' : 'fd'));
    }

    public function drop_image(){
        $product_id = $this->uri->segment(4);

        $data = array(
                'image1' => ''
            );

        if($this->debit_m->adding_image($data,$product_id))
        {
            header('location:'.base_url().'product/update/'.$product_id.'?'.($res ? 'sdi' : 'fdi'));
        }
        
    }

    public function drop_image2(){
        $product_id = $this->uri->segment(4);

        $data = array(
                'image2' => ''
            );

        if($this->debit_m->adding_image($data,$product_id))
        {
            header('location:'.base_url().'product/update/'.$product_id.'?'.($res ? 'sdi' : 'fdi'));
        }
        
    }

    public function drop_image3(){
        $product_id = $this->uri->segment(4);

        $data = array(
                'image3' => ''
            );

        if($this->debit_m->adding_image($data,$product_id))
        {
            header('location:'.base_url().'product/update/'.$product_id.'?'.($res ? 'sdi' : 'fdi'));
        }
        
    }

    public function drop_image4(){
        $product_id = $this->uri->segment(4);

        $data = array(
                'image4' => ''
            );

        if($this->debit_m->adding_image($data,$product_id))
        {
            header('location:'.base_url().'product/update/'.$product_id.'?'.($res ? 'sdi' : 'fdi'));
        }
        
    }
       public function drop_image5(){
        $product_id = $this->uri->segment(4);

        $data = array(
                'image5' => ''
            );

        if($this->debit_m->adding_image($data,$product_id))
        {
            header('location:'.base_url().'product/update/'.$product_id.'?'.($res ? 'sdi' : 'fdi'));
        }
        
    }

}
