<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2014-08-27 02:08:19 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\Galaxia-Store\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-08-27 02:08:42 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
ERROR - 2014-08-27 02:08:56 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\Galaxia-Store\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-08-27 02:08:56 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
ERROR - 2014-08-27 02:11:02 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\Galaxia-Store\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-08-27 02:11:09 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 100
ERROR - 2014-08-27 02:11:09 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 100
ERROR - 2014-08-27 02:11:17 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 100
ERROR - 2014-08-27 02:11:17 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 100
ERROR - 2014-08-27 02:11:20 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 100
ERROR - 2014-08-27 02:11:20 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 100
ERROR - 2014-08-27 02:11:28 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 100
ERROR - 2014-08-27 02:11:28 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 100
ERROR - 2014-08-27 02:12:02 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 100
ERROR - 2014-08-27 02:12:02 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 100
ERROR - 2014-08-27 02:12:11 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 100
ERROR - 2014-08-27 02:12:11 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 100
ERROR - 2014-08-27 02:14:57 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
ERROR - 2014-08-27 02:15:10 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 100
ERROR - 2014-08-27 02:15:10 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 100
ERROR - 2014-08-27 02:16:04 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 100
ERROR - 2014-08-27 02:16:04 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 100
ERROR - 2014-08-27 02:18:16 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 100
ERROR - 2014-08-27 02:18:16 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 100
ERROR - 2014-08-27 02:18:20 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 100
ERROR - 2014-08-27 02:18:20 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 100
ERROR - 2014-08-27 02:18:42 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 100
ERROR - 2014-08-27 02:18:42 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 100
ERROR - 2014-08-27 02:18:43 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\Galaxia-Store\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-08-27 02:18:48 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 100
ERROR - 2014-08-27 02:18:48 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 100
ERROR - 2014-08-27 02:18:56 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 100
ERROR - 2014-08-27 02:18:56 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 100
ERROR - 2014-08-27 02:19:00 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 100
ERROR - 2014-08-27 02:19:00 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 100
ERROR - 2014-08-27 02:19:03 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 100
ERROR - 2014-08-27 02:19:03 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 100
ERROR - 2014-08-27 02:37:39 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 101
ERROR - 2014-08-27 02:37:39 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 101
ERROR - 2014-08-27 02:38:04 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
ERROR - 2014-08-27 02:38:14 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 101
ERROR - 2014-08-27 02:38:14 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 101
ERROR - 2014-08-27 02:39:21 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 104
ERROR - 2014-08-27 02:39:21 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 104
ERROR - 2014-08-27 02:39:30 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 105
ERROR - 2014-08-27 02:39:30 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 105
ERROR - 2014-08-27 02:39:41 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 105
ERROR - 2014-08-27 02:39:41 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 105
ERROR - 2014-08-27 02:41:17 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 106
ERROR - 2014-08-27 02:41:17 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 106
ERROR - 2014-08-27 02:41:26 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
ERROR - 2014-08-27 02:41:36 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 106
ERROR - 2014-08-27 02:41:36 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 106
ERROR - 2014-08-27 02:42:22 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 106
ERROR - 2014-08-27 02:42:22 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 106
ERROR - 2014-08-27 02:42:37 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 106
ERROR - 2014-08-27 02:42:37 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 106
ERROR - 2014-08-27 02:43:40 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 106
ERROR - 2014-08-27 02:43:40 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 106
ERROR - 2014-08-27 02:43:56 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 106
ERROR - 2014-08-27 02:43:56 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 106
ERROR - 2014-08-27 02:44:09 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 106
ERROR - 2014-08-27 02:44:09 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 106
ERROR - 2014-08-27 02:52:13 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 106
ERROR - 2014-08-27 02:52:13 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 106
ERROR - 2014-08-27 02:55:26 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 106
ERROR - 2014-08-27 02:55:26 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 106
ERROR - 2014-08-27 03:00:41 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
ERROR - 2014-08-27 03:01:01 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 106
ERROR - 2014-08-27 03:01:01 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 106
ERROR - 2014-08-27 03:01:35 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 106
ERROR - 2014-08-27 03:01:35 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 106
ERROR - 2014-08-27 03:01:46 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 106
ERROR - 2014-08-27 03:01:46 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 106
ERROR - 2014-08-27 03:02:52 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
ERROR - 2014-08-27 03:03:04 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
ERROR - 2014-08-27 03:03:19 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 106
ERROR - 2014-08-27 03:03:19 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 106
ERROR - 2014-08-27 03:03:36 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
ERROR - 2014-08-27 03:04:29 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
ERROR - 2014-08-27 03:04:49 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
ERROR - 2014-08-27 03:04:54 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
ERROR - 2014-08-27 03:05:13 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
ERROR - 2014-08-27 03:07:29 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 106
ERROR - 2014-08-27 03:07:29 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 106
ERROR - 2014-08-27 03:07:43 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 106
ERROR - 2014-08-27 03:07:43 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 106
ERROR - 2014-08-27 03:07:46 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 106
ERROR - 2014-08-27 03:07:46 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 106
ERROR - 2014-08-27 03:34:25 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
ERROR - 2014-08-27 03:34:34 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 107
ERROR - 2014-08-27 03:34:34 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 107
ERROR - 2014-08-27 03:35:16 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 107
ERROR - 2014-08-27 03:35:16 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 107
ERROR - 2014-08-27 03:35:24 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 107
ERROR - 2014-08-27 03:35:24 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 107
ERROR - 2014-08-27 03:36:53 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 116
ERROR - 2014-08-27 03:36:53 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 116
ERROR - 2014-08-27 03:37:10 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 116
ERROR - 2014-08-27 03:37:10 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 116
ERROR - 2014-08-27 03:37:43 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 116
ERROR - 2014-08-27 03:37:43 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 116
ERROR - 2014-08-27 03:37:47 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 116
ERROR - 2014-08-27 03:37:47 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 116
ERROR - 2014-08-27 03:38:01 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 116
ERROR - 2014-08-27 03:38:01 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 116
ERROR - 2014-08-27 03:38:04 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 116
ERROR - 2014-08-27 03:38:04 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 116
ERROR - 2014-08-27 03:38:13 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 116
ERROR - 2014-08-27 03:38:13 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 116
ERROR - 2014-08-27 03:39:47 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 121
ERROR - 2014-08-27 03:39:47 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 121
ERROR - 2014-08-27 03:40:12 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 121
ERROR - 2014-08-27 03:40:12 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 121
ERROR - 2014-08-27 03:40:18 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 121
ERROR - 2014-08-27 03:40:18 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 121
ERROR - 2014-08-27 03:40:45 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 121
ERROR - 2014-08-27 03:40:45 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 121
ERROR - 2014-08-27 03:41:11 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 121
ERROR - 2014-08-27 03:41:11 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 121
ERROR - 2014-08-27 03:41:16 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 121
ERROR - 2014-08-27 03:41:16 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 121
ERROR - 2014-08-27 03:41:18 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 121
ERROR - 2014-08-27 03:41:18 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 121
ERROR - 2014-08-27 03:44:10 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 137
ERROR - 2014-08-27 03:44:10 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 137
ERROR - 2014-08-27 03:44:17 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 137
ERROR - 2014-08-27 03:44:17 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 137
ERROR - 2014-08-27 03:44:27 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 137
ERROR - 2014-08-27 03:44:27 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 137
ERROR - 2014-08-27 03:44:55 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 137
ERROR - 2014-08-27 03:44:55 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 137
ERROR - 2014-08-27 03:45:07 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 139
ERROR - 2014-08-27 03:45:07 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 139
ERROR - 2014-08-27 03:45:19 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 139
ERROR - 2014-08-27 03:45:19 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 139
ERROR - 2014-08-27 03:46:59 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 139
ERROR - 2014-08-27 03:46:59 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 139
ERROR - 2014-08-27 03:56:28 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 139
ERROR - 2014-08-27 03:56:28 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 139
ERROR - 2014-08-27 03:56:32 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 139
ERROR - 2014-08-27 03:56:32 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 139
ERROR - 2014-08-27 04:25:34 --> 404 Page Not Found --> template
ERROR - 2014-08-27 04:25:44 --> 404 Page Not Found --> template
ERROR - 2014-08-27 04:26:07 --> 404 Page Not Found --> template
ERROR - 2014-08-27 04:26:22 --> 404 Page Not Found --> template
ERROR - 2014-08-27 04:26:34 --> 404 Page Not Found --> template
ERROR - 2014-08-27 04:26:38 --> 404 Page Not Found --> template
ERROR - 2014-08-27 04:26:40 --> 404 Page Not Found --> template
ERROR - 2014-08-27 04:32:48 --> 404 Page Not Found --> template
ERROR - 2014-08-27 04:50:50 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 139
ERROR - 2014-08-27 04:50:50 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 139
ERROR - 2014-08-27 05:23:30 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
ERROR - 2014-08-27 05:23:34 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 139
ERROR - 2014-08-27 05:23:34 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 139
ERROR - 2014-08-27 05:23:43 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 139
ERROR - 2014-08-27 05:23:43 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 139
ERROR - 2014-08-27 06:28:11 --> Severity: Notice  --> Undefined property: stdClass::$amount_shipping_cost C:\wamp\www\Galaxia-Store\application\views\checkout.php 32
ERROR - 2014-08-27 06:28:22 --> Severity: Notice  --> Undefined property: stdClass::$amount_shipping_cost C:\wamp\www\Galaxia-Store\application\views\checkout.php 32
ERROR - 2014-08-27 06:28:37 --> Severity: Notice  --> Undefined property: stdClass::$amount_shipping_cost C:\wamp\www\Galaxia-Store\application\views\checkout.php 32
ERROR - 2014-08-27 06:29:33 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 139
ERROR - 2014-08-27 06:29:33 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 139
ERROR - 2014-08-27 06:29:38 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 139
ERROR - 2014-08-27 06:29:38 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 139
ERROR - 2014-08-27 06:30:05 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 139
ERROR - 2014-08-27 06:30:05 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 139
ERROR - 2014-08-27 06:33:16 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 141
ERROR - 2014-08-27 06:33:16 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 141
ERROR - 2014-08-27 06:33:18 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 141
ERROR - 2014-08-27 06:33:18 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 141
ERROR - 2014-08-27 06:35:27 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 141
ERROR - 2014-08-27 06:35:27 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 141
ERROR - 2014-08-27 06:37:40 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 141
ERROR - 2014-08-27 06:37:40 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 141
ERROR - 2014-08-27 06:38:51 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 141
ERROR - 2014-08-27 06:38:51 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 141
ERROR - 2014-08-27 06:39:03 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
ERROR - 2014-08-27 06:39:12 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 141
ERROR - 2014-08-27 06:39:12 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 141
ERROR - 2014-08-27 06:39:20 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 141
ERROR - 2014-08-27 06:39:20 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 141
ERROR - 2014-08-27 06:39:21 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 141
ERROR - 2014-08-27 06:39:21 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 141
ERROR - 2014-08-27 06:39:31 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 141
ERROR - 2014-08-27 06:39:31 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 141
ERROR - 2014-08-27 06:40:08 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
ERROR - 2014-08-27 06:40:16 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 141
ERROR - 2014-08-27 06:40:16 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 141
ERROR - 2014-08-27 06:40:31 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 141
ERROR - 2014-08-27 06:40:31 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 141
ERROR - 2014-08-27 06:40:52 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 141
ERROR - 2014-08-27 06:40:52 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 141
ERROR - 2014-08-27 06:41:07 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 141
ERROR - 2014-08-27 06:41:07 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 141
ERROR - 2014-08-27 06:41:44 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 141
ERROR - 2014-08-27 06:41:44 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 141
ERROR - 2014-08-27 06:42:10 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 141
ERROR - 2014-08-27 06:42:10 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 141
ERROR - 2014-08-27 06:42:12 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 141
ERROR - 2014-08-27 06:42:12 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 141
ERROR - 2014-08-27 06:42:16 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 141
ERROR - 2014-08-27 06:42:16 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 141
ERROR - 2014-08-27 06:42:26 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
ERROR - 2014-08-27 06:42:34 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 141
ERROR - 2014-08-27 06:42:34 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 141
ERROR - 2014-08-27 06:42:41 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 141
ERROR - 2014-08-27 06:42:41 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 141
ERROR - 2014-08-27 06:42:52 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 141
ERROR - 2014-08-27 06:42:52 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 141
ERROR - 2014-08-27 06:43:15 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 141
ERROR - 2014-08-27 06:43:16 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 141
ERROR - 2014-08-27 06:43:32 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 141
ERROR - 2014-08-27 06:43:32 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 141
ERROR - 2014-08-27 06:43:49 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 141
ERROR - 2014-08-27 06:43:49 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 141
ERROR - 2014-08-27 06:47:53 --> 404 Page Not Found --> template
ERROR - 2014-08-27 06:48:34 --> 404 Page Not Found --> template
ERROR - 2014-08-27 06:57:11 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
ERROR - 2014-08-27 07:05:01 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 141
ERROR - 2014-08-27 07:05:01 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 141
ERROR - 2014-08-27 07:07:12 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 141
ERROR - 2014-08-27 07:07:12 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 141
ERROR - 2014-08-27 07:07:19 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 141
ERROR - 2014-08-27 07:07:19 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 141
ERROR - 2014-08-27 07:28:07 --> 404 Page Not Found --> template
ERROR - 2014-08-27 07:29:09 --> 404 Page Not Found --> template
ERROR - 2014-08-27 07:29:30 --> 404 Page Not Found --> template
ERROR - 2014-08-27 07:32:29 --> 404 Page Not Found --> template
ERROR - 2014-08-27 07:34:45 --> 404 Page Not Found --> cart/check_voucher_code
ERROR - 2014-08-27 07:34:47 --> 404 Page Not Found --> cart/check_voucher_code
ERROR - 2014-08-27 07:46:12 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 141
ERROR - 2014-08-27 07:46:12 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 141
ERROR - 2014-08-27 07:53:14 --> 404 Page Not Found --> template
ERROR - 2014-08-27 07:53:56 --> 404 Page Not Found --> template
ERROR - 2014-08-27 07:54:18 --> 404 Page Not Found --> template
ERROR - 2014-08-27 07:55:21 --> 404 Page Not Found --> template
ERROR - 2014-08-27 07:56:12 --> 404 Page Not Found --> template
ERROR - 2014-08-27 07:56:40 --> 404 Page Not Found --> template
ERROR - 2014-08-27 07:56:52 --> 404 Page Not Found --> template
ERROR - 2014-08-27 07:57:01 --> 404 Page Not Found --> template
ERROR - 2014-08-27 07:57:12 --> 404 Page Not Found --> template
ERROR - 2014-08-27 07:57:25 --> 404 Page Not Found --> template
ERROR - 2014-08-27 07:57:28 --> 404 Page Not Found --> template
ERROR - 2014-08-27 07:57:53 --> 404 Page Not Found --> template
ERROR - 2014-08-27 07:58:11 --> 404 Page Not Found --> template
ERROR - 2014-08-27 07:58:21 --> 404 Page Not Found --> template
ERROR - 2014-08-27 07:58:41 --> 404 Page Not Found --> template
ERROR - 2014-08-27 07:59:17 --> 404 Page Not Found --> template
ERROR - 2014-08-27 08:01:03 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 141
ERROR - 2014-08-27 08:01:03 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 141
ERROR - 2014-08-27 08:01:06 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 141
ERROR - 2014-08-27 08:01:06 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 141
ERROR - 2014-08-27 08:03:21 --> 404 Page Not Found --> cart/check_voucher_code1asa
ERROR - 2014-08-27 08:03:39 --> 404 Page Not Found --> cart/check_voucher_code1asa
ERROR - 2014-08-27 08:04:02 --> 404 Page Not Found --> cart/check_voucher_code1asa
ERROR - 2014-08-27 08:04:03 --> 404 Page Not Found --> cart/check_voucher_code1asa
ERROR - 2014-08-27 08:04:03 --> 404 Page Not Found --> cart/check_voucher_code1asa
ERROR - 2014-08-27 08:04:04 --> 404 Page Not Found --> cart/check_voucher_code1asa
ERROR - 2014-08-27 08:04:05 --> 404 Page Not Found --> template
ERROR - 2014-08-27 08:04:14 --> 404 Page Not Found --> template
ERROR - 2014-08-27 08:04:31 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 141
ERROR - 2014-08-27 08:04:31 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 141
ERROR - 2014-08-27 08:04:36 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 141
ERROR - 2014-08-27 08:04:36 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 141
ERROR - 2014-08-27 08:04:42 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 141
ERROR - 2014-08-27 08:04:42 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 141
ERROR - 2014-08-27 08:29:01 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 141
ERROR - 2014-08-27 08:29:01 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 141
ERROR - 2014-08-27 08:29:05 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 141
ERROR - 2014-08-27 08:29:05 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 141
ERROR - 2014-08-27 08:37:32 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 141
ERROR - 2014-08-27 08:37:32 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 141
ERROR - 2014-08-27 08:37:36 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 141
ERROR - 2014-08-27 08:37:36 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 141
