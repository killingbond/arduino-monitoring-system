<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-11-16 14:15:12 --> Severity: Warning  --> mysqli_connect(): (HY000/1045): Access denied for user 'ozantcom_wassup'@'localhost' (using password: YES) C:\xampp\htdocs\wassuphaters.com\w4zzup\system\database\drivers\mysqli\mysqli_driver.php 76
ERROR - 2015-11-16 14:15:12 --> Unable to connect to the database
ERROR - 2015-11-16 14:21:23 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_category\edit_category.php 37
ERROR - 2015-11-16 14:21:23 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_category\edit_category.php 43
ERROR - 2015-11-16 14:33:23 --> Query error: Unknown column 'category' in 'where clause'
ERROR - 2015-11-16 14:34:10 --> Severity: Notice  --> Undefined property: stdClass::$category C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_category\category.php 86
ERROR - 2015-11-16 14:34:10 --> Severity: Notice  --> Undefined property: stdClass::$category C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_category\category.php 86
ERROR - 2015-11-16 14:34:10 --> Severity: Notice  --> Undefined property: stdClass::$category C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_category\category.php 86
ERROR - 2015-11-16 14:34:10 --> Severity: Notice  --> Undefined property: stdClass::$category C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_category\category.php 86
ERROR - 2015-11-16 14:34:10 --> Severity: Notice  --> Undefined property: stdClass::$category C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_category\category.php 86
ERROR - 2015-11-16 14:34:10 --> Severity: Notice  --> Undefined property: stdClass::$category C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_category\category.php 86
ERROR - 2015-11-16 14:34:10 --> Severity: Notice  --> Undefined property: stdClass::$category C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_category\category.php 86
ERROR - 2015-11-16 14:34:10 --> Severity: Notice  --> Undefined property: stdClass::$category C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_category\category.php 86
ERROR - 2015-11-16 14:34:10 --> Severity: Notice  --> Undefined property: stdClass::$category C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_category\category.php 86
ERROR - 2015-11-16 14:34:10 --> Severity: Notice  --> Undefined property: stdClass::$category C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_category\category.php 86
ERROR - 2015-11-16 14:34:13 --> Severity: Notice  --> Undefined property: stdClass::$category C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_category\category.php 86
ERROR - 2015-11-16 14:34:13 --> Severity: Notice  --> Undefined property: stdClass::$category C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_category\category.php 86
ERROR - 2015-11-16 14:34:13 --> Severity: Notice  --> Undefined property: stdClass::$category C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_category\category.php 86
ERROR - 2015-11-16 14:34:13 --> Severity: Notice  --> Undefined property: stdClass::$category C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_category\category.php 86
ERROR - 2015-11-16 14:34:13 --> Severity: Notice  --> Undefined property: stdClass::$category C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_category\category.php 86
ERROR - 2015-11-16 14:34:13 --> Severity: Notice  --> Undefined property: stdClass::$category C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_category\category.php 86
ERROR - 2015-11-16 14:34:13 --> Severity: Notice  --> Undefined property: stdClass::$category C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_category\category.php 86
ERROR - 2015-11-16 14:34:13 --> Severity: Notice  --> Undefined property: stdClass::$category C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_category\category.php 86
ERROR - 2015-11-16 14:34:13 --> Severity: Notice  --> Undefined property: stdClass::$category C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_category\category.php 86
ERROR - 2015-11-16 14:34:13 --> Severity: Notice  --> Undefined property: stdClass::$category C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_category\category.php 86
ERROR - 2015-11-16 14:34:15 --> Severity: Notice  --> Undefined property: stdClass::$category C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_category\category.php 86
ERROR - 2015-11-16 14:34:15 --> Severity: Notice  --> Undefined property: stdClass::$category C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_category\category.php 86
ERROR - 2015-11-16 14:34:15 --> Severity: Notice  --> Undefined property: stdClass::$category C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_category\category.php 86
ERROR - 2015-11-16 14:34:15 --> Severity: Notice  --> Undefined property: stdClass::$category C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_category\category.php 86
ERROR - 2015-11-16 14:34:15 --> Severity: Notice  --> Undefined property: stdClass::$category C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_category\category.php 86
ERROR - 2015-11-16 14:34:15 --> Severity: Notice  --> Undefined property: stdClass::$category C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_category\category.php 86
ERROR - 2015-11-16 14:34:15 --> Severity: Notice  --> Undefined property: stdClass::$category C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_category\category.php 86
ERROR - 2015-11-16 14:34:15 --> Severity: Notice  --> Undefined property: stdClass::$category C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_category\category.php 86
ERROR - 2015-11-16 14:34:15 --> Severity: Notice  --> Undefined property: stdClass::$category C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_category\category.php 86
ERROR - 2015-11-16 14:34:15 --> Severity: Notice  --> Undefined property: stdClass::$category C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_category\category.php 86
ERROR - 2015-11-16 14:40:24 --> 404 Page Not Found --> product_sub_category/index
