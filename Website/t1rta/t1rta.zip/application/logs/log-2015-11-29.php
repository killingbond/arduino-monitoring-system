<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-11-29 04:05:48 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-29 04:05:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-29 04:05:48 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-29 04:05:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-29 04:05:48 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-29 04:05:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-29 04:05:48 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-29 04:05:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-29 04:05:48 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-29 04:05:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-29 04:05:49 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-29 04:05:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-29 04:05:49 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-29 04:05:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-29 04:05:49 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-29 04:05:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-29 04:05:49 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-29 04:05:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-29 04:05:49 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-29 04:05:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-29 04:05:49 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-29 04:05:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-29 04:05:49 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-29 04:05:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-29 04:05:49 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-29 04:05:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-29 04:05:49 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-29 04:05:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-29 04:05:49 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-29 04:05:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-29 04:05:49 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-29 04:05:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-29 04:05:49 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-29 04:05:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-29 04:05:49 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-29 04:05:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-29 04:05:49 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-29 04:05:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-29 04:05:49 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-29 04:05:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-29 04:05:49 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-29 04:05:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-29 04:05:49 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-29 04:05:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-29 04:05:49 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-29 04:05:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-29 04:05:49 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-29 04:05:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-29 04:05:49 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-29 04:05:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-29 04:05:49 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-29 04:05:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-29 04:08:25 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-29 04:08:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-29 04:08:25 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-29 04:08:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-29 04:08:25 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-29 04:08:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-29 04:08:26 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-29 04:08:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-29 04:08:26 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-29 04:08:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-29 04:08:26 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-29 04:08:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-29 04:08:26 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-29 04:08:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-29 04:08:26 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-29 04:08:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-29 04:08:26 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-29 04:08:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-29 04:08:26 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-29 04:08:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-29 04:08:26 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-29 04:08:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-29 04:08:26 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-29 04:08:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-29 04:08:26 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-29 04:08:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-29 04:08:26 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-29 04:08:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-29 04:08:26 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-29 04:08:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-29 04:08:26 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-29 04:08:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-29 04:08:26 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-29 04:08:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-29 04:08:26 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-29 04:08:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-29 04:08:26 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-29 04:08:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-29 04:08:26 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-29 04:08:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-29 04:08:26 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-29 04:08:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-29 04:08:26 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-29 04:08:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-29 04:08:26 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-29 04:08:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-29 04:08:26 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-29 04:08:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-29 04:08:26 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-29 04:08:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-29 04:08:26 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-29 04:08:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-29 04:15:50 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-29 04:15:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-29 04:15:50 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-29 04:15:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-29 04:15:50 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-29 04:15:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-29 04:15:50 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-29 04:15:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-29 04:15:50 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-29 04:15:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-29 04:15:51 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-29 04:15:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-29 04:15:51 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-29 04:15:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-29 04:15:51 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-29 04:15:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-29 04:15:51 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-29 04:15:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-29 04:15:51 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-29 04:15:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-29 04:15:51 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-29 04:15:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-29 04:15:51 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-29 04:15:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-29 04:15:51 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-29 04:15:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-29 04:15:51 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-29 04:15:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-29 04:15:51 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-29 04:15:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-29 04:15:51 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-29 04:15:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-29 04:15:51 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-29 04:15:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-29 04:15:51 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-29 04:15:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-29 04:15:51 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-29 04:15:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-29 04:15:51 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-29 04:15:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-29 04:15:51 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-29 04:15:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-29 04:15:51 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-29 04:15:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-29 04:15:51 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-29 04:15:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-29 04:15:51 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-29 04:15:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-29 04:15:51 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-29 04:15:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-29 04:15:51 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-29 04:15:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
