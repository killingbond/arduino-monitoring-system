<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-10-06 11:31:00 --> Severity: Warning  --> escapeshellarg() has been disabled for security reasons /home/ozantcom/public_html/wassuphaters.com/w4zzup/system/libraries/Upload.php 1066
ERROR - 2015-10-06 11:31:46 --> Severity: Warning  --> escapeshellarg() has been disabled for security reasons /home/ozantcom/public_html/wassuphaters.com/w4zzup/system/libraries/Upload.php 1066
