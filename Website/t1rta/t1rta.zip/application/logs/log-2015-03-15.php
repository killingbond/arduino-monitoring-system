<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-03-15 10:28:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-03-15 10:28:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-15 10:28:03 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-15 10:28:03 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-15 10:28:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-15 10:28:10 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-15 10:28:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-15 10:28:14 --> 404 Page Not Found --> esgotado
ERROR - 2015-03-15 10:28:15 --> 404 Page Not Found --> esgotado
ERROR - 2015-03-15 10:28:15 --> 404 Page Not Found --> esgotado
ERROR - 2015-03-15 10:28:15 --> 404 Page Not Found --> esgotado
ERROR - 2015-03-15 10:28:15 --> 404 Page Not Found --> esgotado
ERROR - 2015-03-15 10:28:15 --> 404 Page Not Found --> esgotado
ERROR - 2015-03-15 10:28:15 --> 404 Page Not Found --> esgotado
ERROR - 2015-03-15 10:28:15 --> 404 Page Not Found --> esgotado
ERROR - 2015-03-15 10:28:15 --> 404 Page Not Found --> esgotado
ERROR - 2015-03-15 10:28:15 --> 404 Page Not Found --> esgotado
ERROR - 2015-03-15 10:28:15 --> 404 Page Not Found --> esgotado
ERROR - 2015-03-15 10:28:15 --> 404 Page Not Found --> esgotado
ERROR - 2015-03-15 10:28:15 --> 404 Page Not Found --> esgotado
ERROR - 2015-03-15 10:28:15 --> 404 Page Not Found --> esgotado
ERROR - 2015-03-15 10:28:15 --> 404 Page Not Found --> esgotado
ERROR - 2015-03-15 10:28:15 --> 404 Page Not Found --> esgotado
ERROR - 2015-03-15 10:28:15 --> 404 Page Not Found --> esgotado
ERROR - 2015-03-15 10:28:15 --> 404 Page Not Found --> esgotado
ERROR - 2015-03-15 10:28:15 --> 404 Page Not Found --> esgotado
ERROR - 2015-03-15 10:28:15 --> 404 Page Not Found --> esgotado
ERROR - 2015-03-15 10:28:15 --> 404 Page Not Found --> esgotado
ERROR - 2015-03-15 10:28:15 --> 404 Page Not Found --> esgotado
ERROR - 2015-03-15 10:28:15 --> 404 Page Not Found --> esgotado
ERROR - 2015-03-15 10:28:15 --> 404 Page Not Found --> esgotado
ERROR - 2015-03-15 10:28:15 --> 404 Page Not Found --> esgotado
ERROR - 2015-03-15 10:28:15 --> 404 Page Not Found --> esgotado
ERROR - 2015-03-15 10:28:15 --> 404 Page Not Found --> esgotado
ERROR - 2015-03-15 10:28:16 --> 404 Page Not Found --> esgotado
ERROR - 2015-03-15 10:28:16 --> 404 Page Not Found --> Esgotado
ERROR - 2015-03-15 10:28:18 --> 404 Page Not Found --> Esgotado
ERROR - 2015-03-15 10:28:23 --> 404 Page Not Found --> esgotado
ERROR - 2015-03-15 10:28:24 --> 404 Page Not Found --> esgotado
ERROR - 2015-03-15 10:33:44 --> 404 Page Not Found --> esgotado
ERROR - 2015-03-15 10:33:44 --> 404 Page Not Found --> esgotado
ERROR - 2015-03-15 10:33:44 --> 404 Page Not Found --> esgotado
ERROR - 2015-03-15 10:33:44 --> 404 Page Not Found --> esgotado
ERROR - 2015-03-15 10:33:44 --> 404 Page Not Found --> esgotado
ERROR - 2015-03-15 10:33:44 --> 404 Page Not Found --> esgotado
ERROR - 2015-03-15 10:38:27 --> 404 Page Not Found --> esgotado
ERROR - 2015-03-15 10:41:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-15 10:41:53 --> 404 Page Not Found --> template
ERROR - 2015-03-15 10:41:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-15 10:41:56 --> 404 Page Not Found --> template
ERROR - 2015-03-15 10:42:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-15 10:42:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-15 10:42:05 --> 404 Page Not Found --> template
ERROR - 2015-03-15 10:42:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-15 10:42:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-15 10:42:15 --> 404 Page Not Found --> template
