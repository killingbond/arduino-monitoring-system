<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-06-18 03:09:14 --> 404 Page Not Found --> template
ERROR - 2015-06-18 03:09:16 --> 404 Page Not Found --> template
