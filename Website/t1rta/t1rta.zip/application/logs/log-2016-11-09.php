<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2016-11-09 00:50:14 --> 404 Page Not Found --> WaterFlow
ERROR - 2016-11-09 00:50:45 --> 404 Page Not Found --> WaterFlow
ERROR - 2016-11-09 00:56:08 --> Query error: Table 'db_tirta_dahaga.notification' doesn't exist
ERROR - 2016-11-09 00:56:20 --> Query error: Table 'db_tirta_dahaga.notification' doesn't exist
ERROR - 2016-11-09 00:59:03 --> Query error: Table 'db_tirta_dahaga.notification' doesn't exist
ERROR - 2016-11-09 00:59:04 --> Query error: Table 'db_tirta_dahaga.notification' doesn't exist
ERROR - 2016-11-09 00:59:04 --> Query error: Table 'db_tirta_dahaga.notification' doesn't exist
ERROR - 2016-11-09 00:59:04 --> Query error: Table 'db_tirta_dahaga.notification' doesn't exist
ERROR - 2016-11-09 00:59:04 --> Query error: Table 'db_tirta_dahaga.notification' doesn't exist
ERROR - 2016-11-09 00:59:04 --> Query error: Table 'db_tirta_dahaga.notification' doesn't exist
ERROR - 2016-11-09 00:59:04 --> Query error: Table 'db_tirta_dahaga.notification' doesn't exist
ERROR - 2016-11-09 00:59:05 --> Query error: Table 'db_tirta_dahaga.notification' doesn't exist
ERROR - 2016-11-09 01:00:27 --> Query error: Table 'db_tirta_dahaga.notification' doesn't exist
ERROR - 2016-11-09 01:00:27 --> Query error: Table 'db_tirta_dahaga.notification' doesn't exist
ERROR - 2016-11-09 01:00:28 --> Query error: Table 'db_tirta_dahaga.notification' doesn't exist
ERROR - 2016-11-09 01:00:28 --> Query error: Table 'db_tirta_dahaga.notification' doesn't exist
ERROR - 2016-11-09 01:00:28 --> Query error: Table 'db_tirta_dahaga.notification' doesn't exist
ERROR - 2016-11-09 01:00:28 --> Query error: Table 'db_tirta_dahaga.notification' doesn't exist
ERROR - 2016-11-09 01:00:28 --> Query error: Table 'db_tirta_dahaga.notification' doesn't exist
ERROR - 2016-11-09 01:00:29 --> Query error: Table 'db_tirta_dahaga.notification' doesn't exist
ERROR - 2016-11-09 01:00:29 --> Query error: Table 'db_tirta_dahaga.notification' doesn't exist
ERROR - 2016-11-09 01:00:29 --> Query error: Table 'db_tirta_dahaga.notification' doesn't exist
ERROR - 2016-11-09 01:00:29 --> Query error: Table 'db_tirta_dahaga.notification' doesn't exist
ERROR - 2016-11-09 01:00:29 --> Query error: Table 'db_tirta_dahaga.notification' doesn't exist
ERROR - 2016-11-09 01:00:29 --> Query error: Table 'db_tirta_dahaga.notification' doesn't exist
ERROR - 2016-11-09 01:00:51 --> Query error: Table 'db_tirta_dahaga.notification' doesn't exist
ERROR - 2016-11-09 01:00:51 --> Query error: Table 'db_tirta_dahaga.notification' doesn't exist
ERROR - 2016-11-09 01:00:52 --> Query error: Table 'db_tirta_dahaga.notification' doesn't exist
ERROR - 2016-11-09 01:00:52 --> Query error: Table 'db_tirta_dahaga.notification' doesn't exist
ERROR - 2016-11-09 01:00:53 --> Query error: Table 'db_tirta_dahaga.notification' doesn't exist
ERROR - 2016-11-09 01:00:53 --> Query error: Table 'db_tirta_dahaga.notification' doesn't exist
ERROR - 2016-11-09 01:00:53 --> Query error: Table 'db_tirta_dahaga.notification' doesn't exist
ERROR - 2016-11-09 01:00:53 --> Query error: Table 'db_tirta_dahaga.notification' doesn't exist
ERROR - 2016-11-09 01:00:53 --> Query error: Table 'db_tirta_dahaga.notification' doesn't exist
ERROR - 2016-11-09 01:00:53 --> Query error: Table 'db_tirta_dahaga.notification' doesn't exist
ERROR - 2016-11-09 01:01:10 --> Query error: Table 'db_tirta_dahaga.notification' doesn't exist
ERROR - 2016-11-09 01:01:10 --> Query error: Table 'db_tirta_dahaga.notification' doesn't exist
ERROR - 2016-11-09 01:01:11 --> Query error: Table 'db_tirta_dahaga.notification' doesn't exist
ERROR - 2016-11-09 01:01:11 --> Query error: Table 'db_tirta_dahaga.notification' doesn't exist
ERROR - 2016-11-09 01:01:11 --> Query error: Table 'db_tirta_dahaga.notification' doesn't exist
ERROR - 2016-11-09 01:01:11 --> Query error: Table 'db_tirta_dahaga.notification' doesn't exist
ERROR - 2016-11-09 01:04:58 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 79
ERROR - 2016-11-09 01:04:58 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 92
ERROR - 2016-11-09 01:05:02 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 79
ERROR - 2016-11-09 01:05:02 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 92
ERROR - 2016-11-09 01:05:02 --> Query error: Table 'db_tirta_dahaga.statistic' doesn't exist
ERROR - 2016-11-09 01:07:27 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 79
ERROR - 2016-11-09 01:07:27 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 92
ERROR - 2016-11-09 01:07:27 --> Query error: Table 'db_tirta_dahaga.orderlist' doesn't exist
ERROR - 2016-11-09 01:07:27 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 79
ERROR - 2016-11-09 01:07:27 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 92
ERROR - 2016-11-09 01:07:27 --> Query error: Table 'db_tirta_dahaga.orderlist' doesn't exist
ERROR - 2016-11-09 01:07:27 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 79
ERROR - 2016-11-09 01:07:27 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 92
ERROR - 2016-11-09 01:07:28 --> Query error: Table 'db_tirta_dahaga.orderlist' doesn't exist
ERROR - 2016-11-09 01:07:28 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 79
ERROR - 2016-11-09 01:07:28 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 92
ERROR - 2016-11-09 01:07:28 --> Query error: Table 'db_tirta_dahaga.orderlist' doesn't exist
ERROR - 2016-11-09 01:07:28 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 79
ERROR - 2016-11-09 01:07:28 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 92
ERROR - 2016-11-09 01:07:28 --> Query error: Table 'db_tirta_dahaga.orderlist' doesn't exist
ERROR - 2016-11-09 01:07:28 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 79
ERROR - 2016-11-09 01:07:28 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 92
ERROR - 2016-11-09 01:07:28 --> Query error: Table 'db_tirta_dahaga.orderlist' doesn't exist
ERROR - 2016-11-09 01:07:28 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 79
ERROR - 2016-11-09 01:07:28 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 92
ERROR - 2016-11-09 01:07:28 --> Query error: Table 'db_tirta_dahaga.orderlist' doesn't exist
ERROR - 2016-11-09 01:07:28 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 79
ERROR - 2016-11-09 01:07:28 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 92
ERROR - 2016-11-09 01:07:28 --> Query error: Table 'db_tirta_dahaga.orderlist' doesn't exist
ERROR - 2016-11-09 01:07:29 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 79
ERROR - 2016-11-09 01:07:29 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 92
ERROR - 2016-11-09 01:07:29 --> Query error: Table 'db_tirta_dahaga.orderlist' doesn't exist
ERROR - 2016-11-09 01:07:29 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 79
ERROR - 2016-11-09 01:07:29 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 92
ERROR - 2016-11-09 01:07:29 --> Query error: Table 'db_tirta_dahaga.orderlist' doesn't exist
ERROR - 2016-11-09 01:07:29 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 79
ERROR - 2016-11-09 01:07:29 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 92
ERROR - 2016-11-09 01:07:29 --> Query error: Table 'db_tirta_dahaga.orderlist' doesn't exist
ERROR - 2016-11-09 01:07:29 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 79
ERROR - 2016-11-09 01:07:29 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 92
ERROR - 2016-11-09 01:07:29 --> Query error: Table 'db_tirta_dahaga.orderlist' doesn't exist
ERROR - 2016-11-09 01:07:29 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 79
ERROR - 2016-11-09 01:07:29 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 92
ERROR - 2016-11-09 01:07:29 --> Query error: Table 'db_tirta_dahaga.orderlist' doesn't exist
ERROR - 2016-11-09 01:07:29 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 79
ERROR - 2016-11-09 01:07:29 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 92
ERROR - 2016-11-09 01:07:29 --> Query error: Table 'db_tirta_dahaga.orderlist' doesn't exist
ERROR - 2016-11-09 01:07:30 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 79
ERROR - 2016-11-09 01:07:30 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 92
ERROR - 2016-11-09 01:07:30 --> Query error: Table 'db_tirta_dahaga.orderlist' doesn't exist
ERROR - 2016-11-09 01:07:30 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 79
ERROR - 2016-11-09 01:07:30 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 92
ERROR - 2016-11-09 01:07:30 --> Query error: Table 'db_tirta_dahaga.orderlist' doesn't exist
ERROR - 2016-11-09 01:07:30 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 79
ERROR - 2016-11-09 01:07:30 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 92
ERROR - 2016-11-09 01:07:30 --> Query error: Table 'db_tirta_dahaga.orderlist' doesn't exist
ERROR - 2016-11-09 01:07:30 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 79
ERROR - 2016-11-09 01:07:30 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 92
ERROR - 2016-11-09 01:07:30 --> Query error: Table 'db_tirta_dahaga.orderlist' doesn't exist
ERROR - 2016-11-09 01:07:30 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 79
ERROR - 2016-11-09 01:07:30 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 92
ERROR - 2016-11-09 01:07:30 --> Query error: Table 'db_tirta_dahaga.orderlist' doesn't exist
ERROR - 2016-11-09 01:07:30 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 79
ERROR - 2016-11-09 01:07:30 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 92
ERROR - 2016-11-09 01:07:30 --> Query error: Table 'db_tirta_dahaga.orderlist' doesn't exist
ERROR - 2016-11-09 01:07:31 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 79
ERROR - 2016-11-09 01:07:31 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 92
ERROR - 2016-11-09 01:07:31 --> Query error: Table 'db_tirta_dahaga.orderlist' doesn't exist
ERROR - 2016-11-09 01:07:31 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 79
ERROR - 2016-11-09 01:07:31 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 92
ERROR - 2016-11-09 01:07:31 --> Query error: Table 'db_tirta_dahaga.orderlist' doesn't exist
ERROR - 2016-11-09 01:07:31 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 79
ERROR - 2016-11-09 01:07:31 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 92
ERROR - 2016-11-09 01:07:31 --> Query error: Table 'db_tirta_dahaga.orderlist' doesn't exist
ERROR - 2016-11-09 01:07:31 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 79
ERROR - 2016-11-09 01:07:31 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 92
ERROR - 2016-11-09 01:07:31 --> Query error: Table 'db_tirta_dahaga.orderlist' doesn't exist
ERROR - 2016-11-09 01:07:31 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 79
ERROR - 2016-11-09 01:07:31 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 92
ERROR - 2016-11-09 01:07:31 --> Query error: Table 'db_tirta_dahaga.orderlist' doesn't exist
ERROR - 2016-11-09 01:07:37 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 79
ERROR - 2016-11-09 01:07:37 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 92
ERROR - 2016-11-09 01:07:37 --> Query error: Table 'db_tirta_dahaga.orderlist' doesn't exist
ERROR - 2016-11-09 01:07:37 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 79
ERROR - 2016-11-09 01:07:37 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 92
ERROR - 2016-11-09 01:07:37 --> Query error: Table 'db_tirta_dahaga.orderlist' doesn't exist
ERROR - 2016-11-09 01:07:38 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 79
ERROR - 2016-11-09 01:07:38 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 92
ERROR - 2016-11-09 01:07:38 --> Query error: Table 'db_tirta_dahaga.orderlist' doesn't exist
ERROR - 2016-11-09 01:07:38 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 79
ERROR - 2016-11-09 01:07:38 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 92
ERROR - 2016-11-09 01:07:38 --> Query error: Table 'db_tirta_dahaga.orderlist' doesn't exist
ERROR - 2016-11-09 01:07:38 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 79
ERROR - 2016-11-09 01:07:38 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 92
ERROR - 2016-11-09 01:07:38 --> Query error: Table 'db_tirta_dahaga.orderlist' doesn't exist
ERROR - 2016-11-09 01:07:38 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 79
ERROR - 2016-11-09 01:07:38 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 92
ERROR - 2016-11-09 01:07:38 --> Query error: Table 'db_tirta_dahaga.orderlist' doesn't exist
ERROR - 2016-11-09 01:08:06 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 79
ERROR - 2016-11-09 01:08:06 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 92
ERROR - 2016-11-09 01:08:06 --> Query error: Table 'db_tirta_dahaga.orderlist' doesn't exist
ERROR - 2016-11-09 01:08:07 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 79
ERROR - 2016-11-09 01:08:07 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 92
ERROR - 2016-11-09 01:08:07 --> Query error: Table 'db_tirta_dahaga.orderlist' doesn't exist
ERROR - 2016-11-09 01:08:07 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 79
ERROR - 2016-11-09 01:08:07 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 92
ERROR - 2016-11-09 01:08:07 --> Query error: Table 'db_tirta_dahaga.orderlist' doesn't exist
ERROR - 2016-11-09 01:08:07 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 79
ERROR - 2016-11-09 01:08:07 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 92
ERROR - 2016-11-09 01:08:07 --> Query error: Table 'db_tirta_dahaga.orderlist' doesn't exist
ERROR - 2016-11-09 01:08:07 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 79
ERROR - 2016-11-09 01:08:07 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 92
ERROR - 2016-11-09 01:08:07 --> Query error: Table 'db_tirta_dahaga.orderlist' doesn't exist
ERROR - 2016-11-09 01:08:08 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 79
ERROR - 2016-11-09 01:08:08 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 92
ERROR - 2016-11-09 01:08:08 --> Query error: Table 'db_tirta_dahaga.orderlist' doesn't exist
ERROR - 2016-11-09 01:08:08 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 79
ERROR - 2016-11-09 01:08:08 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 92
ERROR - 2016-11-09 01:08:08 --> Query error: Table 'db_tirta_dahaga.orderlist' doesn't exist
ERROR - 2016-11-09 01:08:08 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 79
ERROR - 2016-11-09 01:08:08 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 92
ERROR - 2016-11-09 01:08:08 --> Query error: Table 'db_tirta_dahaga.orderlist' doesn't exist
ERROR - 2016-11-09 01:08:08 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 79
ERROR - 2016-11-09 01:08:08 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 92
ERROR - 2016-11-09 01:08:08 --> Query error: Table 'db_tirta_dahaga.orderlist' doesn't exist
ERROR - 2016-11-09 01:08:08 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 79
ERROR - 2016-11-09 01:08:08 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 92
ERROR - 2016-11-09 01:08:08 --> Query error: Table 'db_tirta_dahaga.orderlist' doesn't exist
ERROR - 2016-11-09 01:08:08 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 79
ERROR - 2016-11-09 01:08:08 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 92
ERROR - 2016-11-09 01:08:08 --> Query error: Table 'db_tirta_dahaga.orderlist' doesn't exist
ERROR - 2016-11-09 01:08:09 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 79
ERROR - 2016-11-09 01:08:09 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 92
ERROR - 2016-11-09 01:08:09 --> Query error: Table 'db_tirta_dahaga.orderlist' doesn't exist
ERROR - 2016-11-09 01:08:09 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 79
ERROR - 2016-11-09 01:08:09 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 92
ERROR - 2016-11-09 01:08:09 --> Query error: Table 'db_tirta_dahaga.orderlist' doesn't exist
ERROR - 2016-11-09 01:08:09 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 79
ERROR - 2016-11-09 01:08:09 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 92
ERROR - 2016-11-09 01:08:09 --> Query error: Table 'db_tirta_dahaga.orderlist' doesn't exist
ERROR - 2016-11-09 01:08:09 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 79
ERROR - 2016-11-09 01:08:09 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 92
ERROR - 2016-11-09 01:08:09 --> Query error: Table 'db_tirta_dahaga.orderlist' doesn't exist
ERROR - 2016-11-09 01:08:09 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 79
ERROR - 2016-11-09 01:08:09 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 92
ERROR - 2016-11-09 01:08:09 --> Query error: Table 'db_tirta_dahaga.orderlist' doesn't exist
ERROR - 2016-11-09 01:08:09 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 79
ERROR - 2016-11-09 01:08:09 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 92
ERROR - 2016-11-09 01:08:09 --> Query error: Table 'db_tirta_dahaga.orderlist' doesn't exist
ERROR - 2016-11-09 01:08:10 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 79
ERROR - 2016-11-09 01:08:10 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 92
ERROR - 2016-11-09 01:08:10 --> Query error: Table 'db_tirta_dahaga.orderlist' doesn't exist
ERROR - 2016-11-09 01:08:10 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 79
ERROR - 2016-11-09 01:08:10 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 92
ERROR - 2016-11-09 01:08:10 --> Query error: Table 'db_tirta_dahaga.orderlist' doesn't exist
ERROR - 2016-11-09 01:08:10 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 79
ERROR - 2016-11-09 01:08:10 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 92
ERROR - 2016-11-09 01:08:10 --> Query error: Table 'db_tirta_dahaga.orderlist' doesn't exist
ERROR - 2016-11-09 01:08:10 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 79
ERROR - 2016-11-09 01:08:10 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 92
ERROR - 2016-11-09 01:08:10 --> Query error: Table 'db_tirta_dahaga.orderlist' doesn't exist
ERROR - 2016-11-09 01:08:10 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 79
ERROR - 2016-11-09 01:08:10 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 92
ERROR - 2016-11-09 01:08:10 --> Query error: Table 'db_tirta_dahaga.orderlist' doesn't exist
ERROR - 2016-11-09 01:08:11 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 79
ERROR - 2016-11-09 01:08:11 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 92
ERROR - 2016-11-09 01:08:12 --> Query error: Table 'db_tirta_dahaga.orderlist' doesn't exist
ERROR - 2016-11-09 01:08:12 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 79
ERROR - 2016-11-09 01:08:12 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 92
ERROR - 2016-11-09 01:08:12 --> Query error: Table 'db_tirta_dahaga.orderlist' doesn't exist
ERROR - 2016-11-09 01:08:12 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 79
ERROR - 2016-11-09 01:08:12 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 92
ERROR - 2016-11-09 01:08:12 --> Query error: Table 'db_tirta_dahaga.orderlist' doesn't exist
ERROR - 2016-11-09 01:08:12 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 79
ERROR - 2016-11-09 01:08:12 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 92
ERROR - 2016-11-09 01:08:12 --> Query error: Table 'db_tirta_dahaga.orderlist' doesn't exist
ERROR - 2016-11-09 01:08:12 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 79
ERROR - 2016-11-09 01:08:12 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 92
ERROR - 2016-11-09 01:08:12 --> Query error: Table 'db_tirta_dahaga.orderlist' doesn't exist
ERROR - 2016-11-09 01:08:12 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 79
ERROR - 2016-11-09 01:08:12 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 92
ERROR - 2016-11-09 01:08:12 --> Query error: Table 'db_tirta_dahaga.orderlist' doesn't exist
ERROR - 2016-11-09 01:08:13 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 79
ERROR - 2016-11-09 01:08:13 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 92
ERROR - 2016-11-09 01:08:13 --> Query error: Table 'db_tirta_dahaga.orderlist' doesn't exist
ERROR - 2016-11-09 01:08:13 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 79
ERROR - 2016-11-09 01:08:13 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 92
ERROR - 2016-11-09 01:08:13 --> Query error: Table 'db_tirta_dahaga.orderlist' doesn't exist
ERROR - 2016-11-09 01:08:13 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 79
ERROR - 2016-11-09 01:08:13 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 92
ERROR - 2016-11-09 01:08:13 --> Query error: Table 'db_tirta_dahaga.orderlist' doesn't exist
ERROR - 2016-11-09 01:08:13 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 79
ERROR - 2016-11-09 01:08:13 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 92
ERROR - 2016-11-09 01:08:13 --> Query error: Table 'db_tirta_dahaga.orderlist' doesn't exist
ERROR - 2016-11-09 01:08:18 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 79
ERROR - 2016-11-09 01:08:18 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 92
ERROR - 2016-11-09 01:08:18 --> Query error: Table 'db_tirta_dahaga.orderlist' doesn't exist
ERROR - 2016-11-09 01:08:18 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 79
ERROR - 2016-11-09 01:08:18 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 92
ERROR - 2016-11-09 01:08:18 --> Query error: Table 'db_tirta_dahaga.orderlist' doesn't exist
ERROR - 2016-11-09 01:08:18 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 79
ERROR - 2016-11-09 01:08:18 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 92
ERROR - 2016-11-09 01:08:18 --> Query error: Table 'db_tirta_dahaga.orderlist' doesn't exist
ERROR - 2016-11-09 01:08:19 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 79
ERROR - 2016-11-09 01:08:19 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 92
ERROR - 2016-11-09 01:08:19 --> Query error: Table 'db_tirta_dahaga.orderlist' doesn't exist
ERROR - 2016-11-09 01:08:19 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 79
ERROR - 2016-11-09 01:08:19 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 92
ERROR - 2016-11-09 01:08:19 --> Query error: Table 'db_tirta_dahaga.orderlist' doesn't exist
ERROR - 2016-11-09 01:08:19 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 79
ERROR - 2016-11-09 01:08:19 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 92
ERROR - 2016-11-09 01:08:19 --> Query error: Table 'db_tirta_dahaga.orderlist' doesn't exist
ERROR - 2016-11-09 01:09:52 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 79
ERROR - 2016-11-09 01:09:52 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 92
ERROR - 2016-11-09 01:10:11 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 79
ERROR - 2016-11-09 01:10:11 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 92
ERROR - 2016-11-09 01:10:11 --> Severity: Notice  --> Undefined variable: total_order C:\xampp\htdocs\tirta_dahaga\application\views\home.php 32
ERROR - 2016-11-09 01:10:11 --> Severity: Notice  --> Undefined variable: today_viewer C:\xampp\htdocs\tirta_dahaga\application\views\home.php 45
ERROR - 2016-11-09 01:10:11 --> Severity: Notice  --> Undefined variable: total_viewer C:\xampp\htdocs\tirta_dahaga\application\views\home.php 58
ERROR - 2016-11-09 01:10:11 --> Severity: Notice  --> Undefined variable: total_product C:\xampp\htdocs\tirta_dahaga\application\views\home.php 71
ERROR - 2016-11-09 01:10:11 --> Severity: Notice  --> Undefined variable: chart_delivered C:\xampp\htdocs\tirta_dahaga\application\views\home.php 111
ERROR - 2016-11-09 01:10:11 --> Severity: Notice  --> Undefined variable: chart_canceled C:\xampp\htdocs\tirta_dahaga\application\views\home.php 130
ERROR - 2016-11-09 01:10:13 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 79
ERROR - 2016-11-09 01:10:13 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 92
ERROR - 2016-11-09 01:10:13 --> Severity: Notice  --> Undefined variable: total_order C:\xampp\htdocs\tirta_dahaga\application\views\home.php 32
ERROR - 2016-11-09 01:10:13 --> Severity: Notice  --> Undefined variable: today_viewer C:\xampp\htdocs\tirta_dahaga\application\views\home.php 45
ERROR - 2016-11-09 01:10:13 --> Severity: Notice  --> Undefined variable: total_viewer C:\xampp\htdocs\tirta_dahaga\application\views\home.php 58
ERROR - 2016-11-09 01:10:13 --> Severity: Notice  --> Undefined variable: total_product C:\xampp\htdocs\tirta_dahaga\application\views\home.php 71
ERROR - 2016-11-09 01:10:13 --> Severity: Notice  --> Undefined variable: chart_delivered C:\xampp\htdocs\tirta_dahaga\application\views\home.php 111
ERROR - 2016-11-09 01:10:13 --> Severity: Notice  --> Undefined variable: chart_canceled C:\xampp\htdocs\tirta_dahaga\application\views\home.php 130
ERROR - 2016-11-09 01:10:13 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 79
ERROR - 2016-11-09 01:10:13 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 92
ERROR - 2016-11-09 01:10:13 --> Severity: Notice  --> Undefined variable: total_order C:\xampp\htdocs\tirta_dahaga\application\views\home.php 32
ERROR - 2016-11-09 01:10:13 --> Severity: Notice  --> Undefined variable: today_viewer C:\xampp\htdocs\tirta_dahaga\application\views\home.php 45
ERROR - 2016-11-09 01:10:13 --> Severity: Notice  --> Undefined variable: total_viewer C:\xampp\htdocs\tirta_dahaga\application\views\home.php 58
ERROR - 2016-11-09 01:10:13 --> Severity: Notice  --> Undefined variable: total_product C:\xampp\htdocs\tirta_dahaga\application\views\home.php 71
ERROR - 2016-11-09 01:10:13 --> Severity: Notice  --> Undefined variable: chart_delivered C:\xampp\htdocs\tirta_dahaga\application\views\home.php 111
ERROR - 2016-11-09 01:10:13 --> Severity: Notice  --> Undefined variable: chart_canceled C:\xampp\htdocs\tirta_dahaga\application\views\home.php 130
ERROR - 2016-11-09 01:11:36 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 79
ERROR - 2016-11-09 01:11:36 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 92
ERROR - 2016-11-09 01:11:36 --> Severity: Notice  --> Undefined variable: total_order C:\xampp\htdocs\tirta_dahaga\application\views\home.php 32
ERROR - 2016-11-09 01:11:36 --> Severity: Notice  --> Undefined variable: today_viewer C:\xampp\htdocs\tirta_dahaga\application\views\home.php 45
ERROR - 2016-11-09 01:11:36 --> Severity: Notice  --> Undefined variable: total_viewer C:\xampp\htdocs\tirta_dahaga\application\views\home.php 58
ERROR - 2016-11-09 01:11:36 --> Severity: Notice  --> Undefined variable: total_product C:\xampp\htdocs\tirta_dahaga\application\views\home.php 71
ERROR - 2016-11-09 01:11:36 --> Severity: Notice  --> Undefined variable: chart_delivered C:\xampp\htdocs\tirta_dahaga\application\views\home.php 112
ERROR - 2016-11-09 01:11:36 --> Severity: Notice  --> Undefined variable: chart_canceled C:\xampp\htdocs\tirta_dahaga\application\views\home.php 131
ERROR - 2016-11-09 01:11:39 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 79
ERROR - 2016-11-09 01:11:39 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 92
ERROR - 2016-11-09 01:11:39 --> Severity: Notice  --> Undefined variable: total_order C:\xampp\htdocs\tirta_dahaga\application\views\home.php 32
ERROR - 2016-11-09 01:11:39 --> Severity: Notice  --> Undefined variable: today_viewer C:\xampp\htdocs\tirta_dahaga\application\views\home.php 45
ERROR - 2016-11-09 01:11:39 --> Severity: Notice  --> Undefined variable: total_viewer C:\xampp\htdocs\tirta_dahaga\application\views\home.php 58
ERROR - 2016-11-09 01:11:39 --> Severity: Notice  --> Undefined variable: total_product C:\xampp\htdocs\tirta_dahaga\application\views\home.php 71
ERROR - 2016-11-09 01:11:39 --> Severity: Notice  --> Undefined variable: chart_delivered C:\xampp\htdocs\tirta_dahaga\application\views\home.php 112
ERROR - 2016-11-09 01:11:39 --> Severity: Notice  --> Undefined variable: chart_canceled C:\xampp\htdocs\tirta_dahaga\application\views\home.php 131
ERROR - 2016-11-09 01:11:40 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 79
ERROR - 2016-11-09 01:11:40 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 92
ERROR - 2016-11-09 01:11:40 --> Severity: Notice  --> Undefined variable: total_order C:\xampp\htdocs\tirta_dahaga\application\views\home.php 32
ERROR - 2016-11-09 01:11:40 --> Severity: Notice  --> Undefined variable: today_viewer C:\xampp\htdocs\tirta_dahaga\application\views\home.php 45
ERROR - 2016-11-09 01:11:40 --> Severity: Notice  --> Undefined variable: total_viewer C:\xampp\htdocs\tirta_dahaga\application\views\home.php 58
ERROR - 2016-11-09 01:11:40 --> Severity: Notice  --> Undefined variable: total_product C:\xampp\htdocs\tirta_dahaga\application\views\home.php 71
ERROR - 2016-11-09 01:11:40 --> Severity: Notice  --> Undefined variable: chart_delivered C:\xampp\htdocs\tirta_dahaga\application\views\home.php 112
ERROR - 2016-11-09 01:11:40 --> Severity: Notice  --> Undefined variable: chart_canceled C:\xampp\htdocs\tirta_dahaga\application\views\home.php 131
ERROR - 2016-11-09 01:11:40 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 79
ERROR - 2016-11-09 01:11:40 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 92
ERROR - 2016-11-09 01:11:40 --> Severity: Notice  --> Undefined variable: total_order C:\xampp\htdocs\tirta_dahaga\application\views\home.php 32
ERROR - 2016-11-09 01:11:40 --> Severity: Notice  --> Undefined variable: today_viewer C:\xampp\htdocs\tirta_dahaga\application\views\home.php 45
ERROR - 2016-11-09 01:11:40 --> Severity: Notice  --> Undefined variable: total_viewer C:\xampp\htdocs\tirta_dahaga\application\views\home.php 58
ERROR - 2016-11-09 01:11:40 --> Severity: Notice  --> Undefined variable: total_product C:\xampp\htdocs\tirta_dahaga\application\views\home.php 71
ERROR - 2016-11-09 01:11:40 --> Severity: Notice  --> Undefined variable: chart_delivered C:\xampp\htdocs\tirta_dahaga\application\views\home.php 112
ERROR - 2016-11-09 01:11:40 --> Severity: Notice  --> Undefined variable: chart_canceled C:\xampp\htdocs\tirta_dahaga\application\views\home.php 131
ERROR - 2016-11-09 01:11:40 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 79
ERROR - 2016-11-09 01:11:40 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 92
ERROR - 2016-11-09 01:11:40 --> Severity: Notice  --> Undefined variable: total_order C:\xampp\htdocs\tirta_dahaga\application\views\home.php 32
ERROR - 2016-11-09 01:11:40 --> Severity: Notice  --> Undefined variable: today_viewer C:\xampp\htdocs\tirta_dahaga\application\views\home.php 45
ERROR - 2016-11-09 01:11:40 --> Severity: Notice  --> Undefined variable: total_viewer C:\xampp\htdocs\tirta_dahaga\application\views\home.php 58
ERROR - 2016-11-09 01:11:40 --> Severity: Notice  --> Undefined variable: total_product C:\xampp\htdocs\tirta_dahaga\application\views\home.php 71
ERROR - 2016-11-09 01:11:40 --> Severity: Notice  --> Undefined variable: chart_delivered C:\xampp\htdocs\tirta_dahaga\application\views\home.php 112
ERROR - 2016-11-09 01:11:40 --> Severity: Notice  --> Undefined variable: chart_canceled C:\xampp\htdocs\tirta_dahaga\application\views\home.php 131
ERROR - 2016-11-09 01:12:31 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 79
ERROR - 2016-11-09 01:12:31 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 92
ERROR - 2016-11-09 01:12:31 --> Severity: Notice  --> Undefined variable: total_order C:\xampp\htdocs\tirta_dahaga\application\views\home.php 32
ERROR - 2016-11-09 01:12:31 --> Severity: Notice  --> Undefined variable: today_viewer C:\xampp\htdocs\tirta_dahaga\application\views\home.php 45
ERROR - 2016-11-09 01:12:31 --> Severity: Notice  --> Undefined variable: total_viewer C:\xampp\htdocs\tirta_dahaga\application\views\home.php 58
ERROR - 2016-11-09 01:12:31 --> Severity: Notice  --> Undefined variable: total_product C:\xampp\htdocs\tirta_dahaga\application\views\home.php 72
ERROR - 2016-11-09 01:12:31 --> Severity: Notice  --> Undefined variable: chart_delivered C:\xampp\htdocs\tirta_dahaga\application\views\home.php 113
ERROR - 2016-11-09 01:12:31 --> Severity: Notice  --> Undefined variable: chart_canceled C:\xampp\htdocs\tirta_dahaga\application\views\home.php 132
ERROR - 2016-11-09 01:12:32 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 79
ERROR - 2016-11-09 01:12:32 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 92
ERROR - 2016-11-09 01:12:32 --> Severity: Notice  --> Undefined variable: total_order C:\xampp\htdocs\tirta_dahaga\application\views\home.php 32
ERROR - 2016-11-09 01:12:32 --> Severity: Notice  --> Undefined variable: today_viewer C:\xampp\htdocs\tirta_dahaga\application\views\home.php 45
ERROR - 2016-11-09 01:12:32 --> Severity: Notice  --> Undefined variable: total_viewer C:\xampp\htdocs\tirta_dahaga\application\views\home.php 58
ERROR - 2016-11-09 01:12:32 --> Severity: Notice  --> Undefined variable: total_product C:\xampp\htdocs\tirta_dahaga\application\views\home.php 72
ERROR - 2016-11-09 01:12:32 --> Severity: Notice  --> Undefined variable: chart_delivered C:\xampp\htdocs\tirta_dahaga\application\views\home.php 113
ERROR - 2016-11-09 01:12:32 --> Severity: Notice  --> Undefined variable: chart_canceled C:\xampp\htdocs\tirta_dahaga\application\views\home.php 132
ERROR - 2016-11-09 01:12:33 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 79
ERROR - 2016-11-09 01:12:33 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 92
ERROR - 2016-11-09 01:12:33 --> Severity: Notice  --> Undefined variable: total_order C:\xampp\htdocs\tirta_dahaga\application\views\home.php 32
ERROR - 2016-11-09 01:12:33 --> Severity: Notice  --> Undefined variable: today_viewer C:\xampp\htdocs\tirta_dahaga\application\views\home.php 45
ERROR - 2016-11-09 01:12:33 --> Severity: Notice  --> Undefined variable: total_viewer C:\xampp\htdocs\tirta_dahaga\application\views\home.php 58
ERROR - 2016-11-09 01:12:33 --> Severity: Notice  --> Undefined variable: total_product C:\xampp\htdocs\tirta_dahaga\application\views\home.php 72
ERROR - 2016-11-09 01:12:33 --> Severity: Notice  --> Undefined variable: chart_delivered C:\xampp\htdocs\tirta_dahaga\application\views\home.php 113
ERROR - 2016-11-09 01:12:33 --> Severity: Notice  --> Undefined variable: chart_canceled C:\xampp\htdocs\tirta_dahaga\application\views\home.php 132
ERROR - 2016-11-09 01:12:46 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 79
ERROR - 2016-11-09 01:12:46 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 92
ERROR - 2016-11-09 01:12:46 --> Severity: Notice  --> Undefined variable: total_order C:\xampp\htdocs\tirta_dahaga\application\views\home.php 32
ERROR - 2016-11-09 01:12:46 --> Severity: Notice  --> Undefined variable: today_viewer C:\xampp\htdocs\tirta_dahaga\application\views\home.php 45
ERROR - 2016-11-09 01:12:46 --> Severity: Notice  --> Undefined variable: total_viewer C:\xampp\htdocs\tirta_dahaga\application\views\home.php 58
ERROR - 2016-11-09 01:12:46 --> Severity: Notice  --> Undefined variable: total_product C:\xampp\htdocs\tirta_dahaga\application\views\home.php 74
ERROR - 2016-11-09 01:12:46 --> Severity: Notice  --> Undefined variable: chart_delivered C:\xampp\htdocs\tirta_dahaga\application\views\home.php 115
ERROR - 2016-11-09 01:12:46 --> Severity: Notice  --> Undefined variable: chart_canceled C:\xampp\htdocs\tirta_dahaga\application\views\home.php 134
ERROR - 2016-11-09 01:12:59 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 79
ERROR - 2016-11-09 01:12:59 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 92
ERROR - 2016-11-09 01:12:59 --> Severity: Notice  --> Undefined variable: total_order C:\xampp\htdocs\tirta_dahaga\application\views\home.php 32
ERROR - 2016-11-09 01:12:59 --> Severity: Notice  --> Undefined variable: today_viewer C:\xampp\htdocs\tirta_dahaga\application\views\home.php 45
ERROR - 2016-11-09 01:12:59 --> Severity: Notice  --> Undefined variable: total_product C:\xampp\htdocs\tirta_dahaga\application\views\home.php 71
ERROR - 2016-11-09 01:12:59 --> Severity: Notice  --> Undefined variable: chart_delivered C:\xampp\htdocs\tirta_dahaga\application\views\home.php 112
ERROR - 2016-11-09 01:12:59 --> Severity: Notice  --> Undefined variable: chart_canceled C:\xampp\htdocs\tirta_dahaga\application\views\home.php 131
ERROR - 2016-11-09 01:13:21 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 79
ERROR - 2016-11-09 01:13:21 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 92
ERROR - 2016-11-09 01:13:21 --> Severity: Notice  --> Undefined variable: total_order C:\xampp\htdocs\tirta_dahaga\application\views\home.php 32
ERROR - 2016-11-09 01:13:21 --> Severity: Notice  --> Undefined variable: chart_delivered C:\xampp\htdocs\tirta_dahaga\application\views\home.php 112
ERROR - 2016-11-09 01:13:21 --> Severity: Notice  --> Undefined variable: chart_canceled C:\xampp\htdocs\tirta_dahaga\application\views\home.php 131
ERROR - 2016-11-09 01:13:32 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 79
ERROR - 2016-11-09 01:13:32 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 92
ERROR - 2016-11-09 01:13:32 --> Severity: Notice  --> Undefined variable: chart_delivered C:\xampp\htdocs\tirta_dahaga\application\views\home.php 112
ERROR - 2016-11-09 01:13:32 --> Severity: Notice  --> Undefined variable: chart_canceled C:\xampp\htdocs\tirta_dahaga\application\views\home.php 131
ERROR - 2016-11-09 01:13:43 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 79
ERROR - 2016-11-09 01:13:43 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 92
ERROR - 2016-11-09 01:13:43 --> Severity: Notice  --> Undefined variable: chart_delivered C:\xampp\htdocs\tirta_dahaga\application\views\home.php 112
ERROR - 2016-11-09 01:13:43 --> Severity: Notice  --> Undefined variable: chart_canceled C:\xampp\htdocs\tirta_dahaga\application\views\home.php 131
ERROR - 2016-11-09 01:14:03 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 79
ERROR - 2016-11-09 01:14:03 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 92
ERROR - 2016-11-09 01:14:03 --> Severity: Notice  --> Undefined variable: chart_delivered C:\xampp\htdocs\tirta_dahaga\application\views\home.php 112
ERROR - 2016-11-09 01:14:03 --> Severity: Notice  --> Undefined variable: chart_canceled C:\xampp\htdocs\tirta_dahaga\application\views\home.php 131
ERROR - 2016-11-09 01:14:11 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 79
ERROR - 2016-11-09 01:14:11 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 92
ERROR - 2016-11-09 01:14:11 --> Severity: Notice  --> Undefined variable: chart_delivered C:\xampp\htdocs\tirta_dahaga\application\views\home.php 112
ERROR - 2016-11-09 01:14:11 --> Severity: Notice  --> Undefined variable: chart_canceled C:\xampp\htdocs\tirta_dahaga\application\views\home.php 131
ERROR - 2016-11-09 01:14:12 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 79
ERROR - 2016-11-09 01:14:12 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 92
ERROR - 2016-11-09 01:14:19 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 79
ERROR - 2016-11-09 01:14:19 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 92
ERROR - 2016-11-09 01:14:19 --> Severity: Notice  --> Undefined variable: chart_delivered C:\xampp\htdocs\tirta_dahaga\application\views\home.php 112
ERROR - 2016-11-09 01:14:19 --> Severity: Notice  --> Undefined variable: chart_canceled C:\xampp\htdocs\tirta_dahaga\application\views\home.php 131
ERROR - 2016-11-09 01:14:22 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 79
ERROR - 2016-11-09 01:14:22 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 92
ERROR - 2016-11-09 01:14:25 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 79
ERROR - 2016-11-09 01:14:25 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 92
ERROR - 2016-11-09 01:14:25 --> Severity: Notice  --> Undefined variable: chart_delivered C:\xampp\htdocs\tirta_dahaga\application\views\home.php 112
ERROR - 2016-11-09 01:14:25 --> Severity: Notice  --> Undefined variable: chart_canceled C:\xampp\htdocs\tirta_dahaga\application\views\home.php 131
ERROR - 2016-11-09 01:14:27 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 79
ERROR - 2016-11-09 01:14:27 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 92
ERROR - 2016-11-09 01:14:28 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 79
ERROR - 2016-11-09 01:14:28 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 92
ERROR - 2016-11-09 01:14:28 --> Severity: Notice  --> Undefined variable: chart_delivered C:\xampp\htdocs\tirta_dahaga\application\views\home.php 112
ERROR - 2016-11-09 01:14:28 --> Severity: Notice  --> Undefined variable: chart_canceled C:\xampp\htdocs\tirta_dahaga\application\views\home.php 131
ERROR - 2016-11-09 01:14:31 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 79
ERROR - 2016-11-09 01:14:31 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 92
