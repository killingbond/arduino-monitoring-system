<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-12-26 11:52:59 --> You did not select a file to upload.
ERROR - 2015-12-26 11:53:06 --> You did not select a file to upload.
ERROR - 2015-12-26 11:53:21 --> You did not select a file to upload.
ERROR - 2015-12-26 11:53:28 --> You did not select a file to upload.
ERROR - 2015-12-26 11:53:37 --> You did not select a file to upload.
