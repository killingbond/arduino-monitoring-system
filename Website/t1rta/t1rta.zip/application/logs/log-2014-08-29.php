<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2014-08-29 03:48:39 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\Galaxia-Store\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-08-29 03:48:39 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
ERROR - 2014-08-29 04:06:40 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
ERROR - 2014-08-29 04:06:50 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 141
ERROR - 2014-08-29 04:06:50 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 141
ERROR - 2014-08-29 04:07:02 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 141
ERROR - 2014-08-29 04:07:02 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 141
ERROR - 2014-08-29 04:07:24 --> Severity: Notice  --> Undefined property: stdClass::$used C:\wamp\www\Galaxia-Store\application\controllers\cart.php 207
ERROR - 2014-08-29 04:07:33 --> 404 Page Not Found --> template
ERROR - 2014-08-29 04:08:02 --> Severity: Notice  --> Undefined property: stdClass::$used C:\wamp\www\Galaxia-Store\application\controllers\cart.php 207
ERROR - 2014-08-29 04:14:35 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 141
ERROR - 2014-08-29 04:14:35 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 141
ERROR - 2014-08-29 04:18:08 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 141
ERROR - 2014-08-29 04:18:08 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 141
ERROR - 2014-08-29 04:18:12 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 141
ERROR - 2014-08-29 04:18:12 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 141
ERROR - 2014-08-29 04:18:26 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 141
ERROR - 2014-08-29 04:18:26 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 141
ERROR - 2014-08-29 04:18:30 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 141
ERROR - 2014-08-29 04:18:30 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 141
ERROR - 2014-08-29 04:25:22 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
ERROR - 2014-08-29 04:41:20 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
ERROR - 2014-08-29 04:41:26 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 141
ERROR - 2014-08-29 04:41:26 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 141
ERROR - 2014-08-29 04:41:34 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 141
ERROR - 2014-08-29 04:41:34 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 141
ERROR - 2014-08-29 04:41:42 --> Query error: Unknown column 'product_detail_id' in 'where clause'
ERROR - 2014-08-29 04:42:44 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
ERROR - 2014-08-29 04:42:52 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 141
ERROR - 2014-08-29 04:42:52 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 141
ERROR - 2014-08-29 04:43:00 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 141
ERROR - 2014-08-29 04:43:00 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 141
ERROR - 2014-08-29 04:43:17 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
ERROR - 2014-08-29 04:43:47 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 141
ERROR - 2014-08-29 04:43:47 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 141
ERROR - 2014-08-29 04:43:53 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 141
ERROR - 2014-08-29 04:43:53 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 141
ERROR - 2014-08-29 05:41:22 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
ERROR - 2014-08-29 05:41:33 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 141
ERROR - 2014-08-29 05:41:33 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 141
ERROR - 2014-08-29 05:42:36 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 141
ERROR - 2014-08-29 05:42:36 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 141
ERROR - 2014-08-29 06:09:45 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
ERROR - 2014-08-29 06:10:42 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 141
ERROR - 2014-08-29 06:10:42 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 141
ERROR - 2014-08-29 06:10:48 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 141
ERROR - 2014-08-29 06:10:48 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 141
ERROR - 2014-08-29 06:12:16 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
ERROR - 2014-08-29 06:12:21 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 141
ERROR - 2014-08-29 06:12:21 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 141
ERROR - 2014-08-29 06:12:27 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 141
ERROR - 2014-08-29 06:12:27 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 141
ERROR - 2014-08-29 06:12:59 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
ERROR - 2014-08-29 06:13:15 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
