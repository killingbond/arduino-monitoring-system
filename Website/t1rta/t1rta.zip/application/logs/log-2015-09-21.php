<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-09-21 08:39:48 --> The upload path does not appear to be valid.
ERROR - 2015-09-21 08:40:45 --> Severity: Warning  --> escapeshellarg() has been disabled for security reasons /home/ozantcom/public_html/wassuphaters.com/new/admin/system/libraries/Upload.php 1066
ERROR - 2015-09-21 08:41:03 --> Severity: Warning  --> escapeshellarg() has been disabled for security reasons /home/ozantcom/public_html/wassuphaters.com/new/admin/system/libraries/Upload.php 1066
