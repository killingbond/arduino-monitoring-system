<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2014-08-25 03:00:13 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
ERROR - 2014-08-25 03:17:22 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 100
ERROR - 2014-08-25 03:17:22 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 100
ERROR - 2014-08-25 03:19:20 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 100
ERROR - 2014-08-25 03:19:20 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 100
ERROR - 2014-08-25 03:19:24 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 100
ERROR - 2014-08-25 03:19:24 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 100
ERROR - 2014-08-25 03:21:36 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
ERROR - 2014-08-25 03:23:01 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
ERROR - 2014-08-25 03:23:14 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 100
ERROR - 2014-08-25 03:23:15 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 100
ERROR - 2014-08-25 03:23:17 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 100
ERROR - 2014-08-25 03:23:18 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 100
ERROR - 2014-08-25 03:29:53 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
ERROR - 2014-08-25 03:33:15 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
ERROR - 2014-08-25 03:35:31 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
ERROR - 2014-08-25 03:40:18 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
ERROR - 2014-08-25 03:40:22 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 100
ERROR - 2014-08-25 03:40:22 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 100
ERROR - 2014-08-25 03:40:30 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 100
ERROR - 2014-08-25 03:40:30 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 100
ERROR - 2014-08-25 03:42:59 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 100
ERROR - 2014-08-25 03:42:59 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 100
ERROR - 2014-08-25 03:43:01 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 100
ERROR - 2014-08-25 03:43:02 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 100
ERROR - 2014-08-25 03:48:55 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Galaxia-Store\application\models\cart_m.php 344
ERROR - 2014-08-25 03:48:55 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Galaxia-Store\application\models\cart_m.php 344
ERROR - 2014-08-25 03:50:58 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
ERROR - 2014-08-25 03:50:58 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\Galaxia-Store\application\models\cart_m.php 329
ERROR - 2014-08-25 03:50:58 --> Severity: Notice  --> Undefined variable: data_detail C:\wamp\www\Galaxia-Store\application\models\cart_m.php 355
ERROR - 2014-08-25 03:51:03 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 100
ERROR - 2014-08-25 03:51:03 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 100
ERROR - 2014-08-25 03:51:32 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
ERROR - 2014-08-25 03:51:32 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\Galaxia-Store\application\models\cart_m.php 329
ERROR - 2014-08-25 03:51:32 --> Severity: Notice  --> Undefined variable: data_detail C:\wamp\www\Galaxia-Store\application\models\cart_m.php 355
ERROR - 2014-08-25 03:51:58 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 100
ERROR - 2014-08-25 03:51:58 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 100
ERROR - 2014-08-25 03:53:39 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
ERROR - 2014-08-25 03:53:45 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 100
ERROR - 2014-08-25 03:53:45 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 100
ERROR - 2014-08-25 03:53:47 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 100
ERROR - 2014-08-25 03:53:47 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 100
ERROR - 2014-08-25 03:53:53 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 100
ERROR - 2014-08-25 03:53:53 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 100
ERROR - 2014-08-25 03:55:13 --> Severity: Notice  --> Undefined property: stdClass::$price_ C:\wamp\www\Galaxia-Store\application\views\checkout.php 483
ERROR - 2014-08-25 03:59:25 --> Severity: Notice  --> Undefined property: stdClass::$amount C:\wamp\www\Galaxia-Store\application\views\checkout.php 529
ERROR - 2014-08-25 04:00:14 --> Severity: Notice  --> Undefined variable: tax C:\wamp\www\Galaxia-Store\application\views\checkout.php 520
ERROR - 2014-08-25 04:00:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Galaxia-Store\application\views\checkout.php 527
ERROR - 2014-08-25 04:00:14 --> Severity: Warning  --> Division by zero C:\wamp\www\Galaxia-Store\application\views\checkout.php 527
ERROR - 2014-08-25 04:00:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Galaxia-Store\application\views\checkout.php 529
ERROR - 2014-08-25 04:00:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Galaxia-Store\application\views\checkout.php 533
ERROR - 2014-08-25 04:00:36 --> Severity: Notice  --> Undefined variable: tax C:\wamp\www\Galaxia-Store\application\views\checkout.php 520
ERROR - 2014-08-25 04:00:36 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Galaxia-Store\application\views\checkout.php 527
ERROR - 2014-08-25 04:00:36 --> Severity: Warning  --> Division by zero C:\wamp\www\Galaxia-Store\application\views\checkout.php 527
ERROR - 2014-08-25 04:00:36 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Galaxia-Store\application\views\checkout.php 529
ERROR - 2014-08-25 04:00:36 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Galaxia-Store\application\views\checkout.php 533
ERROR - 2014-08-25 04:00:38 --> Severity: Notice  --> Undefined variable: tax C:\wamp\www\Galaxia-Store\application\views\checkout.php 520
ERROR - 2014-08-25 04:00:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Galaxia-Store\application\views\checkout.php 527
ERROR - 2014-08-25 04:00:38 --> Severity: Warning  --> Division by zero C:\wamp\www\Galaxia-Store\application\views\checkout.php 527
ERROR - 2014-08-25 04:00:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Galaxia-Store\application\views\checkout.php 529
ERROR - 2014-08-25 04:00:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Galaxia-Store\application\views\checkout.php 533
ERROR - 2014-08-25 04:01:54 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 100
ERROR - 2014-08-25 04:01:54 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 100
ERROR - 2014-08-25 04:05:41 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 100
ERROR - 2014-08-25 04:05:41 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 100
ERROR - 2014-08-25 04:05:52 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 100
ERROR - 2014-08-25 04:05:52 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 100
ERROR - 2014-08-25 04:05:58 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 100
ERROR - 2014-08-25 04:05:58 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 100
ERROR - 2014-08-25 04:06:19 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 100
ERROR - 2014-08-25 04:06:19 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 100
ERROR - 2014-08-25 04:06:36 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 100
ERROR - 2014-08-25 04:06:36 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 100
ERROR - 2014-08-25 04:07:14 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 100
ERROR - 2014-08-25 04:07:14 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 100
ERROR - 2014-08-25 04:07:16 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 100
ERROR - 2014-08-25 04:07:16 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 100
ERROR - 2014-08-25 04:07:45 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 100
ERROR - 2014-08-25 04:07:45 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 100
ERROR - 2014-08-25 04:08:13 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 100
ERROR - 2014-08-25 04:08:13 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 100
ERROR - 2014-08-25 04:08:17 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 100
ERROR - 2014-08-25 04:08:17 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 100
ERROR - 2014-08-25 04:08:29 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 100
ERROR - 2014-08-25 04:08:29 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 100
ERROR - 2014-08-25 04:08:31 --> 404 Page Not Found --> cart/delete_cart
ERROR - 2014-08-25 04:09:59 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 100
ERROR - 2014-08-25 04:09:59 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 100
ERROR - 2014-08-25 04:10:00 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 100
ERROR - 2014-08-25 04:10:00 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 100
ERROR - 2014-08-25 04:11:50 --> Query error: Lock wait timeout exceeded; try restarting transaction
ERROR - 2014-08-25 04:12:24 --> Severity: Notice  --> Undefined variable: member_id C:\wamp\www\Galaxia-Store\application\views\cart.php 86
ERROR - 2014-08-25 04:12:24 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 100
ERROR - 2014-08-25 04:12:24 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 100
ERROR - 2014-08-25 04:13:11 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 100
ERROR - 2014-08-25 04:13:11 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 100
ERROR - 2014-08-25 04:13:44 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 100
ERROR - 2014-08-25 04:13:44 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 100
ERROR - 2014-08-25 04:14:02 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 100
ERROR - 2014-08-25 04:14:02 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 100
ERROR - 2014-08-25 04:14:20 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 100
ERROR - 2014-08-25 04:14:20 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 100
ERROR - 2014-08-25 04:14:33 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 100
ERROR - 2014-08-25 04:14:33 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 100
ERROR - 2014-08-25 04:19:16 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 100
ERROR - 2014-08-25 04:19:16 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 100
ERROR - 2014-08-25 04:19:20 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 100
ERROR - 2014-08-25 04:19:20 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 100
ERROR - 2014-08-25 04:19:27 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 100
ERROR - 2014-08-25 04:19:27 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 100
ERROR - 2014-08-25 04:22:05 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 100
ERROR - 2014-08-25 04:22:05 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 100
ERROR - 2014-08-25 04:22:08 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 100
ERROR - 2014-08-25 04:22:08 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 100
ERROR - 2014-08-25 04:22:13 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 100
ERROR - 2014-08-25 04:22:14 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 100
ERROR - 2014-08-25 04:22:48 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 100
ERROR - 2014-08-25 04:22:48 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 100
ERROR - 2014-08-25 04:22:55 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 100
ERROR - 2014-08-25 04:22:55 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 100
ERROR - 2014-08-25 04:22:59 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 100
ERROR - 2014-08-25 04:22:59 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 100
ERROR - 2014-08-25 04:23:20 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 100
ERROR - 2014-08-25 04:23:20 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 100
ERROR - 2014-08-25 04:23:33 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 100
ERROR - 2014-08-25 04:23:33 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 100
ERROR - 2014-08-25 04:23:44 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 100
ERROR - 2014-08-25 04:23:44 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 100
ERROR - 2014-08-25 04:24:14 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 100
ERROR - 2014-08-25 04:24:14 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 100
ERROR - 2014-08-25 04:24:59 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 100
ERROR - 2014-08-25 04:24:59 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 100
ERROR - 2014-08-25 04:25:33 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 100
ERROR - 2014-08-25 04:25:33 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 100
ERROR - 2014-08-25 04:25:36 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 100
ERROR - 2014-08-25 04:25:36 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 100
ERROR - 2014-08-25 04:25:39 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 100
ERROR - 2014-08-25 04:25:39 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 100
ERROR - 2014-08-25 04:25:43 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 100
ERROR - 2014-08-25 04:25:43 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 100
ERROR - 2014-08-25 04:26:00 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 100
ERROR - 2014-08-25 04:26:00 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 100
ERROR - 2014-08-25 04:26:04 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 100
ERROR - 2014-08-25 04:26:04 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 100
ERROR - 2014-08-25 04:26:12 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 100
ERROR - 2014-08-25 04:26:12 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 100
ERROR - 2014-08-25 04:26:15 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 100
ERROR - 2014-08-25 04:26:15 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 100
ERROR - 2014-08-25 04:27:44 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 100
ERROR - 2014-08-25 04:27:44 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 100
ERROR - 2014-08-25 04:27:48 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 100
ERROR - 2014-08-25 04:27:48 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 100
ERROR - 2014-08-25 04:27:56 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 100
ERROR - 2014-08-25 04:27:56 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 100
ERROR - 2014-08-25 04:28:00 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 100
ERROR - 2014-08-25 04:28:00 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 100
ERROR - 2014-08-25 04:29:08 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 100
ERROR - 2014-08-25 04:29:08 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 100
ERROR - 2014-08-25 04:29:13 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 100
ERROR - 2014-08-25 04:29:13 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 100
ERROR - 2014-08-25 04:44:13 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
ERROR - 2014-08-25 04:45:34 --> Severity: Notice  --> Undefined variable: is_checkout C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 83
ERROR - 2014-08-25 04:45:34 --> Severity: Notice  --> Undefined variable: country C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 186
ERROR - 2014-08-25 04:45:34 --> Severity: Notice  --> Undefined variable: province C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 203
ERROR - 2014-08-25 04:45:34 --> Severity: Notice  --> Undefined variable: city C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 220
ERROR - 2014-08-25 04:45:34 --> Severity: Notice  --> Undefined variable: district C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 237
ERROR - 2014-08-25 04:46:05 --> Severity: Notice  --> Undefined variable: is_register C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 33
ERROR - 2014-08-25 04:46:05 --> Severity: Notice  --> Undefined variable: is_checkout C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 42
ERROR - 2014-08-25 04:46:05 --> Severity: Notice  --> Undefined variable: is_register C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 63
ERROR - 2014-08-25 04:46:05 --> Severity: Notice  --> Undefined variable: name C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 76
ERROR - 2014-08-25 04:46:05 --> Severity: Notice  --> Undefined variable: gender C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 82
ERROR - 2014-08-25 04:46:05 --> Severity: Notice  --> Undefined variable: gender C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 83
ERROR - 2014-08-25 04:46:05 --> Severity: Notice  --> Undefined variable: date C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 93
ERROR - 2014-08-25 04:46:05 --> Severity: Notice  --> Undefined variable: date C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 93
ERROR - 2014-08-25 04:46:05 --> Severity: Notice  --> Undefined variable: date C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 93
ERROR - 2014-08-25 04:46:05 --> Severity: Notice  --> Undefined variable: date C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 93
ERROR - 2014-08-25 04:46:05 --> Severity: Notice  --> Undefined variable: date C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 93
ERROR - 2014-08-25 04:46:05 --> Severity: Notice  --> Undefined variable: date C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 93
ERROR - 2014-08-25 04:46:05 --> Severity: Notice  --> Undefined variable: date C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 93
ERROR - 2014-08-25 04:46:05 --> Severity: Notice  --> Undefined variable: date C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 93
ERROR - 2014-08-25 04:46:05 --> Severity: Notice  --> Undefined variable: date C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 93
ERROR - 2014-08-25 04:46:05 --> Severity: Notice  --> Undefined variable: date C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 93
ERROR - 2014-08-25 04:46:05 --> Severity: Notice  --> Undefined variable: date C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 93
ERROR - 2014-08-25 04:46:05 --> Severity: Notice  --> Undefined variable: date C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 93
ERROR - 2014-08-25 04:46:05 --> Severity: Notice  --> Undefined variable: date C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 93
ERROR - 2014-08-25 04:46:05 --> Severity: Notice  --> Undefined variable: date C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 93
ERROR - 2014-08-25 04:46:05 --> Severity: Notice  --> Undefined variable: date C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 93
ERROR - 2014-08-25 04:46:05 --> Severity: Notice  --> Undefined variable: date C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 93
ERROR - 2014-08-25 04:46:05 --> Severity: Notice  --> Undefined variable: date C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 93
ERROR - 2014-08-25 04:46:05 --> Severity: Notice  --> Undefined variable: date C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 93
ERROR - 2014-08-25 04:46:05 --> Severity: Notice  --> Undefined variable: date C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 93
ERROR - 2014-08-25 04:46:05 --> Severity: Notice  --> Undefined variable: date C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 93
ERROR - 2014-08-25 04:46:05 --> Severity: Notice  --> Undefined variable: date C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 93
ERROR - 2014-08-25 04:46:05 --> Severity: Notice  --> Undefined variable: date C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 93
ERROR - 2014-08-25 04:46:05 --> Severity: Notice  --> Undefined variable: date C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 93
ERROR - 2014-08-25 04:46:05 --> Severity: Notice  --> Undefined variable: date C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 93
ERROR - 2014-08-25 04:46:05 --> Severity: Notice  --> Undefined variable: date C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 93
ERROR - 2014-08-25 04:46:05 --> Severity: Notice  --> Undefined variable: date C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 93
ERROR - 2014-08-25 04:46:05 --> Severity: Notice  --> Undefined variable: date C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 93
ERROR - 2014-08-25 04:46:05 --> Severity: Notice  --> Undefined variable: date C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 93
ERROR - 2014-08-25 04:46:05 --> Severity: Notice  --> Undefined variable: date C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 93
ERROR - 2014-08-25 04:46:05 --> Severity: Notice  --> Undefined variable: date C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 93
ERROR - 2014-08-25 04:46:05 --> Severity: Notice  --> Undefined variable: date C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 93
ERROR - 2014-08-25 04:46:05 --> Severity: Notice  --> Undefined variable: month C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 107
ERROR - 2014-08-25 04:46:05 --> Severity: Notice  --> Undefined variable: month C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 107
ERROR - 2014-08-25 04:46:05 --> Severity: Notice  --> Undefined variable: month C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 107
ERROR - 2014-08-25 04:46:05 --> Severity: Notice  --> Undefined variable: month C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 107
ERROR - 2014-08-25 04:46:05 --> Severity: Notice  --> Undefined variable: month C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 107
ERROR - 2014-08-25 04:46:05 --> Severity: Notice  --> Undefined variable: month C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 107
ERROR - 2014-08-25 04:46:05 --> Severity: Notice  --> Undefined variable: month C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 107
ERROR - 2014-08-25 04:46:05 --> Severity: Notice  --> Undefined variable: month C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 107
ERROR - 2014-08-25 04:46:05 --> Severity: Notice  --> Undefined variable: month C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 107
ERROR - 2014-08-25 04:46:05 --> Severity: Notice  --> Undefined variable: month C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 107
ERROR - 2014-08-25 04:46:05 --> Severity: Notice  --> Undefined variable: month C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 107
ERROR - 2014-08-25 04:46:05 --> Severity: Notice  --> Undefined variable: month C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 107
ERROR - 2014-08-25 04:46:05 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 120
ERROR - 2014-08-25 04:46:05 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 120
ERROR - 2014-08-25 04:46:05 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 120
ERROR - 2014-08-25 04:46:05 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 120
ERROR - 2014-08-25 04:46:05 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 120
ERROR - 2014-08-25 04:46:05 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 120
ERROR - 2014-08-25 04:46:05 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 120
ERROR - 2014-08-25 04:46:05 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 120
ERROR - 2014-08-25 04:46:05 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 120
ERROR - 2014-08-25 04:46:05 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 120
ERROR - 2014-08-25 04:46:05 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 120
ERROR - 2014-08-25 04:46:05 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 120
ERROR - 2014-08-25 04:46:05 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 120
ERROR - 2014-08-25 04:46:05 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 120
ERROR - 2014-08-25 04:46:05 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 120
ERROR - 2014-08-25 04:46:05 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 120
ERROR - 2014-08-25 04:46:05 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 120
ERROR - 2014-08-25 04:46:05 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 120
ERROR - 2014-08-25 04:46:05 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 120
ERROR - 2014-08-25 04:46:05 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 120
ERROR - 2014-08-25 04:46:05 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 120
ERROR - 2014-08-25 04:46:05 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 120
ERROR - 2014-08-25 04:46:05 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 120
ERROR - 2014-08-25 04:46:05 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 120
ERROR - 2014-08-25 04:46:05 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 120
ERROR - 2014-08-25 04:46:05 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 120
ERROR - 2014-08-25 04:46:05 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 120
ERROR - 2014-08-25 04:46:05 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 120
ERROR - 2014-08-25 04:46:05 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 120
ERROR - 2014-08-25 04:46:05 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 120
ERROR - 2014-08-25 04:46:05 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 120
ERROR - 2014-08-25 04:46:05 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 120
ERROR - 2014-08-25 04:46:05 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 120
ERROR - 2014-08-25 04:46:05 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 120
ERROR - 2014-08-25 04:46:05 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 120
ERROR - 2014-08-25 04:46:05 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 120
ERROR - 2014-08-25 04:46:05 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 120
ERROR - 2014-08-25 04:46:05 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 120
ERROR - 2014-08-25 04:46:05 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 120
ERROR - 2014-08-25 04:46:05 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 120
ERROR - 2014-08-25 04:46:05 --> Severity: Notice  --> Undefined variable: phone C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 132
ERROR - 2014-08-25 04:46:05 --> Severity: Notice  --> Undefined variable: address C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 137
ERROR - 2014-08-25 04:46:05 --> Severity: Notice  --> Undefined variable: country C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 145
ERROR - 2014-08-25 04:46:05 --> Severity: Notice  --> Undefined variable: province C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 162
ERROR - 2014-08-25 04:46:05 --> Severity: Notice  --> Undefined variable: city C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 179
ERROR - 2014-08-25 04:46:05 --> Severity: Notice  --> Undefined variable: district C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 196
ERROR - 2014-08-25 04:46:05 --> Severity: Notice  --> Undefined variable: postcode C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 210
ERROR - 2014-08-25 04:46:05 --> Severity: Notice  --> Undefined variable: email C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 217
ERROR - 2014-08-25 04:46:05 --> Severity: Notice  --> Undefined variable: is_register C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 257
ERROR - 2014-08-25 04:46:34 --> Severity: Notice  --> Undefined variable: is_register C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 31
ERROR - 2014-08-25 04:46:34 --> Severity: Notice  --> Undefined variable: is_checkout C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 40
ERROR - 2014-08-25 04:46:34 --> Severity: Notice  --> Undefined variable: is_register C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 61
ERROR - 2014-08-25 04:46:34 --> Severity: Notice  --> Undefined variable: name C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 74
ERROR - 2014-08-25 04:46:34 --> Severity: Notice  --> Undefined variable: gender C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 80
ERROR - 2014-08-25 04:46:34 --> Severity: Notice  --> Undefined variable: gender C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 81
ERROR - 2014-08-25 04:46:34 --> Severity: Notice  --> Undefined variable: date C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 91
ERROR - 2014-08-25 04:46:34 --> Severity: Notice  --> Undefined variable: date C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 91
ERROR - 2014-08-25 04:46:34 --> Severity: Notice  --> Undefined variable: date C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 91
ERROR - 2014-08-25 04:46:34 --> Severity: Notice  --> Undefined variable: date C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 91
ERROR - 2014-08-25 04:46:34 --> Severity: Notice  --> Undefined variable: date C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 91
ERROR - 2014-08-25 04:46:34 --> Severity: Notice  --> Undefined variable: date C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 91
ERROR - 2014-08-25 04:46:34 --> Severity: Notice  --> Undefined variable: date C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 91
ERROR - 2014-08-25 04:46:34 --> Severity: Notice  --> Undefined variable: date C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 91
ERROR - 2014-08-25 04:46:34 --> Severity: Notice  --> Undefined variable: date C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 91
ERROR - 2014-08-25 04:46:34 --> Severity: Notice  --> Undefined variable: date C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 91
ERROR - 2014-08-25 04:46:34 --> Severity: Notice  --> Undefined variable: date C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 91
ERROR - 2014-08-25 04:46:34 --> Severity: Notice  --> Undefined variable: date C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 91
ERROR - 2014-08-25 04:46:34 --> Severity: Notice  --> Undefined variable: date C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 91
ERROR - 2014-08-25 04:46:34 --> Severity: Notice  --> Undefined variable: date C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 91
ERROR - 2014-08-25 04:46:34 --> Severity: Notice  --> Undefined variable: date C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 91
ERROR - 2014-08-25 04:46:34 --> Severity: Notice  --> Undefined variable: date C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 91
ERROR - 2014-08-25 04:46:34 --> Severity: Notice  --> Undefined variable: date C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 91
ERROR - 2014-08-25 04:46:34 --> Severity: Notice  --> Undefined variable: date C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 91
ERROR - 2014-08-25 04:46:34 --> Severity: Notice  --> Undefined variable: date C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 91
ERROR - 2014-08-25 04:46:34 --> Severity: Notice  --> Undefined variable: date C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 91
ERROR - 2014-08-25 04:46:34 --> Severity: Notice  --> Undefined variable: date C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 91
ERROR - 2014-08-25 04:46:34 --> Severity: Notice  --> Undefined variable: date C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 91
ERROR - 2014-08-25 04:46:34 --> Severity: Notice  --> Undefined variable: date C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 91
ERROR - 2014-08-25 04:46:34 --> Severity: Notice  --> Undefined variable: date C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 91
ERROR - 2014-08-25 04:46:34 --> Severity: Notice  --> Undefined variable: date C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 91
ERROR - 2014-08-25 04:46:34 --> Severity: Notice  --> Undefined variable: date C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 91
ERROR - 2014-08-25 04:46:34 --> Severity: Notice  --> Undefined variable: date C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 91
ERROR - 2014-08-25 04:46:34 --> Severity: Notice  --> Undefined variable: date C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 91
ERROR - 2014-08-25 04:46:34 --> Severity: Notice  --> Undefined variable: date C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 91
ERROR - 2014-08-25 04:46:34 --> Severity: Notice  --> Undefined variable: date C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 91
ERROR - 2014-08-25 04:46:34 --> Severity: Notice  --> Undefined variable: date C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 91
ERROR - 2014-08-25 04:46:34 --> Severity: Notice  --> Undefined variable: month C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 105
ERROR - 2014-08-25 04:46:34 --> Severity: Notice  --> Undefined variable: month C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 105
ERROR - 2014-08-25 04:46:34 --> Severity: Notice  --> Undefined variable: month C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 105
ERROR - 2014-08-25 04:46:34 --> Severity: Notice  --> Undefined variable: month C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 105
ERROR - 2014-08-25 04:46:34 --> Severity: Notice  --> Undefined variable: month C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 105
ERROR - 2014-08-25 04:46:34 --> Severity: Notice  --> Undefined variable: month C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 105
ERROR - 2014-08-25 04:46:34 --> Severity: Notice  --> Undefined variable: month C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 105
ERROR - 2014-08-25 04:46:34 --> Severity: Notice  --> Undefined variable: month C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 105
ERROR - 2014-08-25 04:46:34 --> Severity: Notice  --> Undefined variable: month C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 105
ERROR - 2014-08-25 04:46:34 --> Severity: Notice  --> Undefined variable: month C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 105
ERROR - 2014-08-25 04:46:34 --> Severity: Notice  --> Undefined variable: month C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 105
ERROR - 2014-08-25 04:46:34 --> Severity: Notice  --> Undefined variable: month C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 105
ERROR - 2014-08-25 04:46:34 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 118
ERROR - 2014-08-25 04:46:34 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 118
ERROR - 2014-08-25 04:46:34 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 118
ERROR - 2014-08-25 04:46:34 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 118
ERROR - 2014-08-25 04:46:34 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 118
ERROR - 2014-08-25 04:46:34 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 118
ERROR - 2014-08-25 04:46:34 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 118
ERROR - 2014-08-25 04:46:34 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 118
ERROR - 2014-08-25 04:46:34 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 118
ERROR - 2014-08-25 04:46:34 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 118
ERROR - 2014-08-25 04:46:34 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 118
ERROR - 2014-08-25 04:46:34 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 118
ERROR - 2014-08-25 04:46:34 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 118
ERROR - 2014-08-25 04:46:34 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 118
ERROR - 2014-08-25 04:46:34 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 118
ERROR - 2014-08-25 04:46:34 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 118
ERROR - 2014-08-25 04:46:34 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 118
ERROR - 2014-08-25 04:46:34 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 118
ERROR - 2014-08-25 04:46:34 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 118
ERROR - 2014-08-25 04:46:34 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 118
ERROR - 2014-08-25 04:46:34 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 118
ERROR - 2014-08-25 04:46:34 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 118
ERROR - 2014-08-25 04:46:34 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 118
ERROR - 2014-08-25 04:46:34 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 118
ERROR - 2014-08-25 04:46:34 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 118
ERROR - 2014-08-25 04:46:34 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 118
ERROR - 2014-08-25 04:46:34 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 118
ERROR - 2014-08-25 04:46:34 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 118
ERROR - 2014-08-25 04:46:34 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 118
ERROR - 2014-08-25 04:46:34 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 118
ERROR - 2014-08-25 04:46:34 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 118
ERROR - 2014-08-25 04:46:34 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 118
ERROR - 2014-08-25 04:46:34 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 118
ERROR - 2014-08-25 04:46:34 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 118
ERROR - 2014-08-25 04:46:34 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 118
ERROR - 2014-08-25 04:46:34 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 118
ERROR - 2014-08-25 04:46:34 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 118
ERROR - 2014-08-25 04:46:34 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 118
ERROR - 2014-08-25 04:46:34 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 118
ERROR - 2014-08-25 04:46:34 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 118
ERROR - 2014-08-25 04:46:34 --> Severity: Notice  --> Undefined variable: phone C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 130
ERROR - 2014-08-25 04:46:34 --> Severity: Notice  --> Undefined variable: address C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 135
ERROR - 2014-08-25 04:46:34 --> Severity: Notice  --> Undefined variable: country C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 143
ERROR - 2014-08-25 04:46:34 --> Severity: Notice  --> Undefined variable: province C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 160
ERROR - 2014-08-25 04:46:34 --> Severity: Notice  --> Undefined variable: city C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 177
ERROR - 2014-08-25 04:46:34 --> Severity: Notice  --> Undefined variable: district C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 194
ERROR - 2014-08-25 04:46:34 --> Severity: Notice  --> Undefined variable: postcode C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 208
ERROR - 2014-08-25 04:46:34 --> Severity: Notice  --> Undefined variable: email C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 215
ERROR - 2014-08-25 04:46:34 --> Severity: Notice  --> Undefined variable: is_register C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 255
ERROR - 2014-08-25 04:47:16 --> Severity: Notice  --> Undefined variable: is_checkout C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 40
ERROR - 2014-08-25 04:47:16 --> Severity: Notice  --> Undefined variable: is_register C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 79
ERROR - 2014-08-25 04:47:24 --> Severity: Notice  --> Undefined variable: is_register C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 78
ERROR - 2014-08-25 04:47:25 --> Severity: Notice  --> Undefined variable: is_register C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 78
ERROR - 2014-08-25 04:48:29 --> Severity: Notice  --> Undefined variable: is_register C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 78
ERROR - 2014-08-25 04:48:47 --> Severity: Notice  --> Undefined variable: is_register C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 78
ERROR - 2014-08-25 04:51:09 --> Severity: Notice  --> Undefined variable: is_register C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 79
ERROR - 2014-08-25 04:53:17 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'gxa_bank' at line 1
ERROR - 2014-08-25 04:53:43 --> Severity: Notice  --> Undefined variable: is_register C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 86
ERROR - 2014-08-25 05:52:45 --> Severity: Notice  --> Undefined variable: is_register C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 86
ERROR - 2014-08-25 05:52:58 --> Severity: Notice  --> Undefined variable: is_register C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 86
ERROR - 2014-08-25 05:53:43 --> Severity: Notice  --> Undefined variable: is_register C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 86
ERROR - 2014-08-25 05:54:15 --> Severity: Notice  --> Undefined variable: is_register C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 97
ERROR - 2014-08-25 05:54:45 --> Severity: Notice  --> Undefined variable: is_register C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 97
ERROR - 2014-08-25 05:55:30 --> Severity: Notice  --> Undefined variable: is_register C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 97
ERROR - 2014-08-25 05:58:10 --> Severity: Notice  --> Undefined variable: is_register C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 106
ERROR - 2014-08-25 05:58:24 --> Severity: Notice  --> Undefined variable: is_register C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 106
ERROR - 2014-08-25 06:00:02 --> Severity: Notice  --> Undefined variable: is_register C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 109
ERROR - 2014-08-25 06:00:08 --> Severity: Notice  --> Undefined variable: is_register C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 109
ERROR - 2014-08-25 06:00:58 --> Severity: Notice  --> Undefined variable: is_register C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 112
ERROR - 2014-08-25 06:01:03 --> Severity: Notice  --> Undefined variable: is_register C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 112
ERROR - 2014-08-25 06:02:42 --> Severity: Notice  --> Undefined variable: is_register C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 118
ERROR - 2014-08-25 06:02:56 --> Severity: Notice  --> Undefined variable: is_register C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 118
ERROR - 2014-08-25 06:03:07 --> Severity: Notice  --> Undefined variable: is_register C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 118
ERROR - 2014-08-25 06:03:36 --> Severity: Notice  --> Undefined variable: is_register C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 118
ERROR - 2014-08-25 06:04:24 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
ERROR - 2014-08-25 06:04:24 --> Severity: Notice  --> Undefined variable: is_register C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 118
ERROR - 2014-08-25 06:04:31 --> Severity: Notice  --> Undefined variable: is_register C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 118
ERROR - 2014-08-25 06:05:03 --> Severity: Notice  --> Undefined variable: is_register C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 118
ERROR - 2014-08-25 06:05:33 --> Severity: Notice  --> Undefined variable: is_register C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 118
ERROR - 2014-08-25 06:05:48 --> Severity: Notice  --> Undefined variable: is_register C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 118
ERROR - 2014-08-25 06:13:56 --> Severity: Notice  --> Undefined variable: is_register C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 118
ERROR - 2014-08-25 06:13:57 --> Severity: Notice  --> Undefined variable: is_register C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 118
ERROR - 2014-08-25 06:14:29 --> You did not select a file to upload.
ERROR - 2014-08-25 06:14:29 --> Severity: Notice  --> Undefined variable: is_register C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 118
ERROR - 2014-08-25 06:15:18 --> Severity: Notice  --> Undefined variable: is_register C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 118
ERROR - 2014-08-25 06:16:27 --> Severity: Notice  --> Undefined variable: is_register C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 119
ERROR - 2014-08-25 06:16:32 --> Severity: Notice  --> Undefined variable: is_register C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 119
ERROR - 2014-08-25 06:17:07 --> Severity: Notice  --> Undefined variable: is_register C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 120
ERROR - 2014-08-25 06:17:30 --> You did not select a file to upload.
ERROR - 2014-08-25 06:17:30 --> Severity: Notice  --> Undefined variable: is_register C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 120
ERROR - 2014-08-25 06:17:39 --> Severity: Notice  --> Undefined variable: is_register C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 120
ERROR - 2014-08-25 06:17:45 --> You did not select a file to upload.
ERROR - 2014-08-25 06:17:45 --> Severity: Notice  --> Undefined variable: is_register C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 120
ERROR - 2014-08-25 06:18:03 --> Severity: Notice  --> Undefined variable: is_register C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 120
ERROR - 2014-08-25 06:18:38 --> Severity: Notice  --> Undefined variable: is_register C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 120
ERROR - 2014-08-25 06:18:53 --> Severity: Notice  --> Undefined variable: is_register C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 120
ERROR - 2014-08-25 06:18:53 --> Severity: Notice  --> Undefined variable: is_register C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 120
ERROR - 2014-08-25 06:18:58 --> The upload path does not appear to be valid.
ERROR - 2014-08-25 06:18:58 --> Severity: Notice  --> Undefined variable: is_register C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 120
ERROR - 2014-08-25 06:19:37 --> The upload path does not appear to be valid.
ERROR - 2014-08-25 06:19:37 --> Severity: Notice  --> Undefined variable: is_register C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 120
ERROR - 2014-08-25 06:20:27 --> Severity: Notice  --> Undefined variable: is_register C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 120
ERROR - 2014-08-25 06:20:36 --> Severity: Notice  --> Undefined variable: is_register C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 120
ERROR - 2014-08-25 06:20:44 --> The upload path does not appear to be valid.
ERROR - 2014-08-25 06:20:44 --> Severity: Notice  --> Undefined variable: is_register C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 120
ERROR - 2014-08-25 06:21:17 --> Severity: Notice  --> Undefined variable: is_register C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 120
ERROR - 2014-08-25 06:21:18 --> Severity: Notice  --> Undefined variable: is_register C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 120
ERROR - 2014-08-25 06:21:29 --> The upload path does not appear to be valid.
ERROR - 2014-08-25 06:21:29 --> Severity: Notice  --> Undefined variable: is_register C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 120
ERROR - 2014-08-25 06:22:33 --> The upload path does not appear to be valid.
ERROR - 2014-08-25 06:22:57 --> Severity: Notice  --> Undefined variable: is_register C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 120
ERROR - 2014-08-25 06:22:58 --> Severity: Notice  --> Undefined variable: is_register C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 120
ERROR - 2014-08-25 06:23:24 --> Severity: Notice  --> Undefined variable: is_register C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 120
ERROR - 2014-08-25 06:24:08 --> Severity: Notice  --> Undefined variable: is_register C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 120
ERROR - 2014-08-25 06:24:34 --> Severity: Notice  --> Undefined variable: is_register C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 120
ERROR - 2014-08-25 06:25:06 --> Severity: Notice  --> Undefined variable: is_register C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 120
ERROR - 2014-08-25 06:26:40 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
ERROR - 2014-08-25 06:26:40 --> Severity: Notice  --> Undefined variable: is_register C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 120
ERROR - 2014-08-25 06:26:46 --> Severity: Notice  --> Undefined variable: is_register C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 120
ERROR - 2014-08-25 06:28:12 --> Severity: Notice  --> Undefined variable: is_register C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 122
ERROR - 2014-08-25 06:28:23 --> Severity: Notice  --> Undefined variable: is_register C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 122
ERROR - 2014-08-25 06:29:37 --> Severity: Notice  --> Undefined variable: is_register C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 123
ERROR - 2014-08-25 06:29:37 --> Severity: Notice  --> Undefined variable: is_register C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 123
ERROR - 2014-08-25 06:31:06 --> Severity: Notice  --> Undefined variable: is_register C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 123
ERROR - 2014-08-25 06:31:17 --> Severity: Notice  --> Undefined variable: is_register C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 123
ERROR - 2014-08-25 06:32:07 --> Severity: Notice  --> Undefined variable: is_register C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 123
ERROR - 2014-08-25 06:32:18 --> Severity: Notice  --> Undefined variable: is_register C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 123
ERROR - 2014-08-25 06:33:04 --> Severity: Notice  --> Undefined variable: is_register C:\wamp\www\Galaxia-Store\application\views\confirm_payment.php 123
ERROR - 2014-08-25 06:38:48 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
ERROR - 2014-08-25 06:39:35 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
ERROR - 2014-08-25 06:41:03 --> 404 Page Not Found --> template
ERROR - 2014-08-25 06:41:03 --> 404 Page Not Found --> template
ERROR - 2014-08-25 06:41:03 --> 404 Page Not Found --> template
ERROR - 2014-08-25 06:41:03 --> 404 Page Not Found --> template
ERROR - 2014-08-25 06:41:03 --> 404 Page Not Found --> template
ERROR - 2014-08-25 06:41:03 --> 404 Page Not Found --> template
ERROR - 2014-08-25 06:41:03 --> 404 Page Not Found --> template
ERROR - 2014-08-25 06:41:03 --> 404 Page Not Found --> template
ERROR - 2014-08-25 06:41:03 --> 404 Page Not Found --> template
ERROR - 2014-08-25 06:41:06 --> 404 Page Not Found --> template
ERROR - 2014-08-25 06:41:37 --> 404 Page Not Found --> template
ERROR - 2014-08-25 06:41:37 --> 404 Page Not Found --> template
ERROR - 2014-08-25 06:41:37 --> 404 Page Not Found --> template
ERROR - 2014-08-25 06:41:37 --> 404 Page Not Found --> template
ERROR - 2014-08-25 06:41:37 --> 404 Page Not Found --> template
ERROR - 2014-08-25 06:41:37 --> 404 Page Not Found --> template
ERROR - 2014-08-25 06:41:37 --> 404 Page Not Found --> template
ERROR - 2014-08-25 06:41:37 --> 404 Page Not Found --> template
ERROR - 2014-08-25 06:41:37 --> 404 Page Not Found --> template
ERROR - 2014-08-25 06:41:37 --> 404 Page Not Found --> template
ERROR - 2014-08-25 06:41:37 --> 404 Page Not Found --> template
ERROR - 2014-08-25 06:41:37 --> 404 Page Not Found --> template
ERROR - 2014-08-25 06:41:37 --> 404 Page Not Found --> template
ERROR - 2014-08-25 06:41:37 --> 404 Page Not Found --> template
ERROR - 2014-08-25 06:41:37 --> 404 Page Not Found --> template
ERROR - 2014-08-25 06:41:37 --> 404 Page Not Found --> template
ERROR - 2014-08-25 06:41:37 --> 404 Page Not Found --> template
ERROR - 2014-08-25 06:41:37 --> 404 Page Not Found --> template
ERROR - 2014-08-25 06:41:37 --> 404 Page Not Found --> template
ERROR - 2014-08-25 06:41:37 --> 404 Page Not Found --> template
ERROR - 2014-08-25 06:41:37 --> 404 Page Not Found --> template
ERROR - 2014-08-25 06:41:37 --> 404 Page Not Found --> template
ERROR - 2014-08-25 06:41:38 --> 404 Page Not Found --> template
ERROR - 2014-08-25 06:41:38 --> 404 Page Not Found --> template
ERROR - 2014-08-25 06:41:38 --> 404 Page Not Found --> template
ERROR - 2014-08-25 06:41:38 --> 404 Page Not Found --> template
ERROR - 2014-08-25 06:41:38 --> 404 Page Not Found --> template
ERROR - 2014-08-25 06:41:38 --> 404 Page Not Found --> template
ERROR - 2014-08-25 06:41:38 --> 404 Page Not Found --> template
ERROR - 2014-08-25 06:41:38 --> 404 Page Not Found --> template
ERROR - 2014-08-25 06:41:38 --> 404 Page Not Found --> template
ERROR - 2014-08-25 06:41:39 --> 404 Page Not Found --> template
ERROR - 2014-08-25 06:48:31 --> Severity: Notice  --> Undefined index: username C:\wamp\www\Galaxia-Store\application\views\login.php 20
ERROR - 2014-08-25 07:54:19 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
ERROR - 2014-08-25 08:51:49 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
ERROR - 2014-08-25 08:52:03 --> You did not select a file to upload.
ERROR - 2014-08-25 08:55:36 --> You did not select a file to upload.
