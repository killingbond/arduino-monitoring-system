<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-03-20 00:00:05 --> 404 Page Not Found --> template
ERROR - 2015-03-20 00:00:29 --> 404 Page Not Found --> template
ERROR - 2015-03-20 00:00:43 --> 404 Page Not Found --> template
ERROR - 2015-03-20 00:00:59 --> 404 Page Not Found --> template
ERROR - 2015-03-20 02:38:08 --> 404 Page Not Found --> template
