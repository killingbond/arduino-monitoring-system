<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-03-25 00:00:13 --> 404 Page Not Found --> template
