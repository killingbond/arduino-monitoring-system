<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2016-11-30 08:25:22 --> Severity: Notice  --> Undefined variable: notification_order /home/tirtadah/public_html/t1rta/application/views/slices/sidebar.php 85
ERROR - 2016-11-30 08:25:22 --> Severity: Notice  --> Undefined variable: notification_order /home/tirtadah/public_html/t1rta/application/views/slices/sidebar.php 98
ERROR - 2016-11-30 23:48:52 --> Severity: Notice  --> Undefined variable: notification_order /home/tirtadah/public_html/t1rta/application/views/slices/sidebar.php 85
ERROR - 2016-11-30 23:48:52 --> Severity: Notice  --> Undefined variable: notification_order /home/tirtadah/public_html/t1rta/application/views/slices/sidebar.php 98
