<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-03-09 05:16:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 05:16:51 --> 404 Page Not Found --> template
ERROR - 2015-03-09 05:19:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 05:19:57 --> Severity: Notice  --> Undefined variable: sidebar_widget /Applications/MAMP/htdocs/Esgotado/application/views/block/footer.php 9
ERROR - 2015-03-09 05:19:57 --> 404 Page Not Found --> template
ERROR - 2015-03-09 05:20:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 05:20:23 --> 404 Page Not Found --> template
ERROR - 2015-03-09 05:30:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 05:30:34 --> 404 Page Not Found --> template
ERROR - 2015-03-09 05:31:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 05:31:17 --> 404 Page Not Found --> template
ERROR - 2015-03-09 05:31:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 05:31:48 --> 404 Page Not Found --> template
ERROR - 2015-03-09 05:32:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 05:32:15 --> 404 Page Not Found --> template
ERROR - 2015-03-09 05:33:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 05:33:18 --> 404 Page Not Found --> template
ERROR - 2015-03-09 05:34:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 05:34:17 --> 404 Page Not Found --> template
ERROR - 2015-03-09 05:34:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 05:34:31 --> 404 Page Not Found --> template
ERROR - 2015-03-09 05:34:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 05:34:43 --> 404 Page Not Found --> template
ERROR - 2015-03-09 05:34:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 05:34:59 --> 404 Page Not Found --> template
ERROR - 2015-03-09 05:35:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 05:35:00 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/Esgotado/application/controllers/autoload.php:33) /Applications/MAMP/htdocs/Esgotado/system/core/Output.php 391
ERROR - 2015-03-09 05:35:00 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/Esgotado/application/controllers/autoload.php:33) /Applications/MAMP/htdocs/Esgotado/system/core/Output.php 391
ERROR - 2015-03-09 05:35:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 05:35:13 --> 404 Page Not Found --> template
ERROR - 2015-03-09 05:35:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 05:35:20 --> 404 Page Not Found --> template
ERROR - 2015-03-09 05:35:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 05:35:22 --> 404 Page Not Found --> template
ERROR - 2015-03-09 05:35:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 05:35:24 --> 404 Page Not Found --> template
ERROR - 2015-03-09 05:36:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 05:36:52 --> 404 Page Not Found --> template
ERROR - 2015-03-09 05:39:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 05:39:29 --> 404 Page Not Found --> template
ERROR - 2015-03-09 05:39:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 05:39:49 --> 404 Page Not Found --> template
ERROR - 2015-03-09 05:40:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 05:40:37 --> 404 Page Not Found --> template
ERROR - 2015-03-09 05:41:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 05:41:07 --> 404 Page Not Found --> template
ERROR - 2015-03-09 05:41:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 05:41:26 --> 404 Page Not Found --> template
ERROR - 2015-03-09 05:41:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 05:41:30 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/Esgotado/application/controllers/autoload.php:33) /Applications/MAMP/htdocs/Esgotado/system/core/Output.php 391
ERROR - 2015-03-09 05:41:30 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/Esgotado/application/controllers/autoload.php:33) /Applications/MAMP/htdocs/Esgotado/system/core/Output.php 391
ERROR - 2015-03-09 05:43:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 05:43:34 --> 404 Page Not Found --> template
ERROR - 2015-03-09 05:43:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 05:43:37 --> 404 Page Not Found --> template
ERROR - 2015-03-09 05:43:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 05:43:38 --> 404 Page Not Found --> template
ERROR - 2015-03-09 05:43:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 05:43:39 --> 404 Page Not Found --> template
ERROR - 2015-03-09 06:01:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 06:01:20 --> 404 Page Not Found --> template
ERROR - 2015-03-09 06:01:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 06:01:39 --> 404 Page Not Found --> template
ERROR - 2015-03-09 06:02:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 06:02:06 --> 404 Page Not Found --> template
ERROR - 2015-03-09 06:02:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 06:02:18 --> 404 Page Not Found --> template
ERROR - 2015-03-09 06:03:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 06:03:54 --> 404 Page Not Found --> template
ERROR - 2015-03-09 06:05:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 06:05:10 --> 404 Page Not Found --> template
ERROR - 2015-03-09 06:06:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 06:06:38 --> 404 Page Not Found --> template
ERROR - 2015-03-09 06:08:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 06:08:32 --> 404 Page Not Found --> template
ERROR - 2015-03-09 06:09:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 06:09:32 --> 404 Page Not Found --> template
ERROR - 2015-03-09 06:11:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 06:11:26 --> 404 Page Not Found --> template
ERROR - 2015-03-09 06:11:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 06:11:32 --> 404 Page Not Found --> template
ERROR - 2015-03-09 06:11:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 06:11:33 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/Esgotado/application/controllers/autoload.php:33) /Applications/MAMP/htdocs/Esgotado/system/core/Output.php 391
ERROR - 2015-03-09 06:11:33 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/Esgotado/application/controllers/autoload.php:33) /Applications/MAMP/htdocs/Esgotado/system/core/Output.php 391
ERROR - 2015-03-09 06:12:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 06:12:52 --> 404 Page Not Found --> template
ERROR - 2015-03-09 06:12:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 06:14:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 06:14:26 --> 404 Page Not Found --> template
ERROR - 2015-03-09 06:14:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 06:14:28 --> 404 Page Not Found --> template
ERROR - 2015-03-09 06:15:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 06:15:39 --> 404 Page Not Found --> template
ERROR - 2015-03-09 06:16:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 06:16:16 --> 404 Page Not Found --> template
ERROR - 2015-03-09 06:16:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 06:16:17 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/Esgotado/application/controllers/autoload.php:33) /Applications/MAMP/htdocs/Esgotado/system/core/Output.php 391
ERROR - 2015-03-09 06:16:17 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/Esgotado/application/controllers/autoload.php:33) /Applications/MAMP/htdocs/Esgotado/system/core/Output.php 391
ERROR - 2015-03-09 06:17:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 06:17:07 --> 404 Page Not Found --> template
ERROR - 2015-03-09 06:18:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 06:18:24 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/Esgotado/application/controllers/autoload.php:33) /Applications/MAMP/htdocs/Esgotado/system/core/Output.php 391
ERROR - 2015-03-09 06:18:24 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/Esgotado/application/controllers/autoload.php:33) /Applications/MAMP/htdocs/Esgotado/system/core/Output.php 391
ERROR - 2015-03-09 06:19:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 06:19:46 --> 404 Page Not Found --> template
ERROR - 2015-03-09 06:20:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 06:20:18 --> 404 Page Not Found --> template
ERROR - 2015-03-09 06:20:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 06:20:21 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/Esgotado/application/controllers/autoload.php:33) /Applications/MAMP/htdocs/Esgotado/system/core/Output.php 391
ERROR - 2015-03-09 06:20:21 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/Esgotado/application/controllers/autoload.php:33) /Applications/MAMP/htdocs/Esgotado/system/core/Output.php 391
ERROR - 2015-03-09 06:20:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 06:20:31 --> 404 Page Not Found --> template
ERROR - 2015-03-09 06:20:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 06:20:35 --> 404 Page Not Found --> template
ERROR - 2015-03-09 06:20:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 06:20:48 --> 404 Page Not Found --> template
ERROR - 2015-03-09 06:22:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 06:22:57 --> 404 Page Not Found --> template
ERROR - 2015-03-09 06:24:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 06:24:23 --> 404 Page Not Found --> template
ERROR - 2015-03-09 06:26:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 06:26:45 --> 404 Page Not Found --> template
ERROR - 2015-03-09 06:27:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 06:27:03 --> 404 Page Not Found --> template
ERROR - 2015-03-09 07:05:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 07:05:32 --> 404 Page Not Found --> template
ERROR - 2015-03-09 07:05:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 07:05:51 --> 404 Page Not Found --> template
ERROR - 2015-03-09 07:05:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 07:05:55 --> 404 Page Not Found --> template
ERROR - 2015-03-09 07:06:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 07:06:41 --> 404 Page Not Found --> template
ERROR - 2015-03-09 07:07:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 07:07:05 --> 404 Page Not Found --> template
ERROR - 2015-03-09 07:07:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 07:07:57 --> 404 Page Not Found --> template
ERROR - 2015-03-09 07:08:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 07:08:45 --> 404 Page Not Found --> template
ERROR - 2015-03-09 07:10:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 07:10:21 --> 404 Page Not Found --> template
ERROR - 2015-03-09 07:11:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 07:11:25 --> 404 Page Not Found --> template
ERROR - 2015-03-09 07:11:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 07:11:41 --> 404 Page Not Found --> template
ERROR - 2015-03-09 07:50:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 07:50:45 --> 404 Page Not Found --> template
ERROR - 2015-03-09 07:51:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 07:51:08 --> 404 Page Not Found --> template
ERROR - 2015-03-09 07:51:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 07:51:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 07:51:16 --> 404 Page Not Found --> template
ERROR - 2015-03-09 07:51:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 07:51:18 --> 404 Page Not Found --> template
ERROR - 2015-03-09 07:51:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 07:51:20 --> 404 Page Not Found --> template
ERROR - 2015-03-09 07:51:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 07:51:23 --> 404 Page Not Found --> template
ERROR - 2015-03-09 07:53:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 07:53:56 --> 404 Page Not Found --> template
ERROR - 2015-03-09 07:54:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 07:54:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 07:55:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 07:55:17 --> 404 Page Not Found --> template
ERROR - 2015-03-09 07:55:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 07:55:19 --> 404 Page Not Found --> template
ERROR - 2015-03-09 07:55:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 07:55:22 --> 404 Page Not Found --> template
ERROR - 2015-03-09 07:55:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 07:55:58 --> 404 Page Not Found --> template
ERROR - 2015-03-09 07:56:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 07:56:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 07:56:15 --> 404 Page Not Found --> template
ERROR - 2015-03-09 07:57:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 07:57:13 --> 404 Page Not Found --> template
ERROR - 2015-03-09 07:58:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 07:58:20 --> 404 Page Not Found --> template
ERROR - 2015-03-09 07:58:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 07:58:47 --> 404 Page Not Found --> template
ERROR - 2015-03-09 07:59:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 07:59:16 --> 404 Page Not Found --> template
ERROR - 2015-03-09 07:59:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 07:59:29 --> 404 Page Not Found --> template
ERROR - 2015-03-09 07:59:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 07:59:33 --> 404 Page Not Found --> template
ERROR - 2015-03-09 07:59:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 07:59:34 --> 404 Page Not Found --> template
ERROR - 2015-03-09 07:59:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 07:59:36 --> 404 Page Not Found --> template
ERROR - 2015-03-09 07:59:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 07:59:37 --> 404 Page Not Found --> template
ERROR - 2015-03-09 07:59:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 07:59:42 --> 404 Page Not Found --> template
ERROR - 2015-03-09 07:59:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 07:59:43 --> 404 Page Not Found --> template
ERROR - 2015-03-09 07:59:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 07:59:54 --> 404 Page Not Found --> template
ERROR - 2015-03-09 08:00:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 08:00:09 --> 404 Page Not Found --> template
ERROR - 2015-03-09 08:00:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 08:00:14 --> 404 Page Not Found --> template
ERROR - 2015-03-09 08:00:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 08:00:28 --> 404 Page Not Found --> template
ERROR - 2015-03-09 08:01:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 08:01:02 --> 404 Page Not Found --> template
ERROR - 2015-03-09 08:01:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 08:01:20 --> 404 Page Not Found --> template
ERROR - 2015-03-09 08:01:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 08:01:56 --> 404 Page Not Found --> template
ERROR - 2015-03-09 08:02:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 08:02:38 --> 404 Page Not Found --> template
ERROR - 2015-03-09 08:02:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 08:02:51 --> 404 Page Not Found --> template
ERROR - 2015-03-09 08:03:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 08:03:04 --> 404 Page Not Found --> template
ERROR - 2015-03-09 08:06:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 08:06:36 --> 404 Page Not Found --> template
ERROR - 2015-03-09 08:07:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 08:07:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 08:07:07 --> 404 Page Not Found --> template
ERROR - 2015-03-09 08:07:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 08:07:57 --> 404 Page Not Found --> template
ERROR - 2015-03-09 08:08:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 08:08:18 --> 404 Page Not Found --> template
ERROR - 2015-03-09 08:08:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 08:08:22 --> 404 Page Not Found --> template
ERROR - 2015-03-09 08:08:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 08:08:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 08:08:31 --> 404 Page Not Found --> template
ERROR - 2015-03-09 08:08:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 08:08:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 08:08:37 --> 404 Page Not Found --> template
ERROR - 2015-03-09 08:08:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 08:08:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 08:08:43 --> 404 Page Not Found --> template
ERROR - 2015-03-09 08:08:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 08:08:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 08:08:52 --> 404 Page Not Found --> template
ERROR - 2015-03-09 08:08:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 08:08:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 08:08:59 --> 404 Page Not Found --> template
ERROR - 2015-03-09 08:10:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 08:10:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 08:10:07 --> 404 Page Not Found --> template
ERROR - 2015-03-09 08:11:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 08:11:11 --> 404 Page Not Found --> template
ERROR - 2015-03-09 08:11:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 08:11:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 08:11:16 --> 404 Page Not Found --> template
ERROR - 2015-03-09 08:11:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 08:11:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 08:11:29 --> 404 Page Not Found --> template
ERROR - 2015-03-09 08:11:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 08:11:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 08:11:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 08:11:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 08:11:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 08:11:59 --> 404 Page Not Found --> template
ERROR - 2015-03-09 08:12:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 08:12:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 08:12:09 --> 404 Page Not Found --> template
ERROR - 2015-03-09 08:12:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 08:12:15 --> 404 Page Not Found --> template
ERROR - 2015-03-09 08:13:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 08:13:43 --> 404 Page Not Found --> template
ERROR - 2015-03-09 08:14:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 08:14:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 08:14:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 08:14:48 --> 404 Page Not Found --> template
ERROR - 2015-03-09 08:16:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 08:16:29 --> 404 Page Not Found --> template
ERROR - 2015-03-09 08:16:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 08:16:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 08:16:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 08:16:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 08:16:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 08:16:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 08:16:45 --> 404 Page Not Found --> template
ERROR - 2015-03-09 08:17:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 08:17:20 --> 404 Page Not Found --> template
ERROR - 2015-03-09 08:17:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 08:17:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 08:17:25 --> 404 Page Not Found --> template
ERROR - 2015-03-09 08:17:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 08:17:26 --> 404 Page Not Found --> template
ERROR - 2015-03-09 08:17:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 08:17:51 --> 404 Page Not Found --> template
ERROR - 2015-03-09 08:18:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 08:18:07 --> 404 Page Not Found --> template
ERROR - 2015-03-09 08:18:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 08:18:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 08:18:12 --> 404 Page Not Found --> template
ERROR - 2015-03-09 08:18:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 08:18:17 --> 404 Page Not Found --> template
ERROR - 2015-03-09 08:22:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 08:22:19 --> Severity: Notice  --> Undefined variable: is_checkout /Applications/MAMP/htdocs/Esgotado/application/views/member/edit_password.php 51
ERROR - 2015-03-09 08:22:20 --> 404 Page Not Found --> template
ERROR - 2015-03-09 08:22:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 08:22:29 --> 404 Page Not Found --> template
ERROR - 2015-03-09 08:23:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 08:23:12 --> 404 Page Not Found --> template
ERROR - 2015-03-09 08:23:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 08:23:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 08:23:16 --> 404 Page Not Found --> template
ERROR - 2015-03-09 08:26:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 08:26:12 --> 404 Page Not Found --> template
ERROR - 2015-03-09 08:26:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 08:26:32 --> 404 Page Not Found --> template
ERROR - 2015-03-09 08:27:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 08:27:05 --> 404 Page Not Found --> template
ERROR - 2015-03-09 08:27:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 08:27:44 --> 404 Page Not Found --> template
ERROR - 2015-03-09 08:27:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 08:27:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 08:27:59 --> 404 Page Not Found --> template
ERROR - 2015-03-09 08:36:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 08:36:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 08:36:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 08:37:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 08:37:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 08:37:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 08:37:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 08:37:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 08:37:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 08:37:47 --> 404 Page Not Found --> template
ERROR - 2015-03-09 08:37:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 08:37:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 08:37:56 --> 404 Page Not Found --> template
ERROR - 2015-03-09 08:38:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 08:38:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 08:38:25 --> 404 Page Not Found --> template
ERROR - 2015-03-09 08:39:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 08:39:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 08:39:22 --> 404 Page Not Found --> template
ERROR - 2015-03-09 08:40:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 08:41:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 08:43:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 08:43:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 08:47:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 08:47:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 08:49:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 08:49:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 08:49:55 --> 404 Page Not Found --> template
ERROR - 2015-03-09 08:50:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 08:50:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 08:50:08 --> 404 Page Not Found --> template
ERROR - 2015-03-09 08:50:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 08:50:27 --> 404 Page Not Found --> template
ERROR - 2015-03-09 08:50:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 08:50:49 --> 404 Page Not Found --> template
ERROR - 2015-03-09 08:50:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 08:50:54 --> 404 Page Not Found --> template
ERROR - 2015-03-09 08:50:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 08:50:58 --> 404 Page Not Found --> template
ERROR - 2015-03-09 08:51:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 08:51:17 --> 404 Page Not Found --> template
ERROR - 2015-03-09 08:51:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 08:51:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 08:51:59 --> 404 Page Not Found --> template
ERROR - 2015-03-09 08:52:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 08:52:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 08:52:12 --> 404 Page Not Found --> template
ERROR - 2015-03-09 08:52:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 08:52:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 08:52:20 --> 404 Page Not Found --> template
ERROR - 2015-03-09 08:52:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 08:52:22 --> 404 Page Not Found --> template
ERROR - 2015-03-09 08:52:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 08:52:44 --> 404 Page Not Found --> template
ERROR - 2015-03-09 08:52:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 08:52:48 --> 404 Page Not Found --> template
ERROR - 2015-03-09 08:52:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 08:52:53 --> 404 Page Not Found --> template
ERROR - 2015-03-09 08:52:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 08:52:55 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/Esgotado/application/controllers/autoload.php:33) /Applications/MAMP/htdocs/Esgotado/system/core/Output.php 391
ERROR - 2015-03-09 08:52:55 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/Esgotado/application/controllers/autoload.php:33) /Applications/MAMP/htdocs/Esgotado/system/core/Output.php 391
ERROR - 2015-03-09 08:52:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 08:52:57 --> 404 Page Not Found --> template
ERROR - 2015-03-09 08:52:57 --> 404 Page Not Found --> my_js
ERROR - 2015-03-09 08:53:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 08:53:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 08:53:00 --> Severity: Notice  --> Undefined variable: percent_ppn /Applications/MAMP/htdocs/Esgotado/application/views/cart.php 137
ERROR - 2015-03-09 08:53:00 --> Severity: Notice  --> Undefined variable: ppn /Applications/MAMP/htdocs/Esgotado/application/views/cart.php 137
ERROR - 2015-03-09 08:53:00 --> 404 Page Not Found --> template
ERROR - 2015-03-09 08:53:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 08:53:07 --> 404 Page Not Found --> template
ERROR - 2015-03-09 08:53:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 08:53:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 08:53:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 08:53:12 --> 404 Page Not Found --> template
ERROR - 2015-03-09 08:53:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 08:53:24 --> 404 Page Not Found --> template
ERROR - 2015-03-09 08:53:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 08:53:29 --> 404 Page Not Found --> template
ERROR - 2015-03-09 08:53:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 08:53:41 --> 404 Page Not Found --> template
ERROR - 2015-03-09 08:53:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 08:53:44 --> Severity: Notice  --> Undefined variable: percent_ppn /Applications/MAMP/htdocs/Esgotado/application/views/cart.php 137
ERROR - 2015-03-09 08:53:44 --> Severity: Notice  --> Undefined variable: ppn /Applications/MAMP/htdocs/Esgotado/application/views/cart.php 137
ERROR - 2015-03-09 08:53:44 --> 404 Page Not Found --> template
ERROR - 2015-03-09 08:58:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 08:58:13 --> Severity: Notice  --> Undefined variable: percent_ppn /Applications/MAMP/htdocs/Esgotado/application/views/cart.php 138
ERROR - 2015-03-09 08:58:13 --> Severity: Notice  --> Undefined variable: ppn /Applications/MAMP/htdocs/Esgotado/application/views/cart.php 138
ERROR - 2015-03-09 08:58:14 --> 404 Page Not Found --> template
ERROR - 2015-03-09 08:58:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 08:58:48 --> Severity: Notice  --> Undefined variable: percent_ppn /Applications/MAMP/htdocs/Esgotado/application/views/cart.php 138
ERROR - 2015-03-09 08:58:48 --> Severity: Notice  --> Undefined variable: ppn /Applications/MAMP/htdocs/Esgotado/application/views/cart.php 138
ERROR - 2015-03-09 08:58:48 --> 404 Page Not Found --> template
ERROR - 2015-03-09 08:59:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 08:59:34 --> Severity: Notice  --> Undefined variable: percent_ppn /Applications/MAMP/htdocs/Esgotado/application/views/cart.php 138
ERROR - 2015-03-09 08:59:34 --> Severity: Notice  --> Undefined variable: ppn /Applications/MAMP/htdocs/Esgotado/application/views/cart.php 138
ERROR - 2015-03-09 08:59:34 --> 404 Page Not Found --> template
ERROR - 2015-03-09 08:59:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 08:59:45 --> 404 Page Not Found --> template
ERROR - 2015-03-09 08:59:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 08:59:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:00:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:00:58 --> 404 Page Not Found --> template
ERROR - 2015-03-09 09:00:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:00:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:02:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:02:39 --> 404 Page Not Found --> template
ERROR - 2015-03-09 09:02:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:02:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:04:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:04:14 --> 404 Page Not Found --> template
ERROR - 2015-03-09 09:04:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:04:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:04:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:04:56 --> 404 Page Not Found --> template
ERROR - 2015-03-09 09:04:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:04:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:05:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:05:12 --> 404 Page Not Found --> template
ERROR - 2015-03-09 09:05:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:05:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:06:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:06:33 --> 404 Page Not Found --> template
ERROR - 2015-03-09 09:06:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:06:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:06:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:06:43 --> 404 Page Not Found --> template
ERROR - 2015-03-09 09:06:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:06:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:07:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:07:27 --> 404 Page Not Found --> template
ERROR - 2015-03-09 09:07:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:07:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:07:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:07:44 --> 404 Page Not Found --> template
ERROR - 2015-03-09 09:07:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:07:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:08:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:08:02 --> 404 Page Not Found --> template
ERROR - 2015-03-09 09:08:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:08:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:08:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:08:16 --> 404 Page Not Found --> template
ERROR - 2015-03-09 09:08:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:08:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:08:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:08:27 --> 404 Page Not Found --> template
ERROR - 2015-03-09 09:08:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:08:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:10:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:10:03 --> 404 Page Not Found --> template
ERROR - 2015-03-09 09:10:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:10:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:10:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:10:22 --> 404 Page Not Found --> template
ERROR - 2015-03-09 09:10:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:10:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:10:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:10:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:10:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:10:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:10:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:10:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:10:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:10:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:10:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:10:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:10:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:10:41 --> 404 Page Not Found --> template
ERROR - 2015-03-09 09:10:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:10:45 --> 404 Page Not Found --> template
ERROR - 2015-03-09 09:10:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:10:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:11:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:11:50 --> 404 Page Not Found --> template
ERROR - 2015-03-09 09:11:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:11:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:13:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:13:10 --> 404 Page Not Found --> template
ERROR - 2015-03-09 09:13:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:13:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:13:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:13:19 --> 404 Page Not Found --> template
ERROR - 2015-03-09 09:13:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:13:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:15:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:15:22 --> 404 Page Not Found --> template
ERROR - 2015-03-09 09:15:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:15:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:16:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:16:12 --> 404 Page Not Found --> template
ERROR - 2015-03-09 09:16:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:16:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:17:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:17:38 --> 404 Page Not Found --> template
ERROR - 2015-03-09 09:17:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:17:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:17:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:17:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:17:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:17:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:18:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:18:18 --> 404 Page Not Found --> template
ERROR - 2015-03-09 09:18:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:18:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:18:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:18:41 --> 404 Page Not Found --> template
ERROR - 2015-03-09 09:18:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:18:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:18:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:18:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:18:53 --> 404 Page Not Found --> template
ERROR - 2015-03-09 09:19:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:19:04 --> 404 Page Not Found --> template
ERROR - 2015-03-09 09:19:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:19:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:19:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:19:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:19:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:19:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:19:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:19:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:19:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:19:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:19:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:19:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:22:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:22:37 --> 404 Page Not Found --> template
ERROR - 2015-03-09 09:22:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:22:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:22:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:22:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:22:39 --> 404 Page Not Found --> template
ERROR - 2015-03-09 09:22:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:22:53 --> 404 Page Not Found --> template
ERROR - 2015-03-09 09:24:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:24:28 --> 404 Page Not Found --> template
ERROR - 2015-03-09 09:24:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:24:43 --> 404 Page Not Found --> template
ERROR - 2015-03-09 09:25:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:25:27 --> 404 Page Not Found --> template
ERROR - 2015-03-09 09:26:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:26:52 --> 404 Page Not Found --> template
ERROR - 2015-03-09 09:30:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:30:36 --> 404 Page Not Found --> template
ERROR - 2015-03-09 09:30:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:30:51 --> 404 Page Not Found --> template
ERROR - 2015-03-09 09:30:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:30:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:31:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:31:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:31:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:31:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:31:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:31:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:31:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:31:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:31:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:31:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:31:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:31:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:31:41 --> 404 Page Not Found --> template
ERROR - 2015-03-09 09:32:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:32:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:32:06 --> 404 Page Not Found --> template
ERROR - 2015-03-09 09:34:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:34:48 --> 404 Page Not Found --> template
ERROR - 2015-03-09 09:34:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:34:50 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/Esgotado/application/controllers/autoload.php:33) /Applications/MAMP/htdocs/Esgotado/system/core/Output.php 391
ERROR - 2015-03-09 09:34:50 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/Esgotado/application/controllers/autoload.php:33) /Applications/MAMP/htdocs/Esgotado/system/core/Output.php 391
ERROR - 2015-03-09 09:34:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:34:52 --> 404 Page Not Found --> template
ERROR - 2015-03-09 09:34:52 --> 404 Page Not Found --> my_js
ERROR - 2015-03-09 09:34:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:34:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:34:55 --> Severity: Notice  --> Undefined variable: percent_ppn /Applications/MAMP/htdocs/Esgotado/application/views/cart.php 138
ERROR - 2015-03-09 09:34:55 --> Severity: Notice  --> Undefined variable: ppn /Applications/MAMP/htdocs/Esgotado/application/views/cart.php 138
ERROR - 2015-03-09 09:34:55 --> 404 Page Not Found --> template
ERROR - 2015-03-09 09:34:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:34:57 --> 404 Page Not Found --> template
ERROR - 2015-03-09 09:34:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:34:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:35:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:35:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:35:01 --> 404 Page Not Found --> template
ERROR - 2015-03-09 09:35:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:35:09 --> 404 Page Not Found --> template
ERROR - 2015-03-09 09:39:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:39:33 --> 404 Page Not Found --> template
ERROR - 2015-03-09 09:39:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:39:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:40:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:40:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:40:21 --> 404 Page Not Found --> template
ERROR - 2015-03-09 09:40:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:40:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:40:24 --> 404 Page Not Found --> template
ERROR - 2015-03-09 09:41:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:41:42 --> 404 Page Not Found --> template
ERROR - 2015-03-09 09:41:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:41:43 --> 404 Page Not Found --> template
ERROR - 2015-03-09 09:41:43 --> 404 Page Not Found --> my_js
ERROR - 2015-03-09 09:41:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:41:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:41:51 --> Severity: Notice  --> Undefined variable: percent_ppn /Applications/MAMP/htdocs/Esgotado/application/views/cart.php 138
ERROR - 2015-03-09 09:41:51 --> Severity: Notice  --> Undefined variable: ppn /Applications/MAMP/htdocs/Esgotado/application/views/cart.php 138
ERROR - 2015-03-09 09:41:51 --> 404 Page Not Found --> template
ERROR - 2015-03-09 09:41:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:41:56 --> 404 Page Not Found --> template
ERROR - 2015-03-09 09:41:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:41:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:42:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:42:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:42:02 --> 404 Page Not Found --> template
ERROR - 2015-03-09 09:42:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:43:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:44:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:44:01 --> 404 Page Not Found --> template
ERROR - 2015-03-09 09:44:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:44:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:44:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:44:22 --> 404 Page Not Found --> template
ERROR - 2015-03-09 09:44:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:47:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:48:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:48:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 09:48:04 --> 404 Page Not Found --> template
ERROR - 2015-03-09 10:17:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 10:17:06 --> 404 Page Not Found --> template
ERROR - 2015-03-09 10:17:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 10:17:32 --> 404 Page Not Found --> template
ERROR - 2015-03-09 10:17:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 10:17:47 --> 404 Page Not Found --> template
ERROR - 2015-03-09 10:18:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 10:18:39 --> 404 Page Not Found --> template
ERROR - 2015-03-09 10:18:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 10:18:47 --> 404 Page Not Found --> template
ERROR - 2015-03-09 10:18:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 10:18:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 10:18:55 --> 404 Page Not Found --> template
ERROR - 2015-03-09 10:18:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 10:18:58 --> 404 Page Not Found --> template
ERROR - 2015-03-09 10:19:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 10:19:06 --> 404 Page Not Found --> template
ERROR - 2015-03-09 10:19:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 10:19:07 --> 404 Page Not Found --> template
ERROR - 2015-03-09 10:19:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 10:19:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 10:19:12 --> 404 Page Not Found --> template
ERROR - 2015-03-09 10:19:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 10:19:16 --> 404 Page Not Found --> template
ERROR - 2015-03-09 10:19:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 10:19:17 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/Esgotado/application/controllers/autoload.php:33) /Applications/MAMP/htdocs/Esgotado/system/core/Output.php 391
ERROR - 2015-03-09 10:19:17 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/Esgotado/application/controllers/autoload.php:33) /Applications/MAMP/htdocs/Esgotado/system/core/Output.php 391
ERROR - 2015-03-09 10:22:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 10:22:19 --> 404 Page Not Found --> template
ERROR - 2015-03-09 10:22:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 10:22:21 --> 404 Page Not Found --> my_js
ERROR - 2015-03-09 10:22:21 --> 404 Page Not Found --> template
ERROR - 2015-03-09 10:22:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 10:23:25 --> Query error: Lock wait timeout exceeded; try restarting transaction
ERROR - 2015-03-09 10:23:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 10:23:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 10:24:37 --> Query error: Lock wait timeout exceeded; try restarting transaction
ERROR - 2015-03-09 10:26:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 10:26:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 10:26:36 --> 404 Page Not Found --> template
ERROR - 2015-03-09 10:26:36 --> 404 Page Not Found --> my_js
ERROR - 2015-03-09 10:26:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 10:26:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 10:26:46 --> Severity: Notice  --> Undefined variable: percent_ppn /Applications/MAMP/htdocs/Esgotado/application/views/cart.php 138
ERROR - 2015-03-09 10:26:46 --> Severity: Notice  --> Undefined variable: ppn /Applications/MAMP/htdocs/Esgotado/application/views/cart.php 138
ERROR - 2015-03-09 10:26:46 --> 404 Page Not Found --> template
ERROR - 2015-03-09 10:26:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 10:26:50 --> 404 Page Not Found --> template
ERROR - 2015-03-09 10:26:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 10:26:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 10:27:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 10:27:53 --> 404 Page Not Found --> template
ERROR - 2015-03-09 10:27:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 10:27:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 10:28:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 10:28:19 --> 404 Page Not Found --> template
ERROR - 2015-03-09 10:28:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 10:28:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 10:30:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 10:30:11 --> 404 Page Not Found --> template
ERROR - 2015-03-09 10:30:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 10:30:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 10:30:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 10:30:44 --> 404 Page Not Found --> template
ERROR - 2015-03-09 10:30:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 10:30:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 10:31:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 10:31:02 --> 404 Page Not Found --> template
ERROR - 2015-03-09 10:31:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 10:31:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 10:32:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 10:32:21 --> 404 Page Not Found --> template
ERROR - 2015-03-09 10:32:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 10:32:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 10:32:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 10:32:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 10:32:25 --> 404 Page Not Found --> template
ERROR - 2015-03-09 10:32:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 10:32:33 --> 404 Page Not Found --> template
ERROR - 2015-03-09 10:32:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 10:32:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 10:32:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 10:32:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 10:32:37 --> 404 Page Not Found --> template
ERROR - 2015-03-09 10:32:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 10:32:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 10:32:40 --> 404 Page Not Found --> template
ERROR - 2015-03-09 10:33:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 10:33:55 --> 404 Page Not Found --> template
ERROR - 2015-03-09 10:33:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 10:33:57 --> 404 Page Not Found --> template
ERROR - 2015-03-09 10:33:57 --> 404 Page Not Found --> my_js
ERROR - 2015-03-09 10:34:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 10:34:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 10:34:03 --> Severity: Notice  --> Undefined variable: percent_ppn /Applications/MAMP/htdocs/Esgotado/application/views/cart.php 138
ERROR - 2015-03-09 10:34:03 --> Severity: Notice  --> Undefined variable: ppn /Applications/MAMP/htdocs/Esgotado/application/views/cart.php 138
ERROR - 2015-03-09 10:34:03 --> 404 Page Not Found --> template
ERROR - 2015-03-09 10:34:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 10:34:11 --> 404 Page Not Found --> template
ERROR - 2015-03-09 10:34:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 10:34:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 10:34:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 10:34:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 10:34:14 --> 404 Page Not Found --> template
ERROR - 2015-03-09 10:35:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 10:35:14 --> 404 Page Not Found --> template
ERROR - 2015-03-09 10:39:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 10:39:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 10:39:32 --> 404 Page Not Found --> template
ERROR - 2015-03-09 11:36:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 11:36:18 --> 404 Page Not Found --> template
ERROR - 2015-03-09 11:36:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 11:36:19 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/Esgotado/application/controllers/autoload.php:33) /Applications/MAMP/htdocs/Esgotado/system/core/Output.php 391
ERROR - 2015-03-09 11:36:19 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/Esgotado/application/controllers/autoload.php:33) /Applications/MAMP/htdocs/Esgotado/system/core/Output.php 391
ERROR - 2015-03-09 11:36:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 11:36:20 --> 404 Page Not Found --> template
ERROR - 2015-03-09 11:36:20 --> 404 Page Not Found --> my_js
ERROR - 2015-03-09 11:36:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 11:36:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 11:36:26 --> Severity: Notice  --> Undefined variable: percent_ppn /Applications/MAMP/htdocs/Esgotado/application/views/cart.php 138
ERROR - 2015-03-09 11:36:26 --> Severity: Notice  --> Undefined variable: ppn /Applications/MAMP/htdocs/Esgotado/application/views/cart.php 138
ERROR - 2015-03-09 11:36:26 --> 404 Page Not Found --> template
ERROR - 2015-03-09 11:36:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 11:36:29 --> 404 Page Not Found --> template
ERROR - 2015-03-09 11:36:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 11:36:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 11:36:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 11:36:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 11:36:31 --> 404 Page Not Found --> template
ERROR - 2015-03-09 11:36:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 11:36:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 11:36:36 --> 404 Page Not Found --> template
ERROR - 2015-03-09 11:41:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 11:41:03 --> 404 Page Not Found --> template
ERROR - 2015-03-09 11:41:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 11:41:05 --> 404 Page Not Found --> template
ERROR - 2015-03-09 11:41:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 11:41:06 --> 404 Page Not Found --> template
ERROR - 2015-03-09 11:41:06 --> 404 Page Not Found --> my_js
ERROR - 2015-03-09 11:41:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 11:41:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 11:41:08 --> Severity: Notice  --> Undefined variable: percent_ppn /Applications/MAMP/htdocs/Esgotado/application/views/cart.php 138
ERROR - 2015-03-09 11:41:08 --> Severity: Notice  --> Undefined variable: ppn /Applications/MAMP/htdocs/Esgotado/application/views/cart.php 138
ERROR - 2015-03-09 11:41:08 --> 404 Page Not Found --> template
ERROR - 2015-03-09 11:41:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 11:41:37 --> 404 Page Not Found --> template
ERROR - 2015-03-09 11:41:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 11:41:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 11:42:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 11:42:33 --> Severity: Notice  --> Undefined variable: percent_ppn /Applications/MAMP/htdocs/Esgotado/application/views/cart.php 138
ERROR - 2015-03-09 11:42:33 --> Severity: Notice  --> Undefined variable: ppn /Applications/MAMP/htdocs/Esgotado/application/views/cart.php 138
ERROR - 2015-03-09 11:42:33 --> 404 Page Not Found --> template
ERROR - 2015-03-09 11:42:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 11:42:36 --> 404 Page Not Found --> template
ERROR - 2015-03-09 11:42:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 11:42:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 11:46:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 11:46:26 --> 404 Page Not Found --> template
ERROR - 2015-03-09 11:46:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 11:46:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 11:49:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 11:49:40 --> 404 Page Not Found --> template
ERROR - 2015-03-09 11:49:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 11:49:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 11:54:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 11:54:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 11:54:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 11:54:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:11:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:11:32 --> 404 Page Not Found --> template
ERROR - 2015-03-09 12:11:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:11:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:12:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:12:35 --> 404 Page Not Found --> template
ERROR - 2015-03-09 12:12:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:12:37 --> 404 Page Not Found --> template
ERROR - 2015-03-09 12:12:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:12:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:12:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:12:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:14:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:14:38 --> 404 Page Not Found --> template
ERROR - 2015-03-09 12:14:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:14:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:15:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:15:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:15:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:16:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:16:25 --> 404 Page Not Found --> template
ERROR - 2015-03-09 12:16:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:16:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:16:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:16:47 --> 404 Page Not Found --> template
ERROR - 2015-03-09 12:17:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:17:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:19:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:19:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:19:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:19:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:19:55 --> 404 Page Not Found --> home/css
ERROR - 2015-03-09 12:19:55 --> 404 Page Not Found --> home/css
ERROR - 2015-03-09 12:19:55 --> 404 Page Not Found --> home/css
ERROR - 2015-03-09 12:19:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:19:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:19:55 --> 404 Page Not Found --> home/css
ERROR - 2015-03-09 12:19:55 --> 404 Page Not Found --> home/js
ERROR - 2015-03-09 12:20:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:20:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:20:17 --> 404 Page Not Found --> home/js
ERROR - 2015-03-09 12:21:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:21:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:21:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:21:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:21:47 --> 404 Page Not Found --> template
ERROR - 2015-03-09 12:21:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:21:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:21:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:21:52 --> 404 Page Not Found --> template
ERROR - 2015-03-09 12:21:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:21:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:23:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:23:15 --> 404 Page Not Found --> template
ERROR - 2015-03-09 12:23:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:23:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:24:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:24:50 --> 404 Page Not Found --> template
ERROR - 2015-03-09 12:24:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:24:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:24:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:24:59 --> 404 Page Not Found --> template
ERROR - 2015-03-09 12:25:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:25:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:25:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:25:12 --> 404 Page Not Found --> template
ERROR - 2015-03-09 12:25:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:25:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:25:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:25:22 --> 404 Page Not Found --> template
ERROR - 2015-03-09 12:25:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:25:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:41:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:41:52 --> 404 Page Not Found --> template
ERROR - 2015-03-09 12:41:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:41:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:43:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:43:47 --> 404 Page Not Found --> template
ERROR - 2015-03-09 12:43:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:43:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:43:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:43:56 --> 404 Page Not Found --> template
ERROR - 2015-03-09 12:43:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:43:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:44:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:44:18 --> 404 Page Not Found --> template
ERROR - 2015-03-09 12:44:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:44:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:44:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:44:48 --> 404 Page Not Found --> template
ERROR - 2015-03-09 12:44:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:44:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:45:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:45:34 --> 404 Page Not Found --> template
ERROR - 2015-03-09 12:45:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:45:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:46:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:46:37 --> 404 Page Not Found --> template
ERROR - 2015-03-09 12:46:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:46:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:48:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:48:29 --> 404 Page Not Found --> template
ERROR - 2015-03-09 12:48:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:48:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:48:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:48:49 --> 404 Page Not Found --> template
ERROR - 2015-03-09 12:48:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:48:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:49:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:49:18 --> 404 Page Not Found --> template
ERROR - 2015-03-09 12:49:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:49:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:49:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:49:33 --> 404 Page Not Found --> template
ERROR - 2015-03-09 12:49:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:49:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:49:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:49:44 --> 404 Page Not Found --> template
ERROR - 2015-03-09 12:49:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:49:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:49:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:49:53 --> 404 Page Not Found --> template
ERROR - 2015-03-09 12:49:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:49:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:50:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:50:19 --> 404 Page Not Found --> template
ERROR - 2015-03-09 12:50:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:50:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:50:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:50:33 --> 404 Page Not Found --> template
ERROR - 2015-03-09 12:50:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:50:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:51:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:51:20 --> 404 Page Not Found --> template
ERROR - 2015-03-09 12:51:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:51:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:51:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:51:48 --> 404 Page Not Found --> template
ERROR - 2015-03-09 12:51:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:51:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:54:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:54:28 --> 404 Page Not Found --> template
ERROR - 2015-03-09 12:54:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:54:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:54:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:54:47 --> 404 Page Not Found --> template
ERROR - 2015-03-09 12:54:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:54:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:55:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:55:29 --> 404 Page Not Found --> template
ERROR - 2015-03-09 12:55:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:55:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:55:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:55:53 --> 404 Page Not Found --> template
ERROR - 2015-03-09 12:55:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:55:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:55:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:56:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:56:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:56:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:56:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:56:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:56:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:56:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:56:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:56:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:56:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:56:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:56:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:56:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:56:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:56:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:56:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:56:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:56:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:57:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:57:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:57:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:57:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:57:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:57:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:58:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:58:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:58:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:58:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:58:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:58:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:58:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:58:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:58:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:58:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:58:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:58:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:58:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:58:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:58:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:58:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:58:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:58:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:59:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:59:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 12:59:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:01:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:01:06 --> 404 Page Not Found --> template
ERROR - 2015-03-09 13:01:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:01:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:02:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:02:03 --> 404 Page Not Found --> template
ERROR - 2015-03-09 13:02:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:02:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:02:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:02:16 --> 404 Page Not Found --> template
ERROR - 2015-03-09 13:02:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:02:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:02:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:02:26 --> 404 Page Not Found --> template
ERROR - 2015-03-09 13:02:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:02:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:02:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:02:29 --> 404 Page Not Found --> template
ERROR - 2015-03-09 13:02:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:02:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:02:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:02:30 --> 404 Page Not Found --> template
ERROR - 2015-03-09 13:02:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:02:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:02:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:02:31 --> 404 Page Not Found --> template
ERROR - 2015-03-09 13:02:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:02:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:02:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:02:32 --> 404 Page Not Found --> template
ERROR - 2015-03-09 13:02:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:02:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:02:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:02:33 --> 404 Page Not Found --> template
ERROR - 2015-03-09 13:02:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:02:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:02:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:02:34 --> 404 Page Not Found --> template
ERROR - 2015-03-09 13:02:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:02:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:02:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:02:47 --> 404 Page Not Found --> template
ERROR - 2015-03-09 13:02:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:02:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:02:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:02:54 --> 404 Page Not Found --> template
ERROR - 2015-03-09 13:02:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:02:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:03:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:03:27 --> 404 Page Not Found --> template
ERROR - 2015-03-09 13:03:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:03:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:03:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:03:31 --> 404 Page Not Found --> template
ERROR - 2015-03-09 13:03:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:03:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:03:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:03:42 --> 404 Page Not Found --> template
ERROR - 2015-03-09 13:03:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:03:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:05:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:05:44 --> 404 Page Not Found --> template
ERROR - 2015-03-09 13:05:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:05:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:05:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:05:45 --> 404 Page Not Found --> template
ERROR - 2015-03-09 13:05:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:05:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:05:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:05:48 --> 404 Page Not Found --> template
ERROR - 2015-03-09 13:05:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:05:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:06:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:06:47 --> 404 Page Not Found --> template
ERROR - 2015-03-09 13:06:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:06:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:07:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:07:26 --> 404 Page Not Found --> template
ERROR - 2015-03-09 13:07:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:07:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:07:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:07:41 --> 404 Page Not Found --> template
ERROR - 2015-03-09 13:07:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:07:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:07:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:07:55 --> 404 Page Not Found --> template
ERROR - 2015-03-09 13:07:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:07:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:08:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:08:01 --> 404 Page Not Found --> template
ERROR - 2015-03-09 13:08:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:08:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:08:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:08:07 --> 404 Page Not Found --> template
ERROR - 2015-03-09 13:08:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:08:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:08:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:08:12 --> 404 Page Not Found --> template
ERROR - 2015-03-09 13:08:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:08:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:12:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:12:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:12:36 --> 404 Page Not Found --> template
ERROR - 2015-03-09 13:36:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:36:02 --> 404 Page Not Found --> template
ERROR - 2015-03-09 13:36:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:36:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:37:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:37:58 --> 404 Page Not Found --> template
ERROR - 2015-03-09 13:37:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:37:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:38:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:38:17 --> 404 Page Not Found --> template
ERROR - 2015-03-09 13:38:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:38:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:39:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:39:53 --> 404 Page Not Found --> template
ERROR - 2015-03-09 13:39:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:39:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:40:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:40:04 --> 404 Page Not Found --> template
ERROR - 2015-03-09 13:40:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:40:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:40:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:40:15 --> 404 Page Not Found --> template
ERROR - 2015-03-09 13:40:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:40:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:40:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:40:48 --> 404 Page Not Found --> template
ERROR - 2015-03-09 13:40:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:40:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:43:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:43:01 --> 404 Page Not Found --> template
ERROR - 2015-03-09 13:43:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:43:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:43:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:43:11 --> 404 Page Not Found --> template
ERROR - 2015-03-09 13:43:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:43:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:43:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:43:46 --> 404 Page Not Found --> template
ERROR - 2015-03-09 13:43:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:43:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:43:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:43:56 --> 404 Page Not Found --> template
ERROR - 2015-03-09 13:43:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:43:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:44:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:44:00 --> 404 Page Not Found --> template
ERROR - 2015-03-09 13:44:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:44:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:45:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:45:18 --> 404 Page Not Found --> template
ERROR - 2015-03-09 13:45:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:45:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:45:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:45:35 --> 404 Page Not Found --> template
ERROR - 2015-03-09 13:45:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:45:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:45:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:45:51 --> 404 Page Not Found --> template
ERROR - 2015-03-09 13:45:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:45:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:45:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:45:59 --> 404 Page Not Found --> template
ERROR - 2015-03-09 13:45:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:45:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:46:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:46:29 --> 404 Page Not Found --> template
ERROR - 2015-03-09 13:46:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:46:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:47:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:47:52 --> 404 Page Not Found --> template
ERROR - 2015-03-09 13:47:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:47:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:48:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:48:17 --> 404 Page Not Found --> template
ERROR - 2015-03-09 13:48:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:48:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:48:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:48:40 --> 404 Page Not Found --> template
ERROR - 2015-03-09 13:48:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:48:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:48:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:48:45 --> 404 Page Not Found --> template
ERROR - 2015-03-09 13:48:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:48:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:49:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:49:15 --> 404 Page Not Found --> template
ERROR - 2015-03-09 13:49:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:49:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:49:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:49:17 --> 404 Page Not Found --> template
ERROR - 2015-03-09 13:49:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:49:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:49:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:49:24 --> 404 Page Not Found --> template
ERROR - 2015-03-09 13:49:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:49:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:49:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:49:37 --> 404 Page Not Found --> template
ERROR - 2015-03-09 13:49:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:49:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:49:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:49:42 --> 404 Page Not Found --> template
ERROR - 2015-03-09 13:49:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:49:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:50:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:50:00 --> 404 Page Not Found --> template
ERROR - 2015-03-09 13:50:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:50:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:50:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:50:17 --> 404 Page Not Found --> template
ERROR - 2015-03-09 13:50:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:50:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:50:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:50:35 --> 404 Page Not Found --> template
ERROR - 2015-03-09 13:50:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:50:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:50:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:50:45 --> 404 Page Not Found --> template
ERROR - 2015-03-09 13:50:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:50:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:50:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:50:54 --> 404 Page Not Found --> template
ERROR - 2015-03-09 13:50:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:50:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:51:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:51:14 --> 404 Page Not Found --> template
ERROR - 2015-03-09 13:51:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:51:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:51:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:51:34 --> 404 Page Not Found --> template
ERROR - 2015-03-09 13:51:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:51:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:51:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:51:38 --> 404 Page Not Found --> template
ERROR - 2015-03-09 13:51:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:51:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:51:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:51:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:51:49 --> 404 Page Not Found --> template
ERROR - 2015-03-09 13:52:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:52:38 --> 404 Page Not Found --> template
ERROR - 2015-03-09 13:52:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:52:58 --> 404 Page Not Found --> template
ERROR - 2015-03-09 13:53:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:53:21 --> 404 Page Not Found --> template
ERROR - 2015-03-09 13:53:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:53:52 --> 404 Page Not Found --> template
ERROR - 2015-03-09 13:54:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:54:32 --> 404 Page Not Found --> template
ERROR - 2015-03-09 13:54:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:54:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:54:41 --> 404 Page Not Found --> template
ERROR - 2015-03-09 13:55:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:55:08 --> 404 Page Not Found --> template
ERROR - 2015-03-09 13:56:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:56:35 --> 404 Page Not Found --> template
ERROR - 2015-03-09 13:56:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:56:40 --> 404 Page Not Found --> template
ERROR - 2015-03-09 13:56:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:56:47 --> 404 Page Not Found --> template
ERROR - 2015-03-09 13:57:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:57:01 --> 404 Page Not Found --> template
ERROR - 2015-03-09 13:57:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:57:14 --> 404 Page Not Found --> template
ERROR - 2015-03-09 13:59:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 13:59:45 --> 404 Page Not Found --> template
ERROR - 2015-03-09 14:00:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 14:00:42 --> 404 Page Not Found --> template
ERROR - 2015-03-09 14:00:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 14:00:53 --> 404 Page Not Found --> template
ERROR - 2015-03-09 14:02:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 14:02:37 --> 404 Page Not Found --> template
ERROR - 2015-03-09 14:02:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 14:02:57 --> 404 Page Not Found --> template
ERROR - 2015-03-09 14:03:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 14:03:19 --> 404 Page Not Found --> template
ERROR - 2015-03-09 14:03:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 14:03:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 14:03:30 --> 404 Page Not Found --> template
ERROR - 2015-03-09 14:03:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 14:03:32 --> 404 Page Not Found --> template
ERROR - 2015-03-09 14:03:32 --> 404 Page Not Found --> my_js
ERROR - 2015-03-09 14:03:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 14:03:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 14:03:34 --> Severity: Notice  --> Undefined variable: percent_ppn /Applications/MAMP/htdocs/Esgotado/application/views/cart.php 138
ERROR - 2015-03-09 14:03:34 --> Severity: Notice  --> Undefined variable: ppn /Applications/MAMP/htdocs/Esgotado/application/views/cart.php 138
ERROR - 2015-03-09 14:03:34 --> 404 Page Not Found --> template
ERROR - 2015-03-09 14:03:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 14:03:35 --> 404 Page Not Found --> template
ERROR - 2015-03-09 14:03:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 14:03:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 14:04:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 14:04:33 --> 404 Page Not Found --> template
ERROR - 2015-03-09 14:04:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 14:04:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 14:05:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 14:05:03 --> 404 Page Not Found --> template
ERROR - 2015-03-09 14:05:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 14:05:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 14:05:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 14:05:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 14:05:14 --> 404 Page Not Found --> template
ERROR - 2015-03-09 14:05:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 14:05:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 14:05:29 --> 404 Page Not Found --> template
ERROR - 2015-03-09 14:22:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 14:22:22 --> 404 Page Not Found --> template
ERROR - 2015-03-09 14:26:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 14:26:20 --> 404 Page Not Found --> template
ERROR - 2015-03-09 14:28:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 14:28:20 --> 404 Page Not Found --> template
ERROR - 2015-03-09 14:28:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 14:28:52 --> 404 Page Not Found --> template
ERROR - 2015-03-09 14:28:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 14:28:53 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/Esgotado/application/controllers/autoload.php:33) /Applications/MAMP/htdocs/Esgotado/system/core/Output.php 391
ERROR - 2015-03-09 14:28:53 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/Esgotado/application/controllers/autoload.php:33) /Applications/MAMP/htdocs/Esgotado/system/core/Output.php 391
ERROR - 2015-03-09 14:28:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 14:28:54 --> 404 Page Not Found --> template
ERROR - 2015-03-09 14:28:54 --> 404 Page Not Found --> my_js
ERROR - 2015-03-09 14:28:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 14:28:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 14:28:56 --> Severity: Notice  --> Undefined variable: percent_ppn /Applications/MAMP/htdocs/Esgotado/application/views/cart.php 138
ERROR - 2015-03-09 14:28:56 --> Severity: Notice  --> Undefined variable: ppn /Applications/MAMP/htdocs/Esgotado/application/views/cart.php 138
ERROR - 2015-03-09 14:28:56 --> 404 Page Not Found --> template
ERROR - 2015-03-09 14:28:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 14:28:58 --> 404 Page Not Found --> template
ERROR - 2015-03-09 14:28:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 14:28:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 14:29:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 14:29:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 14:29:07 --> 404 Page Not Found --> template
ERROR - 2015-03-09 14:30:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 14:30:04 --> 404 Page Not Found --> template
ERROR - 2015-03-09 14:30:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 14:30:13 --> 404 Page Not Found --> template
ERROR - 2015-03-09 14:30:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 14:30:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 14:30:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 14:30:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 14:30:17 --> 404 Page Not Found --> template
ERROR - 2015-03-09 14:30:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 14:30:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 14:30:38 --> 404 Page Not Found --> template
ERROR - 2015-03-09 14:31:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 14:31:12 --> 404 Page Not Found --> template
ERROR - 2015-03-09 14:32:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-09 14:32:21 --> 404 Page Not Found --> template
ERROR - 2015-03-09 16:45:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-09 16:45:28 --> Query error: Table 'galaxia_store.gxa_widget' doesn't exist
ERROR - 2015-03-09 16:47:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-09 16:48:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-09 16:48:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-09 16:48:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-09 16:48:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-09 16:48:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-09 16:48:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-09 16:48:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-09 16:48:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
