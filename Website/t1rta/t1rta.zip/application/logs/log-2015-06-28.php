<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-06-28 22:05:05 --> 404 Page Not Found --> template
ERROR - 2015-06-28 22:05:11 --> 404 Page Not Found --> template
ERROR - 2015-06-28 22:11:31 --> 404 Page Not Found --> template
ERROR - 2015-06-28 22:14:11 --> 404 Page Not Found --> template
ERROR - 2015-06-28 22:14:20 --> 404 Page Not Found --> template
ERROR - 2015-06-28 22:14:35 --> 404 Page Not Found --> template
ERROR - 2015-06-28 22:15:08 --> 404 Page Not Found --> template
ERROR - 2015-06-28 22:15:46 --> 404 Page Not Found --> template
ERROR - 2015-06-28 22:16:08 --> 404 Page Not Found --> template
ERROR - 2015-06-28 22:17:21 --> 404 Page Not Found --> template
ERROR - 2015-06-28 22:22:47 --> 404 Page Not Found --> template
ERROR - 2015-06-28 22:22:52 --> 404 Page Not Found --> template
ERROR - 2015-06-28 22:23:06 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2015-06-28 22:23:06 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2015-06-28 22:23:06 --> 404 Page Not Found --> template
ERROR - 2015-06-28 22:23:08 --> 404 Page Not Found --> template
ERROR - 2015-06-28 22:23:15 --> 404 Page Not Found --> template
ERROR - 2015-06-28 22:23:27 --> 404 Page Not Found --> template
ERROR - 2015-06-28 22:23:31 --> Severity: Warning  --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\wamp\www\Esgotado\system\libraries\Email.php 1553
ERROR - 2015-06-28 22:23:32 --> 404 Page Not Found --> template
