<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2014-10-24 06:06:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-24 06:06:14 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
ERROR - 2014-10-24 06:06:14 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-24 06:06:14 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-24 06:06:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-24 06:06:22 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-24 06:06:22 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-24 06:06:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-24 06:06:24 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-24 06:06:24 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
