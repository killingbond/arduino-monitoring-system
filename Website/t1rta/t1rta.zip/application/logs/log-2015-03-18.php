<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-03-18 00:48:35 --> 404 Page Not Found --> template
ERROR - 2015-03-18 01:26:38 --> 404 Page Not Found --> template
ERROR - 2015-03-18 01:26:46 --> 404 Page Not Found --> template
ERROR - 2015-03-18 01:37:48 --> 404 Page Not Found --> template
ERROR - 2015-03-18 01:37:48 --> 404 Page Not Found --> my_js
ERROR - 2015-03-18 02:18:50 --> 404 Page Not Found --> template
ERROR - 2015-03-18 02:21:50 --> 404 Page Not Found --> template
ERROR - 2015-03-18 02:23:25 --> 404 Page Not Found --> template
ERROR - 2015-03-18 02:31:27 --> 404 Page Not Found --> template
ERROR - 2015-03-18 02:32:31 --> 404 Page Not Found --> template
ERROR - 2015-03-18 02:32:41 --> 404 Page Not Found --> template
ERROR - 2015-03-18 02:32:50 --> 404 Page Not Found --> template
ERROR - 2015-03-18 02:34:38 --> 404 Page Not Found --> template
ERROR - 2015-03-18 09:48:59 --> 404 Page Not Found --> template
ERROR - 2015-03-18 09:49:05 --> 404 Page Not Found --> template
ERROR - 2015-03-18 09:49:05 --> 404 Page Not Found --> my_js
ERROR - 2015-03-18 09:49:08 --> 404 Page Not Found --> template
ERROR - 2015-03-18 09:49:12 --> 404 Page Not Found --> template
ERROR - 2015-03-18 09:49:12 --> 404 Page Not Found --> my_js
ERROR - 2015-03-18 09:49:14 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-18 09:49:15 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2015-03-18 09:49:15 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2015-03-18 09:49:15 --> 404 Page Not Found --> template
ERROR - 2015-03-18 09:49:23 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2015-03-18 09:49:23 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2015-03-18 09:49:24 --> 404 Page Not Found --> template
ERROR - 2015-03-18 09:49:26 --> 404 Page Not Found --> template
ERROR - 2015-03-18 09:49:33 --> 404 Page Not Found --> template
ERROR - 2015-03-18 09:49:54 --> 404 Page Not Found --> template
ERROR - 2015-03-18 11:25:14 --> 404 Page Not Found --> template
