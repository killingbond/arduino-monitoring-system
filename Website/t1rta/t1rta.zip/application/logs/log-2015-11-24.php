<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-11-24 08:39:00 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-24 08:39:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-24 08:39:00 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-24 08:39:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-24 08:39:00 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-24 08:39:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-24 08:39:00 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-24 08:39:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-24 08:39:00 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-24 08:39:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-24 08:39:00 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-24 08:39:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-24 08:39:00 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:39:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:39:00 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:39:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:39:00 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:39:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:39:00 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:39:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:39:00 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:39:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:39:00 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:39:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:39:00 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:39:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:39:00 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:39:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:39:00 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:39:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:39:00 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:39:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:39:00 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:39:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:39:00 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:39:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:39:00 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:39:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:39:00 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:39:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:39:00 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:39:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:39:00 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:39:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:39:00 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:39:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:39:00 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:39:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:39:00 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:39:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:39:00 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:39:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:39:58 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-24 08:39:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-24 08:39:58 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-24 08:39:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-24 08:39:58 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-24 08:39:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-24 08:39:58 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-24 08:39:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-24 08:39:58 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-24 08:39:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-24 08:39:58 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-24 08:39:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-24 08:39:58 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:39:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:39:58 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:39:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:39:58 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:39:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:39:58 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:39:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:39:58 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:39:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:39:58 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:39:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:39:58 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:39:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:39:58 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:39:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:39:58 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:39:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:39:58 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:39:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:39:58 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:39:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:39:58 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:39:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:39:59 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:39:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:39:59 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:39:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:39:59 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:39:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:39:59 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:39:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:39:59 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:39:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:39:59 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:39:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:39:59 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:39:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:39:59 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:39:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:40:54 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-24 08:40:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-24 08:40:54 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-24 08:40:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-24 08:40:54 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-24 08:40:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-24 08:40:54 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-24 08:40:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-24 08:40:54 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-24 08:40:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-24 08:40:54 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-24 08:40:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-24 08:40:54 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:40:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:40:54 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:40:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:40:54 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:40:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:40:54 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:40:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:40:54 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:40:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:40:54 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:40:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:40:54 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:40:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:40:54 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:40:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:40:54 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:40:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:40:54 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:40:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:40:54 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:40:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:40:54 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:40:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:40:54 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:40:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:40:54 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:40:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:40:54 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:40:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:40:54 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:40:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:40:54 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:40:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:40:54 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:40:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:40:54 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:40:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:40:54 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:40:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:41:13 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-24 08:41:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-24 08:41:13 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-24 08:41:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-24 08:41:13 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-24 08:41:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-24 08:41:13 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-24 08:41:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-24 08:41:13 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-24 08:41:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-24 08:41:13 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-24 08:41:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-24 08:41:13 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:41:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:41:13 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:41:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:41:14 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:41:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:41:14 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:41:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:41:14 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:41:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:41:14 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:41:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:41:14 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:41:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:41:14 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:41:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:41:14 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:41:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:41:14 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:41:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:41:14 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:41:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:41:14 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:41:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:41:14 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:41:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:41:14 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:41:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:41:14 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:41:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:41:14 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:41:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:41:14 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:41:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:41:14 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:41:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:41:14 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:41:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:41:14 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:41:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:52:32 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-24 08:52:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-24 08:52:32 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-24 08:52:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-24 08:52:32 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-24 08:52:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-24 08:52:32 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-24 08:52:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-24 08:52:32 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-24 08:52:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-24 08:52:32 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-24 08:52:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-24 08:52:32 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:52:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:52:32 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:52:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:52:32 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:52:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:52:32 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:52:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:52:32 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:52:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:52:32 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:52:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:52:32 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:52:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:52:32 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:52:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:52:32 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:52:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:52:32 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:52:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:52:32 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:52:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:52:32 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:52:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:52:32 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:52:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:52:32 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:52:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:52:32 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:52:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:52:32 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:52:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:52:32 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:52:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:52:32 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:52:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:52:32 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:52:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:52:32 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:52:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:52:50 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-24 08:52:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-24 08:52:50 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-24 08:52:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-24 08:52:50 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-24 08:52:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-24 08:52:50 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-24 08:52:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-24 08:52:50 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-24 08:52:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-24 08:52:50 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-24 08:52:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-24 08:52:50 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:52:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:52:50 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:52:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:52:50 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:52:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:52:50 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:52:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:52:50 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:52:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:52:50 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:52:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:52:50 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:52:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:52:50 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:52:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:52:50 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:52:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:52:50 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:52:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:52:50 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:52:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:52:50 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:52:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:52:50 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:52:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:52:50 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:52:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:52:50 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:52:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:52:50 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:52:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:52:50 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:52:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:52:50 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:52:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:52:50 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:52:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:52:50 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:52:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:53:12 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-24 08:53:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-24 08:53:12 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-24 08:53:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-24 08:53:12 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-24 08:53:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-24 08:53:12 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-24 08:53:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-24 08:53:12 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-24 08:53:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-24 08:53:12 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-24 08:53:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-24 08:53:12 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:53:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:53:12 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:53:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:53:12 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:53:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:53:12 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:53:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:53:12 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:53:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:53:12 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:53:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:53:12 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:53:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:53:12 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:53:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:53:12 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:53:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:53:12 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:53:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:53:12 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:53:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:53:12 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:53:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:53:12 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:53:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:53:12 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:53:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:53:12 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:53:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:53:12 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:53:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:53:12 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:53:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:53:12 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:53:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:53:12 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:53:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:53:12 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:53:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:53:27 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-24 08:53:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-24 08:53:27 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-24 08:53:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-24 08:53:27 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-24 08:53:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-24 08:53:27 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-24 08:53:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-24 08:53:27 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-24 08:53:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-24 08:53:27 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-24 08:53:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-24 08:53:27 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:53:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:53:27 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:53:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:53:27 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:53:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:53:27 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:53:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:53:27 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:53:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:53:27 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:53:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:53:27 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:53:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:53:27 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:53:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:53:27 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:53:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:53:27 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:53:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:53:27 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:53:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:53:27 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:53:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:53:27 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:53:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:53:27 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:53:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:53:27 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:53:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:53:27 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:53:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:53:27 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:53:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:53:27 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:53:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:53:27 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:53:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:53:27 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:53:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:53:38 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-24 08:53:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-24 08:53:38 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-24 08:53:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-24 08:53:38 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-24 08:53:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-24 08:53:38 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-24 08:53:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-24 08:53:38 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-24 08:53:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-24 08:53:38 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-24 08:53:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-24 08:53:38 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:53:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:53:38 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:53:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:53:38 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:53:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:53:38 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:53:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:53:38 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:53:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:53:38 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:53:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:53:38 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:53:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:53:38 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:53:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:53:38 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:53:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:53:38 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:53:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:53:38 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:53:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:53:38 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:53:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:53:38 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:53:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:53:38 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:53:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:53:38 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:53:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:53:38 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:53:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:53:38 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:53:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:53:38 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:53:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:53:38 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:53:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:53:38 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-24 08:53:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
