<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2016-11-22 15:23:30 --> Severity: Notice  --> Undefined variable: notification_order /home/tirtadah/public_html/t1rta/application/views/slices/sidebar.php 85
ERROR - 2016-11-22 15:23:30 --> Severity: Notice  --> Undefined variable: notification_order /home/tirtadah/public_html/t1rta/application/views/slices/sidebar.php 98
ERROR - 2016-11-22 15:23:41 --> Severity: Notice  --> Undefined variable: notification_order /home/tirtadah/public_html/t1rta/application/views/slices/sidebar.php 85
ERROR - 2016-11-22 15:23:41 --> Severity: Notice  --> Undefined variable: notification_order /home/tirtadah/public_html/t1rta/application/views/slices/sidebar.php 98
ERROR - 2016-11-22 15:23:45 --> Severity: Notice  --> Undefined variable: notification_order /home/tirtadah/public_html/t1rta/application/views/slices/sidebar.php 85
ERROR - 2016-11-22 15:23:45 --> Severity: Notice  --> Undefined variable: notification_order /home/tirtadah/public_html/t1rta/application/views/slices/sidebar.php 98
ERROR - 2016-11-22 15:23:45 --> Severity: Notice  --> Undefined variable: chart_delivered /home/tirtadah/public_html/t1rta/application/views/home.php 112
ERROR - 2016-11-22 15:23:45 --> Severity: Notice  --> Undefined variable: chart_canceled /home/tirtadah/public_html/t1rta/application/views/home.php 131
ERROR - 2016-11-22 15:23:50 --> Severity: Notice  --> Undefined variable: notification_order /home/tirtadah/public_html/t1rta/application/views/slices/sidebar.php 85
ERROR - 2016-11-22 15:23:50 --> Severity: Notice  --> Undefined variable: notification_order /home/tirtadah/public_html/t1rta/application/views/slices/sidebar.php 98
ERROR - 2016-11-22 15:23:52 --> Severity: Notice  --> Undefined variable: notification_order /home/tirtadah/public_html/t1rta/application/views/slices/sidebar.php 85
ERROR - 2016-11-22 15:23:52 --> Severity: Notice  --> Undefined variable: notification_order /home/tirtadah/public_html/t1rta/application/views/slices/sidebar.php 98
ERROR - 2016-11-22 15:24:09 --> Severity: Notice  --> Undefined variable: notification_order /home/tirtadah/public_html/t1rta/application/views/slices/sidebar.php 85
ERROR - 2016-11-22 15:24:09 --> Severity: Notice  --> Undefined variable: notification_order /home/tirtadah/public_html/t1rta/application/views/slices/sidebar.php 98
ERROR - 2016-11-22 15:24:16 --> Severity: Notice  --> Undefined variable: notification_order /home/tirtadah/public_html/t1rta/application/views/slices/sidebar.php 85
ERROR - 2016-11-22 15:24:16 --> Severity: Notice  --> Undefined variable: notification_order /home/tirtadah/public_html/t1rta/application/views/slices/sidebar.php 98
ERROR - 2016-11-22 15:24:23 --> Severity: Notice  --> Undefined variable: notification_order /home/tirtadah/public_html/t1rta/application/views/slices/sidebar.php 85
ERROR - 2016-11-22 15:24:23 --> Severity: Notice  --> Undefined variable: notification_order /home/tirtadah/public_html/t1rta/application/views/slices/sidebar.php 98
ERROR - 2016-11-22 15:24:27 --> Severity: Notice  --> Undefined variable: notification_order /home/tirtadah/public_html/t1rta/application/views/slices/sidebar.php 85
ERROR - 2016-11-22 15:24:27 --> Severity: Notice  --> Undefined variable: notification_order /home/tirtadah/public_html/t1rta/application/views/slices/sidebar.php 98
ERROR - 2016-11-22 23:32:19 --> Severity: Notice  --> Undefined variable: notification_order /home/tirtadah/public_html/t1rta/application/views/slices/sidebar.php 85
ERROR - 2016-11-22 23:32:19 --> Severity: Notice  --> Undefined variable: notification_order /home/tirtadah/public_html/t1rta/application/views/slices/sidebar.php 98
ERROR - 2016-11-22 23:32:20 --> Severity: Notice  --> Undefined variable: notification_order /home/tirtadah/public_html/t1rta/application/views/slices/sidebar.php 85
ERROR - 2016-11-22 23:32:20 --> Severity: Notice  --> Undefined variable: notification_order /home/tirtadah/public_html/t1rta/application/views/slices/sidebar.php 98
