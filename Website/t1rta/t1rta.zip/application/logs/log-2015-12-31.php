<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-12-31 06:32:29 --> Query error: Table 'radusa_company.product_collection' doesn't exist
ERROR - 2015-12-31 06:32:31 --> Query error: Table 'radusa_company.product_collection' doesn't exist
ERROR - 2015-12-31 06:34:01 --> Query error: Table 'radusa_company.roduct_sub_category' doesn't exist
ERROR - 2015-12-31 06:34:11 --> Severity: Notice  --> Undefined property: stdClass::$collection_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\edit_product.php 121
ERROR - 2015-12-31 06:34:11 --> Severity: Notice  --> Undefined property: stdClass::$collection_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\edit_product.php 121
ERROR - 2015-12-31 06:34:11 --> Severity: Notice  --> Undefined property: stdClass::$collection_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\edit_product.php 122
ERROR - 2015-12-31 06:34:11 --> Severity: Notice  --> Undefined property: stdClass::$collection_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\edit_product.php 122
ERROR - 2015-12-31 06:34:11 --> Severity: Notice  --> Undefined property: stdClass::$collection C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\edit_product.php 122
ERROR - 2015-12-31 06:34:11 --> Severity: Notice  --> Undefined property: stdClass::$collection_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\edit_product.php 121
ERROR - 2015-12-31 06:34:11 --> Severity: Notice  --> Undefined property: stdClass::$collection_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\edit_product.php 121
ERROR - 2015-12-31 06:34:11 --> Severity: Notice  --> Undefined property: stdClass::$collection_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\edit_product.php 122
ERROR - 2015-12-31 06:34:11 --> Severity: Notice  --> Undefined property: stdClass::$collection_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\edit_product.php 122
ERROR - 2015-12-31 06:34:12 --> Severity: Notice  --> Undefined property: stdClass::$collection C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\edit_product.php 122
ERROR - 2015-12-31 06:34:12 --> Severity: Notice  --> Undefined property: stdClass::$collection_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\edit_product.php 121
ERROR - 2015-12-31 06:34:12 --> Severity: Notice  --> Undefined property: stdClass::$collection_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\edit_product.php 121
ERROR - 2015-12-31 06:34:12 --> Severity: Notice  --> Undefined property: stdClass::$collection_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\edit_product.php 122
ERROR - 2015-12-31 06:34:12 --> Severity: Notice  --> Undefined property: stdClass::$collection_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\edit_product.php 122
ERROR - 2015-12-31 06:34:12 --> Severity: Notice  --> Undefined property: stdClass::$collection C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\edit_product.php 122
ERROR - 2015-12-31 06:34:12 --> Severity: Notice  --> Undefined property: stdClass::$collection_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\edit_product.php 121
ERROR - 2015-12-31 06:34:12 --> Severity: Notice  --> Undefined property: stdClass::$collection_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\edit_product.php 121
ERROR - 2015-12-31 06:34:12 --> Severity: Notice  --> Undefined property: stdClass::$collection_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\edit_product.php 122
ERROR - 2015-12-31 06:34:12 --> Severity: Notice  --> Undefined property: stdClass::$collection_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\edit_product.php 122
ERROR - 2015-12-31 06:34:12 --> Severity: Notice  --> Undefined property: stdClass::$collection C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\edit_product.php 122
ERROR - 2015-12-31 06:34:12 --> Severity: Notice  --> Undefined property: stdClass::$collection_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\edit_product.php 121
ERROR - 2015-12-31 06:34:12 --> Severity: Notice  --> Undefined property: stdClass::$collection_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\edit_product.php 121
ERROR - 2015-12-31 06:34:12 --> Severity: Notice  --> Undefined property: stdClass::$collection_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\edit_product.php 122
ERROR - 2015-12-31 06:34:12 --> Severity: Notice  --> Undefined property: stdClass::$collection_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\edit_product.php 122
ERROR - 2015-12-31 06:34:12 --> Severity: Notice  --> Undefined property: stdClass::$collection C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\edit_product.php 122
ERROR - 2015-12-31 06:47:13 --> Severity: Notice  --> Undefined property: stdClass::$collection C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\edit_product.php 123
ERROR - 2015-12-31 06:47:13 --> Severity: Notice  --> Undefined property: stdClass::$collection C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\edit_product.php 123
ERROR - 2015-12-31 06:47:13 --> Severity: Notice  --> Undefined property: stdClass::$collection C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\edit_product.php 123
ERROR - 2015-12-31 06:47:13 --> Severity: Notice  --> Undefined property: stdClass::$collection C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\edit_product.php 123
ERROR - 2015-12-31 06:47:13 --> Severity: Notice  --> Undefined property: stdClass::$collection C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\edit_product.php 123
ERROR - 2015-12-31 06:47:16 --> Severity: Notice  --> Undefined property: stdClass::$collection C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\edit_product.php 123
ERROR - 2015-12-31 06:47:16 --> Severity: Notice  --> Undefined property: stdClass::$collection C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\edit_product.php 123
ERROR - 2015-12-31 06:47:16 --> Severity: Notice  --> Undefined property: stdClass::$collection C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\edit_product.php 123
ERROR - 2015-12-31 06:47:16 --> Severity: Notice  --> Undefined property: stdClass::$collection C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\edit_product.php 123
ERROR - 2015-12-31 06:47:16 --> Severity: Notice  --> Undefined property: stdClass::$collection C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\edit_product.php 123
ERROR - 2015-12-31 06:48:10 --> Severity: Notice  --> Undefined property: stdClass::$collection C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\edit_product.php 123
ERROR - 2015-12-31 06:48:10 --> Severity: Notice  --> Undefined property: stdClass::$collection C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\edit_product.php 123
ERROR - 2015-12-31 06:48:10 --> Severity: Notice  --> Undefined property: stdClass::$collection C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\edit_product.php 123
ERROR - 2015-12-31 06:48:10 --> Severity: Notice  --> Undefined property: stdClass::$collection C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\edit_product.php 123
ERROR - 2015-12-31 06:48:10 --> Severity: Notice  --> Undefined property: stdClass::$collection C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\edit_product.php 123
ERROR - 2015-12-31 06:49:03 --> Severity: Notice  --> Undefined property: stdClass::$collection C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\edit_product.php 123
ERROR - 2015-12-31 06:49:03 --> Severity: Notice  --> Undefined property: stdClass::$collection C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\edit_product.php 123
ERROR - 2015-12-31 06:49:03 --> Severity: Notice  --> Undefined property: stdClass::$collection C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\edit_product.php 123
ERROR - 2015-12-31 06:49:03 --> Severity: Notice  --> Undefined property: stdClass::$collection C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\edit_product.php 123
ERROR - 2015-12-31 06:49:03 --> Severity: Notice  --> Undefined property: stdClass::$collection C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\edit_product.php 123
ERROR - 2015-12-31 06:52:58 --> Severity: Notice  --> Undefined property: stdClass::$collection C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\edit_product.php 124
ERROR - 2015-12-31 06:54:09 --> Severity: Notice  --> Undefined property: stdClass::$collection C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\edit_product.php 124
