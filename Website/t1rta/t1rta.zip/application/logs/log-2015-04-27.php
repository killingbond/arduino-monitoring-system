<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-04-27 16:23:56 --> 404 Page Not Found --> template
ERROR - 2015-04-27 16:24:23 --> 404 Page Not Found --> template
ERROR - 2015-04-27 16:24:25 --> 404 Page Not Found --> template
ERROR - 2015-04-27 16:24:27 --> 404 Page Not Found --> template
ERROR - 2015-04-27 16:24:28 --> 404 Page Not Found --> template
ERROR - 2015-04-27 16:24:30 --> 404 Page Not Found --> template
ERROR - 2015-04-27 16:24:32 --> 404 Page Not Found --> template
