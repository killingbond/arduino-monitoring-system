<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-04-20 03:11:43 --> 404 Page Not Found --> template
ERROR - 2015-04-20 05:53:14 --> 404 Page Not Found --> template
ERROR - 2015-04-20 05:53:15 --> 404 Page Not Found --> template
ERROR - 2015-04-20 06:05:16 --> 404 Page Not Found --> template
ERROR - 2015-04-20 06:05:16 --> 404 Page Not Found --> template
ERROR - 2015-04-20 06:05:20 --> Severity: Notice  --> Undefined property: Contact::$contact_m C:\wamp\www\Esgotado\application\controllers\contact.php 7
ERROR - 2015-04-20 06:05:35 --> 404 Page Not Found --> template
ERROR - 2015-04-20 06:05:35 --> 404 Page Not Found --> template
ERROR - 2015-04-20 06:06:41 --> 404 Page Not Found --> template
ERROR - 2015-04-20 06:06:41 --> 404 Page Not Found --> template
ERROR - 2015-04-20 06:08:08 --> Severity: Notice  --> Undefined variable: gender C:\wamp\www\Esgotado\application\views\contact.php 72
ERROR - 2015-04-20 06:08:08 --> Severity: Notice  --> Undefined variable: gender C:\wamp\www\Esgotado\application\views\contact.php 73
ERROR - 2015-04-20 06:08:08 --> 404 Page Not Found --> template
ERROR - 2015-04-20 06:08:08 --> 404 Page Not Found --> template
ERROR - 2015-04-20 06:08:14 --> Severity: Notice  --> Undefined variable: gender C:\wamp\www\Esgotado\application\views\contact.php 72
ERROR - 2015-04-20 06:08:14 --> Severity: Notice  --> Undefined variable: gender C:\wamp\www\Esgotado\application\views\contact.php 73
ERROR - 2015-04-20 06:08:14 --> 404 Page Not Found --> template
ERROR - 2015-04-20 06:08:14 --> 404 Page Not Found --> template
ERROR - 2015-04-20 06:09:38 --> Severity: Notice  --> Undefined variable: gender C:\wamp\www\Esgotado\application\views\contact.php 72
ERROR - 2015-04-20 06:09:38 --> Severity: Notice  --> Undefined variable: gender C:\wamp\www\Esgotado\application\views\contact.php 73
ERROR - 2015-04-20 06:09:38 --> 404 Page Not Found --> template
ERROR - 2015-04-20 06:09:38 --> 404 Page Not Found --> template
ERROR - 2015-04-20 06:10:04 --> 404 Page Not Found --> template
ERROR - 2015-04-20 06:10:04 --> 404 Page Not Found --> template
ERROR - 2015-04-20 06:10:23 --> 404 Page Not Found --> template
ERROR - 2015-04-20 06:10:23 --> 404 Page Not Found --> template
ERROR - 2015-04-20 06:13:26 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\models\contact_m.php 45
ERROR - 2015-04-20 06:13:26 --> 404 Page Not Found --> template
ERROR - 2015-04-20 06:13:26 --> 404 Page Not Found --> template
ERROR - 2015-04-20 06:13:37 --> Severity: Warning  --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\wamp\www\Esgotado\system\libraries\Email.php 1553
ERROR - 2015-04-20 06:13:37 --> 404 Page Not Found --> template
ERROR - 2015-04-20 06:13:37 --> 404 Page Not Found --> template
ERROR - 2015-04-20 07:10:21 --> 404 Page Not Found --> template
ERROR - 2015-04-20 07:10:23 --> 404 Page Not Found --> template
ERROR - 2015-04-20 07:10:31 --> Severity: Warning  --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\wamp\www\Esgotado\system\libraries\Email.php 1553
ERROR - 2015-04-20 07:10:32 --> 404 Page Not Found --> template
ERROR - 2015-04-20 07:10:35 --> 404 Page Not Found --> template
ERROR - 2015-04-20 07:10:37 --> 404 Page Not Found --> template
ERROR - 2015-04-20 07:10:41 --> 404 Page Not Found --> template
ERROR - 2015-04-20 07:10:45 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2015-04-20 07:10:45 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2015-04-20 07:10:45 --> 404 Page Not Found --> template
ERROR - 2015-04-20 07:10:48 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2015-04-20 07:10:48 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2015-04-20 07:10:48 --> 404 Page Not Found --> template
ERROR - 2015-04-20 07:10:50 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2015-04-20 07:10:50 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2015-04-20 07:10:50 --> 404 Page Not Found --> template
ERROR - 2015-04-20 07:10:53 --> 404 Page Not Found --> template
ERROR - 2015-04-20 07:10:56 --> 404 Page Not Found --> template
ERROR - 2015-04-20 08:35:31 --> 404 Page Not Found --> template
ERROR - 2015-04-20 08:35:33 --> 404 Page Not Found --> template
