<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-04-29 18:07:19 --> 404 Page Not Found --> template
ERROR - 2015-04-29 18:07:34 --> 404 Page Not Found --> template
ERROR - 2015-04-29 18:07:38 --> 404 Page Not Found --> template
