<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2016-02-19 19:12:14 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-19 19:12:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-19 19:12:14 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-19 19:12:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-19 19:12:14 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-19 19:12:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-19 19:12:14 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-19 19:12:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-19 19:12:14 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-19 19:12:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-19 19:12:14 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:12:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:12:14 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:12:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:12:14 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:12:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:12:14 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:12:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:12:14 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:12:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:12:14 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:12:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:12:14 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:12:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:12:14 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:12:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:12:14 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:12:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:12:14 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:12:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:12:14 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:12:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:12:14 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:12:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:12:14 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:12:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:12:14 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:12:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:12:14 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:12:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:12:14 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:12:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:12:14 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:12:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:12:14 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:12:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:12:14 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:12:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:12:14 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:12:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:12:14 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:12:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:12:34 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-19 19:12:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-19 19:12:34 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-19 19:12:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-19 19:12:34 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-19 19:12:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-19 19:12:34 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-19 19:12:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-19 19:12:34 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-19 19:12:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-19 19:12:34 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:12:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:12:34 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:12:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:12:34 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:12:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:12:34 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:12:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:12:34 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:12:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:12:34 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:12:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:12:34 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:12:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:12:34 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:12:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:12:34 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:12:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:12:34 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:12:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:12:34 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:12:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:12:34 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:12:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:12:34 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:12:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:12:34 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:12:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:12:34 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:12:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:12:34 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:12:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:12:34 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:12:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:12:34 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:12:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:12:34 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:12:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:12:34 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:12:35 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:12:35 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:12:35 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:12:45 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-19 19:12:45 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-19 19:12:45 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-19 19:12:45 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-19 19:12:45 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-19 19:12:45 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-19 19:12:45 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-19 19:12:45 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-19 19:12:46 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-19 19:12:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-19 19:12:46 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:12:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:12:46 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:12:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:12:46 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:12:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:12:46 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:12:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:12:46 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:12:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:12:46 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:12:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:12:46 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:12:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:12:46 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:12:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:12:46 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:12:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:12:46 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:12:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:12:46 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:12:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:12:46 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:12:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:12:46 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:12:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:12:46 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:12:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:12:46 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:12:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:12:46 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:12:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:12:46 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:12:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:12:46 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:12:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:12:46 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:12:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:12:46 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:12:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:12:46 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:12:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:13:21 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-19 19:13:21 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-19 19:13:21 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-19 19:13:21 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-19 19:13:21 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-19 19:13:21 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-19 19:13:21 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-19 19:13:21 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-19 19:13:21 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-19 19:13:21 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-19 19:13:21 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:13:21 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:13:21 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:13:21 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:13:21 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:13:21 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:13:21 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:13:21 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:13:21 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:13:21 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:13:21 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:13:21 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:13:22 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:13:22 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:13:22 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:13:22 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:13:22 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:13:22 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:13:22 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:13:22 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:13:22 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:13:22 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:13:22 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:13:22 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:13:22 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:13:22 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:13:22 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:13:22 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:13:22 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:13:22 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:13:22 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:13:22 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:13:22 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:13:22 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:13:22 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:13:22 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:13:22 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:13:22 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:13:22 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:13:22 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:13:22 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:13:22 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:13:42 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-19 19:13:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-19 19:13:42 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-19 19:13:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-19 19:13:42 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-19 19:13:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-19 19:13:42 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-19 19:13:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-19 19:13:42 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-19 19:13:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-19 19:13:42 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:13:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:13:42 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:13:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:13:42 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:13:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:13:42 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:13:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:13:42 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:13:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:13:42 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:13:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:13:42 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:13:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:13:42 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:13:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:13:42 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:13:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:13:42 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:13:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:13:42 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:13:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:13:42 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:13:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:13:42 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:13:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:13:42 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:13:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:13:42 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:13:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:13:42 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:13:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:13:42 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:13:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:13:42 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:13:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:13:42 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:13:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:13:42 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:13:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:13:42 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:13:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:14:39 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-19 19:14:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-19 19:14:39 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-19 19:14:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-19 19:14:39 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-19 19:14:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-19 19:14:39 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-19 19:14:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-19 19:14:39 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-19 19:14:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-19 19:14:39 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:14:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:14:39 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:14:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:14:39 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:14:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:14:39 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:14:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:14:39 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:14:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:14:39 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:14:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:14:39 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:14:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:14:39 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:14:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:14:39 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:14:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:14:39 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:14:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:14:39 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:14:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:14:39 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:14:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:14:39 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:14:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:14:39 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:14:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:14:39 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:14:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:14:39 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:14:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:14:39 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:14:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:14:39 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:14:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:14:39 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:14:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:14:39 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:14:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:14:39 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:14:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:15:22 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-19 19:15:22 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-19 19:15:22 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-19 19:15:22 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-19 19:15:22 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-19 19:15:22 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-19 19:15:22 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-19 19:15:22 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-19 19:15:22 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-19 19:15:22 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-19 19:15:22 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:15:22 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:15:22 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:15:22 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:15:22 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:15:22 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:15:22 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:15:22 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:15:22 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:15:22 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:15:22 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:15:22 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:15:22 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:15:22 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:15:22 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:15:22 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:15:22 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:15:22 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:15:22 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:15:22 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:15:22 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:15:22 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:15:22 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:15:22 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:15:22 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:15:22 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:15:22 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:15:22 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:15:23 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:15:23 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:15:23 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:15:23 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:15:23 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:15:23 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:15:23 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:15:23 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:15:23 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:15:23 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:15:23 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:15:23 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:15:23 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:15:23 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:02 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-19 19:25:02 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-19 19:25:02 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-19 19:25:02 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-19 19:25:02 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-19 19:25:02 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-19 19:25:02 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-19 19:25:02 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-19 19:25:02 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-19 19:25:02 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-19 19:25:02 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:02 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:02 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:02 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:02 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:02 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:02 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:02 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:02 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:02 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:03 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:03 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:03 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:03 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:03 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:03 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:03 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:03 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:03 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:03 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:03 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:03 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:03 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:03 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:03 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:03 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:03 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:03 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:03 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:03 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:03 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:03 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:03 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:03 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:03 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:03 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:03 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:03 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:03 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:03 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:03 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:03 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:19 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-19 19:25:20 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-19 19:25:20 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-19 19:25:20 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-19 19:25:20 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-19 19:25:20 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-19 19:25:20 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-19 19:25:20 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-19 19:25:20 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-19 19:25:20 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-19 19:25:20 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:20 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:20 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:20 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:20 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:20 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:20 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:20 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:20 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:20 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:20 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:20 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:20 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:20 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:20 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:20 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:20 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:20 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:20 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:20 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:20 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:20 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:20 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:20 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:20 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:20 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:20 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:20 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:20 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:20 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:20 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:20 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:20 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:20 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:20 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:20 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:20 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:20 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:20 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:20 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:20 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:20 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:38 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-19 19:25:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-19 19:25:38 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-19 19:25:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-19 19:25:38 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-19 19:25:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-19 19:25:38 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-19 19:25:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-19 19:25:38 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-19 19:25:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-19 19:25:38 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:38 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:38 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:38 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:38 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:38 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:38 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:38 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:38 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:38 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:38 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:38 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:38 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:38 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:38 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:38 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:39 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:39 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:39 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:39 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:39 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:56 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-19 19:25:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-19 19:25:57 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-19 19:25:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-19 19:25:57 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-19 19:25:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-19 19:25:57 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-19 19:25:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-19 19:25:57 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-19 19:25:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-19 19:25:57 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:57 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:57 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:57 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:57 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:57 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:57 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:57 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:57 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:57 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:57 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:57 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:57 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:57 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:57 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:57 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:57 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:57 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:57 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:57 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:57 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:25:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:26:19 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-19 19:26:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-19 19:26:19 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-19 19:26:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-19 19:26:19 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-19 19:26:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-19 19:26:19 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-19 19:26:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-19 19:26:19 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-19 19:26:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-19 19:26:19 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:26:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:26:19 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:26:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:26:19 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:26:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:26:19 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:26:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:26:19 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:26:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:26:19 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:26:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:26:19 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:26:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:26:19 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:26:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:26:19 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:26:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:26:19 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:26:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:26:19 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:26:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:26:19 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:26:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:26:19 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:26:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:26:19 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:26:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:26:19 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:26:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:26:19 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:26:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:26:19 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:26:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:26:19 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:26:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:26:19 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:26:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:26:19 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:26:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:26:19 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-19 19:26:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
