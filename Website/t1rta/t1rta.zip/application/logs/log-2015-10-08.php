<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-10-08 20:00:29 --> You did not select a file to upload.
ERROR - 2015-10-08 20:01:43 --> You did not select a file to upload.
ERROR - 2015-10-08 20:03:25 --> You did not select a file to upload.
ERROR - 2015-10-08 20:06:09 --> You did not select a file to upload.
ERROR - 2015-10-08 20:24:11 --> You did not select a file to upload.
ERROR - 2015-10-08 20:24:58 --> You did not select a file to upload.
