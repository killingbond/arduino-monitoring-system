<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-11-22 13:18:44 --> Query error: Unknown column 'image' in 'field list'
ERROR - 2015-11-22 13:18:59 --> Severity: Notice  --> Undefined property: stdClass::$image C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 140
ERROR - 2015-11-22 13:18:59 --> Severity: Notice  --> Undefined property: stdClass::$pimage_id C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 141
ERROR - 2015-11-22 13:19:27 --> Severity: Notice  --> Undefined property: stdClass::$image C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 140
ERROR - 2015-11-22 13:19:27 --> Severity: Notice  --> Undefined property: stdClass::$pimage_id C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 141
ERROR - 2015-11-22 13:36:40 --> Severity: Warning  --> Missing argument 4 for MX_Model::update(), called in C:\xampp\htdocs\wassuphaters.com\w4zzup\application\models\product_m.php on line 84 and defined C:\xampp\htdocs\wassuphaters.com\w4zzup\application\core\MX_Model.php 127
ERROR - 2015-11-22 13:36:40 --> Severity: Notice  --> Undefined variable: data C:\xampp\htdocs\wassuphaters.com\w4zzup\application\core\MX_Model.php 137
ERROR - 2015-11-22 13:38:29 --> You did not select a file to upload.
ERROR - 2015-11-22 13:38:29 --> Severity: Notice  --> Undefined variable: product_id C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product.php 166
ERROR - 2015-11-22 13:38:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 36
ERROR - 2015-11-22 13:38:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 41
ERROR - 2015-11-22 13:38:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 49
ERROR - 2015-11-22 13:38:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 57
ERROR - 2015-11-22 13:38:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 71
ERROR - 2015-11-22 13:38:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 71
ERROR - 2015-11-22 13:38:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 71
ERROR - 2015-11-22 13:38:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 71
ERROR - 2015-11-22 13:38:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 71
ERROR - 2015-11-22 13:38:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 71
ERROR - 2015-11-22 13:38:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 92
ERROR - 2015-11-22 13:38:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 92
ERROR - 2015-11-22 13:38:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 92
ERROR - 2015-11-22 13:38:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 92
ERROR - 2015-11-22 13:38:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 92
ERROR - 2015-11-22 13:38:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 92
ERROR - 2015-11-22 13:38:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 92
ERROR - 2015-11-22 13:38:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 92
ERROR - 2015-11-22 13:38:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 92
ERROR - 2015-11-22 13:38:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 92
ERROR - 2015-11-22 13:38:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 92
ERROR - 2015-11-22 13:38:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 92
ERROR - 2015-11-22 13:38:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 92
ERROR - 2015-11-22 13:38:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 92
ERROR - 2015-11-22 13:38:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 92
ERROR - 2015-11-22 13:38:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 92
ERROR - 2015-11-22 13:38:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 92
ERROR - 2015-11-22 13:38:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 92
ERROR - 2015-11-22 13:38:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 92
ERROR - 2015-11-22 13:38:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 115
ERROR - 2015-11-22 13:38:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 169
ERROR - 2015-11-22 13:38:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 230
ERROR - 2015-11-22 13:38:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 287
ERROR - 2015-11-22 13:41:25 --> Severity: Warning  --> Missing argument 4 for MX_Model::update(), called in C:\xampp\htdocs\wassuphaters.com\w4zzup\application\models\product_m.php on line 84 and defined C:\xampp\htdocs\wassuphaters.com\w4zzup\application\core\MX_Model.php 127
ERROR - 2015-11-22 13:41:25 --> Severity: Notice  --> Undefined variable: data C:\xampp\htdocs\wassuphaters.com\w4zzup\application\core\MX_Model.php 137
ERROR - 2015-11-22 13:45:04 --> You did not select a file to upload.
ERROR - 2015-11-22 13:45:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 36
ERROR - 2015-11-22 13:45:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 41
ERROR - 2015-11-22 13:45:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 49
ERROR - 2015-11-22 13:45:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 57
ERROR - 2015-11-22 13:45:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 71
ERROR - 2015-11-22 13:45:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 71
ERROR - 2015-11-22 13:45:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 71
ERROR - 2015-11-22 13:45:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 71
ERROR - 2015-11-22 13:45:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 71
ERROR - 2015-11-22 13:45:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 71
ERROR - 2015-11-22 13:45:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 92
ERROR - 2015-11-22 13:45:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 92
ERROR - 2015-11-22 13:45:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 92
ERROR - 2015-11-22 13:45:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 92
ERROR - 2015-11-22 13:45:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 92
ERROR - 2015-11-22 13:45:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 92
ERROR - 2015-11-22 13:45:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 92
ERROR - 2015-11-22 13:45:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 92
ERROR - 2015-11-22 13:45:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 92
ERROR - 2015-11-22 13:45:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 92
ERROR - 2015-11-22 13:45:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 92
ERROR - 2015-11-22 13:45:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 92
ERROR - 2015-11-22 13:45:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 92
ERROR - 2015-11-22 13:45:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 92
ERROR - 2015-11-22 13:45:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 92
ERROR - 2015-11-22 13:45:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 92
ERROR - 2015-11-22 13:45:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 92
ERROR - 2015-11-22 13:45:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 92
ERROR - 2015-11-22 13:45:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 92
ERROR - 2015-11-22 13:45:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 115
ERROR - 2015-11-22 13:45:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 169
ERROR - 2015-11-22 13:45:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 230
ERROR - 2015-11-22 13:45:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 287
ERROR - 2015-11-22 13:45:14 --> Severity: Warning  --> Missing argument 4 for MX_Model::update(), called in C:\xampp\htdocs\wassuphaters.com\w4zzup\application\models\product_m.php on line 84 and defined C:\xampp\htdocs\wassuphaters.com\w4zzup\application\core\MX_Model.php 127
ERROR - 2015-11-22 13:45:14 --> Severity: Notice  --> Undefined variable: data C:\xampp\htdocs\wassuphaters.com\w4zzup\application\core\MX_Model.php 137
ERROR - 2015-11-22 13:46:07 --> You did not select a file to upload.
ERROR - 2015-11-22 13:46:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 36
ERROR - 2015-11-22 13:46:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 41
ERROR - 2015-11-22 13:46:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 49
ERROR - 2015-11-22 13:46:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 57
ERROR - 2015-11-22 13:46:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 71
ERROR - 2015-11-22 13:46:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 71
ERROR - 2015-11-22 13:46:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 71
ERROR - 2015-11-22 13:46:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 71
ERROR - 2015-11-22 13:46:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 71
ERROR - 2015-11-22 13:46:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 71
ERROR - 2015-11-22 13:46:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 92
ERROR - 2015-11-22 13:46:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 92
ERROR - 2015-11-22 13:46:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 92
ERROR - 2015-11-22 13:46:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 92
ERROR - 2015-11-22 13:46:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 92
ERROR - 2015-11-22 13:46:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 92
ERROR - 2015-11-22 13:46:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 92
ERROR - 2015-11-22 13:46:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 92
ERROR - 2015-11-22 13:46:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 92
ERROR - 2015-11-22 13:46:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 92
ERROR - 2015-11-22 13:46:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 92
ERROR - 2015-11-22 13:46:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 92
ERROR - 2015-11-22 13:46:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 92
ERROR - 2015-11-22 13:46:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 92
ERROR - 2015-11-22 13:46:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 92
ERROR - 2015-11-22 13:46:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 92
ERROR - 2015-11-22 13:46:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 92
ERROR - 2015-11-22 13:46:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 92
ERROR - 2015-11-22 13:46:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 92
ERROR - 2015-11-22 13:46:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 115
ERROR - 2015-11-22 13:46:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 169
ERROR - 2015-11-22 13:46:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 230
ERROR - 2015-11-22 13:46:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 287
ERROR - 2015-11-22 13:46:14 --> Severity: Warning  --> Missing argument 4 for MX_Model::update(), called in C:\xampp\htdocs\wassuphaters.com\w4zzup\application\models\product_m.php on line 84 and defined C:\xampp\htdocs\wassuphaters.com\w4zzup\application\core\MX_Model.php 127
ERROR - 2015-11-22 13:46:14 --> Severity: Notice  --> Undefined variable: data C:\xampp\htdocs\wassuphaters.com\w4zzup\application\core\MX_Model.php 137
ERROR - 2015-11-22 13:48:55 --> Severity: Notice  --> Array to string conversion C:\xampp\htdocs\wassuphaters.com\w4zzup\system\database\DB_active_rec.php 427
ERROR - 2015-11-22 13:48:55 --> Query error: Unknown column 'Array' in 'where clause'
ERROR - 2015-11-22 13:53:15 --> Severity: Notice  --> Array to string conversion C:\xampp\htdocs\wassuphaters.com\w4zzup\application\models\product_m.php 84
ERROR - 2015-11-22 13:54:30 --> Severity: Notice  --> Array to string conversion C:\xampp\htdocs\wassuphaters.com\w4zzup\application\models\product_m.php 84
ERROR - 2015-11-22 13:57:06 --> Severity: Notice  --> Array to string conversion C:\xampp\htdocs\wassuphaters.com\w4zzup\system\database\DB_active_rec.php 427
ERROR - 2015-11-22 13:57:06 --> Query error: Unknown column 'Array' in 'where clause'
ERROR - 2015-11-22 13:57:32 --> You did not select a file to upload.
ERROR - 2015-11-22 13:57:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 36
ERROR - 2015-11-22 13:57:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 41
ERROR - 2015-11-22 13:57:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 49
ERROR - 2015-11-22 13:57:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 57
ERROR - 2015-11-22 13:57:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 71
ERROR - 2015-11-22 13:57:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 71
ERROR - 2015-11-22 13:57:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 71
ERROR - 2015-11-22 13:57:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 71
ERROR - 2015-11-22 13:57:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 71
ERROR - 2015-11-22 13:57:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 71
ERROR - 2015-11-22 13:57:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 92
ERROR - 2015-11-22 13:57:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 92
ERROR - 2015-11-22 13:57:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 92
ERROR - 2015-11-22 13:57:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 92
ERROR - 2015-11-22 13:57:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 92
ERROR - 2015-11-22 13:57:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 92
ERROR - 2015-11-22 13:57:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 92
ERROR - 2015-11-22 13:57:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 92
ERROR - 2015-11-22 13:57:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 92
ERROR - 2015-11-22 13:57:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 92
ERROR - 2015-11-22 13:57:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 92
ERROR - 2015-11-22 13:57:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 92
ERROR - 2015-11-22 13:57:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 92
ERROR - 2015-11-22 13:57:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 92
ERROR - 2015-11-22 13:57:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 92
ERROR - 2015-11-22 13:57:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 92
ERROR - 2015-11-22 13:57:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 92
ERROR - 2015-11-22 13:57:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 92
ERROR - 2015-11-22 13:57:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 92
ERROR - 2015-11-22 13:57:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 115
ERROR - 2015-11-22 13:57:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 169
ERROR - 2015-11-22 13:57:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 230
ERROR - 2015-11-22 13:57:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 287
ERROR - 2015-11-22 13:57:42 --> Severity: Notice  --> Array to string conversion C:\xampp\htdocs\wassuphaters.com\w4zzup\system\database\DB_active_rec.php 427
ERROR - 2015-11-22 13:57:42 --> Query error: Unknown column 'Array' in 'where clause'
ERROR - 2015-11-22 13:59:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product.php 221
ERROR - 2015-11-22 13:59:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product.php 221
ERROR - 2015-11-22 13:59:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product.php 221
ERROR - 2015-11-22 14:03:52 --> Severity: Notice  --> Undefined variable: res C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product.php 225
ERROR - 2015-11-22 14:04:10 --> Severity: Notice  --> Undefined variable: res C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product.php 225
ERROR - 2015-11-22 14:48:42 --> Severity: Notice  --> Undefined variable: product_image2 C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 167
ERROR - 2015-11-22 14:48:42 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 167
ERROR - 2015-11-22 14:49:26 --> Severity: Notice  --> Undefined property: stdClass::$image2 C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 170
ERROR - 2015-11-22 14:54:55 --> Severity: Notice  --> Undefined variable: res C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product.php 299
ERROR - 2015-11-22 14:58:36 --> Severity: Notice  --> Undefined variable: res C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product.php 299
ERROR - 2015-11-22 14:59:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 180
ERROR - 2015-11-22 15:00:10 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 180
ERROR - 2015-11-22 15:24:16 --> Severity: Notice  --> Undefined variable: res C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product.php 285
ERROR - 2015-11-22 15:24:18 --> Severity: Notice  --> Undefined variable: res C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product.php 299
ERROR - 2015-11-22 15:27:00 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-22 15:27:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-22 15:27:00 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-22 15:27:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-22 15:27:00 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-22 15:27:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-22 15:27:00 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-22 15:27:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-22 15:27:00 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-22 15:27:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-22 15:27:00 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-22 15:27:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-22 15:27:00 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:27:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:27:00 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:27:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:27:00 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:27:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:27:00 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:27:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:27:00 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:27:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:27:00 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:27:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:27:00 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:27:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:27:00 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:27:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:27:00 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:27:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:27:00 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:27:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:27:00 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:27:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:27:00 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:27:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:27:00 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:27:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:27:00 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:27:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:27:00 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:27:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:27:00 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:27:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:27:01 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:27:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:27:01 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:27:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:27:01 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:27:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:27:12 --> Query error: Unknown column 'type' in 'field list'
ERROR - 2015-11-22 15:34:04 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-22 15:34:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-22 15:34:04 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-22 15:34:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-22 15:34:04 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-22 15:34:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-22 15:34:04 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-22 15:34:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-22 15:34:04 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-22 15:34:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-22 15:34:04 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-22 15:34:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-22 15:34:04 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:34:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:34:04 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:34:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:34:04 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:34:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:34:04 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:34:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:34:04 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:34:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:34:04 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:34:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:34:04 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:34:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:34:04 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:34:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:34:04 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:34:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:34:04 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:34:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:34:04 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:34:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:34:04 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:34:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:34:04 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:34:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:34:04 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:34:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:34:04 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:34:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:34:04 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:34:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:34:04 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:34:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:34:04 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:34:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:34:04 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:34:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:34:24 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-22 15:34:24 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-22 15:34:24 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-22 15:34:24 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-22 15:34:25 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-22 15:34:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-22 15:34:25 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-22 15:34:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-22 15:34:25 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-22 15:34:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-22 15:34:25 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-22 15:34:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-22 15:34:25 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:34:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:34:25 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:34:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:34:25 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:34:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:34:25 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:34:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:34:25 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:34:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:34:25 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:34:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:34:25 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:34:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:34:25 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:34:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:34:25 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:34:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:34:25 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:34:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:34:25 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:34:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:34:25 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:34:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:34:25 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:34:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:34:25 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:34:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:34:25 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:34:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:34:25 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:34:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:34:25 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:34:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:34:25 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:34:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:34:25 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:34:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:34:38 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-22 15:34:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-22 15:34:38 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-22 15:34:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-22 15:34:38 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-22 15:34:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-22 15:34:38 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-22 15:34:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-22 15:34:38 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-22 15:34:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-22 15:34:38 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-22 15:34:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-22 15:34:38 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:34:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:34:38 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:34:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:34:38 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:34:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:34:38 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:34:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:34:38 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:34:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:34:38 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:34:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:34:38 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:34:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:34:38 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:34:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:34:38 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:34:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:34:38 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:34:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:34:38 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:34:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:34:38 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:34:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:34:38 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:34:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:34:38 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:34:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:34:38 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:34:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:34:38 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:34:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:34:38 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:34:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:34:38 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:34:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:34:38 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:34:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:34:58 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-22 15:34:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-22 15:34:58 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-22 15:34:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-22 15:34:58 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-22 15:34:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-22 15:34:58 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-22 15:34:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-22 15:34:58 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-22 15:34:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-22 15:34:58 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-22 15:34:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-22 15:34:58 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:34:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:34:58 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:34:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:34:58 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:34:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:34:58 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:34:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:34:58 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:34:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:34:58 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:34:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:34:58 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:34:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:34:58 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:34:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:34:58 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:34:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:34:58 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:34:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:34:58 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:34:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:34:58 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:34:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:34:58 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:34:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:34:58 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:34:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:34:58 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:34:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:34:58 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:34:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:34:58 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:34:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:34:58 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:34:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:34:58 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:34:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-22 15:38:01 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'LIMIT 0, 10' at line 1
ERROR - 2015-11-22 15:38:04 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'LIMIT 0, 10' at line 1
ERROR - 2015-11-22 16:14:35 --> You did not select a file to upload.
