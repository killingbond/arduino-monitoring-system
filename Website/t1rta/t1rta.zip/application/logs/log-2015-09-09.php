<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-09-09 02:41:00 --> 404 Page Not Found --> login/index
ERROR - 2015-09-09 02:41:29 --> 404 Page Not Found --> login/auth
ERROR - 2015-09-09 02:55:18 --> 404 Page Not Found --> home/profile
ERROR - 2015-09-09 03:26:37 --> 404 Page Not Found --> contact
ERROR - 2015-09-09 03:30:21 --> Severity: Notice  --> Undefined variable: max_page /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/size/size.php 493
ERROR - 2015-09-09 03:30:21 --> Severity: Notice  --> Undefined variable: max_page /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/size/size.php 496
ERROR - 2015-09-09 03:30:21 --> Severity: Notice  --> Undefined variable: max_page /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/size/size.php 523
ERROR - 2015-09-09 03:30:21 --> Severity: Notice  --> Undefined variable: max_page /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/size/size.php 523
ERROR - 2015-09-09 03:30:21 --> Severity: Notice  --> Undefined variable: max_page /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/size/size.php 524
ERROR - 2015-09-09 03:30:21 --> Severity: Notice  --> Undefined variable: max_page /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/size/size.php 524
ERROR - 2015-09-09 03:30:52 --> Severity: Notice  --> Undefined variable: order /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/size/size.php 516
ERROR - 2015-09-09 03:30:52 --> Severity: Notice  --> Undefined variable: order /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/size/size.php 518
ERROR - 2015-09-09 03:30:52 --> Severity: Notice  --> Undefined variable: order /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/size/size.php 518
ERROR - 2015-09-09 03:30:52 --> Severity: Notice  --> Undefined variable: order /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/size/size.php 518
ERROR - 2015-09-09 03:30:52 --> Severity: Notice  --> Undefined variable: order /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/size/size.php 518
ERROR - 2015-09-09 03:30:52 --> Severity: Notice  --> Undefined variable: order /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/size/size.php 523
ERROR - 2015-09-09 03:30:52 --> Severity: Notice  --> Undefined variable: order /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/size/size.php 524
ERROR - 2015-09-09 04:29:00 --> 404 Page Not Found --> size/drop
ERROR - 2015-09-09 04:29:20 --> 404 Page Not Found --> size/drop
ERROR - 2015-09-09 04:33:46 --> Severity: Notice  --> Undefined property: Size::$load /Applications/MAMP/htdocs/Wassuphaters/admin/application/controllers/size.php 5
ERROR - 2015-09-09 04:34:40 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/Wassuphaters/admin/application/helpers/link_helper.php:11) /Applications/MAMP/htdocs/Wassuphaters/admin/application/controllers/size.php 66
ERROR - 2015-09-09 04:35:19 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/Wassuphaters/admin/application/helpers/link_helper.php:11) /Applications/MAMP/htdocs/Wassuphaters/admin/application/controllers/size.php 66
ERROR - 2015-09-09 04:38:39 --> Severity: Notice  --> Undefined property: Size::$load /Applications/MAMP/htdocs/Wassuphaters/admin/application/controllers/size.php 59
ERROR - 2015-09-09 04:39:32 --> Severity: Notice  --> Undefined property: Size::$load /Applications/MAMP/htdocs/Wassuphaters/admin/application/controllers/size.php 59
ERROR - 2015-09-09 04:39:37 --> Severity: Notice  --> Undefined property: Size::$load /Applications/MAMP/htdocs/Wassuphaters/admin/application/controllers/size.php 59
ERROR - 2015-09-09 04:39:56 --> Severity: Notice  --> Undefined property: Size::$input /Applications/MAMP/htdocs/Wassuphaters/admin/application/controllers/size.php 61
ERROR - 2015-09-09 04:43:27 --> Severity: Notice  --> Undefined property: Size::$size_m /Applications/MAMP/htdocs/Wassuphaters/admin/application/controllers/size.php 66
ERROR - 2015-09-09 04:53:58 --> Severity: Notice  --> Undefined variable: max /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/size/add_size.php 62
ERROR - 2015-09-09 04:53:58 --> Severity: Notice  --> Undefined variable: max /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/size/add_size.php 63
ERROR - 2015-09-09 04:53:59 --> Severity: Notice  --> Undefined variable: max /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/size/add_size.php 64
ERROR - 2015-09-09 04:53:59 --> Severity: Notice  --> Undefined variable: max /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/size/add_size.php 65
ERROR - 2015-09-09 04:53:59 --> Severity: Notice  --> Undefined variable: max /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/size/add_size.php 66
ERROR - 2015-09-09 04:53:59 --> Severity: Notice  --> Undefined variable: search /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/size/add_size.php 71
ERROR - 2015-09-09 04:53:59 --> Severity: Notice  --> Undefined variable: data_table /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/size/add_size.php 90
ERROR - 2015-09-09 04:53:59 --> Severity: Notice  --> Undefined variable: start /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/size/add_size.php 111
ERROR - 2015-09-09 04:53:59 --> Severity: Notice  --> Undefined variable: stop /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/size/add_size.php 111
ERROR - 2015-09-09 04:53:59 --> Severity: Notice  --> Undefined variable: max_row /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/size/add_size.php 111
ERROR - 2015-09-09 04:53:59 --> Severity: Notice  --> Undefined variable: page /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/size/add_size.php 116
ERROR - 2015-09-09 04:53:59 --> Severity: Notice  --> Undefined variable: page /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/size/add_size.php 116
ERROR - 2015-09-09 04:53:59 --> Severity: Notice  --> Undefined variable: page /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/size/add_size.php 117
ERROR - 2015-09-09 04:53:59 --> Severity: Notice  --> Undefined variable: page /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/size/add_size.php 117
ERROR - 2015-09-09 04:53:59 --> Severity: Notice  --> Undefined variable: page /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/size/add_size.php 122
ERROR - 2015-09-09 04:53:59 --> Severity: Notice  --> Undefined variable: max_page /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/size/add_size.php 123
ERROR - 2015-09-09 04:53:59 --> Severity: Notice  --> Undefined variable: max_page /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/size/add_size.php 126
ERROR - 2015-09-09 04:53:59 --> Severity: Notice  --> Undefined variable: max_page /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/size/add_size.php 153
ERROR - 2015-09-09 04:53:59 --> Severity: Notice  --> Undefined variable: page /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/size/add_size.php 153
ERROR - 2015-09-09 04:53:59 --> Severity: Notice  --> Undefined variable: max_page /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/size/add_size.php 153
ERROR - 2015-09-09 04:53:59 --> Severity: Notice  --> Undefined variable: page /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/size/add_size.php 153
ERROR - 2015-09-09 04:53:59 --> Severity: Notice  --> Undefined variable: max_page /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/size/add_size.php 154
ERROR - 2015-09-09 04:53:59 --> Severity: Notice  --> Undefined variable: page /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/size/add_size.php 154
ERROR - 2015-09-09 04:53:59 --> Severity: Notice  --> Undefined variable: max_page /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/size/add_size.php 154
ERROR - 2015-09-09 04:53:59 --> Severity: Notice  --> Undefined variable: page /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/size/add_size.php 154
ERROR - 2015-09-09 04:53:59 --> Severity: Notice  --> Undefined variable: page /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/size/add_size.php 254
ERROR - 2015-09-09 04:53:59 --> Severity: Notice  --> Undefined variable: order /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/size/add_size.php 255
ERROR - 2015-09-09 04:54:20 --> Severity: Notice  --> Undefined variable: page /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/size/add_size.php 126
ERROR - 2015-09-09 04:54:20 --> Severity: Notice  --> Undefined variable: order /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/size/add_size.php 127
ERROR - 2015-09-09 05:05:06 --> 404 Page Not Found --> size/update
ERROR - 2015-09-09 05:20:13 --> Severity: Warning  --> Missing argument 4 for Size_m::get_all(), called in /Applications/MAMP/htdocs/Wassuphaters/admin/application/controllers/size.php on line 36 and defined /Applications/MAMP/htdocs/Wassuphaters/admin/application/models/size_m.php 11
ERROR - 2015-09-09 05:20:13 --> Severity: Notice  --> Uninitialized string offset: 1 /Applications/MAMP/htdocs/Wassuphaters/admin/application/models/size_m.php 15
ERROR - 2015-09-09 05:20:13 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'LIKE '%search%'   DESC LIMIT 1, 1A' at line 1
ERROR - 2015-09-09 05:20:13 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/Wassuphaters/admin/system/core/Exceptions.php:185) /Applications/MAMP/htdocs/Wassuphaters/admin/system/core/Common.php 442
ERROR - 2015-09-09 05:20:57 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'LIKE '%search%'   DESC LIMIT 1, 10' at line 1
ERROR - 2015-09-09 05:21:11 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'DESC LIMIT 1, 10' at line 1
ERROR - 2015-09-09 05:21:42 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'DESC LIMIT 1, 10' at line 1
ERROR - 2015-09-09 05:22:02 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'size DESC LIMIT 1, 10' at line 1
ERROR - 2015-09-09 05:22:23 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'size DESC LIMIT 1, 10' at line 1
ERROR - 2015-09-09 05:22:45 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'size ASC LIMIT 1, 10' at line 1
ERROR - 2015-09-09 05:50:03 --> Query error: Table 'wassuphaters.category' doesn't exist
ERROR - 2015-09-09 05:54:28 --> Severity: Notice  --> Undefined property: stdClass::$size /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/product_category/category.php 86
ERROR - 2015-09-09 05:56:44 --> Severity: Notice  --> Undefined property: stdClass::$size_id /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/product_category/edit_category.php 37
ERROR - 2015-09-09 05:56:44 --> Severity: Notice  --> Undefined property: stdClass::$size /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/product_category/edit_category.php 43
ERROR - 2015-09-09 06:05:46 --> Query error: Unknown column 'product' in 'where clause'
ERROR - 2015-09-09 06:06:01 --> Query error: Unknown column 'product' in 'where clause'
ERROR - 2015-09-09 06:06:36 --> Query error: Unknown column 'product' in 'where clause'
ERROR - 2015-09-09 06:25:03 --> 404 Page Not Found --> product_category/add_product
ERROR - 2015-09-09 06:25:27 --> Severity: Notice  --> Undefined property: stdClass::$category /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/product/product.php 98
ERROR - 2015-09-09 06:25:55 --> Query error: Unknown column 'catgory_id' in 'from clause'
ERROR - 2015-09-09 06:26:19 --> Query error: Unknown column 'catgory_id' in 'from clause'
ERROR - 2015-09-09 06:26:22 --> Query error: Unknown column 'catgory_id' in 'from clause'
ERROR - 2015-09-09 06:42:37 --> Severity: Notice  --> Undefined variable: size /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/product/edit_product.php 124
ERROR - 2015-09-09 06:42:54 --> Severity: Notice  --> Undefined variable: size /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/product/edit_product.php 124
ERROR - 2015-09-09 06:43:10 --> Severity: Notice  --> Undefined variable: size /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/product/edit_product.php 124
ERROR - 2015-09-09 06:51:28 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Wassuphaters/admin/application/controllers/product.php 98
ERROR - 2015-09-09 06:51:28 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/Wassuphaters/admin/system/core/Exceptions.php:185) /Applications/MAMP/htdocs/Wassuphaters/admin/application/controllers/product.php 98
ERROR - 2015-09-09 06:51:56 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/product/edit_product.php 40
ERROR - 2015-09-09 06:51:56 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/product/edit_product.php 48
ERROR - 2015-09-09 06:51:56 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/product/edit_product.php 56
ERROR - 2015-09-09 06:51:56 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/product/edit_product.php 65
ERROR - 2015-09-09 06:51:56 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/product/edit_product.php 66
ERROR - 2015-09-09 06:51:56 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/product/edit_product.php 67
ERROR - 2015-09-09 06:51:56 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/product/edit_product.php 81
ERROR - 2015-09-09 06:51:56 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/product/edit_product.php 81
ERROR - 2015-09-09 06:51:56 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/product/edit_product.php 81
ERROR - 2015-09-09 06:51:56 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/product/edit_product.php 81
ERROR - 2015-09-09 06:51:56 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/product/edit_product.php 81
ERROR - 2015-09-09 06:51:56 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/product/edit_product.php 81
ERROR - 2015-09-09 06:51:56 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/product/edit_product.php 81
ERROR - 2015-09-09 06:51:56 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/product/edit_product.php 81
ERROR - 2015-09-09 06:51:56 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/product/edit_product.php 155
ERROR - 2015-09-09 07:00:07 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/product/edit_product.php 40
ERROR - 2015-09-09 07:00:07 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/product/edit_product.php 48
ERROR - 2015-09-09 07:00:10 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/product/edit_product.php 56
ERROR - 2015-09-09 07:00:10 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/product/edit_product.php 65
ERROR - 2015-09-09 07:00:10 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/product/edit_product.php 66
ERROR - 2015-09-09 07:00:10 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/product/edit_product.php 67
ERROR - 2015-09-09 07:00:10 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/product/edit_product.php 81
ERROR - 2015-09-09 07:00:10 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/product/edit_product.php 81
ERROR - 2015-09-09 07:00:10 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/product/edit_product.php 81
ERROR - 2015-09-09 07:00:10 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/product/edit_product.php 81
ERROR - 2015-09-09 07:00:10 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/product/edit_product.php 81
ERROR - 2015-09-09 07:00:10 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/product/edit_product.php 81
ERROR - 2015-09-09 07:00:10 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/product/edit_product.php 81
ERROR - 2015-09-09 07:00:10 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/product/edit_product.php 81
ERROR - 2015-09-09 07:00:10 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/product/edit_product.php 115
ERROR - 2015-09-09 07:00:10 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/product/edit_product.php 168
ERROR - 2015-09-09 07:03:07 --> Query error: Unknown column '10' in 'field list'
ERROR - 2015-09-09 07:04:59 --> 404 Page Not Found --> order
ERROR - 2015-09-09 07:52:06 --> Query error: Unknown column 'category_id' in 'from clause'
ERROR - 2015-09-09 07:52:21 --> Query error: Unknown column 'name' in 'where clause'
ERROR - 2015-09-09 07:54:43 --> Query error: Unknown column 'name' in 'where clause'
ERROR - 2015-09-09 07:54:45 --> Query error: Unknown column 'name' in 'where clause'
ERROR - 2015-09-09 07:54:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/Wassuphaters/admin/application/models/order_m.php 27
ERROR - 2015-09-09 07:54:54 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/Wassuphaters/admin/system/core/Exceptions.php:185) /Applications/MAMP/htdocs/Wassuphaters/admin/system/core/Common.php 442
ERROR - 2015-09-09 07:59:53 --> Severity: Notice  --> Undefined property: stdClass::$name /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/order/order.php 90
ERROR - 2015-09-09 07:59:53 --> Severity: Notice  --> Undefined property: stdClass::$special_price /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/order/order.php 93
ERROR - 2015-09-09 07:59:53 --> Severity: Notice  --> Undefined property: stdClass::$price /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/order/order.php 94
ERROR - 2015-09-09 07:59:53 --> Severity: Notice  --> Undefined variable: type /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/order/order.php 101
ERROR - 2015-09-09 07:59:53 --> Severity: Notice  --> Undefined property: stdClass::$category /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/order/order.php 102
ERROR - 2015-09-09 07:59:53 --> Severity: Notice  --> Undefined property: stdClass::$stock /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/order/order.php 105
ERROR - 2015-09-09 08:09:18 --> Severity: Notice  --> Undefined variable: data_update /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/order/order_detail.php 40
ERROR - 2015-09-09 08:09:18 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/order/order_detail.php 40
ERROR - 2015-09-09 08:09:18 --> Severity: Notice  --> Undefined variable: data_update /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/order/order_detail.php 48
ERROR - 2015-09-09 08:09:18 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/order/order_detail.php 48
ERROR - 2015-09-09 08:09:18 --> Severity: Notice  --> Undefined variable: data_update /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/order/order_detail.php 56
ERROR - 2015-09-09 08:09:18 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/order/order_detail.php 56
ERROR - 2015-09-09 08:09:18 --> Severity: Notice  --> Undefined variable: data_update /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/order/order_detail.php 65
ERROR - 2015-09-09 08:09:18 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/order/order_detail.php 65
ERROR - 2015-09-09 08:09:18 --> Severity: Notice  --> Undefined variable: data_update /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/order/order_detail.php 66
ERROR - 2015-09-09 08:09:18 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/order/order_detail.php 66
ERROR - 2015-09-09 08:09:18 --> Severity: Notice  --> Undefined variable: data_update /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/order/order_detail.php 67
ERROR - 2015-09-09 08:09:18 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/order/order_detail.php 67
ERROR - 2015-09-09 08:09:18 --> Severity: Notice  --> Undefined variable: category /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/order/order_detail.php 79
ERROR - 2015-09-09 08:09:18 --> Severity: Notice  --> Undefined variable: data_update /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/order/order_detail.php 115
ERROR - 2015-09-09 08:09:18 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/order/order_detail.php 115
ERROR - 2015-09-09 08:09:18 --> Severity: Notice  --> Undefined variable: product_detail /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/order/order_detail.php 132
ERROR - 2015-09-09 08:09:18 --> Severity: Notice  --> Undefined variable: data_update /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/order/order_detail.php 176
ERROR - 2015-09-09 08:09:18 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/order/order_detail.php 176
ERROR - 2015-09-09 08:09:18 --> Severity: Notice  --> Undefined variable: size /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/order/order_detail.php 184
ERROR - 2015-09-09 08:10:31 --> Severity: Notice  --> Undefined variable: product_detail /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/order/order_detail.php 49
ERROR - 2015-09-09 08:10:31 --> Severity: Notice  --> Undefined variable: data_update /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/order/order_detail.php 83
ERROR - 2015-09-09 08:10:31 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/order/order_detail.php 83
ERROR - 2015-09-09 08:10:31 --> Severity: Notice  --> Undefined variable: product_detail /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/order/order_detail.php 100
ERROR - 2015-09-09 08:10:31 --> Severity: Notice  --> Undefined variable: data_update /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/order/order_detail.php 144
ERROR - 2015-09-09 08:10:31 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/order/order_detail.php 144
ERROR - 2015-09-09 08:10:31 --> Severity: Notice  --> Undefined variable: size /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/order/order_detail.php 152
ERROR - 2015-09-09 08:10:52 --> Severity: Notice  --> Undefined property: stdClass::$size /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/order/order_detail.php 55
ERROR - 2015-09-09 08:10:52 --> Severity: Notice  --> Undefined property: stdClass::$stock /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/order/order_detail.php 58
ERROR - 2015-09-09 08:10:52 --> Severity: Notice  --> Undefined variable: data_update /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/order/order_detail.php 83
ERROR - 2015-09-09 08:10:52 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/order/order_detail.php 83
ERROR - 2015-09-09 08:10:52 --> Severity: Notice  --> Undefined variable: product_detail /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/order/order_detail.php 100
ERROR - 2015-09-09 08:10:52 --> Severity: Notice  --> Undefined variable: data_update /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/order/order_detail.php 144
ERROR - 2015-09-09 08:10:52 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/order/order_detail.php 144
ERROR - 2015-09-09 08:10:52 --> Severity: Notice  --> Undefined variable: size /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/order/order_detail.php 152
ERROR - 2015-09-09 08:13:08 --> Severity: Notice  --> Undefined property: stdClass::$product_name /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/order/order_detail.php 57
ERROR - 2015-09-09 08:13:08 --> Severity: Notice  --> Undefined variable: data_update /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/order/order_detail.php 83
ERROR - 2015-09-09 08:13:11 --> Severity: Notice  --> Undefined property: stdClass::$product_name /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/order/order_detail.php 57
ERROR - 2015-09-09 08:13:11 --> Severity: Notice  --> Undefined variable: data_update /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/order/order_detail.php 83
ERROR - 2015-09-09 08:13:11 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/order/order_detail.php 83
ERROR - 2015-09-09 08:13:11 --> Severity: Notice  --> Undefined variable: product_detail /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/order/order_detail.php 100
ERROR - 2015-09-09 08:13:11 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/order/order_detail.php 83
ERROR - 2015-09-09 08:13:11 --> Severity: Notice  --> Undefined variable: product_detail /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/order/order_detail.php 100
ERROR - 2015-09-09 08:13:11 --> Severity: Notice  --> Undefined variable: data_update /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/order/order_detail.php 144
ERROR - 2015-09-09 08:13:11 --> Severity: Notice  --> Undefined variable: data_update /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/order/order_detail.php 144
ERROR - 2015-09-09 08:13:11 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/order/order_detail.php 144
ERROR - 2015-09-09 08:13:11 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/order/order_detail.php 144
ERROR - 2015-09-09 08:13:11 --> Severity: Notice  --> Undefined variable: size /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/order/order_detail.php 152
ERROR - 2015-09-09 08:13:11 --> Severity: Notice  --> Undefined variable: size /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/order/order_detail.php 152
ERROR - 2015-09-09 08:14:06 --> Severity: Notice  --> Undefined property: stdClass::$product_name /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/order/order_detail.php 57
ERROR - 2015-09-09 08:14:06 --> Severity: Notice  --> Undefined variable: data_update /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/order/order_detail.php 83
ERROR - 2015-09-09 08:14:06 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/order/order_detail.php 83
ERROR - 2015-09-09 08:14:06 --> Severity: Notice  --> Undefined variable: product_detail /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/order/order_detail.php 100
ERROR - 2015-09-09 08:14:06 --> Severity: Notice  --> Undefined variable: data_update /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/order/order_detail.php 144
ERROR - 2015-09-09 08:14:06 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/order/order_detail.php 144
ERROR - 2015-09-09 08:14:06 --> Severity: Notice  --> Undefined variable: size /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/order/order_detail.php 152
ERROR - 2015-09-09 08:14:26 --> Severity: Notice  --> Undefined variable: data_update /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/order/order_detail.php 83
ERROR - 2015-09-09 08:14:26 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/order/order_detail.php 83
ERROR - 2015-09-09 08:14:26 --> Severity: Notice  --> Undefined variable: product_detail /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/order/order_detail.php 100
ERROR - 2015-09-09 08:14:26 --> Severity: Notice  --> Undefined variable: data_update /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/order/order_detail.php 144
ERROR - 2015-09-09 08:14:26 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/order/order_detail.php 144
ERROR - 2015-09-09 08:14:26 --> Severity: Notice  --> Undefined variable: size /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/order/order_detail.php 152
ERROR - 2015-09-09 08:18:33 --> Severity: Notice  --> Undefined variable: data_update /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/order/order_detail.php 83
ERROR - 2015-09-09 08:18:33 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/order/order_detail.php 83
ERROR - 2015-09-09 08:18:33 --> Severity: Notice  --> Undefined variable: product_detail /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/order/order_detail.php 100
ERROR - 2015-09-09 08:18:33 --> Severity: Notice  --> Undefined variable: data_update /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/order/order_detail.php 144
ERROR - 2015-09-09 08:18:33 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/order/order_detail.php 144
ERROR - 2015-09-09 08:18:33 --> Severity: Notice  --> Undefined variable: size /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/order/order_detail.php 152
ERROR - 2015-09-09 08:21:09 --> Severity: Notice  --> Undefined variable: order /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/order/order_detail.php 78
ERROR - 2015-09-09 08:21:09 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/order/order_detail.php 78
ERROR - 2015-09-09 08:21:09 --> Severity: Notice  --> Undefined variable: order /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/order/order_detail.php 82
ERROR - 2015-09-09 08:21:09 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/order/order_detail.php 82
ERROR - 2015-09-09 08:21:09 --> Severity: Notice  --> Undefined variable: data_update /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/order/order_detail.php 100
ERROR - 2015-09-09 08:21:09 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/order/order_detail.php 100
ERROR - 2015-09-09 08:21:09 --> Severity: Notice  --> Undefined variable: product_detail /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/order/order_detail.php 117
ERROR - 2015-09-09 08:21:09 --> Severity: Notice  --> Undefined variable: data_update /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/order/order_detail.php 161
ERROR - 2015-09-09 08:21:09 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/order/order_detail.php 161
ERROR - 2015-09-09 08:21:09 --> Severity: Notice  --> Undefined variable: size /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/order/order_detail.php 169
ERROR - 2015-09-09 08:21:29 --> Severity: Notice  --> Undefined variable: data_update /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/order/order_detail.php 100
ERROR - 2015-09-09 08:21:29 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/order/order_detail.php 100
ERROR - 2015-09-09 08:21:29 --> Severity: Notice  --> Undefined variable: product_detail /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/order/order_detail.php 117
ERROR - 2015-09-09 08:21:29 --> Severity: Notice  --> Undefined variable: data_update /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/order/order_detail.php 161
ERROR - 2015-09-09 08:21:29 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/order/order_detail.php 161
ERROR - 2015-09-09 08:21:29 --> Severity: Notice  --> Undefined variable: size /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/order/order_detail.php 169
ERROR - 2015-09-09 08:22:22 --> Severity: Notice  --> Undefined variable: data_update /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/order/order_detail.php 100
ERROR - 2015-09-09 08:22:22 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/order/order_detail.php 100
ERROR - 2015-09-09 08:22:22 --> Severity: Notice  --> Undefined variable: product_detail /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/order/order_detail.php 117
ERROR - 2015-09-09 08:22:22 --> Severity: Notice  --> Undefined variable: data_update /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/order/order_detail.php 161
ERROR - 2015-09-09 08:22:22 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/order/order_detail.php 161
ERROR - 2015-09-09 08:22:22 --> Severity: Notice  --> Undefined variable: size /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/order/order_detail.php 169
ERROR - 2015-09-09 08:22:45 --> Severity: Notice  --> Undefined variable: data_update /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/order/order_detail.php 100
ERROR - 2015-09-09 08:22:45 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/order/order_detail.php 100
ERROR - 2015-09-09 08:22:45 --> Severity: Notice  --> Undefined variable: product_detail /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/order/order_detail.php 117
ERROR - 2015-09-09 08:22:45 --> Severity: Notice  --> Undefined variable: data_update /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/order/order_detail.php 161
ERROR - 2015-09-09 08:22:46 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/order/order_detail.php 161
ERROR - 2015-09-09 08:22:46 --> Severity: Notice  --> Undefined variable: size /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/order/order_detail.php 169
ERROR - 2015-09-09 08:28:26 --> Severity: Notice  --> Undefined property: stdClass::$province /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/order/order_detail.php 91
ERROR - 2015-09-09 08:28:26 --> Severity: Notice  --> Undefined property: stdClass::$city /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/order/order_detail.php 99
ERROR - 2015-09-09 08:28:26 --> Severity: Notice  --> Undefined property: stdClass::$district /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/order/order_detail.php 107
ERROR - 2015-09-09 08:34:09 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'orderlist WHERE order_id = 'ORD00001'' at line 1
ERROR - 2015-09-09 08:34:37 --> Query error: Unknown column '0' in 'where clause'
ERROR - 2015-09-09 08:35:03 --> Severity: Notice  --> Undefined property: stdClass::$city /Applications/MAMP/htdocs/Wassuphaters/admin/application/models/order_m.php 40
ERROR - 2015-09-09 08:35:03 --> Severity: Notice  --> Undefined property: stdClass::$province /Applications/MAMP/htdocs/Wassuphaters/admin/application/models/order_m.php 41
ERROR - 2015-09-09 09:03:18 --> Severity: Notice  --> Undefined property: stdClass::$grand_total /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/order/order.php 94
