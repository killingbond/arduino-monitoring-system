<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2014-08-30 03:25:27 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
ERROR - 2014-08-30 03:25:38 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 141
ERROR - 2014-08-30 03:25:38 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 141
ERROR - 2014-08-30 03:25:57 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 141
ERROR - 2014-08-30 03:25:57 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 141
ERROR - 2014-08-30 03:26:38 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 140
ERROR - 2014-08-30 03:26:38 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 140
ERROR - 2014-08-30 03:26:51 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 140
ERROR - 2014-08-30 03:26:51 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 140
ERROR - 2014-08-30 03:26:56 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 140
ERROR - 2014-08-30 03:26:56 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 140
ERROR - 2014-08-30 03:28:13 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-08-30 03:28:13 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-08-30 03:28:38 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-08-30 03:28:38 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-08-30 03:29:05 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-08-30 03:29:05 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-08-30 03:30:19 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-08-30 03:30:19 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-08-30 03:30:33 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-08-30 03:30:33 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-08-30 03:30:37 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-08-30 03:30:37 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-08-30 03:30:53 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-08-30 03:30:53 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-08-30 03:31:07 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-08-30 03:31:07 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-08-30 03:32:59 --> Severity: Warning  --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\wamp\www\Galaxia-Store\system\libraries\Email.php 1553
ERROR - 2014-08-30 03:34:05 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
ERROR - 2014-08-30 03:34:11 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-08-30 03:34:11 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-08-30 03:34:24 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-08-30 03:34:24 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-08-30 03:34:53 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-08-30 03:34:53 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-08-30 03:35:23 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-08-30 03:35:23 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-08-30 03:35:49 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
ERROR - 2014-08-30 03:35:59 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-08-30 03:35:59 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-08-30 03:36:19 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
ERROR - 2014-08-30 03:37:16 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
ERROR - 2014-08-30 03:38:05 --> 404 Page Not Found --> template
ERROR - 2014-08-30 03:38:36 --> Severity: Warning  --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\wamp\www\Galaxia-Store\system\libraries\Email.php 1553
ERROR - 2014-08-30 03:38:37 --> 404 Page Not Found --> template
ERROR - 2014-08-30 03:41:09 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
ERROR - 2014-08-30 03:41:17 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-08-30 03:41:17 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-08-30 03:49:59 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
ERROR - 2014-08-30 03:56:01 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
ERROR - 2014-08-30 03:56:33 --> Severity: Warning  --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\wamp\www\Galaxia-Store\system\libraries\Email.php 1553
ERROR - 2014-08-30 03:57:20 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
ERROR - 2014-08-30 03:58:08 --> Severity: Warning  --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\wamp\www\Galaxia-Store\system\libraries\Email.php 1553
ERROR - 2014-08-30 03:58:18 --> Severity: Warning  --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\wamp\www\Galaxia-Store\system\libraries\Email.php 1553
ERROR - 2014-08-30 04:20:54 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
ERROR - 2014-08-30 04:32:28 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
ERROR - 2014-08-30 04:32:35 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-08-30 04:32:35 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-08-30 04:32:52 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
ERROR - 2014-08-30 04:32:57 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-08-30 04:32:57 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-08-30 04:33:05 --> Severity: Warning  --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\wamp\www\Galaxia-Store\system\libraries\Email.php 1553
ERROR - 2014-08-30 04:53:14 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
ERROR - 2014-08-30 04:53:33 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-08-30 04:53:33 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-08-30 04:53:41 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-08-30 04:53:41 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-08-30 04:53:49 --> Severity: Warning  --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\wamp\www\Galaxia-Store\system\libraries\Email.php 1553
ERROR - 2014-08-30 05:59:08 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
ERROR - 2014-08-30 05:59:14 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-08-30 05:59:14 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-08-30 05:59:20 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-08-30 05:59:20 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-08-30 05:59:33 --> Severity: Warning  --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\wamp\www\Galaxia-Store\system\libraries\Email.php 1553
ERROR - 2014-08-30 06:00:28 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
ERROR - 2014-08-30 06:00:35 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-08-30 06:00:35 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-08-30 06:00:45 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-08-30 06:00:45 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-08-30 06:00:53 --> Severity: Warning  --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\wamp\www\Galaxia-Store\system\libraries\Email.php 1553
ERROR - 2014-08-30 06:04:02 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
ERROR - 2014-08-30 06:04:14 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-08-30 06:04:14 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-08-30 06:04:21 --> Severity: Warning  --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\wamp\www\Galaxia-Store\system\libraries\Email.php 1553
ERROR - 2014-08-30 06:04:30 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-08-30 06:04:30 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-08-30 06:04:37 --> Severity: Warning  --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\wamp\www\Galaxia-Store\system\libraries\Email.php 1553
ERROR - 2014-08-30 06:05:06 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
ERROR - 2014-08-30 06:05:12 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-08-30 06:05:12 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-08-30 06:05:18 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-08-30 06:05:18 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-08-30 06:05:25 --> Severity: Warning  --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\wamp\www\Galaxia-Store\system\libraries\Email.php 1553
ERROR - 2014-08-30 06:06:32 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
ERROR - 2014-08-30 06:06:36 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-08-30 06:06:36 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-08-30 06:07:13 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-08-30 06:07:13 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-08-30 06:07:24 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-08-30 06:07:24 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-08-30 06:07:35 --> Severity: Warning  --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\wamp\www\Galaxia-Store\system\libraries\Email.php 1553
ERROR - 2014-08-30 06:08:17 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
ERROR - 2014-08-30 06:08:20 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-08-30 06:08:20 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-08-30 06:08:25 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-08-30 06:08:25 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-08-30 06:08:32 --> Severity: Warning  --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\wamp\www\Galaxia-Store\system\libraries\Email.php 1553
ERROR - 2014-08-30 06:08:39 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-08-30 06:08:39 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-08-30 06:08:46 --> Severity: Warning  --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\wamp\www\Galaxia-Store\system\libraries\Email.php 1553
ERROR - 2014-08-30 06:39:49 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
ERROR - 2014-08-30 06:40:12 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-08-30 06:40:12 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-08-30 06:40:18 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-08-30 06:40:18 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-08-30 06:40:24 --> Severity: 4096  --> Object of class stdClass could not be converted to string C:\wamp\www\Galaxia-Store\application\models\email_m.php 38
ERROR - 2014-08-30 06:40:24 --> Severity: Notice  --> Object of class stdClass to string conversion C:\wamp\www\Galaxia-Store\application\models\email_m.php 38
ERROR - 2014-08-30 06:40:51 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\Galaxia-Store\application\models\cart_m.php 392
ERROR - 2014-08-30 06:40:51 --> Severity: Notice  --> Undefined variable: data_login C:\wamp\www\Galaxia-Store\application\models\cart_m.php 453
ERROR - 2014-08-30 06:40:51 --> Query error: Column 'member_id' cannot be null
ERROR - 2014-08-30 06:41:36 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Galaxia-Store\application\controllers\cart.php 158
ERROR - 2014-08-30 06:41:36 --> Severity: Notice  --> Undefined property: stdClass::$content C:\wamp\www\Galaxia-Store\application\controllers\cart.php 162
ERROR - 2014-08-30 06:42:21 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Galaxia-Store\application\controllers\cart.php 158
ERROR - 2014-08-30 06:52:12 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
ERROR - 2014-08-30 06:52:19 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-08-30 06:52:19 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-08-30 06:52:25 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-08-30 06:52:25 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-08-30 07:04:26 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
ERROR - 2014-08-30 07:04:26 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Galaxia-Store\application\controllers\cart.php 163
ERROR - 2014-08-30 07:04:26 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Galaxia-Store\application\controllers\cart.php 164
ERROR - 2014-08-30 07:21:31 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
ERROR - 2014-08-30 07:21:31 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Galaxia-Store\application\controllers\cart.php 162
ERROR - 2014-08-30 07:21:31 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Galaxia-Store\application\controllers\cart.php 163
ERROR - 2014-08-30 07:21:31 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Galaxia-Store\application\models\email_m.php 35
ERROR - 2014-08-30 07:21:31 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Galaxia-Store\application\models\email_m.php 36
ERROR - 2014-08-30 07:21:31 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Galaxia-Store\application\models\email_m.php 37
ERROR - 2014-08-30 07:21:31 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Galaxia-Store\application\models\email_m.php 38
ERROR - 2014-08-30 07:21:31 --> Severity: Notice  --> Undefined index: content C:\wamp\www\Galaxia-Store\application\models\email_m.php 49
ERROR - 2014-08-30 07:21:53 --> Severity: 4096  --> Object of class stdClass could not be converted to string C:\wamp\www\Galaxia-Store\application\models\email_m.php 39
ERROR - 2014-08-30 07:21:53 --> Severity: Notice  --> Object of class stdClass to string conversion C:\wamp\www\Galaxia-Store\application\models\email_m.php 39
ERROR - 2014-08-30 07:21:53 --> Severity: 4096  --> Object of class stdClass could not be converted to string C:\wamp\www\Galaxia-Store\application\models\email_m.php 40
ERROR - 2014-08-30 07:21:53 --> Severity: Notice  --> Object of class stdClass to string conversion C:\wamp\www\Galaxia-Store\application\models\email_m.php 40
ERROR - 2014-08-30 07:21:53 --> Severity: 4096  --> Object of class stdClass could not be converted to string C:\wamp\www\Galaxia-Store\application\models\email_m.php 41
ERROR - 2014-08-30 07:21:53 --> Severity: Notice  --> Object of class stdClass to string conversion C:\wamp\www\Galaxia-Store\application\models\email_m.php 41
ERROR - 2014-08-30 07:21:53 --> Severity: 4096  --> Object of class stdClass could not be converted to string C:\wamp\www\Galaxia-Store\application\models\email_m.php 42
ERROR - 2014-08-30 07:21:53 --> Severity: Notice  --> Object of class stdClass to string conversion C:\wamp\www\Galaxia-Store\application\models\email_m.php 42
ERROR - 2014-08-30 07:21:53 --> Severity: 4096  --> Object of class stdClass could not be converted to string C:\wamp\www\Galaxia-Store\application\models\email_m.php 43
ERROR - 2014-08-30 07:21:53 --> Severity: Notice  --> Object of class stdClass to string conversion C:\wamp\www\Galaxia-Store\application\models\email_m.php 43
ERROR - 2014-08-30 07:21:53 --> Severity: 4096  --> Object of class stdClass could not be converted to string C:\wamp\www\Galaxia-Store\application\models\email_m.php 44
ERROR - 2014-08-30 07:21:53 --> Severity: Notice  --> Object of class stdClass to string conversion C:\wamp\www\Galaxia-Store\application\models\email_m.php 44
ERROR - 2014-08-30 07:21:53 --> Severity: 4096  --> Object of class stdClass could not be converted to string C:\wamp\www\Galaxia-Store\application\models\email_m.php 45
ERROR - 2014-08-30 07:21:53 --> Severity: Notice  --> Object of class stdClass to string conversion C:\wamp\www\Galaxia-Store\application\models\email_m.php 45
ERROR - 2014-08-30 07:21:53 --> Severity: Notice  --> Undefined index: content C:\wamp\www\Galaxia-Store\application\models\email_m.php 49
ERROR - 2014-08-30 07:25:12 --> Severity: Notice  --> Undefined property: stdClass::$address C:\wamp\www\Galaxia-Store\application\models\email_m.php 40
ERROR - 2014-08-30 07:25:12 --> Severity: Notice  --> Undefined index: content C:\wamp\www\Galaxia-Store\application\models\email_m.php 49
ERROR - 2014-08-30 07:25:22 --> Severity: Notice  --> Undefined index: content C:\wamp\www\Galaxia-Store\application\models\email_m.php 49
ERROR - 2014-08-30 07:40:55 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
ERROR - 2014-08-30 07:40:59 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-08-30 07:40:59 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-08-30 07:42:28 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
ERROR - 2014-08-30 07:43:23 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
ERROR - 2014-08-30 07:43:43 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-08-30 07:43:43 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-08-30 08:00:11 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Galaxia-Store\application\controllers\cart.php 203
ERROR - 2014-08-30 08:00:11 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Galaxia-Store\application\controllers\cart.php 204
ERROR - 2014-08-30 08:00:11 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Galaxia-Store\application\controllers\cart.php 210
ERROR - 2014-08-30 08:00:11 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Galaxia-Store\application\controllers\cart.php 210
ERROR - 2014-08-30 08:00:11 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Galaxia-Store\application\controllers\cart.php 212
ERROR - 2014-08-30 08:00:11 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Galaxia-Store\application\controllers\cart.php 212
ERROR - 2014-08-30 09:30:03 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
ERROR - 2014-08-30 09:39:00 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-08-30 09:39:00 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
