<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-05-09 05:50:57 --> 404 Page Not Found --> template
ERROR - 2015-05-09 08:18:07 --> 404 Page Not Found --> template
