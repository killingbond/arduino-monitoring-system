<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2016-01-20 07:25:24 --> Severity: Notice  --> Undefined property: stdClass::$name C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\order\order_detail.php 171
ERROR - 2016-01-20 07:25:49 --> Severity: Notice  --> Undefined property: stdClass::$name C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\order\order_detail.php 171
ERROR - 2016-01-20 07:26:10 --> Severity: Notice  --> Undefined property: stdClass::$name C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\order\order_detail.php 171
ERROR - 2016-01-20 07:26:13 --> Severity: Notice  --> Undefined property: stdClass::$name C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\order\order_detail.php 171
ERROR - 2016-01-20 07:27:04 --> Severity: Notice  --> Undefined property: stdClass::$name C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\order\order_detail.php 171
ERROR - 2016-01-20 07:27:57 --> Severity: Notice  --> Undefined property: stdClass::$name C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\order\order_detail.php 172
ERROR - 2016-01-20 07:28:37 --> Severity: Notice  --> Undefined property: stdClass::$product_id C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\order\order_detail.php 172
ERROR - 2016-01-20 07:30:08 --> Severity: Notice  --> Undefined property: stdClass::$pdtail_id C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\order\order_detail.php 172
ERROR - 2016-01-20 07:45:19 --> Severity: Notice  --> Undefined property: stdClass::$name C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\order\order_detail.php 171
ERROR - 2016-01-20 16:51:28 --> Severity: Notice  --> Undefined property: stdClass::$name C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\order\order_detail.php 171
ERROR - 2016-01-20 16:59:20 --> Severity: Notice  --> Undefined property: stdClass::$product_name C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\order\order_detail.php 171
