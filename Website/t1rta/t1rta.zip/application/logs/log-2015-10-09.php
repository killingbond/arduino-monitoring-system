<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-10-09 09:10:29 --> Severity: Warning  --> escapeshellarg() has been disabled for security reasons /home/ozantcom/public_html/wassuphaters.com/w4zzup/system/libraries/Upload.php 1066
ERROR - 2015-10-09 09:12:26 --> Severity: Warning  --> escapeshellarg() has been disabled for security reasons /home/ozantcom/public_html/wassuphaters.com/w4zzup/system/libraries/Upload.php 1066
ERROR - 2015-10-09 09:13:44 --> You did not select a file to upload.
ERROR - 2015-10-09 09:14:33 --> You did not select a file to upload.
ERROR - 2015-10-09 09:15:27 --> You did not select a file to upload.
ERROR - 2015-10-09 09:20:07 --> You did not select a file to upload.
ERROR - 2015-10-09 09:21:04 --> You did not select a file to upload.
ERROR - 2015-10-09 09:22:01 --> You did not select a file to upload.
ERROR - 2015-10-09 09:22:39 --> You did not select a file to upload.
