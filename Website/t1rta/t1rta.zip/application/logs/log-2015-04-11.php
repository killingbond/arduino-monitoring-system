<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-04-11 13:02:56 --> 404 Page Not Found --> template
ERROR - 2015-04-11 13:03:26 --> 404 Page Not Found --> template
ERROR - 2015-04-11 13:03:35 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2015-04-11 13:03:35 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2015-04-11 13:03:35 --> 404 Page Not Found --> template
ERROR - 2015-04-11 13:03:40 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2015-04-11 13:03:40 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2015-04-11 13:03:41 --> 404 Page Not Found --> template
ERROR - 2015-04-11 13:03:43 --> 404 Page Not Found --> template
ERROR - 2015-04-11 13:03:50 --> 404 Page Not Found --> template
ERROR - 2015-04-11 13:03:53 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2015-04-11 13:03:53 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2015-04-11 13:03:53 --> 404 Page Not Found --> template
ERROR - 2015-04-11 13:03:58 --> 404 Page Not Found --> template
ERROR - 2015-04-11 13:04:22 --> Severity: Warning  --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\wamp\www\Esgotado\system\libraries\Email.php 1553
ERROR - 2015-04-11 13:04:22 --> 404 Page Not Found --> template
ERROR - 2015-04-11 13:05:01 --> 404 Page Not Found --> template
ERROR - 2015-04-11 13:05:04 --> 404 Page Not Found --> template
ERROR - 2015-04-11 13:05:19 --> 404 Page Not Found --> template
ERROR - 2015-04-11 13:05:30 --> 404 Page Not Found --> template
ERROR - 2015-04-11 13:05:34 --> 404 Page Not Found --> template
ERROR - 2015-04-11 13:05:36 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2015-04-11 13:05:36 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2015-04-11 13:05:36 --> 404 Page Not Found --> template
ERROR - 2015-04-11 13:05:39 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2015-04-11 13:05:39 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2015-04-11 13:05:39 --> 404 Page Not Found --> template
ERROR - 2015-04-11 13:05:41 --> 404 Page Not Found --> template
ERROR - 2015-04-11 13:05:51 --> 404 Page Not Found --> template
ERROR - 2015-04-11 13:05:57 --> 404 Page Not Found --> template
ERROR - 2015-04-11 13:05:59 --> 404 Page Not Found --> template
ERROR - 2015-04-11 13:08:13 --> 404 Page Not Found --> template
ERROR - 2015-04-11 13:08:49 --> 404 Page Not Found --> template
ERROR - 2015-04-11 13:09:03 --> 404 Page Not Found --> template
ERROR - 2015-04-11 13:09:09 --> 404 Page Not Found --> template
ERROR - 2015-04-11 13:09:14 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2015-04-11 13:09:14 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2015-04-11 13:09:14 --> 404 Page Not Found --> template
ERROR - 2015-04-11 13:09:17 --> 404 Page Not Found --> template
ERROR - 2015-04-11 13:09:26 --> 404 Page Not Found --> template
ERROR - 2015-04-11 13:09:31 --> Severity: Warning  --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\wamp\www\Esgotado\system\libraries\Email.php 1553
ERROR - 2015-04-11 13:09:31 --> 404 Page Not Found --> template
ERROR - 2015-04-11 13:11:02 --> 404 Page Not Found --> template
