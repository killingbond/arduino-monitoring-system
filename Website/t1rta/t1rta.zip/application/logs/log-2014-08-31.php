<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2014-08-31 02:27:00 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\Galaxia-Store\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-08-31 02:27:00 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
ERROR - 2014-08-31 02:29:54 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\Galaxia-Store\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-08-31 02:31:28 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\Galaxia-Store\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-08-31 02:34:41 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
ERROR - 2014-08-31 02:34:46 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\Galaxia-Store\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-08-31 02:34:53 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\Galaxia-Store\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-08-31 02:35:12 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
ERROR - 2014-08-31 02:37:20 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\Galaxia-Store\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-08-31 02:40:41 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-08-31 02:40:41 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-08-31 02:40:45 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-08-31 02:40:45 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-08-31 02:45:34 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
ERROR - 2014-08-31 02:46:18 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\Galaxia-Store\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-08-31 03:46:24 --> You did not select a file to upload.
ERROR - 2014-08-31 03:46:24 --> Severity: Warning  --> Missing argument 2 for Format_date::dmy_to_ymd(), called in C:\wamp\www\Galaxia-Store\application\controllers\confirm.php on line 59 and defined C:\wamp\www\Galaxia-Store\application\libraries\format_date.php 13
ERROR - 2014-08-31 03:46:24 --> Severity: Notice  --> Undefined variable: separator C:\wamp\www\Galaxia-Store\application\libraries\format_date.php 18
ERROR - 2014-08-31 03:46:24 --> Severity: Notice  --> Undefined variable: separator C:\wamp\www\Galaxia-Store\application\libraries\format_date.php 18
ERROR - 2014-08-31 03:46:25 --> Severity: Warning  --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\wamp\www\Galaxia-Store\system\libraries\Email.php 1553
ERROR - 2014-08-31 03:46:54 --> You did not select a file to upload.
ERROR - 2014-08-31 03:46:54 --> Severity: Warning  --> Missing argument 2 for Format_date::dmy_to_ymd(), called in C:\wamp\www\Galaxia-Store\application\controllers\confirm.php on line 59 and defined C:\wamp\www\Galaxia-Store\application\libraries\format_date.php 13
ERROR - 2014-08-31 03:46:54 --> Severity: Notice  --> Undefined variable: separator C:\wamp\www\Galaxia-Store\application\libraries\format_date.php 18
ERROR - 2014-08-31 03:46:54 --> Severity: Notice  --> Undefined variable: separator C:\wamp\www\Galaxia-Store\application\libraries\format_date.php 18
ERROR - 2014-08-31 03:46:55 --> Severity: Warning  --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\wamp\www\Galaxia-Store\system\libraries\Email.php 1553
ERROR - 2014-08-31 03:47:20 --> You did not select a file to upload.
ERROR - 2014-08-31 03:47:21 --> Severity: Warning  --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\wamp\www\Galaxia-Store\system\libraries\Email.php 1553
ERROR - 2014-08-31 03:47:37 --> You did not select a file to upload.
ERROR - 2014-08-31 03:47:38 --> Severity: Warning  --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\wamp\www\Galaxia-Store\system\libraries\Email.php 1553
ERROR - 2014-08-31 03:47:51 --> You did not select a file to upload.
ERROR - 2014-08-31 03:47:52 --> Severity: Warning  --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\wamp\www\Galaxia-Store\system\libraries\Email.php 1553
ERROR - 2014-08-31 03:48:11 --> You did not select a file to upload.
ERROR - 2014-08-31 03:48:12 --> Severity: Warning  --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\wamp\www\Galaxia-Store\system\libraries\Email.php 1553
ERROR - 2014-08-31 03:48:21 --> You did not select a file to upload.
ERROR - 2014-08-31 03:48:22 --> Severity: Warning  --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\wamp\www\Galaxia-Store\system\libraries\Email.php 1553
ERROR - 2014-08-31 03:48:41 --> You did not select a file to upload.
ERROR - 2014-08-31 03:48:42 --> Severity: Warning  --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\wamp\www\Galaxia-Store\system\libraries\Email.php 1553
ERROR - 2014-08-31 03:48:55 --> You did not select a file to upload.
ERROR - 2014-08-31 03:48:56 --> Severity: Warning  --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\wamp\www\Galaxia-Store\system\libraries\Email.php 1553
ERROR - 2014-08-31 03:49:19 --> You did not select a file to upload.
ERROR - 2014-08-31 03:49:20 --> Severity: Warning  --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\wamp\www\Galaxia-Store\system\libraries\Email.php 1553
ERROR - 2014-08-31 03:49:41 --> You did not select a file to upload.
ERROR - 2014-08-31 03:49:42 --> Severity: Warning  --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\wamp\www\Galaxia-Store\system\libraries\Email.php 1553
ERROR - 2014-08-31 03:50:03 --> You did not select a file to upload.
ERROR - 2014-08-31 03:50:04 --> Severity: Warning  --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\wamp\www\Galaxia-Store\system\libraries\Email.php 1553
ERROR - 2014-08-31 03:50:19 --> You did not select a file to upload.
ERROR - 2014-08-31 03:50:20 --> Severity: Warning  --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\wamp\www\Galaxia-Store\system\libraries\Email.php 1553
ERROR - 2014-08-31 03:50:28 --> You did not select a file to upload.
ERROR - 2014-08-31 03:50:29 --> Severity: Warning  --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\wamp\www\Galaxia-Store\system\libraries\Email.php 1553
ERROR - 2014-08-31 03:50:46 --> You did not select a file to upload.
ERROR - 2014-08-31 03:50:47 --> Severity: Warning  --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\wamp\www\Galaxia-Store\system\libraries\Email.php 1553
ERROR - 2014-08-31 03:51:27 --> You did not select a file to upload.
ERROR - 2014-08-31 03:51:28 --> Severity: Warning  --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\wamp\www\Galaxia-Store\system\libraries\Email.php 1553
ERROR - 2014-08-31 03:51:38 --> You did not select a file to upload.
ERROR - 2014-08-31 03:51:40 --> Severity: Warning  --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\wamp\www\Galaxia-Store\system\libraries\Email.php 1553
ERROR - 2014-08-31 03:53:18 --> You did not select a file to upload.
ERROR - 2014-08-31 03:53:18 --> Severity: Notice  --> Undefined variable: image C:\wamp\www\Galaxia-Store\application\models\email_m.php 120
ERROR - 2014-08-31 03:53:19 --> Severity: Warning  --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\wamp\www\Galaxia-Store\system\libraries\Email.php 1553
ERROR - 2014-08-31 03:54:07 --> Severity: Notice  --> Undefined variable: image C:\wamp\www\Galaxia-Store\application\models\email_m.php 120
ERROR - 2014-08-31 03:54:08 --> Severity: Warning  --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\wamp\www\Galaxia-Store\system\libraries\Email.php 1553
ERROR - 2014-08-31 03:54:31 --> Severity: Warning  --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\wamp\www\Galaxia-Store\system\libraries\Email.php 1553
ERROR - 2014-08-31 03:55:31 --> Severity: Warning  --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\wamp\www\Galaxia-Store\system\libraries\Email.php 1553
ERROR - 2014-08-31 03:56:10 --> Severity: Warning  --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\wamp\www\Galaxia-Store\system\libraries\Email.php 1553
ERROR - 2014-08-31 04:12:14 --> Severity: Notice  --> Undefined property: Member::$get_last_member_id C:\wamp\www\Galaxia-Store\system\core\Model.php 51
ERROR - 2014-08-31 04:16:18 --> Severity: Warning  --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\wamp\www\Galaxia-Store\system\libraries\Email.php 1553
