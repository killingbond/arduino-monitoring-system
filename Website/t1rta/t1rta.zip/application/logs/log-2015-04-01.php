<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-04-01 13:54:46 --> 404 Page Not Found --> template
ERROR - 2015-04-01 16:20:29 --> 404 Page Not Found --> template
ERROR - 2015-04-01 16:20:33 --> 404 Page Not Found --> template
ERROR - 2015-04-01 16:28:59 --> 404 Page Not Found --> template
ERROR - 2015-04-01 16:29:21 --> Severity: Warning  --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\wamp\www\Esgotado\system\libraries\Email.php 1553
ERROR - 2015-04-01 16:29:21 --> 404 Page Not Found --> template
ERROR - 2015-04-01 16:47:37 --> Severity: Notice  --> Undefined index: coming_soon C:\wamp\www\Esgotado\application\core\MX_Controller.php 22
ERROR - 2015-04-01 16:47:37 --> 404 Page Not Found --> template
ERROR - 2015-04-01 16:47:37 --> Severity: Notice  --> Undefined index: coming_soon C:\wamp\www\Esgotado\application\core\MX_Controller.php 22
ERROR - 2015-04-01 16:50:56 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\block\sidebar.php 27
ERROR - 2015-04-01 16:50:56 --> 404 Page Not Found --> template
ERROR - 2015-04-01 16:50:56 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\block\sidebar.php 27
ERROR - 2015-04-01 16:51:56 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\block\sidebar.php 28
ERROR - 2015-04-01 16:51:56 --> 404 Page Not Found --> template
ERROR - 2015-04-01 16:51:56 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\block\sidebar.php 28
ERROR - 2015-04-01 16:52:17 --> 404 Page Not Found --> template
ERROR - 2015-04-01 16:57:23 --> Severity: Warning  --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\wamp\www\Esgotado\system\libraries\Email.php 1553
ERROR - 2015-04-01 16:57:23 --> 404 Page Not Found --> template
ERROR - 2015-04-01 16:59:03 --> Severity: Warning  --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\wamp\www\Esgotado\system\libraries\Email.php 1553
ERROR - 2015-04-01 16:59:04 --> 404 Page Not Found --> template
ERROR - 2015-04-01 17:00:26 --> Severity: Warning  --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\wamp\www\Esgotado\system\libraries\Email.php 1553
ERROR - 2015-04-01 17:00:27 --> 404 Page Not Found --> template
ERROR - 2015-04-01 17:01:55 --> 404 Page Not Found --> template
ERROR - 2015-04-01 17:02:31 --> 404 Page Not Found --> template
ERROR - 2015-04-01 17:03:14 --> 404 Page Not Found --> template
ERROR - 2015-04-01 17:03:17 --> 404 Page Not Found --> template
ERROR - 2015-04-01 17:03:19 --> 404 Page Not Found --> template
ERROR - 2015-04-01 17:03:20 --> 404 Page Not Found --> template
ERROR - 2015-04-01 17:09:31 --> 404 Page Not Found --> template
ERROR - 2015-04-01 17:09:35 --> 404 Page Not Found --> template
ERROR - 2015-04-01 17:16:53 --> 404 Page Not Found --> template
