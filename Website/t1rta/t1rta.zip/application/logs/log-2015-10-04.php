<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-10-04 10:24:13 --> Severity: Warning  --> escapeshellarg() has been disabled for security reasons /home/ozantcom/public_html/wassuphaters.com/w4zzup/system/libraries/Upload.php 1066
ERROR - 2015-10-04 10:24:21 --> Severity: Warning  --> escapeshellarg() has been disabled for security reasons /home/ozantcom/public_html/wassuphaters.com/w4zzup/system/libraries/Upload.php 1066
ERROR - 2015-10-04 10:24:45 --> Severity: Warning  --> escapeshellarg() has been disabled for security reasons /home/ozantcom/public_html/wassuphaters.com/w4zzup/system/libraries/Upload.php 1066
ERROR - 2015-10-04 10:25:36 --> Severity: Warning  --> escapeshellarg() has been disabled for security reasons /home/ozantcom/public_html/wassuphaters.com/w4zzup/system/libraries/Upload.php 1066
ERROR - 2015-10-04 10:26:26 --> Severity: Warning  --> escapeshellarg() has been disabled for security reasons /home/ozantcom/public_html/wassuphaters.com/w4zzup/system/libraries/Upload.php 1066
ERROR - 2015-10-04 10:28:01 --> Severity: Warning  --> escapeshellarg() has been disabled for security reasons /home/ozantcom/public_html/wassuphaters.com/w4zzup/system/libraries/Upload.php 1066
ERROR - 2015-10-04 10:30:04 --> Severity: Warning  --> escapeshellarg() has been disabled for security reasons /home/ozantcom/public_html/wassuphaters.com/w4zzup/system/libraries/Upload.php 1066
ERROR - 2015-10-04 10:51:43 --> Severity: Warning  --> escapeshellarg() has been disabled for security reasons /home/ozantcom/public_html/wassuphaters.com/w4zzup/system/libraries/Upload.php 1066
ERROR - 2015-10-04 17:02:56 --> You did not select a file to upload.
