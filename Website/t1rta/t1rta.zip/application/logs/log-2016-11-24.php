<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2016-11-24 00:23:10 --> Severity: Notice  --> Undefined variable: notification_order /home/tirtadah/public_html/t1rta/application/views/slices/sidebar.php 85
ERROR - 2016-11-24 00:23:10 --> Severity: Notice  --> Undefined variable: notification_order /home/tirtadah/public_html/t1rta/application/views/slices/sidebar.php 98
ERROR - 2016-11-24 07:00:42 --> Severity: Notice  --> Undefined variable: notification_order /home/tirtadah/public_html/t1rta/application/views/slices/sidebar.php 85
ERROR - 2016-11-24 07:00:42 --> Severity: Notice  --> Undefined variable: notification_order /home/tirtadah/public_html/t1rta/application/views/slices/sidebar.php 98
ERROR - 2016-11-24 22:14:45 --> Severity: Notice  --> Undefined variable: notification_order /home/tirtadah/public_html/t1rta/application/views/slices/sidebar.php 85
ERROR - 2016-11-24 22:14:45 --> Severity: Notice  --> Undefined variable: notification_order /home/tirtadah/public_html/t1rta/application/views/slices/sidebar.php 98
