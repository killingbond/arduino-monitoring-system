<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2014-09-05 03:33:47 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-09-05 03:33:47 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-09-05 03:33:47 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-09-05 03:33:47 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-09-05 03:47:38 --> Severity: Warning  --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\wamp\www\Galaxia-Store\system\libraries\Email.php 1553
ERROR - 2014-09-05 03:56:32 --> You did not select a file to upload.
ERROR - 2014-09-05 03:56:32 --> Severity: Warning  --> number_format() expects parameter 1 to be double, string given C:\wamp\www\Galaxia-Store\application\controllers\confirm.php 60
ERROR - 2014-09-05 03:56:33 --> Severity: Warning  --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\wamp\www\Galaxia-Store\system\libraries\Email.php 1553
ERROR - 2014-09-05 04:15:56 --> You did not select a file to upload.
ERROR - 2014-09-05 04:15:56 --> Severity: Warning  --> number_format() expects parameter 1 to be double, string given C:\wamp\www\Galaxia-Store\application\controllers\confirm.php 60
ERROR - 2014-09-05 04:15:57 --> Severity: Warning  --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\wamp\www\Galaxia-Store\system\libraries\Email.php 1553
ERROR - 2014-09-05 04:16:18 --> You did not select a file to upload.
ERROR - 2014-09-05 04:16:18 --> Severity: Warning  --> number_format() expects parameter 1 to be double, string given C:\wamp\www\Galaxia-Store\application\controllers\confirm.php 60
ERROR - 2014-09-05 04:16:19 --> Severity: Warning  --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\wamp\www\Galaxia-Store\system\libraries\Email.php 1553
ERROR - 2014-09-05 04:17:19 --> You did not select a file to upload.
ERROR - 2014-09-05 04:17:19 --> Severity: Warning  --> number_format() expects parameter 1 to be double, string given C:\wamp\www\Galaxia-Store\application\controllers\confirm.php 60
ERROR - 2014-09-05 04:17:20 --> Severity: Warning  --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\wamp\www\Galaxia-Store\system\libraries\Email.php 1553
ERROR - 2014-09-05 04:23:10 --> You did not select a file to upload.
ERROR - 2014-09-05 04:23:10 --> Severity: Warning  --> number_format() expects parameter 1 to be double, string given C:\wamp\www\Galaxia-Store\application\controllers\confirm.php 60
ERROR - 2014-09-05 04:23:11 --> Severity: Warning  --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\wamp\www\Galaxia-Store\system\libraries\Email.php 1553
ERROR - 2014-09-05 04:23:39 --> You did not select a file to upload.
ERROR - 2014-09-05 04:23:39 --> Severity: Warning  --> number_format() expects parameter 1 to be double, string given C:\wamp\www\Galaxia-Store\application\controllers\confirm.php 60
ERROR - 2014-09-05 04:23:40 --> Severity: Warning  --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\wamp\www\Galaxia-Store\system\libraries\Email.php 1553
ERROR - 2014-09-05 04:31:45 --> You did not select a file to upload.
ERROR - 2014-09-05 04:32:39 --> You did not select a file to upload.
ERROR - 2014-09-05 04:33:08 --> You did not select a file to upload.
ERROR - 2014-09-05 04:36:35 --> You did not select a file to upload.
ERROR - 2014-09-05 04:36:53 --> You did not select a file to upload.
ERROR - 2014-09-05 04:37:56 --> You did not select a file to upload.
ERROR - 2014-09-05 04:38:09 --> You did not select a file to upload.
ERROR - 2014-09-05 04:38:32 --> You did not select a file to upload.
ERROR - 2014-09-05 04:38:33 --> Severity: Warning  --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\wamp\www\Galaxia-Store\system\libraries\Email.php 1553
ERROR - 2014-09-05 04:38:42 --> You did not select a file to upload.
ERROR - 2014-09-05 04:39:22 --> You did not select a file to upload.
ERROR - 2014-09-05 04:42:27 --> You did not select a file to upload.
ERROR - 2014-09-05 09:22:45 --> You did not select a file to upload.
ERROR - 2014-09-05 09:22:46 --> Severity: Warning  --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\wamp\www\Galaxia-Store\system\libraries\Email.php 1553
ERROR - 2014-09-05 09:25:00 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-09-05 09:25:00 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-09-05 09:25:01 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-09-05 09:25:01 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-09-05 09:25:07 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-09-05 09:25:07 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-09-05 09:25:07 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-09-05 09:25:07 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-09-05 09:25:18 --> Severity: Warning  --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\wamp\www\Galaxia-Store\system\libraries\Email.php 1553
ERROR - 2014-09-05 09:48:19 --> You did not select a file to upload.
ERROR - 2014-09-05 09:48:20 --> Severity: Warning  --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\wamp\www\Galaxia-Store\system\libraries\Email.php 1553
ERROR - 2014-09-05 09:57:50 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-09-05 09:57:50 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-09-05 09:57:51 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-09-05 09:57:51 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-09-05 09:57:59 --> Severity: Warning  --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\wamp\www\Galaxia-Store\system\libraries\Email.php 1553
ERROR - 2014-09-05 09:59:01 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
