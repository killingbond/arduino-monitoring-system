<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-03-21 00:26:33 --> 404 Page Not Found --> template
ERROR - 2015-03-21 00:27:36 --> Could not find the language line "aaa"
ERROR - 2015-03-21 00:27:52 --> Could not find the language line "en_customer_service"
ERROR - 2015-03-21 00:28:43 --> Could not find the language line "en_customer_service"
ERROR - 2015-03-21 00:28:44 --> Could not find the language line "en_customer_service"
ERROR - 2015-03-21 00:29:41 --> Could not find the language line "UM12"
ERROR - 2015-03-21 00:29:51 --> Could not find the language line "UM12"
ERROR - 2015-03-21 00:30:06 --> Could not find the language line "UM12"
ERROR - 2015-03-21 00:30:50 --> Could not find the language line "date_year"
ERROR - 2015-03-21 00:33:35 --> Could not find the language line "date_year"
ERROR - 2015-03-21 00:37:51 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\head.php 7
ERROR - 2015-03-21 00:37:51 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\block\head.php 7
ERROR - 2015-03-21 00:37:51 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\head.php 8
ERROR - 2015-03-21 00:37:51 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\block\head.php 8
ERROR - 2015-03-21 00:37:51 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\head.php 9
ERROR - 2015-03-21 00:37:51 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\block\head.php 9
ERROR - 2015-03-21 00:37:51 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\head.php 44
ERROR - 2015-03-21 00:37:51 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\head.php 123
ERROR - 2015-03-21 00:37:51 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\head.php 124
ERROR - 2015-03-21 00:37:51 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\head.php 125
ERROR - 2015-03-21 00:37:51 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\head.php 126
ERROR - 2015-03-21 00:37:51 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\head.php 127
ERROR - 2015-03-21 00:37:51 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\header.php 14
ERROR - 2015-03-21 00:37:51 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\block\header.php 14
ERROR - 2015-03-21 00:37:51 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\header.php 15
ERROR - 2015-03-21 00:37:51 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\block\header.php 15
ERROR - 2015-03-21 00:37:51 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\header.php 46
ERROR - 2015-03-21 00:37:51 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\header.php 79
ERROR - 2015-03-21 00:37:51 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\header.php 136
ERROR - 2015-03-21 00:37:51 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\header.php 210
ERROR - 2015-03-21 00:37:51 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\home.php 8
ERROR - 2015-03-21 00:37:51 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\home.php 116
ERROR - 2015-03-21 00:37:51 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\home.php 116
ERROR - 2015-03-21 00:37:51 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\home.php 116
ERROR - 2015-03-21 00:37:51 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\home.php 116
ERROR - 2015-03-21 00:37:51 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\home.php 116
ERROR - 2015-03-21 00:37:51 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\home.php 116
ERROR - 2015-03-21 00:37:51 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\home.php 116
ERROR - 2015-03-21 00:37:51 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\home.php 116
ERROR - 2015-03-21 00:37:51 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\home.php 116
ERROR - 2015-03-21 00:37:51 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\home.php 116
ERROR - 2015-03-21 00:37:51 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\home.php 116
ERROR - 2015-03-21 00:37:51 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\home.php 116
ERROR - 2015-03-21 00:37:51 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\home.php 153
ERROR - 2015-03-21 00:37:51 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\footer.php 10
ERROR - 2015-03-21 00:37:51 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\footer.php 146
ERROR - 2015-03-21 00:37:51 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\block\footer.php 146
ERROR - 2015-03-21 00:37:51 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\footer.php 150
ERROR - 2015-03-21 00:37:51 --> 404 Page Not Found --> template
ERROR - 2015-03-21 00:38:34 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\head.php 7
ERROR - 2015-03-21 00:38:34 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\block\head.php 7
ERROR - 2015-03-21 00:38:34 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\head.php 8
ERROR - 2015-03-21 00:38:34 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\block\head.php 8
ERROR - 2015-03-21 00:38:34 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\head.php 9
ERROR - 2015-03-21 00:38:34 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\block\head.php 9
ERROR - 2015-03-21 00:38:34 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\head.php 44
ERROR - 2015-03-21 00:38:34 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\head.php 123
ERROR - 2015-03-21 00:38:34 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\head.php 124
ERROR - 2015-03-21 00:38:34 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\head.php 125
ERROR - 2015-03-21 00:38:34 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\head.php 126
ERROR - 2015-03-21 00:38:34 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\head.php 127
ERROR - 2015-03-21 00:38:34 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\header.php 14
ERROR - 2015-03-21 00:38:34 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\block\header.php 14
ERROR - 2015-03-21 00:38:35 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\header.php 15
ERROR - 2015-03-21 00:38:35 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\block\header.php 15
ERROR - 2015-03-21 00:38:35 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\header.php 46
ERROR - 2015-03-21 00:38:35 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\header.php 79
ERROR - 2015-03-21 00:38:35 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\header.php 136
ERROR - 2015-03-21 00:38:35 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\header.php 210
ERROR - 2015-03-21 00:38:35 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\home.php 8
ERROR - 2015-03-21 00:38:35 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\home.php 116
ERROR - 2015-03-21 00:38:35 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\home.php 116
ERROR - 2015-03-21 00:38:35 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\home.php 116
ERROR - 2015-03-21 00:38:35 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\home.php 116
ERROR - 2015-03-21 00:38:35 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\home.php 116
ERROR - 2015-03-21 00:38:35 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\home.php 116
ERROR - 2015-03-21 00:38:35 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\home.php 116
ERROR - 2015-03-21 00:38:35 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\home.php 116
ERROR - 2015-03-21 00:38:35 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\home.php 116
ERROR - 2015-03-21 00:38:35 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\home.php 116
ERROR - 2015-03-21 00:38:35 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\home.php 116
ERROR - 2015-03-21 00:38:35 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\home.php 116
ERROR - 2015-03-21 00:38:35 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\home.php 153
ERROR - 2015-03-21 00:38:35 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\footer.php 10
ERROR - 2015-03-21 00:38:35 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\footer.php 146
ERROR - 2015-03-21 00:38:35 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\block\footer.php 146
ERROR - 2015-03-21 00:38:35 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\footer.php 150
ERROR - 2015-03-21 00:38:35 --> 404 Page Not Found --> template
ERROR - 2015-03-21 00:38:43 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\head.php 7
ERROR - 2015-03-21 00:38:43 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\block\head.php 7
ERROR - 2015-03-21 00:38:43 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\head.php 8
ERROR - 2015-03-21 00:38:43 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\block\head.php 8
ERROR - 2015-03-21 00:38:43 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\head.php 9
ERROR - 2015-03-21 00:38:43 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\block\head.php 9
ERROR - 2015-03-21 00:38:43 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\head.php 44
ERROR - 2015-03-21 00:38:43 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\head.php 123
ERROR - 2015-03-21 00:38:43 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\head.php 124
ERROR - 2015-03-21 00:38:43 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\head.php 125
ERROR - 2015-03-21 00:38:43 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\head.php 126
ERROR - 2015-03-21 00:38:43 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\head.php 127
ERROR - 2015-03-21 00:38:43 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\header.php 14
ERROR - 2015-03-21 00:38:43 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\block\header.php 14
ERROR - 2015-03-21 00:38:43 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\header.php 15
ERROR - 2015-03-21 00:38:43 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\block\header.php 15
ERROR - 2015-03-21 00:38:43 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\header.php 46
ERROR - 2015-03-21 00:38:43 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\header.php 79
ERROR - 2015-03-21 00:38:43 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\header.php 136
ERROR - 2015-03-21 00:38:43 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\header.php 210
ERROR - 2015-03-21 00:38:43 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\home.php 8
ERROR - 2015-03-21 00:38:43 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\home.php 116
ERROR - 2015-03-21 00:38:43 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\home.php 116
ERROR - 2015-03-21 00:38:43 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\home.php 116
ERROR - 2015-03-21 00:38:43 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\home.php 116
ERROR - 2015-03-21 00:38:43 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\home.php 116
ERROR - 2015-03-21 00:38:43 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\home.php 116
ERROR - 2015-03-21 00:38:43 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\home.php 116
ERROR - 2015-03-21 00:38:43 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\home.php 116
ERROR - 2015-03-21 00:38:43 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\home.php 116
ERROR - 2015-03-21 00:38:43 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\home.php 116
ERROR - 2015-03-21 00:38:43 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\home.php 116
ERROR - 2015-03-21 00:38:43 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\home.php 116
ERROR - 2015-03-21 00:38:43 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\home.php 153
ERROR - 2015-03-21 00:38:43 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\footer.php 10
ERROR - 2015-03-21 00:38:43 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\footer.php 146
ERROR - 2015-03-21 00:38:43 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\block\footer.php 146
ERROR - 2015-03-21 00:38:43 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\footer.php 150
ERROR - 2015-03-21 00:43:17 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\head.php 7
ERROR - 2015-03-21 00:43:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\block\head.php 7
ERROR - 2015-03-21 00:43:17 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\head.php 8
ERROR - 2015-03-21 00:43:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\block\head.php 8
ERROR - 2015-03-21 00:43:17 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\head.php 9
ERROR - 2015-03-21 00:43:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\block\head.php 9
ERROR - 2015-03-21 00:43:17 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\head.php 44
ERROR - 2015-03-21 00:43:17 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\head.php 123
ERROR - 2015-03-21 00:43:17 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\head.php 124
ERROR - 2015-03-21 00:43:17 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\head.php 125
ERROR - 2015-03-21 00:43:17 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\head.php 126
ERROR - 2015-03-21 00:43:17 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\head.php 127
ERROR - 2015-03-21 00:43:17 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\header.php 14
ERROR - 2015-03-21 00:43:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\block\header.php 14
ERROR - 2015-03-21 00:43:17 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\header.php 15
ERROR - 2015-03-21 00:43:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\block\header.php 15
ERROR - 2015-03-21 00:43:17 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\header.php 46
ERROR - 2015-03-21 00:43:17 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\header.php 79
ERROR - 2015-03-21 00:43:17 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\header.php 136
ERROR - 2015-03-21 00:43:17 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\header.php 210
ERROR - 2015-03-21 00:43:17 --> Severity: Notice  --> Undefined variable: breadcrumb C:\wamp\www\Esgotado\application\views\blog.php 6
ERROR - 2015-03-21 00:43:17 --> Severity: Notice  --> Undefined variable: breadcrumb C:\wamp\www\Esgotado\application\views\blog.php 11
ERROR - 2015-03-21 00:43:17 --> Severity: Notice  --> Undefined variable: sidebar C:\wamp\www\Esgotado\application\views\blog.php 112
ERROR - 2015-03-21 00:43:17 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\footer.php 10
ERROR - 2015-03-21 00:43:17 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\footer.php 146
ERROR - 2015-03-21 00:43:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\block\footer.php 146
ERROR - 2015-03-21 00:43:17 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\footer.php 150
ERROR - 2015-03-21 00:43:40 --> Severity: Notice  --> Undefined variable: sidebar C:\wamp\www\Esgotado\application\views\blog.php 112
ERROR - 2015-03-21 00:43:40 --> Severity: Notice  --> Undefined variable: sidebar C:\wamp\www\Esgotado\application\views\blog.php 112
ERROR - 2015-03-21 00:46:24 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\head.php 7
ERROR - 2015-03-21 00:46:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\block\head.php 7
ERROR - 2015-03-21 00:46:24 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\head.php 8
ERROR - 2015-03-21 00:46:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\block\head.php 8
ERROR - 2015-03-21 00:46:24 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\head.php 9
ERROR - 2015-03-21 00:46:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\block\head.php 9
ERROR - 2015-03-21 00:46:24 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\head.php 44
ERROR - 2015-03-21 00:46:24 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\head.php 123
ERROR - 2015-03-21 00:46:24 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\head.php 124
ERROR - 2015-03-21 00:46:24 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\head.php 125
ERROR - 2015-03-21 00:46:24 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\head.php 126
ERROR - 2015-03-21 00:46:24 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\head.php 127
ERROR - 2015-03-21 00:46:24 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\header.php 14
ERROR - 2015-03-21 00:46:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\block\header.php 14
ERROR - 2015-03-21 00:46:24 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\header.php 15
ERROR - 2015-03-21 00:46:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\block\header.php 15
ERROR - 2015-03-21 00:46:24 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\header.php 46
ERROR - 2015-03-21 00:46:24 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\header.php 79
ERROR - 2015-03-21 00:46:25 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\header.php 136
ERROR - 2015-03-21 00:46:25 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\header.php 210
ERROR - 2015-03-21 00:46:25 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\footer.php 10
ERROR - 2015-03-21 00:46:25 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\footer.php 146
ERROR - 2015-03-21 00:46:25 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\block\footer.php 146
ERROR - 2015-03-21 00:46:25 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\footer.php 150
ERROR - 2015-03-21 00:49:38 --> 404 Page Not Found --> my_js
ERROR - 2015-03-21 00:49:46 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2015-03-21 00:49:46 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2015-03-21 00:50:40 --> Severity: Warning  --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\wamp\www\Esgotado\system\libraries\Email.php 1553
ERROR - 2015-03-21 00:52:39 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\head.php 7
ERROR - 2015-03-21 00:52:39 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\block\head.php 7
ERROR - 2015-03-21 00:52:39 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\head.php 8
ERROR - 2015-03-21 00:52:39 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\block\head.php 8
ERROR - 2015-03-21 00:52:39 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\head.php 9
ERROR - 2015-03-21 00:52:39 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\block\head.php 9
ERROR - 2015-03-21 00:52:39 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\head.php 44
ERROR - 2015-03-21 00:52:39 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\head.php 123
ERROR - 2015-03-21 00:52:39 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\head.php 124
ERROR - 2015-03-21 00:52:39 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\head.php 125
ERROR - 2015-03-21 00:52:39 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\head.php 126
ERROR - 2015-03-21 00:52:39 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\head.php 127
ERROR - 2015-03-21 00:52:39 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\header.php 14
ERROR - 2015-03-21 00:52:39 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\block\header.php 14
ERROR - 2015-03-21 00:52:39 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\header.php 15
ERROR - 2015-03-21 00:52:39 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\block\header.php 15
ERROR - 2015-03-21 00:52:39 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\header.php 46
ERROR - 2015-03-21 00:52:39 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\header.php 79
ERROR - 2015-03-21 00:52:39 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\header.php 136
ERROR - 2015-03-21 00:52:39 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\header.php 210
ERROR - 2015-03-21 00:52:39 --> Severity: Notice  --> Undefined variable: breadcrumb C:\wamp\www\Esgotado\application\views\confirm_payment.php 6
ERROR - 2015-03-21 00:52:39 --> Severity: Notice  --> Undefined variable: breadcrumb C:\wamp\www\Esgotado\application\views\confirm_payment.php 11
ERROR - 2015-03-21 00:52:39 --> Severity: Notice  --> Undefined variable: sidebar C:\wamp\www\Esgotado\application\views\confirm_payment.php 188
ERROR - 2015-03-21 00:52:39 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\footer.php 10
ERROR - 2015-03-21 00:52:39 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\footer.php 146
ERROR - 2015-03-21 00:52:39 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\block\footer.php 146
ERROR - 2015-03-21 00:52:39 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\footer.php 150
ERROR - 2015-03-21 00:52:39 --> 404 Page Not Found --> template
ERROR - 2015-03-21 00:52:51 --> Severity: Notice  --> Undefined variable: sidebar C:\wamp\www\Esgotado\application\views\confirm_payment.php 188
ERROR - 2015-03-21 00:52:51 --> 404 Page Not Found --> template
ERROR - 2015-03-21 00:53:39 --> 404 Page Not Found --> template
ERROR - 2015-03-21 00:54:27 --> Severity: Warning  --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\wamp\www\Esgotado\system\libraries\Email.php 1553
ERROR - 2015-03-21 00:54:27 --> 404 Page Not Found --> template
ERROR - 2015-03-21 00:55:27 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\sidebar.php 4
ERROR - 2015-03-21 00:55:27 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\head.php 7
ERROR - 2015-03-21 00:55:27 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\block\head.php 7
ERROR - 2015-03-21 00:55:27 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\head.php 8
ERROR - 2015-03-21 00:55:27 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\block\head.php 8
ERROR - 2015-03-21 00:55:27 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\head.php 9
ERROR - 2015-03-21 00:55:27 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\block\head.php 9
ERROR - 2015-03-21 00:55:27 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\head.php 44
ERROR - 2015-03-21 00:55:27 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\head.php 123
ERROR - 2015-03-21 00:55:27 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\head.php 124
ERROR - 2015-03-21 00:55:27 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\head.php 125
ERROR - 2015-03-21 00:55:27 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\head.php 126
ERROR - 2015-03-21 00:55:27 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\head.php 127
ERROR - 2015-03-21 00:55:27 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\header.php 14
ERROR - 2015-03-21 00:55:27 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\block\header.php 14
ERROR - 2015-03-21 00:55:27 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\header.php 15
ERROR - 2015-03-21 00:55:27 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\block\header.php 15
ERROR - 2015-03-21 00:55:27 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\header.php 46
ERROR - 2015-03-21 00:55:27 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\header.php 79
ERROR - 2015-03-21 00:55:27 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\header.php 136
ERROR - 2015-03-21 00:55:27 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\header.php 210
ERROR - 2015-03-21 00:55:27 --> Severity: Notice  --> Undefined variable: breadcrumb C:\wamp\www\Esgotado\application\views\contact.php 6
ERROR - 2015-03-21 00:55:27 --> Severity: Notice  --> Undefined variable: breadcrumb C:\wamp\www\Esgotado\application\views\contact.php 11
ERROR - 2015-03-21 00:55:27 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\footer.php 10
ERROR - 2015-03-21 00:55:27 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\footer.php 146
ERROR - 2015-03-21 00:55:27 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\block\footer.php 146
ERROR - 2015-03-21 00:55:27 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\footer.php 150
ERROR - 2015-03-21 00:55:27 --> 404 Page Not Found --> template
ERROR - 2015-03-21 00:55:34 --> 404 Page Not Found --> template
ERROR - 2015-03-21 00:55:50 --> 404 Page Not Found --> template
ERROR - 2015-03-21 00:56:30 --> Severity: Notice  --> Undefined variable: sidebar C:\wamp\www\Esgotado\application\views\contact.php 100
ERROR - 2015-03-21 00:56:30 --> 404 Page Not Found --> template
ERROR - 2015-03-21 00:56:47 --> 404 Page Not Found --> template
ERROR - 2015-03-21 00:58:38 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\head.php 7
ERROR - 2015-03-21 00:58:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\block\head.php 7
ERROR - 2015-03-21 00:58:38 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\head.php 8
ERROR - 2015-03-21 00:58:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\block\head.php 8
ERROR - 2015-03-21 00:58:38 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\head.php 9
ERROR - 2015-03-21 00:58:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\block\head.php 9
ERROR - 2015-03-21 00:58:38 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\head.php 44
ERROR - 2015-03-21 00:58:38 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\head.php 123
ERROR - 2015-03-21 00:58:38 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\head.php 124
ERROR - 2015-03-21 00:58:38 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\head.php 125
ERROR - 2015-03-21 00:58:38 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\head.php 126
ERROR - 2015-03-21 00:58:38 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\head.php 127
ERROR - 2015-03-21 00:58:38 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\header.php 14
ERROR - 2015-03-21 00:58:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\block\header.php 14
ERROR - 2015-03-21 00:58:38 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\header.php 15
ERROR - 2015-03-21 00:58:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\block\header.php 15
ERROR - 2015-03-21 00:58:38 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\header.php 46
ERROR - 2015-03-21 00:58:38 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\header.php 79
ERROR - 2015-03-21 00:58:38 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\header.php 136
ERROR - 2015-03-21 00:58:38 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\header.php 210
ERROR - 2015-03-21 00:58:38 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\footer.php 10
ERROR - 2015-03-21 00:58:38 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\footer.php 146
ERROR - 2015-03-21 00:58:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\block\footer.php 146
ERROR - 2015-03-21 00:58:38 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\footer.php 150
ERROR - 2015-03-21 00:58:38 --> 404 Page Not Found --> template
ERROR - 2015-03-21 00:59:04 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\head.php 7
ERROR - 2015-03-21 00:59:04 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\block\head.php 7
ERROR - 2015-03-21 00:59:04 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\head.php 8
ERROR - 2015-03-21 00:59:04 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\block\head.php 8
ERROR - 2015-03-21 00:59:04 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\head.php 9
ERROR - 2015-03-21 00:59:04 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\block\head.php 9
ERROR - 2015-03-21 00:59:04 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\head.php 44
ERROR - 2015-03-21 00:59:04 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\head.php 123
ERROR - 2015-03-21 00:59:04 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\head.php 124
ERROR - 2015-03-21 00:59:04 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\head.php 125
ERROR - 2015-03-21 00:59:04 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\head.php 126
ERROR - 2015-03-21 00:59:04 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\head.php 127
ERROR - 2015-03-21 00:59:04 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\header.php 14
ERROR - 2015-03-21 00:59:04 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\block\header.php 14
ERROR - 2015-03-21 00:59:04 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\header.php 15
ERROR - 2015-03-21 00:59:04 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\block\header.php 15
ERROR - 2015-03-21 00:59:04 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\header.php 46
ERROR - 2015-03-21 00:59:04 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\header.php 79
ERROR - 2015-03-21 00:59:04 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\header.php 136
ERROR - 2015-03-21 00:59:04 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\header.php 210
ERROR - 2015-03-21 00:59:04 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\footer.php 10
ERROR - 2015-03-21 00:59:04 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\footer.php 146
ERROR - 2015-03-21 00:59:04 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\block\footer.php 146
ERROR - 2015-03-21 00:59:04 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\footer.php 150
ERROR - 2015-03-21 00:59:04 --> 404 Page Not Found --> template
ERROR - 2015-03-21 00:59:13 --> 404 Page Not Found --> template
ERROR - 2015-03-21 01:00:00 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\comingsoon\index.php 39
ERROR - 2015-03-21 01:00:00 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\comingsoon\index.php 39
ERROR - 2015-03-21 01:00:00 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\comingsoon\index.php 41
ERROR - 2015-03-21 01:00:00 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\comingsoon\index.php 41
ERROR - 2015-03-21 01:00:00 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\comingsoon\index.php 42
ERROR - 2015-03-21 01:00:00 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\comingsoon\index.php 42
ERROR - 2015-03-21 01:00:00 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\comingsoon\index.php 99
ERROR - 2015-03-21 01:00:00 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\comingsoon\index.php 107
ERROR - 2015-03-21 01:00:00 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\comingsoon\index.php 226
ERROR - 2015-03-21 01:00:00 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\comingsoon\index.php 226
ERROR - 2015-03-21 01:00:00 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\comingsoon\index.php 226
ERROR - 2015-03-21 01:00:00 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\comingsoon\index.php 226
ERROR - 2015-03-21 01:00:00 --> 404 Page Not Found --> template
ERROR - 2015-03-21 01:00:12 --> 404 Page Not Found --> template
ERROR - 2015-03-21 01:00:25 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\comingsoon\index.php 39
ERROR - 2015-03-21 01:00:25 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\comingsoon\index.php 39
ERROR - 2015-03-21 01:00:25 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\comingsoon\index.php 41
ERROR - 2015-03-21 01:00:25 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\comingsoon\index.php 41
ERROR - 2015-03-21 01:00:25 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\comingsoon\index.php 42
ERROR - 2015-03-21 01:00:25 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\comingsoon\index.php 42
ERROR - 2015-03-21 01:00:25 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\comingsoon\index.php 99
ERROR - 2015-03-21 01:00:25 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\comingsoon\index.php 107
ERROR - 2015-03-21 01:00:25 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\comingsoon\index.php 226
ERROR - 2015-03-21 01:00:25 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\comingsoon\index.php 226
ERROR - 2015-03-21 01:00:25 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\comingsoon\index.php 226
ERROR - 2015-03-21 01:00:25 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\comingsoon\index.php 226
ERROR - 2015-03-21 01:01:10 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\comingsoon\index.php 39
ERROR - 2015-03-21 01:01:10 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\comingsoon\index.php 39
ERROR - 2015-03-21 01:01:10 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\comingsoon\index.php 41
ERROR - 2015-03-21 01:01:10 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\comingsoon\index.php 41
ERROR - 2015-03-21 01:01:10 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\comingsoon\index.php 42
ERROR - 2015-03-21 01:01:10 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\comingsoon\index.php 42
ERROR - 2015-03-21 01:01:10 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\comingsoon\index.php 99
ERROR - 2015-03-21 01:01:10 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\comingsoon\index.php 107
ERROR - 2015-03-21 01:01:10 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\comingsoon\index.php 226
ERROR - 2015-03-21 01:01:10 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\comingsoon\index.php 226
ERROR - 2015-03-21 01:01:10 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\comingsoon\index.php 226
ERROR - 2015-03-21 01:01:10 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\comingsoon\index.php 226
ERROR - 2015-03-21 01:06:26 --> 404 Page Not Found --> template
ERROR - 2015-03-21 01:06:27 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\sidebar.php 4
ERROR - 2015-03-21 01:06:27 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\head.php 7
ERROR - 2015-03-21 01:06:27 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\block\head.php 7
ERROR - 2015-03-21 01:06:27 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\head.php 8
ERROR - 2015-03-21 01:06:27 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\block\head.php 8
ERROR - 2015-03-21 01:06:27 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\head.php 9
ERROR - 2015-03-21 01:06:27 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\block\head.php 9
ERROR - 2015-03-21 01:06:27 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\head.php 44
ERROR - 2015-03-21 01:06:27 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\head.php 123
ERROR - 2015-03-21 01:06:27 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\head.php 124
ERROR - 2015-03-21 01:06:27 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\head.php 125
ERROR - 2015-03-21 01:06:27 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\head.php 126
ERROR - 2015-03-21 01:06:27 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\head.php 127
ERROR - 2015-03-21 01:06:27 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\header.php 14
ERROR - 2015-03-21 01:06:27 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\block\header.php 14
ERROR - 2015-03-21 01:06:27 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\header.php 15
ERROR - 2015-03-21 01:06:27 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\block\header.php 15
ERROR - 2015-03-21 01:06:27 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\header.php 46
ERROR - 2015-03-21 01:06:27 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\header.php 79
ERROR - 2015-03-21 01:06:27 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\header.php 136
ERROR - 2015-03-21 01:06:27 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\header.php 210
ERROR - 2015-03-21 01:06:27 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\footer.php 10
ERROR - 2015-03-21 01:06:27 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\footer.php 146
ERROR - 2015-03-21 01:06:27 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\block\footer.php 146
ERROR - 2015-03-21 01:06:27 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\footer.php 150
ERROR - 2015-03-21 01:06:28 --> 404 Page Not Found --> template
ERROR - 2015-03-21 01:06:42 --> 404 Page Not Found --> template
ERROR - 2015-03-21 01:07:23 --> 404 Page Not Found --> template
ERROR - 2015-03-21 01:07:29 --> Severity: Notice  --> Undefined variable: is_register C:\wamp\www\Esgotado\application\views\forget_password.php 91
ERROR - 2015-03-21 01:07:29 --> 404 Page Not Found --> template
ERROR - 2015-03-21 01:07:45 --> Severity: Warning  --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\wamp\www\Esgotado\system\libraries\Email.php 1553
ERROR - 2015-03-21 01:07:46 --> Severity: Notice  --> Undefined variable: is_register C:\wamp\www\Esgotado\application\views\forget_password.php 91
ERROR - 2015-03-21 01:07:46 --> 404 Page Not Found --> template
ERROR - 2015-03-21 01:08:27 --> Severity: Warning  --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\wamp\www\Esgotado\system\libraries\Email.php 1553
ERROR - 2015-03-21 01:08:27 --> Severity: Notice  --> Undefined variable: is_register C:\wamp\www\Esgotado\application\views\forget_password.php 91
ERROR - 2015-03-21 01:08:27 --> 404 Page Not Found --> template
ERROR - 2015-03-21 01:14:59 --> 404 Page Not Found --> template
ERROR - 2015-03-21 01:15:05 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\head.php 7
ERROR - 2015-03-21 01:15:05 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\block\head.php 7
ERROR - 2015-03-21 01:15:05 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\head.php 8
ERROR - 2015-03-21 01:15:05 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\block\head.php 8
ERROR - 2015-03-21 01:15:05 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\head.php 9
ERROR - 2015-03-21 01:15:05 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\block\head.php 9
ERROR - 2015-03-21 01:15:05 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\head.php 44
ERROR - 2015-03-21 01:15:05 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\head.php 123
ERROR - 2015-03-21 01:15:05 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\head.php 124
ERROR - 2015-03-21 01:15:05 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\head.php 125
ERROR - 2015-03-21 01:15:05 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\head.php 126
ERROR - 2015-03-21 01:15:05 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\head.php 127
ERROR - 2015-03-21 01:15:05 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\header.php 14
ERROR - 2015-03-21 01:15:05 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\block\header.php 14
ERROR - 2015-03-21 01:15:05 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\header.php 15
ERROR - 2015-03-21 01:15:05 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\block\header.php 15
ERROR - 2015-03-21 01:15:05 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\header.php 46
ERROR - 2015-03-21 01:15:05 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\header.php 79
ERROR - 2015-03-21 01:15:05 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\header.php 136
ERROR - 2015-03-21 01:15:05 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\header.php 210
ERROR - 2015-03-21 01:15:05 --> Severity: Notice  --> Undefined variable: sidebar C:\wamp\www\Esgotado\application\views\member\member.php 339
ERROR - 2015-03-21 01:15:05 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\footer.php 10
ERROR - 2015-03-21 01:15:05 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\footer.php 146
ERROR - 2015-03-21 01:15:05 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\block\footer.php 146
ERROR - 2015-03-21 01:15:05 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\footer.php 150
ERROR - 2015-03-21 01:15:05 --> 404 Page Not Found --> template
ERROR - 2015-03-21 01:15:41 --> 404 Page Not Found --> template
ERROR - 2015-03-21 01:15:46 --> 404 Page Not Found --> template
ERROR - 2015-03-21 01:15:52 --> 404 Page Not Found --> template
ERROR - 2015-03-21 01:15:53 --> 404 Page Not Found --> template
ERROR - 2015-03-21 01:15:57 --> 404 Page Not Found --> template
ERROR - 2015-03-21 01:20:23 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\head.php 7
ERROR - 2015-03-21 01:20:23 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\block\head.php 7
ERROR - 2015-03-21 01:20:23 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\head.php 8
ERROR - 2015-03-21 01:20:23 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\block\head.php 8
ERROR - 2015-03-21 01:20:23 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\head.php 9
ERROR - 2015-03-21 01:20:23 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\block\head.php 9
ERROR - 2015-03-21 01:20:23 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\head.php 44
ERROR - 2015-03-21 01:20:23 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\head.php 123
ERROR - 2015-03-21 01:20:23 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\head.php 124
ERROR - 2015-03-21 01:20:23 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\head.php 125
ERROR - 2015-03-21 01:20:23 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\head.php 126
ERROR - 2015-03-21 01:20:23 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\head.php 127
ERROR - 2015-03-21 01:20:23 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\header.php 14
ERROR - 2015-03-21 01:20:23 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\block\header.php 14
ERROR - 2015-03-21 01:20:23 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\header.php 15
ERROR - 2015-03-21 01:20:23 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\block\header.php 15
ERROR - 2015-03-21 01:20:23 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\header.php 46
ERROR - 2015-03-21 01:20:23 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\header.php 79
ERROR - 2015-03-21 01:20:23 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\header.php 136
ERROR - 2015-03-21 01:20:23 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\header.php 210
ERROR - 2015-03-21 01:20:23 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-21 01:20:23 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-21 01:20:23 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-21 01:20:23 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-21 01:20:23 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-21 01:20:23 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-21 01:20:23 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-21 01:20:23 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-21 01:20:23 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-21 01:20:23 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-21 01:20:23 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-21 01:20:23 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-21 01:20:23 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-21 01:20:23 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-21 01:20:23 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-21 01:20:23 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-21 01:20:23 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-21 01:20:23 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-21 01:20:23 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-21 01:20:23 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-21 01:20:23 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-21 01:20:23 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-21 01:20:23 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-21 01:20:23 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-21 01:20:23 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-21 01:20:23 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-21 01:20:23 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-21 01:20:23 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-21 01:20:23 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-21 01:20:23 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-21 01:20:23 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-21 01:20:23 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-21 01:20:23 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-21 01:20:23 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-21 01:20:23 --> Severity: Notice  --> Undefined variable: city C:\wamp\www\Esgotado\application\views\ongkir.php 71
ERROR - 2015-03-21 01:20:23 --> Severity: Notice  --> Undefined variable: district C:\wamp\www\Esgotado\application\views\ongkir.php 97
ERROR - 2015-03-21 01:20:23 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\ongkir.php 138
ERROR - 2015-03-21 01:20:23 --> Severity: Notice  --> Undefined variable: sidebar C:\wamp\www\Esgotado\application\views\ongkir.php 154
ERROR - 2015-03-21 01:20:23 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\footer.php 10
ERROR - 2015-03-21 01:20:23 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\footer.php 146
ERROR - 2015-03-21 01:20:23 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\block\footer.php 146
ERROR - 2015-03-21 01:20:23 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\footer.php 150
ERROR - 2015-03-21 01:20:23 --> 404 Page Not Found --> template
ERROR - 2015-03-21 01:20:31 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-21 01:20:31 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-21 01:20:31 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-21 01:20:31 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-21 01:20:31 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-21 01:20:31 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-21 01:20:31 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-21 01:20:31 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-21 01:20:31 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-21 01:20:31 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-21 01:20:31 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-21 01:20:31 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-21 01:20:31 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-21 01:20:31 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-21 01:20:31 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-21 01:20:31 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-21 01:20:31 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-21 01:20:31 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-21 01:20:31 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-21 01:20:31 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-21 01:20:31 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-21 01:20:31 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-21 01:20:31 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-21 01:20:31 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-21 01:20:31 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-21 01:20:31 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-21 01:20:31 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-21 01:20:31 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-21 01:20:31 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-21 01:20:31 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-21 01:20:31 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-21 01:20:31 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-21 01:20:31 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-21 01:20:31 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-21 01:20:31 --> Severity: Notice  --> Undefined variable: city C:\wamp\www\Esgotado\application\views\ongkir.php 71
ERROR - 2015-03-21 01:20:31 --> Severity: Notice  --> Undefined variable: district C:\wamp\www\Esgotado\application\views\ongkir.php 97
ERROR - 2015-03-21 01:20:31 --> 404 Page Not Found --> template
ERROR - 2015-03-21 07:13:01 --> 404 Page Not Found --> template
ERROR - 2015-03-21 07:13:08 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-21 07:13:08 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-21 07:13:08 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-21 07:13:08 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-21 07:13:08 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-21 07:13:08 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-21 07:13:08 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-21 07:13:08 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-21 07:13:08 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-21 07:13:08 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-21 07:13:08 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-21 07:13:08 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-21 07:13:08 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-21 07:13:08 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-21 07:13:08 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-21 07:13:08 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-21 07:13:08 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-21 07:13:08 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-21 07:13:08 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-21 07:13:08 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-21 07:13:08 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-21 07:13:08 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-21 07:13:08 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-21 07:13:08 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-21 07:13:08 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-21 07:13:08 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-21 07:13:08 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-21 07:13:08 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-21 07:13:08 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-21 07:13:08 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-21 07:13:08 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-21 07:13:08 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-21 07:13:08 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-21 07:13:08 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-21 07:13:08 --> Severity: Notice  --> Undefined variable: city C:\wamp\www\Esgotado\application\views\ongkir.php 71
ERROR - 2015-03-21 07:13:08 --> Severity: Notice  --> Undefined variable: district C:\wamp\www\Esgotado\application\views\ongkir.php 97
ERROR - 2015-03-21 07:13:08 --> 404 Page Not Found --> template
ERROR - 2015-03-21 07:14:34 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\head.php 7
ERROR - 2015-03-21 07:14:34 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\block\head.php 7
ERROR - 2015-03-21 07:14:34 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\head.php 8
ERROR - 2015-03-21 07:14:34 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\block\head.php 8
ERROR - 2015-03-21 07:14:34 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\head.php 9
ERROR - 2015-03-21 07:14:34 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\block\head.php 9
ERROR - 2015-03-21 07:14:34 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\head.php 44
ERROR - 2015-03-21 07:14:34 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\head.php 123
ERROR - 2015-03-21 07:14:34 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\head.php 124
ERROR - 2015-03-21 07:14:34 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\head.php 125
ERROR - 2015-03-21 07:14:34 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\head.php 126
ERROR - 2015-03-21 07:14:34 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\head.php 127
ERROR - 2015-03-21 07:14:34 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\header.php 14
ERROR - 2015-03-21 07:14:34 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\block\header.php 14
ERROR - 2015-03-21 07:14:34 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\header.php 15
ERROR - 2015-03-21 07:14:34 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\block\header.php 15
ERROR - 2015-03-21 07:14:34 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\header.php 46
ERROR - 2015-03-21 07:14:34 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\header.php 79
ERROR - 2015-03-21 07:14:34 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\header.php 136
ERROR - 2015-03-21 07:14:34 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\header.php 210
ERROR - 2015-03-21 07:14:34 --> Severity: Notice  --> Undefined variable: sidebar C:\wamp\www\Esgotado\application\views\ordertracking.php 165
ERROR - 2015-03-21 07:14:34 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\footer.php 10
ERROR - 2015-03-21 07:14:34 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\footer.php 146
ERROR - 2015-03-21 07:14:34 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\block\footer.php 146
ERROR - 2015-03-21 07:14:34 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\footer.php 150
ERROR - 2015-03-21 07:14:34 --> 404 Page Not Found --> template
ERROR - 2015-03-21 07:14:43 --> 404 Page Not Found --> template
ERROR - 2015-03-21 07:15:04 --> 404 Page Not Found --> template
ERROR - 2015-03-21 07:15:11 --> 404 Page Not Found --> template
ERROR - 2015-03-21 07:16:06 --> 404 Page Not Found --> template
ERROR - 2015-03-21 07:16:08 --> 404 Page Not Found --> template
ERROR - 2015-03-21 07:16:10 --> 404 Page Not Found --> template
ERROR - 2015-03-21 07:16:11 --> 404 Page Not Found --> template
ERROR - 2015-03-21 07:16:14 --> 404 Page Not Found --> template
ERROR - 2015-03-21 08:00:29 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\head.php 7
ERROR - 2015-03-21 08:00:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\block\head.php 7
ERROR - 2015-03-21 08:00:29 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\head.php 8
ERROR - 2015-03-21 08:00:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\block\head.php 8
ERROR - 2015-03-21 08:00:29 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\head.php 9
ERROR - 2015-03-21 08:00:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\block\head.php 9
ERROR - 2015-03-21 08:00:29 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\head.php 44
ERROR - 2015-03-21 08:00:29 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\head.php 123
ERROR - 2015-03-21 08:00:29 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\head.php 124
ERROR - 2015-03-21 08:00:29 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\head.php 125
ERROR - 2015-03-21 08:00:29 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\head.php 126
ERROR - 2015-03-21 08:00:29 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\head.php 127
ERROR - 2015-03-21 08:00:29 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\header.php 14
ERROR - 2015-03-21 08:00:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\block\header.php 14
ERROR - 2015-03-21 08:00:29 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\header.php 15
ERROR - 2015-03-21 08:00:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\block\header.php 15
ERROR - 2015-03-21 08:00:29 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\header.php 46
ERROR - 2015-03-21 08:00:29 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\header.php 79
ERROR - 2015-03-21 08:00:29 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\header.php 136
ERROR - 2015-03-21 08:00:29 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\header.php 210
ERROR - 2015-03-21 08:00:29 --> Severity: Notice  --> Undefined variable: breadcrumb C:\wamp\www\Esgotado\application\views\product_grid.php 6
ERROR - 2015-03-21 08:00:29 --> Severity: Notice  --> Undefined variable: breadcrumb C:\wamp\www\Esgotado\application\views\product_grid.php 11
ERROR - 2015-03-21 08:00:29 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\product_grid.php 140
ERROR - 2015-03-21 08:00:29 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\product_grid.php 140
ERROR - 2015-03-21 08:00:29 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\product_grid.php 140
ERROR - 2015-03-21 08:00:29 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\product_grid.php 140
ERROR - 2015-03-21 08:00:29 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\product_grid.php 140
ERROR - 2015-03-21 08:00:29 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\product_grid.php 140
ERROR - 2015-03-21 08:00:29 --> Severity: Notice  --> Undefined variable: sidebar C:\wamp\www\Esgotado\application\views\product_grid.php 167
ERROR - 2015-03-21 08:00:29 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\product_grid.php 180
ERROR - 2015-03-21 08:00:29 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\footer.php 10
ERROR - 2015-03-21 08:00:29 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\footer.php 146
ERROR - 2015-03-21 08:00:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\block\footer.php 146
ERROR - 2015-03-21 08:00:29 --> Severity: Notice  --> Undefined variable: asset C:\wamp\www\Esgotado\application\views\block\footer.php 150
ERROR - 2015-03-21 08:00:29 --> 404 Page Not Found --> template
ERROR - 2015-03-21 08:00:36 --> Severity: Notice  --> Undefined variable: category C:\wamp\www\Esgotado\application\views\block\sidebar.php 86
ERROR - 2015-03-21 08:00:36 --> Severity: Notice  --> Undefined variable: category C:\wamp\www\Esgotado\application\views\block\sidebar.php 96
ERROR - 2015-03-21 08:00:36 --> Severity: Notice  --> Undefined variable: category C:\wamp\www\Esgotado\application\views\block\sidebar.php 96
ERROR - 2015-03-21 08:00:37 --> 404 Page Not Found --> template
ERROR - 2015-03-21 08:02:42 --> 404 Page Not Found --> template
ERROR - 2015-03-21 08:03:05 --> 404 Page Not Found --> template
ERROR - 2015-03-21 08:03:13 --> 404 Page Not Found --> template
ERROR - 2015-03-21 08:03:15 --> 404 Page Not Found --> template
ERROR - 2015-03-21 08:03:16 --> 404 Page Not Found --> template
ERROR - 2015-03-21 08:03:17 --> 404 Page Not Found --> template
ERROR - 2015-03-21 08:03:18 --> 404 Page Not Found --> template
ERROR - 2015-03-21 08:03:18 --> 404 Page Not Found --> template
ERROR - 2015-03-21 08:03:19 --> 404 Page Not Found --> template
ERROR - 2015-03-21 08:03:21 --> 404 Page Not Found --> template
ERROR - 2015-03-21 08:04:19 --> 404 Page Not Found --> template
ERROR - 2015-03-21 08:04:33 --> 404 Page Not Found --> template
ERROR - 2015-03-21 08:04:34 --> 404 Page Not Found --> template
ERROR - 2015-03-21 08:04:35 --> 404 Page Not Found --> template
ERROR - 2015-03-21 08:04:39 --> 404 Page Not Found --> template
ERROR - 2015-03-21 08:07:22 --> 404 Page Not Found --> template
ERROR - 2015-03-21 08:27:09 --> Severity: Notice  --> Undefined property: stdClass::$link C:\wamp\www\Esgotado\application\views\block\sidebar.php 160
ERROR - 2015-03-21 08:27:09 --> Severity: Notice  --> Undefined property: stdClass::$link C:\wamp\www\Esgotado\application\views\block\sidebar.php 160
ERROR - 2015-03-21 08:27:09 --> Severity: Notice  --> Undefined property: stdClass::$link C:\wamp\www\Esgotado\application\views\block\sidebar.php 160
ERROR - 2015-03-21 08:27:09 --> Severity: Notice  --> Undefined property: stdClass::$link C:\wamp\www\Esgotado\application\views\block\sidebar.php 160
ERROR - 2015-03-21 08:27:09 --> 404 Page Not Found --> template
ERROR - 2015-03-21 08:27:25 --> Query error: Unknown column 'name' in 'order clause'
ERROR - 2015-03-21 08:27:43 --> 404 Page Not Found --> template
ERROR - 2015-03-21 08:30:51 --> 404 Page Not Found --> template
ERROR - 2015-03-21 08:42:53 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\models\area_m.php 60
ERROR - 2015-03-21 08:42:53 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\models\area_m.php 55
ERROR - 2015-03-21 08:42:53 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\models\area_m.php 50
ERROR - 2015-03-21 08:42:53 --> 404 Page Not Found --> template
ERROR - 2015-03-21 08:47:07 --> 404 Page Not Found --> template
ERROR - 2015-03-21 09:03:43 --> 404 Page Not Found --> template
ERROR - 2015-03-21 09:03:44 --> 404 Page Not Found --> template
ERROR - 2015-03-21 09:03:45 --> 404 Page Not Found --> template
ERROR - 2015-03-21 09:03:46 --> 404 Page Not Found --> template
ERROR - 2015-03-21 09:04:33 --> 404 Page Not Found --> template
ERROR - 2015-03-21 09:04:51 --> 404 Page Not Found --> template
ERROR - 2015-03-21 09:09:08 --> 404 Page Not Found --> template
ERROR - 2015-03-21 09:10:26 --> 404 Page Not Found --> template
ERROR - 2015-03-21 09:10:34 --> 404 Page Not Found --> template
ERROR - 2015-03-21 09:10:36 --> 404 Page Not Found --> template
ERROR - 2015-03-21 09:10:40 --> 404 Page Not Found --> template
ERROR - 2015-03-21 09:10:40 --> 404 Page Not Found --> my_js
ERROR - 2015-03-21 09:10:45 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2015-03-21 09:10:45 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2015-03-21 09:10:45 --> 404 Page Not Found --> template
ERROR - 2015-03-21 09:10:48 --> 404 Page Not Found --> template
ERROR - 2015-03-21 09:10:52 --> 404 Page Not Found --> template
ERROR - 2015-03-21 09:10:52 --> 404 Page Not Found --> my_js
ERROR - 2015-03-21 09:10:54 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2015-03-21 09:10:54 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2015-03-21 09:10:54 --> 404 Page Not Found --> template
ERROR - 2015-03-21 09:11:10 --> 404 Page Not Found --> template
ERROR - 2015-03-21 09:11:14 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2015-03-21 09:11:14 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2015-03-21 09:11:14 --> 404 Page Not Found --> template
ERROR - 2015-03-21 09:25:02 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2015-03-21 09:25:02 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2015-03-21 09:25:02 --> 404 Page Not Found --> template
ERROR - 2015-03-21 09:25:04 --> 404 Page Not Found --> template
ERROR - 2015-03-21 09:26:00 --> 404 Page Not Found --> template
ERROR - 2015-03-21 09:26:25 --> Severity: Warning  --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\wamp\www\Esgotado\system\libraries\Email.php 1553
ERROR - 2015-03-21 09:26:26 --> 404 Page Not Found --> template
ERROR - 2015-03-21 09:26:57 --> 404 Page Not Found --> template
ERROR - 2015-03-21 09:27:00 --> 404 Page Not Found --> template
ERROR - 2015-03-21 09:27:04 --> 404 Page Not Found --> template
ERROR - 2015-03-21 09:27:30 --> 404 Page Not Found --> template
ERROR - 2015-03-21 09:27:36 --> 404 Page Not Found --> template
ERROR - 2015-03-21 09:27:37 --> 404 Page Not Found --> template
ERROR - 2015-03-21 09:27:39 --> 404 Page Not Found --> template
ERROR - 2015-03-21 09:27:40 --> 404 Page Not Found --> template
ERROR - 2015-03-21 09:27:42 --> 404 Page Not Found --> template
ERROR - 2015-03-21 09:27:44 --> 404 Page Not Found --> template
ERROR - 2015-03-21 09:27:48 --> 404 Page Not Found --> template
ERROR - 2015-03-21 09:27:50 --> 404 Page Not Found --> template
ERROR - 2015-03-21 09:27:51 --> 404 Page Not Found --> template
ERROR - 2015-03-21 09:32:54 --> 404 Page Not Found --> template
ERROR - 2015-03-21 09:33:33 --> Severity: Warning  --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\wamp\www\Esgotado\system\libraries\Email.php 1553
ERROR - 2015-03-21 09:33:33 --> 404 Page Not Found --> template
ERROR - 2015-03-21 09:34:35 --> 404 Page Not Found --> template
ERROR - 2015-03-21 09:34:51 --> 404 Page Not Found --> template
ERROR - 2015-03-21 09:37:35 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'gxa_bank' at line 1
ERROR - 2015-03-21 09:37:55 --> 404 Page Not Found --> template
ERROR - 2015-03-21 09:38:16 --> 404 Page Not Found --> template
ERROR - 2015-03-21 09:44:52 --> 404 Page Not Found --> template
ERROR - 2015-03-21 09:44:54 --> 404 Page Not Found --> template
ERROR - 2015-03-21 09:44:55 --> 404 Page Not Found --> template
ERROR - 2015-03-21 09:44:56 --> 404 Page Not Found --> template
ERROR - 2015-03-21 09:44:59 --> 404 Page Not Found --> template
ERROR - 2015-03-21 09:45:32 --> 404 Page Not Found --> template
ERROR - 2015-03-21 09:46:39 --> Severity: Warning  --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\wamp\www\Esgotado\system\libraries\Email.php 1553
ERROR - 2015-03-21 09:46:39 --> 404 Page Not Found --> template
ERROR - 2015-03-21 09:47:36 --> 404 Page Not Found --> template
ERROR - 2015-03-21 09:47:38 --> 404 Page Not Found --> template
ERROR - 2015-03-21 09:48:09 --> 404 Page Not Found --> template
ERROR - 2015-03-21 09:52:19 --> 404 Page Not Found --> template
ERROR - 2015-03-21 09:52:20 --> 404 Page Not Found --> template
ERROR - 2015-03-21 09:52:21 --> 404 Page Not Found --> template
ERROR - 2015-03-21 09:54:02 --> 404 Page Not Found --> template
ERROR - 2015-03-21 09:54:10 --> 404 Page Not Found --> template
ERROR - 2015-03-21 09:54:13 --> 404 Page Not Found --> template
ERROR - 2015-03-21 09:54:14 --> 404 Page Not Found --> template
ERROR - 2015-03-21 09:54:15 --> 404 Page Not Found --> template
ERROR - 2015-03-21 09:54:16 --> 404 Page Not Found --> template
ERROR - 2015-03-21 09:54:17 --> 404 Page Not Found --> template
ERROR - 2015-03-21 09:54:18 --> 404 Page Not Found --> template
ERROR - 2015-03-21 09:54:19 --> 404 Page Not Found --> template
ERROR - 2015-03-21 09:54:43 --> 404 Page Not Found --> template
ERROR - 2015-03-21 09:54:55 --> 404 Page Not Found --> template
ERROR - 2015-03-21 09:55:30 --> 404 Page Not Found --> template
ERROR - 2015-03-21 09:55:32 --> 404 Page Not Found --> template
ERROR - 2015-03-21 09:55:33 --> 404 Page Not Found --> template
ERROR - 2015-03-21 09:55:34 --> 404 Page Not Found --> template
ERROR - 2015-03-21 09:55:35 --> 404 Page Not Found --> template
ERROR - 2015-03-21 09:55:36 --> 404 Page Not Found --> template
ERROR - 2015-03-21 09:55:37 --> 404 Page Not Found --> template
ERROR - 2015-03-21 09:55:38 --> 404 Page Not Found --> template
ERROR - 2015-03-21 09:56:51 --> 404 Page Not Found --> template
ERROR - 2015-03-21 09:56:52 --> 404 Page Not Found --> template
ERROR - 2015-03-21 09:56:53 --> 404 Page Not Found --> template
ERROR - 2015-03-21 09:56:54 --> 404 Page Not Found --> template
ERROR - 2015-03-21 09:56:55 --> 404 Page Not Found --> template
ERROR - 2015-03-21 09:56:57 --> 404 Page Not Found --> template
ERROR - 2015-03-21 09:56:58 --> 404 Page Not Found --> template
ERROR - 2015-03-21 09:57:00 --> 404 Page Not Found --> template
ERROR - 2015-03-21 09:57:34 --> 404 Page Not Found --> template
ERROR - 2015-03-21 09:57:36 --> 404 Page Not Found --> template
ERROR - 2015-03-21 09:57:37 --> 404 Page Not Found --> template
ERROR - 2015-03-21 09:57:38 --> 404 Page Not Found --> template
ERROR - 2015-03-21 09:57:39 --> 404 Page Not Found --> template
ERROR - 2015-03-21 09:57:40 --> 404 Page Not Found --> template
ERROR - 2015-03-21 09:57:41 --> 404 Page Not Found --> template
ERROR - 2015-03-21 09:57:46 --> 404 Page Not Found --> template
ERROR - 2015-03-21 09:57:48 --> 404 Page Not Found --> template
ERROR - 2015-03-21 09:57:56 --> 404 Page Not Found --> template
ERROR - 2015-03-21 09:57:59 --> 404 Page Not Found --> template
ERROR - 2015-03-21 09:58:43 --> 404 Page Not Found --> template
ERROR - 2015-03-21 09:58:50 --> 404 Page Not Found --> template
ERROR - 2015-03-21 09:58:52 --> 404 Page Not Found --> template
ERROR - 2015-03-21 09:58:56 --> 404 Page Not Found --> template
ERROR - 2015-03-21 09:58:57 --> 404 Page Not Found --> template
ERROR - 2015-03-21 09:58:58 --> 404 Page Not Found --> template
ERROR - 2015-03-21 09:58:59 --> 404 Page Not Found --> template
ERROR - 2015-03-21 09:59:00 --> 404 Page Not Found --> template
ERROR - 2015-03-21 09:59:01 --> 404 Page Not Found --> template
ERROR - 2015-03-21 09:59:02 --> 404 Page Not Found --> template
ERROR - 2015-03-21 09:59:04 --> 404 Page Not Found --> template
ERROR - 2015-03-21 09:59:18 --> 404 Page Not Found --> template
ERROR - 2015-03-21 09:59:24 --> 404 Page Not Found --> template
ERROR - 2015-03-21 09:59:28 --> 404 Page Not Found --> template
ERROR - 2015-03-21 09:59:30 --> 404 Page Not Found --> template
ERROR - 2015-03-21 10:02:00 --> 404 Page Not Found --> template
ERROR - 2015-03-21 10:02:02 --> 404 Page Not Found --> template
ERROR - 2015-03-21 10:02:04 --> 404 Page Not Found --> template
ERROR - 2015-03-21 10:02:10 --> 404 Page Not Found --> template
ERROR - 2015-03-21 10:02:25 --> 404 Page Not Found --> template
ERROR - 2015-03-21 10:02:32 --> 404 Page Not Found --> template
ERROR - 2015-03-21 10:02:41 --> 404 Page Not Found --> template
ERROR - 2015-03-21 10:02:44 --> 404 Page Not Found --> template
ERROR - 2015-03-21 10:02:46 --> 404 Page Not Found --> template
ERROR - 2015-03-21 10:02:55 --> 404 Page Not Found --> template
ERROR - 2015-03-21 10:02:57 --> 404 Page Not Found --> template
ERROR - 2015-03-21 10:03:00 --> 404 Page Not Found --> template
ERROR - 2015-03-21 10:03:10 --> 404 Page Not Found --> template
ERROR - 2015-03-21 10:03:15 --> 404 Page Not Found --> template
ERROR - 2015-03-21 10:03:40 --> 404 Page Not Found --> template
ERROR - 2015-03-21 10:03:42 --> 404 Page Not Found --> member/order
ERROR - 2015-03-21 10:03:53 --> 404 Page Not Found --> template
ERROR - 2015-03-21 10:03:54 --> 404 Page Not Found --> template
ERROR - 2015-03-21 10:03:58 --> 404 Page Not Found --> template
ERROR - 2015-03-21 10:04:03 --> 404 Page Not Found --> template
ERROR - 2015-03-21 10:04:11 --> 404 Page Not Found --> template
ERROR - 2015-03-21 10:04:16 --> 404 Page Not Found --> template
ERROR - 2015-03-21 10:04:23 --> 404 Page Not Found --> template
ERROR - 2015-03-21 10:04:25 --> 404 Page Not Found --> template
ERROR - 2015-03-21 10:04:27 --> 404 Page Not Found --> template
ERROR - 2015-03-21 13:58:46 --> 404 Page Not Found --> template
ERROR - 2015-03-21 13:58:53 --> 404 Page Not Found --> template
ERROR - 2015-03-21 13:58:58 --> 404 Page Not Found --> template
ERROR - 2015-03-21 14:00:48 --> 404 Page Not Found --> template
ERROR - 2015-03-21 14:00:51 --> 404 Page Not Found --> template
ERROR - 2015-03-21 14:00:51 --> 404 Page Not Found --> my_js
ERROR - 2015-03-21 14:00:53 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2015-03-21 14:00:53 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2015-03-21 14:00:53 --> 404 Page Not Found --> template
ERROR - 2015-03-21 14:03:05 --> 404 Page Not Found --> template
ERROR - 2015-03-21 14:03:27 --> 404 Page Not Found --> template
ERROR - 2015-03-21 14:05:27 --> 404 Page Not Found --> template
ERROR - 2015-03-21 14:05:47 --> 404 Page Not Found --> template
ERROR - 2015-03-21 14:06:23 --> 404 Page Not Found --> template
ERROR - 2015-03-21 14:06:37 --> 404 Page Not Found --> template
ERROR - 2015-03-21 14:06:43 --> 404 Page Not Found --> template
ERROR - 2015-03-21 14:07:24 --> 404 Page Not Found --> template
ERROR - 2015-03-21 14:08:55 --> 404 Page Not Found --> template
ERROR - 2015-03-21 14:09:12 --> 404 Page Not Found --> template
ERROR - 2015-03-21 14:09:15 --> 404 Page Not Found --> template
ERROR - 2015-03-21 14:09:17 --> 404 Page Not Found --> template
ERROR - 2015-03-21 14:09:18 --> 404 Page Not Found --> template
ERROR - 2015-03-21 14:09:25 --> 404 Page Not Found --> template
ERROR - 2015-03-21 14:10:35 --> 404 Page Not Found --> template
ERROR - 2015-03-21 14:10:35 --> 404 Page Not Found --> my_js
ERROR - 2015-03-21 14:12:43 --> 404 Page Not Found --> template
ERROR - 2015-03-21 14:12:46 --> 404 Page Not Found --> template
ERROR - 2015-03-21 14:12:46 --> 404 Page Not Found --> my_js
ERROR - 2015-03-21 14:14:19 --> 404 Page Not Found --> template
ERROR - 2015-03-21 14:14:21 --> 404 Page Not Found --> template
ERROR - 2015-03-21 14:14:21 --> 404 Page Not Found --> template
ERROR - 2015-03-21 14:14:23 --> 404 Page Not Found --> template
ERROR - 2015-03-21 14:16:10 --> 404 Page Not Found --> template
ERROR - 2015-03-21 14:16:43 --> 404 Page Not Found --> template
ERROR - 2015-03-21 14:18:26 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2015-03-21 14:18:26 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2015-03-21 14:18:27 --> 404 Page Not Found --> template
ERROR - 2015-03-21 14:21:29 --> 404 Page Not Found --> template
ERROR - 2015-03-21 14:24:42 --> 404 Page Not Found --> template
ERROR - 2015-03-21 14:25:27 --> 404 Page Not Found --> template
ERROR - 2015-03-21 14:25:52 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2015-03-21 14:25:52 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2015-03-21 14:25:52 --> 404 Page Not Found --> template
ERROR - 2015-03-21 14:25:54 --> 404 Page Not Found --> template
ERROR - 2015-03-21 14:25:57 --> 404 Page Not Found --> template
ERROR - 2015-03-21 14:26:55 --> 404 Page Not Found --> template
ERROR - 2015-03-21 14:27:01 --> 404 Page Not Found --> template
ERROR - 2015-03-21 14:27:09 --> 404 Page Not Found --> template
ERROR - 2015-03-21 14:29:22 --> 404 Page Not Found --> template
ERROR - 2015-03-21 14:29:24 --> 404 Page Not Found --> template
ERROR - 2015-03-21 14:31:17 --> 404 Page Not Found --> template
ERROR - 2015-03-21 14:34:12 --> 404 Page Not Found --> template
ERROR - 2015-03-21 14:34:14 --> 404 Page Not Found --> template
ERROR - 2015-03-21 14:34:16 --> 404 Page Not Found --> template
ERROR - 2015-03-21 14:34:28 --> 404 Page Not Found --> template
ERROR - 2015-03-21 14:34:37 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-21 14:34:37 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-21 14:34:38 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-21 14:34:38 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-21 14:34:38 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-21 14:34:38 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-21 14:34:38 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-21 14:34:38 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-21 14:34:38 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-21 14:34:38 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-21 14:34:38 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-21 14:34:38 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-21 14:34:38 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-21 14:34:38 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-21 14:34:38 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-21 14:34:38 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-21 14:34:38 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-21 14:34:38 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-21 14:34:38 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-21 14:34:38 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-21 14:34:38 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-21 14:34:38 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-21 14:34:38 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-21 14:34:38 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-21 14:34:38 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-21 14:34:38 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-21 14:34:38 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-21 14:34:38 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-21 14:34:38 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-21 14:34:38 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-21 14:34:38 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-21 14:34:38 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-21 14:34:38 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-21 14:34:38 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-21 14:34:38 --> Severity: Notice  --> Undefined variable: city C:\wamp\www\Esgotado\application\views\ongkir.php 71
ERROR - 2015-03-21 14:34:38 --> Severity: Notice  --> Undefined variable: district C:\wamp\www\Esgotado\application\views\ongkir.php 97
ERROR - 2015-03-21 14:34:38 --> 404 Page Not Found --> template
ERROR - 2015-03-21 14:34:42 --> 404 Page Not Found --> template
ERROR - 2015-03-21 14:35:22 --> 404 Page Not Found --> template
ERROR - 2015-03-21 14:35:24 --> 404 Page Not Found --> template
ERROR - 2015-03-21 14:35:36 --> 404 Page Not Found --> template
ERROR - 2015-03-21 14:37:00 --> 404 Page Not Found --> template
ERROR - 2015-03-21 14:37:23 --> 404 Page Not Found --> template
ERROR - 2015-03-21 14:37:24 --> 404 Page Not Found --> template
ERROR - 2015-03-21 14:37:29 --> 404 Page Not Found --> template
ERROR - 2015-03-21 14:37:35 --> 404 Page Not Found --> template
ERROR - 2015-03-21 14:37:37 --> 404 Page Not Found --> template
ERROR - 2015-03-21 14:37:46 --> 404 Page Not Found --> template
ERROR - 2015-03-21 14:37:55 --> 404 Page Not Found --> template
ERROR - 2015-03-21 14:38:40 --> 404 Page Not Found --> template
ERROR - 2015-03-21 14:39:07 --> 404 Page Not Found --> template
ERROR - 2015-03-21 14:39:43 --> 404 Page Not Found --> template
ERROR - 2015-03-21 14:40:10 --> 404 Page Not Found --> template
ERROR - 2015-03-21 14:40:18 --> 404 Page Not Found --> template
ERROR - 2015-03-21 14:41:18 --> 404 Page Not Found --> template
ERROR - 2015-03-21 14:41:30 --> 404 Page Not Found --> template
ERROR - 2015-03-21 14:43:04 --> 404 Page Not Found --> template
ERROR - 2015-03-21 14:44:29 --> 404 Page Not Found --> template
ERROR - 2015-03-21 14:48:29 --> 404 Page Not Found --> template
ERROR - 2015-03-21 14:48:48 --> 404 Page Not Found --> template
ERROR - 2015-03-21 14:48:53 --> 404 Page Not Found --> template
ERROR - 2015-03-21 14:50:35 --> 404 Page Not Found --> template
ERROR - 2015-03-21 14:50:40 --> 404 Page Not Found --> template
ERROR - 2015-03-21 14:50:44 --> 404 Page Not Found --> template
ERROR - 2015-03-21 14:50:48 --> 404 Page Not Found --> template
ERROR - 2015-03-21 14:50:52 --> 404 Page Not Found --> template
ERROR - 2015-03-21 14:50:55 --> 404 Page Not Found --> template
ERROR - 2015-03-21 14:50:58 --> 404 Page Not Found --> template
ERROR - 2015-03-21 14:52:03 --> 404 Page Not Found --> template
ERROR - 2015-03-21 14:52:29 --> 404 Page Not Found --> template
ERROR - 2015-03-21 14:52:29 --> 404 Page Not Found --> my_js
ERROR - 2015-03-21 14:53:34 --> 404 Page Not Found --> template
ERROR - 2015-03-21 14:53:34 --> 404 Page Not Found --> my_js
ERROR - 2015-03-21 14:53:53 --> 404 Page Not Found --> template
ERROR - 2015-03-21 14:53:53 --> 404 Page Not Found --> my_js
ERROR - 2015-03-21 14:54:13 --> 404 Page Not Found --> template
ERROR - 2015-03-21 14:54:13 --> 404 Page Not Found --> my_js
ERROR - 2015-03-21 14:54:34 --> 404 Page Not Found --> template
ERROR - 2015-03-21 14:54:34 --> 404 Page Not Found --> my_js
ERROR - 2015-03-21 14:55:59 --> 404 Page Not Found --> template
ERROR - 2015-03-21 14:55:59 --> 404 Page Not Found --> my_js
ERROR - 2015-03-21 14:56:45 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2015-03-21 14:56:45 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2015-03-21 14:56:45 --> 404 Page Not Found --> template
ERROR - 2015-03-21 14:59:01 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2015-03-21 14:59:01 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2015-03-21 14:59:02 --> 404 Page Not Found --> template
ERROR - 2015-03-21 14:59:20 --> 404 Page Not Found --> template
ERROR - 2015-03-21 15:02:52 --> Could not find the language line "c_cart_is_empty"
ERROR - 2015-03-21 15:02:52 --> 404 Page Not Found --> template
ERROR - 2015-03-21 15:02:57 --> 404 Page Not Found --> template
ERROR - 2015-03-21 15:03:34 --> 404 Page Not Found --> template
ERROR - 2015-03-21 15:03:38 --> 404 Page Not Found --> template
ERROR - 2015-03-21 15:04:39 --> 404 Page Not Found --> template
ERROR - 2015-03-21 15:04:59 --> 404 Page Not Found --> template
ERROR - 2015-03-21 15:05:01 --> 404 Page Not Found --> template
ERROR - 2015-03-21 15:05:01 --> 404 Page Not Found --> my_js
ERROR - 2015-03-21 15:05:03 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2015-03-21 15:05:03 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2015-03-21 15:05:03 --> 404 Page Not Found --> template
ERROR - 2015-03-21 15:05:06 --> 404 Page Not Found --> template
ERROR - 2015-03-21 15:05:57 --> 404 Page Not Found --> template
ERROR - 2015-03-21 15:06:54 --> 404 Page Not Found --> template
ERROR - 2015-03-21 15:07:27 --> 404 Page Not Found --> template
ERROR - 2015-03-21 15:07:40 --> 404 Page Not Found --> template
ERROR - 2015-03-21 15:07:53 --> 404 Page Not Found --> template
ERROR - 2015-03-21 15:08:15 --> 404 Page Not Found --> template
ERROR - 2015-03-21 15:09:17 --> 404 Page Not Found --> template
ERROR - 2015-03-21 15:09:46 --> 404 Page Not Found --> template
ERROR - 2015-03-21 15:10:03 --> 404 Page Not Found --> template
ERROR - 2015-03-21 15:10:05 --> 404 Page Not Found --> template
ERROR - 2015-03-21 15:10:39 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2015-03-21 15:10:39 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2015-03-21 15:10:39 --> 404 Page Not Found --> template
ERROR - 2015-03-21 15:10:40 --> 404 Page Not Found --> template
