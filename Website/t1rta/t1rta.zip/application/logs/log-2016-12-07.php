<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2016-12-07 16:07:00 --> Severity: Notice  --> Undefined variable: notification_order /home/tirtadah/public_html/t1rta/application/views/slices/sidebar.php 85
ERROR - 2016-12-07 16:07:00 --> Severity: Notice  --> Undefined variable: notification_order /home/tirtadah/public_html/t1rta/application/views/slices/sidebar.php 98
ERROR - 2016-12-07 22:59:52 --> Severity: Notice  --> Undefined variable: notification_order /home/tirtadah/public_html/t1rta/application/views/slices/sidebar.php 85
ERROR - 2016-12-07 22:59:52 --> Severity: Notice  --> Undefined variable: notification_order /home/tirtadah/public_html/t1rta/application/views/slices/sidebar.php 98
ERROR - 2016-12-07 22:59:59 --> Severity: Notice  --> Undefined variable: notification_order /home/tirtadah/public_html/t1rta/application/views/slices/sidebar.php 85
ERROR - 2016-12-07 22:59:59 --> Severity: Notice  --> Undefined variable: notification_order /home/tirtadah/public_html/t1rta/application/views/slices/sidebar.php 98
ERROR - 2016-12-07 23:00:00 --> Severity: Notice  --> Undefined variable: notification_order /home/tirtadah/public_html/t1rta/application/views/slices/sidebar.php 85
ERROR - 2016-12-07 23:00:00 --> Severity: Notice  --> Undefined variable: notification_order /home/tirtadah/public_html/t1rta/application/views/slices/sidebar.php 98
ERROR - 2016-12-07 23:00:00 --> Severity: Notice  --> Undefined variable: chart_delivered /home/tirtadah/public_html/t1rta/application/views/home.php 112
ERROR - 2016-12-07 23:00:00 --> Severity: Notice  --> Undefined variable: chart_canceled /home/tirtadah/public_html/t1rta/application/views/home.php 131
ERROR - 2016-12-07 23:00:02 --> Severity: Notice  --> Undefined variable: notification_order /home/tirtadah/public_html/t1rta/application/views/slices/sidebar.php 85
ERROR - 2016-12-07 23:00:02 --> Severity: Notice  --> Undefined variable: notification_order /home/tirtadah/public_html/t1rta/application/views/slices/sidebar.php 98
ERROR - 2016-12-07 23:03:32 --> Severity: Notice  --> Undefined variable: notification_order /home/tirtadah/public_html/t1rta/application/views/slices/sidebar.php 85
ERROR - 2016-12-07 23:03:32 --> Severity: Notice  --> Undefined variable: notification_order /home/tirtadah/public_html/t1rta/application/views/slices/sidebar.php 98
ERROR - 2016-12-07 23:03:36 --> Severity: Notice  --> Undefined variable: notification_order /home/tirtadah/public_html/t1rta/application/views/slices/sidebar.php 85
ERROR - 2016-12-07 23:03:36 --> Severity: Notice  --> Undefined variable: notification_order /home/tirtadah/public_html/t1rta/application/views/slices/sidebar.php 98
ERROR - 2016-12-07 23:04:12 --> Severity: Notice  --> Undefined variable: notification_order /home/tirtadah/public_html/t1rta/application/views/slices/sidebar.php 85
ERROR - 2016-12-07 23:04:12 --> Severity: Notice  --> Undefined variable: notification_order /home/tirtadah/public_html/t1rta/application/views/slices/sidebar.php 98
