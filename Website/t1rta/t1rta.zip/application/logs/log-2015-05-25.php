<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-05-25 03:55:27 --> 404 Page Not Found --> template
ERROR - 2015-05-25 04:26:48 --> 404 Page Not Found --> template
ERROR - 2015-05-25 04:26:55 --> 404 Page Not Found --> template
ERROR - 2015-05-25 04:26:59 --> 404 Page Not Found --> template
ERROR - 2015-05-25 04:27:08 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2015-05-25 04:27:08 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2015-05-25 04:27:08 --> 404 Page Not Found --> template
ERROR - 2015-05-25 04:27:18 --> 404 Page Not Found --> template
ERROR - 2015-05-25 04:27:25 --> 404 Page Not Found --> template
ERROR - 2015-05-25 04:27:32 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2015-05-25 04:27:32 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2015-05-25 04:27:32 --> 404 Page Not Found --> template
ERROR - 2015-05-25 04:27:38 --> 404 Page Not Found --> template
ERROR - 2015-05-25 04:28:49 --> 404 Page Not Found --> template
ERROR - 2015-05-25 04:31:24 --> 404 Page Not Found --> template
ERROR - 2015-05-25 04:32:01 --> 404 Page Not Found --> template
ERROR - 2015-05-25 04:32:23 --> 404 Page Not Found --> template
ERROR - 2015-05-25 04:32:34 --> 404 Page Not Found --> template
ERROR - 2015-05-25 04:32:52 --> 404 Page Not Found --> template
ERROR - 2015-05-25 04:34:13 --> 404 Page Not Found --> template
ERROR - 2015-05-25 04:34:17 --> 404 Page Not Found --> template
ERROR - 2015-05-25 04:35:50 --> 404 Page Not Found --> template
ERROR - 2015-05-25 04:35:55 --> 404 Page Not Found --> template
ERROR - 2015-05-25 04:35:58 --> 404 Page Not Found --> template
ERROR - 2015-05-25 04:36:18 --> 404 Page Not Found --> template
ERROR - 2015-05-25 04:36:39 --> 404 Page Not Found --> template
ERROR - 2015-05-25 04:36:53 --> 404 Page Not Found --> template
ERROR - 2015-05-25 04:38:11 --> 404 Page Not Found --> template
ERROR - 2015-05-25 04:38:53 --> 404 Page Not Found --> template
ERROR - 2015-05-25 04:39:05 --> 404 Page Not Found --> template
ERROR - 2015-05-25 04:39:31 --> 404 Page Not Found --> template
ERROR - 2015-05-25 04:45:06 --> 404 Page Not Found --> template
ERROR - 2015-05-25 04:45:32 --> 404 Page Not Found --> template
ERROR - 2015-05-25 04:45:54 --> 404 Page Not Found --> template
ERROR - 2015-05-25 04:46:26 --> 404 Page Not Found --> template
ERROR - 2015-05-25 04:47:20 --> 404 Page Not Found --> template
ERROR - 2015-05-25 04:47:49 --> 404 Page Not Found --> template
ERROR - 2015-05-25 04:48:01 --> 404 Page Not Found --> template
ERROR - 2015-05-25 04:48:03 --> 404 Page Not Found --> template
ERROR - 2015-05-25 04:49:09 --> 404 Page Not Found --> template
ERROR - 2015-05-25 04:49:49 --> 404 Page Not Found --> template
ERROR - 2015-05-25 04:50:07 --> 404 Page Not Found --> template
ERROR - 2015-05-25 04:51:19 --> 404 Page Not Found --> template
ERROR - 2015-05-25 04:52:10 --> 404 Page Not Found --> template
ERROR - 2015-05-25 04:53:35 --> 404 Page Not Found --> template
ERROR - 2015-05-25 04:55:36 --> 404 Page Not Found --> template
ERROR - 2015-05-25 04:55:51 --> 404 Page Not Found --> template
ERROR - 2015-05-25 04:55:53 --> 404 Page Not Found --> template
ERROR - 2015-05-25 04:56:36 --> 404 Page Not Found --> template
ERROR - 2015-05-25 05:35:36 --> Severity: Warning  --> Missing argument 1 for Product_m::get_all(), called in C:\wamp\www\Esgotado\application\controllers\preorder.php on line 9 and defined C:\wamp\www\Esgotado\application\models\product_m.php 12
ERROR - 2015-05-25 05:35:36 --> Severity: Warning  --> Missing argument 2 for Product_m::get_all(), called in C:\wamp\www\Esgotado\application\controllers\preorder.php on line 9 and defined C:\wamp\www\Esgotado\application\models\product_m.php 12
ERROR - 2015-05-25 05:35:36 --> Severity: Warning  --> Missing argument 3 for Product_m::get_all(), called in C:\wamp\www\Esgotado\application\controllers\preorder.php on line 9 and defined C:\wamp\www\Esgotado\application\models\product_m.php 12
ERROR - 2015-05-25 05:35:36 --> Severity: Warning  --> Missing argument 4 for Product_m::get_all(), called in C:\wamp\www\Esgotado\application\controllers\preorder.php on line 9 and defined C:\wamp\www\Esgotado\application\models\product_m.php 12
ERROR - 2015-05-25 05:35:36 --> Severity: Notice  --> Undefined variable: category C:\wamp\www\Esgotado\application\models\product_m.php 29
ERROR - 2015-05-25 05:35:36 --> Severity: Notice  --> Undefined variable: category C:\wamp\www\Esgotado\application\models\product_m.php 30
ERROR - 2015-05-25 05:35:36 --> Severity: Notice  --> Undefined variable: order C:\wamp\www\Esgotado\application\models\product_m.php 40
ERROR - 2015-05-25 05:35:36 --> Severity: Notice  --> Undefined variable: breadcrumb C:\wamp\www\Esgotado\application\views\contact.php 6
ERROR - 2015-05-25 05:35:36 --> Severity: Notice  --> Undefined variable: breadcrumb C:\wamp\www\Esgotado\application\views\contact.php 11
ERROR - 2015-05-25 05:35:36 --> Severity: Notice  --> Undefined variable: division C:\wamp\www\Esgotado\application\views\contact.php 65
ERROR - 2015-05-25 05:35:36 --> Severity: Notice  --> Undefined variable: division C:\wamp\www\Esgotado\application\views\contact.php 215
ERROR - 2015-05-25 05:35:36 --> 404 Page Not Found --> template
ERROR - 2015-05-25 05:36:15 --> Severity: Warning  --> Missing argument 3 for Product_m::get_all(), called in C:\wamp\www\Esgotado\application\controllers\preorder.php on line 9 and defined C:\wamp\www\Esgotado\application\models\product_m.php 12
ERROR - 2015-05-25 05:36:15 --> Severity: Warning  --> Missing argument 4 for Product_m::get_all(), called in C:\wamp\www\Esgotado\application\controllers\preorder.php on line 9 and defined C:\wamp\www\Esgotado\application\models\product_m.php 12
ERROR - 2015-05-25 05:36:15 --> Severity: Notice  --> Undefined variable: category C:\wamp\www\Esgotado\application\models\product_m.php 29
ERROR - 2015-05-25 05:36:15 --> Severity: Notice  --> Undefined variable: category C:\wamp\www\Esgotado\application\models\product_m.php 30
ERROR - 2015-05-25 05:36:15 --> Severity: Notice  --> Undefined variable: order C:\wamp\www\Esgotado\application\models\product_m.php 40
ERROR - 2015-05-25 05:36:15 --> Severity: Notice  --> Undefined variable: breadcrumb C:\wamp\www\Esgotado\application\views\contact.php 6
ERROR - 2015-05-25 05:36:15 --> Severity: Notice  --> Undefined variable: breadcrumb C:\wamp\www\Esgotado\application\views\contact.php 11
ERROR - 2015-05-25 05:36:15 --> Severity: Notice  --> Undefined variable: division C:\wamp\www\Esgotado\application\views\contact.php 65
ERROR - 2015-05-25 05:36:15 --> Severity: Notice  --> Undefined variable: division C:\wamp\www\Esgotado\application\views\contact.php 215
ERROR - 2015-05-25 05:36:16 --> 404 Page Not Found --> template
ERROR - 2015-05-25 05:36:31 --> Severity: Notice  --> Undefined variable: breadcrumb C:\wamp\www\Esgotado\application\views\contact.php 6
ERROR - 2015-05-25 05:36:31 --> Severity: Notice  --> Undefined variable: breadcrumb C:\wamp\www\Esgotado\application\views\contact.php 11
ERROR - 2015-05-25 05:36:31 --> Severity: Notice  --> Undefined variable: division C:\wamp\www\Esgotado\application\views\contact.php 65
ERROR - 2015-05-25 05:36:31 --> Severity: Notice  --> Undefined variable: division C:\wamp\www\Esgotado\application\views\contact.php 215
ERROR - 2015-05-25 05:36:31 --> 404 Page Not Found --> template
ERROR - 2015-05-25 05:36:46 --> Severity: Notice  --> Undefined variable: breadcrumb C:\wamp\www\Esgotado\application\views\contact.php 6
ERROR - 2015-05-25 05:36:46 --> Severity: Notice  --> Undefined variable: breadcrumb C:\wamp\www\Esgotado\application\views\contact.php 11
ERROR - 2015-05-25 05:36:46 --> Severity: Notice  --> Undefined variable: division C:\wamp\www\Esgotado\application\views\contact.php 65
ERROR - 2015-05-25 05:36:46 --> Severity: Notice  --> Undefined variable: division C:\wamp\www\Esgotado\application\views\contact.php 215
ERROR - 2015-05-25 05:36:46 --> 404 Page Not Found --> template
ERROR - 2015-05-25 05:36:57 --> Severity: Notice  --> Undefined variable: division C:\wamp\www\Esgotado\application\views\preorder.php 65
ERROR - 2015-05-25 05:36:57 --> Severity: Notice  --> Undefined variable: division C:\wamp\www\Esgotado\application\views\preorder.php 215
ERROR - 2015-05-25 05:36:58 --> 404 Page Not Found --> template
ERROR - 2015-05-25 05:36:59 --> 404 Page Not Found --> template
ERROR - 2015-05-25 05:37:01 --> Severity: Notice  --> Undefined variable: division C:\wamp\www\Esgotado\application\views\preorder.php 65
ERROR - 2015-05-25 05:37:01 --> Severity: Notice  --> Undefined variable: division C:\wamp\www\Esgotado\application\views\preorder.php 215
ERROR - 2015-05-25 05:37:23 --> Could not find the language line "c_send_preorder"
ERROR - 2015-05-25 05:37:24 --> Severity: Notice  --> Undefined variable: division C:\wamp\www\Esgotado\application\views\preorder.php 65
ERROR - 2015-05-25 05:37:24 --> Severity: Notice  --> Undefined variable: division C:\wamp\www\Esgotado\application\views\preorder.php 215
ERROR - 2015-05-25 05:37:24 --> 404 Page Not Found --> template
ERROR - 2015-05-25 05:38:07 --> Could not find the language line "c_send_preorder"
ERROR - 2015-05-25 05:38:07 --> Severity: Notice  --> Undefined variable: division C:\wamp\www\Esgotado\application\views\preorder.php 198
ERROR - 2015-05-25 05:38:08 --> 404 Page Not Found --> template
ERROR - 2015-05-25 05:38:20 --> Could not find the language line "c_send_preorder"
ERROR - 2015-05-25 05:38:20 --> Severity: Notice  --> Undefined variable: division C:\wamp\www\Esgotado\application\views\preorder.php 198
ERROR - 2015-05-25 05:38:20 --> 404 Page Not Found --> template
ERROR - 2015-05-25 05:38:27 --> Could not find the language line "c_send_preorder"
ERROR - 2015-05-25 05:38:27 --> Severity: Notice  --> Undefined variable: division C:\wamp\www\Esgotado\application\views\preorder.php 198
ERROR - 2015-05-25 05:38:27 --> 404 Page Not Found --> template
ERROR - 2015-05-25 05:39:13 --> Could not find the language line "c_send_preorder"
ERROR - 2015-05-25 05:39:13 --> Severity: Notice  --> Undefined variable: division C:\wamp\www\Esgotado\application\views\preorder.php 198
ERROR - 2015-05-25 05:39:13 --> 404 Page Not Found --> template
ERROR - 2015-05-25 05:39:21 --> Could not find the language line "c_send_preorder"
ERROR - 2015-05-25 05:39:21 --> Severity: Notice  --> Undefined variable: division C:\wamp\www\Esgotado\application\views\preorder.php 198
ERROR - 2015-05-25 05:39:21 --> 404 Page Not Found --> template
ERROR - 2015-05-25 05:39:31 --> Could not find the language line "c_send_preorder"
ERROR - 2015-05-25 05:39:31 --> Severity: Notice  --> Undefined variable: division C:\wamp\www\Esgotado\application\views\preorder.php 198
ERROR - 2015-05-25 05:39:31 --> 404 Page Not Found --> template
ERROR - 2015-05-25 05:40:58 --> Could not find the language line "c_send_preorder"
ERROR - 2015-05-25 05:40:58 --> Severity: Notice  --> Undefined variable: division C:\wamp\www\Esgotado\application\views\preorder.php 198
ERROR - 2015-05-25 05:40:58 --> 404 Page Not Found --> template
ERROR - 2015-05-25 05:41:06 --> Could not find the language line "c_send_preorder"
ERROR - 2015-05-25 05:41:06 --> Severity: Notice  --> Undefined variable: division C:\wamp\www\Esgotado\application\views\preorder.php 198
ERROR - 2015-05-25 05:41:06 --> 404 Page Not Found --> template
ERROR - 2015-05-25 05:41:11 --> Could not find the language line "c_send_preorder"
ERROR - 2015-05-25 05:41:11 --> Severity: Notice  --> Undefined variable: division C:\wamp\www\Esgotado\application\views\preorder.php 198
ERROR - 2015-05-25 05:41:11 --> 404 Page Not Found --> template
ERROR - 2015-05-25 05:42:20 --> Severity: Notice  --> Undefined variable: division C:\wamp\www\Esgotado\application\views\preorder.php 198
ERROR - 2015-05-25 05:42:20 --> 404 Page Not Found --> template
ERROR - 2015-05-25 05:42:30 --> Severity: Notice  --> Undefined variable: division C:\wamp\www\Esgotado\application\views\preorder.php 198
ERROR - 2015-05-25 05:42:30 --> 404 Page Not Found --> template
ERROR - 2015-05-25 05:42:42 --> 404 Page Not Found --> template
ERROR - 2015-05-25 05:42:45 --> 404 Page Not Found --> template
ERROR - 2015-05-25 05:42:59 --> 404 Page Not Found --> template
ERROR - 2015-05-25 05:43:02 --> Severity: Notice  --> Undefined variable: division C:\wamp\www\Esgotado\application\views\preorder.php 198
ERROR - 2015-05-25 05:45:40 --> Severity: Notice  --> Undefined variable: division C:\wamp\www\Esgotado\application\views\preorder.php 198
ERROR - 2015-05-25 05:45:40 --> 404 Page Not Found --> template
ERROR - 2015-05-25 05:45:48 --> Severity: Notice  --> Undefined variable: division C:\wamp\www\Esgotado\application\views\preorder.php 198
ERROR - 2015-05-25 05:45:48 --> 404 Page Not Found --> template
ERROR - 2015-05-25 05:45:50 --> 404 Page Not Found --> template
ERROR - 2015-05-25 05:46:03 --> 404 Page Not Found --> template
ERROR - 2015-05-25 05:46:11 --> Severity: Notice  --> Undefined variable: division C:\wamp\www\Esgotado\application\views\preorder.php 198
ERROR - 2015-05-25 05:46:19 --> Severity: Notice  --> Undefined variable: division C:\wamp\www\Esgotado\application\views\preorder.php 198
ERROR - 2015-05-25 05:46:19 --> 404 Page Not Found --> template
ERROR - 2015-05-25 05:46:26 --> Severity: Notice  --> Undefined variable: division C:\wamp\www\Esgotado\application\views\preorder.php 198
ERROR - 2015-05-25 05:46:26 --> 404 Page Not Found --> template
ERROR - 2015-05-25 05:46:35 --> Severity: Notice  --> Undefined variable: division C:\wamp\www\Esgotado\application\views\preorder.php 198
ERROR - 2015-05-25 05:46:35 --> 404 Page Not Found --> template
ERROR - 2015-05-25 05:47:04 --> Severity: Notice  --> Undefined variable: division C:\wamp\www\Esgotado\application\views\preorder.php 198
ERROR - 2015-05-25 05:47:04 --> 404 Page Not Found --> template
ERROR - 2015-05-25 05:47:30 --> Severity: Notice  --> Undefined variable: division C:\wamp\www\Esgotado\application\views\preorder.php 198
ERROR - 2015-05-25 05:47:30 --> 404 Page Not Found --> template
ERROR - 2015-05-25 05:47:32 --> Severity: Notice  --> Undefined variable: division C:\wamp\www\Esgotado\application\views\preorder.php 198
ERROR - 2015-05-25 05:47:32 --> 404 Page Not Found --> template
ERROR - 2015-05-25 05:47:42 --> Severity: Notice  --> Undefined variable: division C:\wamp\www\Esgotado\application\views\preorder.php 198
ERROR - 2015-05-25 05:47:42 --> 404 Page Not Found --> template
ERROR - 2015-05-25 05:47:48 --> Severity: Notice  --> Undefined variable: division C:\wamp\www\Esgotado\application\views\preorder.php 198
ERROR - 2015-05-25 05:47:48 --> 404 Page Not Found --> template
ERROR - 2015-05-25 05:50:59 --> Severity: Notice  --> Undefined variable: division C:\wamp\www\Esgotado\application\views\preorder.php 198
ERROR - 2015-05-25 05:51:07 --> Severity: Notice  --> Undefined variable: division C:\wamp\www\Esgotado\application\views\preorder.php 198
ERROR - 2015-05-25 05:51:08 --> 404 Page Not Found --> template
ERROR - 2015-05-25 06:19:52 --> 404 Page Not Found --> template
ERROR - 2015-05-25 06:19:54 --> 404 Page Not Found --> template
ERROR - 2015-05-25 06:20:50 --> 404 Page Not Found --> template
ERROR - 2015-05-25 06:21:13 --> Could not find the language line "p_btn_pre_order"
ERROR - 2015-05-25 06:21:13 --> 404 Page Not Found --> template
ERROR - 2015-05-25 06:21:47 --> 404 Page Not Found --> template
ERROR - 2015-05-25 06:22:21 --> 404 Page Not Found --> template
ERROR - 2015-05-25 06:28:04 --> 404 Page Not Found --> template
ERROR - 2015-05-25 06:28:43 --> 404 Page Not Found --> template
ERROR - 2015-05-25 06:30:46 --> 404 Page Not Found --> template
ERROR - 2015-05-25 06:31:28 --> 404 Page Not Found --> template
ERROR - 2015-05-25 06:34:20 --> 404 Page Not Found --> template
ERROR - 2015-05-25 06:34:55 --> 404 Page Not Found --> template
ERROR - 2015-05-25 06:36:08 --> 404 Page Not Found --> template
ERROR - 2015-05-25 06:36:25 --> 404 Page Not Found --> template
ERROR - 2015-05-25 06:36:37 --> 404 Page Not Found --> template
ERROR - 2015-05-25 06:36:53 --> 404 Page Not Found --> template
