<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-11-30 06:31:47 --> 404 Page Not Found --> ambassador
ERROR - 2015-11-30 07:36:15 --> Severity: Notice  --> Undefined property: CI_Loader::$uru C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\slices\sidebar.php 183
ERROR - 2015-11-30 07:36:16 --> Severity: Notice  --> Undefined property: CI_Loader::$uru C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\slices\sidebar.php 183
ERROR - 2015-11-30 07:36:16 --> Severity: Notice  --> Undefined property: CI_Loader::$uru C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\slices\sidebar.php 183
ERROR - 2015-11-30 07:36:17 --> Severity: Notice  --> Undefined property: CI_Loader::$uru C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\slices\sidebar.php 183
ERROR - 2015-11-30 07:36:17 --> Severity: Notice  --> Undefined property: CI_Loader::$uru C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\slices\sidebar.php 183
ERROR - 2015-11-30 07:36:29 --> Severity: Notice  --> Undefined property: CI_Loader::$uru C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\slices\sidebar.php 183
ERROR - 2015-11-30 07:36:35 --> Severity: Notice  --> Undefined property: CI_Loader::$uru C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\slices\sidebar.php 183
ERROR - 2015-11-30 07:37:38 --> 404 Page Not Found --> newsletter
ERROR - 2015-11-30 07:37:44 --> 404 Page Not Found --> newsletter
ERROR - 2015-11-30 07:40:27 --> 404 Page Not Found --> newsletter
ERROR - 2015-11-30 07:52:17 --> 404 Page Not Found --> newsletter
ERROR - 2015-11-30 08:35:36 --> 404 Page Not Found --> ambassador
ERROR - 2015-11-30 08:39:21 --> 404 Page Not Found --> ambassador
ERROR - 2015-11-30 09:02:11 --> Query error: Unknown column 'article_type_id' in 'where clause'
ERROR - 2015-11-30 09:02:13 --> Query error: Unknown column 'article_type_id' in 'where clause'
ERROR - 2015-11-30 09:02:13 --> Query error: Unknown column 'article_type_id' in 'where clause'
ERROR - 2015-11-30 09:02:13 --> Query error: Unknown column 'article_type_id' in 'where clause'
ERROR - 2015-11-30 09:02:24 --> Query error: Unknown column 'article_type_id' in 'where clause'
ERROR - 2015-11-30 09:03:01 --> Query error: Unknown column 'article_type_id' in 'where clause'
ERROR - 2015-11-30 12:43:58 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'title LIKE '%%'  ORDER BY date DESC LIMIT 0, 10' at line 1
ERROR - 2015-11-30 12:44:09 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'title LIKE '%%'  ORDER BY date DESC LIMIT 0, 10' at line 1
ERROR - 2015-11-30 12:44:10 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'title LIKE '%%'  ORDER BY date DESC LIMIT 0, 10' at line 1
ERROR - 2015-11-30 12:44:10 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'title LIKE '%%'  ORDER BY date DESC LIMIT 0, 10' at line 1
ERROR - 2015-11-30 12:44:10 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'title LIKE '%%'  ORDER BY date DESC LIMIT 0, 10' at line 1
ERROR - 2015-11-30 12:44:10 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'title LIKE '%%'  ORDER BY date DESC LIMIT 0, 10' at line 1
ERROR - 2015-11-30 12:44:10 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'title LIKE '%%'  ORDER BY date DESC LIMIT 0, 10' at line 1
ERROR - 2015-11-30 12:44:10 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'title LIKE '%%'  ORDER BY date DESC LIMIT 0, 10' at line 1
ERROR - 2015-11-30 12:44:11 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'title LIKE '%%'  ORDER BY date DESC LIMIT 0, 10' at line 1
ERROR - 2015-11-30 12:44:25 --> Query error: Unknown column 'article_type_id' in 'where clause'
ERROR - 2015-11-30 12:44:26 --> Query error: Unknown column 'article_type_id' in 'where clause'
ERROR - 2015-11-30 12:44:26 --> Query error: Unknown column 'article_type_id' in 'where clause'
ERROR - 2015-11-30 12:44:26 --> Query error: Unknown column 'article_type_id' in 'where clause'
ERROR - 2015-11-30 12:44:26 --> Query error: Unknown column 'article_type_id' in 'where clause'
ERROR - 2015-11-30 12:44:26 --> Query error: Unknown column 'article_type_id' in 'where clause'
ERROR - 2015-11-30 12:45:47 --> Query error: Unknown column 'article_type_id' in 'where clause'
ERROR - 2015-11-30 12:45:48 --> Query error: Unknown column 'article_type_id' in 'where clause'
ERROR - 2015-11-30 12:45:49 --> Query error: Unknown column 'article_type_id' in 'where clause'
ERROR - 2015-11-30 12:45:49 --> Query error: Unknown column 'article_type_id' in 'where clause'
ERROR - 2015-11-30 13:02:27 --> Severity: Warning  --> Missing argument 5 for Journal_m::get_all(), called in C:\xampp\htdocs\wassuphaters.com\r4dusa\application\controllers\journal.php on line 36 and defined C:\xampp\htdocs\wassuphaters.com\r4dusa\application\models\journal_m.php 11
ERROR - 2015-11-30 13:02:27 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\models\journal_m.php 21
ERROR - 2015-11-30 13:02:27 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'ORDER BY date DESC LIMIT 0, 10' at line 1
ERROR - 2015-11-30 13:05:56 --> Severity: Warning  --> imagepng(../files/images/lookbook/thumb/img58124144888515574.png): failed to open stream: No such file or directory C:\xampp\htdocs\wassuphaters.com\r4dusa\system\libraries\Image_lib.php 1222
ERROR - 2015-11-30 13:05:56 --> Unable to save the image.  Please make sure the image and file directory are writable.
ERROR - 2015-11-30 13:06:06 --> Severity: Warning  --> imagepng(../files/images/lookbook/thumb/img30426144888516568.png): failed to open stream: No such file or directory C:\xampp\htdocs\wassuphaters.com\r4dusa\system\libraries\Image_lib.php 1222
ERROR - 2015-11-30 13:06:06 --> Unable to save the image.  Please make sure the image and file directory are writable.
ERROR - 2015-11-30 13:06:57 --> Severity: Warning  --> imagepng(../files/images/lookbook/thumb/img46814144888521688.png): failed to open stream: No such file or directory C:\xampp\htdocs\wassuphaters.com\r4dusa\system\libraries\Image_lib.php 1222
ERROR - 2015-11-30 13:06:57 --> Unable to save the image.  Please make sure the image and file directory are writable.
ERROR - 2015-11-30 13:32:25 --> 404 Page Not Found --> newsletter
ERROR - 2015-11-30 13:33:26 --> 404 Page Not Found --> newsletter
ERROR - 2015-11-30 13:34:52 --> 404 Page Not Found --> contact
ERROR - 2015-11-30 14:50:03 --> Severity: Notice  --> Undefined property: stdClass::$image3 C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\edit_product.php 218
ERROR - 2015-11-30 14:50:03 --> Severity: Notice  --> Undefined property: stdClass::$image3 C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\edit_product.php 244
ERROR - 2015-11-30 14:52:00 --> Severity: Notice  --> Undefined property: stdClass::$image3 C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\edit_product.php 218
ERROR - 2015-11-30 14:52:00 --> Severity: Notice  --> Undefined property: stdClass::$image3 C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\edit_product.php 244
ERROR - 2015-11-30 14:52:04 --> Severity: Notice  --> Undefined property: stdClass::$image3 C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\edit_product.php 218
ERROR - 2015-11-30 14:52:04 --> Severity: Notice  --> Undefined property: stdClass::$image3 C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\edit_product.php 244
ERROR - 2015-11-30 14:52:05 --> Severity: Notice  --> Undefined property: stdClass::$image3 C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\edit_product.php 218
ERROR - 2015-11-30 14:52:05 --> Severity: Notice  --> Undefined property: stdClass::$image3 C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\edit_product.php 244
ERROR - 2015-11-30 14:54:26 --> Severity: Notice  --> Undefined property: stdClass::$image3 C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\edit_product.php 218
ERROR - 2015-11-30 14:54:26 --> Severity: Notice  --> Undefined property: stdClass::$image3 C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\edit_product.php 244
ERROR - 2015-11-30 14:54:28 --> Severity: Notice  --> Undefined property: stdClass::$image3 C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\edit_product.php 218
ERROR - 2015-11-30 14:54:28 --> Severity: Notice  --> Undefined property: stdClass::$image3 C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\edit_product.php 244
ERROR - 2015-11-30 14:54:35 --> Severity: Notice  --> Undefined property: stdClass::$image3 C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\edit_product.php 218
ERROR - 2015-11-30 14:54:35 --> Severity: Notice  --> Undefined property: stdClass::$image3 C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\edit_product.php 244
ERROR - 2015-11-30 14:55:10 --> Severity: Notice  --> Undefined property: stdClass::$image3 C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\edit_product.php 244
ERROR - 2015-11-30 14:55:33 --> Severity: Notice  --> Undefined property: stdClass::$image3 C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\edit_product.php 244
ERROR - 2015-11-30 14:55:35 --> Severity: Notice  --> Undefined property: stdClass::$image3 C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\edit_product.php 244
ERROR - 2015-11-30 14:59:58 --> Query error: Unknown column 'image5' in 'field list'
ERROR - 2015-11-30 15:00:00 --> Query error: Unknown column 'image5' in 'field list'
ERROR - 2015-11-30 15:00:00 --> Query error: Unknown column 'image5' in 'field list'
ERROR - 2015-11-30 15:00:00 --> Query error: Unknown column 'image5' in 'field list'
ERROR - 2015-11-30 15:00:00 --> Query error: Unknown column 'image5' in 'field list'
ERROR - 2015-11-30 15:00:00 --> Query error: Unknown column 'image5' in 'field list'
ERROR - 2015-11-30 15:00:00 --> Query error: Unknown column 'image5' in 'field list'
ERROR - 2015-11-30 15:00:00 --> Query error: Unknown column 'image5' in 'field list'
ERROR - 2015-11-30 15:00:25 --> 404 Page Not Found --> product/add_image5
ERROR - 2015-11-30 16:36:33 --> Severity: Notice  --> Use of undefined constant bandung - assumed 'bandung' C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\home.php 18
