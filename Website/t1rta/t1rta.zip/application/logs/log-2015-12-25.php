<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-12-25 06:50:23 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-25 06:50:23 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-25 06:50:23 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-25 06:50:23 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-25 06:50:23 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-25 06:50:23 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-25 06:50:23 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-25 06:50:23 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-25 06:50:23 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-25 06:50:23 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-25 06:50:23 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:50:23 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:50:23 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:50:23 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:50:23 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:50:23 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:50:24 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:50:24 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:50:24 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:50:24 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:50:24 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:50:24 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:50:24 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:50:24 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:50:24 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:50:24 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:50:24 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:50:24 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:50:24 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:50:24 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:50:24 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:50:24 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:50:24 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:50:24 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:50:24 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:50:24 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:50:24 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:50:24 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:50:24 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:50:24 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:50:24 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:50:24 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:50:24 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:50:24 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:50:24 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:50:24 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:50:24 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:50:24 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:50:24 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:50:24 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:50:24 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:50:24 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:50:49 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-25 06:50:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-25 06:50:49 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-25 06:50:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-25 06:50:49 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-25 06:50:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-25 06:50:49 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-25 06:50:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-25 06:50:49 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-25 06:50:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-25 06:50:49 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:50:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:50:49 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:50:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:50:49 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:50:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:50:49 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:50:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:50:49 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:50:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:50:49 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:50:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:50:50 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:50:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:50:50 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:50:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:50:50 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:50:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:50:50 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:50:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:50:50 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:50:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:50:50 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:50:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:50:50 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:50:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:50:50 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:50:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:50:50 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:50:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:50:50 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:50:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:50:50 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:50:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:50:50 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:50:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:50:50 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:50:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:50:50 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:50:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:50:50 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:50:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:51:25 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-25 06:51:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-25 06:51:25 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-25 06:51:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-25 06:51:25 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-25 06:51:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-25 06:51:25 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-25 06:51:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-25 06:51:25 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-25 06:51:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-25 06:51:25 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:51:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:51:25 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:51:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:51:25 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:51:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:51:25 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:51:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:51:25 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:51:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:51:25 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:51:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:51:25 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:51:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:51:25 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:51:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:51:25 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:51:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:51:25 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:51:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:51:25 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:51:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:51:25 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:51:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:51:25 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:51:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:51:25 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:51:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:51:25 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:51:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:51:25 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:51:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:51:25 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:51:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:51:25 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:51:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:51:25 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:51:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:51:25 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:51:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:51:25 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:51:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:51:37 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-25 06:51:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-25 06:51:37 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-25 06:51:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-25 06:51:37 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-25 06:51:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-25 06:51:37 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-25 06:51:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-25 06:51:37 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-25 06:51:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-25 06:51:37 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:51:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:51:37 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:51:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:51:37 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:51:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:51:37 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:51:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:51:37 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:51:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:51:38 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:51:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:51:38 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:51:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:51:38 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:51:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:51:38 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:51:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:51:38 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:51:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:51:38 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:51:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:51:38 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:51:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:51:38 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:51:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:51:38 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:51:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:51:38 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:51:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:51:38 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:51:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:51:38 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:51:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:51:38 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:51:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:51:38 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:51:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:51:38 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:51:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:51:38 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:51:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:51:50 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-25 06:51:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-25 06:51:50 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-25 06:51:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-25 06:51:50 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-25 06:51:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-25 06:51:50 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-25 06:51:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-25 06:51:50 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-25 06:51:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-25 06:51:50 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:51:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:51:50 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:51:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:51:50 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:51:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:51:50 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:51:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:51:50 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:51:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:51:50 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:51:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:51:50 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:51:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:51:51 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:51:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:51:51 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:51:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:51:51 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:51:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:51:51 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:51:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:51:51 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:51:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:51:51 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:51:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:51:51 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:51:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:51:51 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:51:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:51:51 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:51:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:51:51 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:51:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:51:51 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:51:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:51:51 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:51:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:51:51 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:51:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:51:51 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:51:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:12 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-25 06:52:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-25 06:52:12 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-25 06:52:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-25 06:52:12 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-25 06:52:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-25 06:52:12 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-25 06:52:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-25 06:52:12 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-25 06:52:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-25 06:52:12 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:12 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:12 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:12 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:12 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:12 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:12 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:12 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:12 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:12 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:12 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:12 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:12 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:12 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:12 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:12 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:13 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:13 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:13 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:13 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:13 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:27 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-25 06:52:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-25 06:52:27 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-25 06:52:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-25 06:52:27 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-25 06:52:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-25 06:52:27 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-25 06:52:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-25 06:52:27 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-25 06:52:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-25 06:52:27 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:27 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:27 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:27 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:27 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:27 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:27 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:27 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:27 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:27 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:27 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:27 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:27 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:27 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:27 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:27 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:27 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:27 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:27 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:27 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:27 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:38 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-25 06:52:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-25 06:52:38 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-25 06:52:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-25 06:52:38 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-25 06:52:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-25 06:52:38 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-25 06:52:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-25 06:52:38 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-25 06:52:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-25 06:52:38 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:38 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:38 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:38 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:38 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:38 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:38 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:38 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:38 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:38 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:38 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:38 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:38 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:38 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:38 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:38 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:38 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:38 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:38 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:38 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:38 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:51 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-25 06:52:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-25 06:52:51 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-25 06:52:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-25 06:52:52 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-25 06:52:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-25 06:52:52 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-25 06:52:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-25 06:52:52 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-25 06:52:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-25 06:52:52 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:52 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:52 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:52 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:52 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:52 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:52 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:52 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:52 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:52 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:52 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:52 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:52 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:52 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:52 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:52 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:52 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:52 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:52 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:52 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:52 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:52:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:53:08 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-25 06:53:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-25 06:53:08 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-25 06:53:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-25 06:53:08 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-25 06:53:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-25 06:53:08 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-25 06:53:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-25 06:53:08 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-25 06:53:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-25 06:53:08 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:53:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:53:08 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:53:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:53:08 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:53:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:53:08 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:53:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:53:08 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:53:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:53:08 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:53:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:53:08 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:53:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:53:08 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:53:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:53:09 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:53:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:53:09 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:53:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:53:09 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:53:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:53:09 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:53:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:53:09 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:53:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:53:09 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:53:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:53:09 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:53:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:53:09 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:53:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:53:09 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:53:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:53:09 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:53:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:53:09 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:53:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:53:09 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:53:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:53:09 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:53:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:53:30 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-25 06:53:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-25 06:53:30 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-25 06:53:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-25 06:53:30 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-25 06:53:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-25 06:53:30 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-25 06:53:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-25 06:53:30 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-25 06:53:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-25 06:53:30 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:53:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:53:30 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:53:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:53:30 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:53:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:53:30 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:53:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:53:30 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:53:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:53:30 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:53:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:53:30 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:53:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:53:30 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:53:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:53:30 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:53:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:53:30 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:53:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:53:30 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:53:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:53:30 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:53:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:53:30 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:53:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:53:30 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:53:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:53:30 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:53:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:53:30 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:53:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:53:30 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:53:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:53:30 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:53:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:53:30 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:53:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:53:30 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:53:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:53:30 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:53:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:53:46 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-25 06:53:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-25 06:53:46 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-25 06:53:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-25 06:53:46 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-25 06:53:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-25 06:53:46 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-25 06:53:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-25 06:53:46 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-25 06:53:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-25 06:53:46 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:53:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:53:46 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:53:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:53:46 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:53:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:53:46 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:53:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:53:46 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:53:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:53:46 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:53:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:53:46 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:53:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:53:46 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:53:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:53:46 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:53:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:53:46 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:53:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:53:46 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:53:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:53:46 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:53:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:53:46 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:53:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:53:46 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:53:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:53:46 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:53:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:53:46 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:53:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:53:46 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:53:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:53:46 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:53:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:53:46 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:53:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:53:46 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:53:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:53:46 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:53:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:54:01 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-25 06:54:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-25 06:54:01 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-25 06:54:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-25 06:54:01 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-25 06:54:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-25 06:54:01 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-25 06:54:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-25 06:54:01 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-25 06:54:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-25 06:54:01 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:54:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:54:01 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:54:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:54:01 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:54:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:54:01 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:54:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:54:01 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:54:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:54:01 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:54:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:54:01 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:54:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:54:01 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:54:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:54:01 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:54:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:54:01 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:54:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:54:01 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:54:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:54:01 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:54:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:54:01 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:54:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:54:01 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:54:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:54:01 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:54:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:54:01 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:54:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:54:01 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:54:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:54:01 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:54:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:54:01 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:54:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:54:01 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:54:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:54:01 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-25 06:54:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
