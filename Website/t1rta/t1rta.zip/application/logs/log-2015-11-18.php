<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-11-18 10:14:24 --> 404 Page Not Found --> collection
ERROR - 2015-11-18 10:14:27 --> 404 Page Not Found --> jenistas
ERROR - 2015-11-18 10:23:40 --> 404 Page Not Found --> collection
ERROR - 2015-11-18 10:23:43 --> 404 Page Not Found --> bagtype
ERROR - 2015-11-18 10:30:18 --> 404 Page Not Found --> collection
ERROR - 2015-11-18 10:31:43 --> 404 Page Not Found --> collection
ERROR - 2015-11-18 10:32:45 --> 404 Page Not Found --> collection
ERROR - 2015-11-18 10:33:34 --> 404 Page Not Found --> product_collection
ERROR - 2015-11-18 10:34:11 --> 404 Page Not Found --> product_collection/index
ERROR - 2015-11-18 10:34:13 --> 404 Page Not Found --> product_collection/index
ERROR - 2015-11-18 10:44:24 --> 404 Page Not Found --> product_type
ERROR - 2015-11-18 10:56:57 --> Severity: Warning  --> Missing argument 5 for Product_category_m::get_all(), called in C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php on line 36 and defined C:\xampp\htdocs\wassuphaters.com\w4zzup\application\models\product_category_m.php 11
ERROR - 2015-11-18 10:56:57 --> Severity: Notice  --> Undefined variable: tabel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\models\product_category_m.php 24
ERROR - 2015-11-18 10:56:57 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE category LIKE '%%'  ORDER BY category_id ASC LIMIT 0, 10' at line 1
ERROR - 2015-11-18 10:57:32 --> Severity: Warning  --> Missing argument 5 for Product_category_m::get_all(), called in C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php on line 37 and defined C:\xampp\htdocs\wassuphaters.com\w4zzup\application\models\product_category_m.php 11
ERROR - 2015-11-18 10:57:32 --> Severity: Notice  --> Undefined variable: tabel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\models\product_category_m.php 24
ERROR - 2015-11-18 10:57:32 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE category LIKE '%%'  ORDER BY category_id ASC LIMIT 0, 10' at line 1
ERROR - 2015-11-18 10:58:43 --> Severity: Warning  --> Missing argument 1 for Product_collection::index() C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 9
ERROR - 2015-11-18 10:58:43 --> Severity: Notice  --> Undefined variable: tabel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 37
ERROR - 2015-11-18 10:58:43 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE category LIKE '%%'  ORDER BY category_id ASC LIMIT 0, 10' at line 1
ERROR - 2015-11-18 10:59:01 --> Severity: Warning  --> Missing argument 1 for Product_collection::index() C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 9
ERROR - 2015-11-18 10:59:01 --> Severity: Notice  --> Undefined variable: tabel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 37
ERROR - 2015-11-18 10:59:01 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE category LIKE '%%'  ORDER BY category_id ASC LIMIT 0, 10' at line 1
ERROR - 2015-11-18 10:59:02 --> Severity: Warning  --> Missing argument 1 for Product_collection::index() C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 9
ERROR - 2015-11-18 10:59:02 --> Severity: Notice  --> Undefined variable: tabel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 37
ERROR - 2015-11-18 10:59:02 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE category LIKE '%%'  ORDER BY category_id ASC LIMIT 0, 10' at line 1
ERROR - 2015-11-18 10:59:03 --> Severity: Warning  --> Missing argument 1 for Product_collection::index() C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 9
ERROR - 2015-11-18 10:59:03 --> Severity: Notice  --> Undefined variable: tabel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 37
ERROR - 2015-11-18 10:59:03 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE category LIKE '%%'  ORDER BY category_id ASC LIMIT 0, 10' at line 1
ERROR - 2015-11-18 10:59:03 --> Severity: Warning  --> Missing argument 1 for Product_collection::index() C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 9
ERROR - 2015-11-18 10:59:03 --> Severity: Notice  --> Undefined variable: tabel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 37
ERROR - 2015-11-18 10:59:03 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE category LIKE '%%'  ORDER BY category_id ASC LIMIT 0, 10' at line 1
ERROR - 2015-11-18 10:59:03 --> Severity: Warning  --> Missing argument 1 for Product_collection::index() C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 9
ERROR - 2015-11-18 10:59:03 --> Severity: Notice  --> Undefined variable: tabel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 37
ERROR - 2015-11-18 10:59:03 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE category LIKE '%%'  ORDER BY category_id ASC LIMIT 0, 10' at line 1
ERROR - 2015-11-18 10:59:11 --> Severity: Warning  --> Missing argument 1 for Product_collection::index() C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 9
ERROR - 2015-11-18 10:59:11 --> Severity: Notice  --> Undefined variable: tabel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 37
ERROR - 2015-11-18 10:59:11 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE category LIKE '%%'  ORDER BY category_id ASC LIMIT 0, 10' at line 1
ERROR - 2015-11-18 10:59:11 --> Severity: Warning  --> Missing argument 1 for Product_collection::index() C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 9
ERROR - 2015-11-18 10:59:11 --> Severity: Notice  --> Undefined variable: tabel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 37
ERROR - 2015-11-18 10:59:11 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE category LIKE '%%'  ORDER BY category_id ASC LIMIT 0, 10' at line 1
ERROR - 2015-11-18 10:59:12 --> Severity: Warning  --> Missing argument 1 for Product_collection::index() C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 9
ERROR - 2015-11-18 10:59:12 --> Severity: Notice  --> Undefined variable: tabel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 37
ERROR - 2015-11-18 10:59:12 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE category LIKE '%%'  ORDER BY category_id ASC LIMIT 0, 10' at line 1
ERROR - 2015-11-18 10:59:12 --> Severity: Warning  --> Missing argument 1 for Product_collection::index() C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 9
ERROR - 2015-11-18 10:59:12 --> Severity: Notice  --> Undefined variable: tabel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 37
ERROR - 2015-11-18 10:59:12 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE category LIKE '%%'  ORDER BY category_id ASC LIMIT 0, 10' at line 1
ERROR - 2015-11-18 10:59:12 --> Severity: Warning  --> Missing argument 1 for Product_collection::index() C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 9
ERROR - 2015-11-18 10:59:12 --> Severity: Notice  --> Undefined variable: tabel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 37
ERROR - 2015-11-18 10:59:12 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE category LIKE '%%'  ORDER BY category_id ASC LIMIT 0, 10' at line 1
ERROR - 2015-11-18 10:59:12 --> Severity: Warning  --> Missing argument 1 for Product_collection::index() C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 9
ERROR - 2015-11-18 10:59:12 --> Severity: Notice  --> Undefined variable: tabel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 37
ERROR - 2015-11-18 10:59:12 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE category LIKE '%%'  ORDER BY category_id ASC LIMIT 0, 10' at line 1
ERROR - 2015-11-18 10:59:12 --> Severity: Warning  --> Missing argument 1 for Product_collection::index() C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 9
ERROR - 2015-11-18 10:59:12 --> Severity: Notice  --> Undefined variable: tabel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 37
ERROR - 2015-11-18 10:59:12 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE category LIKE '%%'  ORDER BY category_id ASC LIMIT 0, 10' at line 1
ERROR - 2015-11-18 10:59:13 --> Severity: Warning  --> Missing argument 1 for Product_collection::index() C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 9
ERROR - 2015-11-18 10:59:13 --> Severity: Notice  --> Undefined variable: tabel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 37
ERROR - 2015-11-18 10:59:13 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE category LIKE '%%'  ORDER BY category_id ASC LIMIT 0, 10' at line 1
ERROR - 2015-11-18 10:59:13 --> Severity: Warning  --> Missing argument 1 for Product_collection::index() C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 9
ERROR - 2015-11-18 10:59:13 --> Severity: Notice  --> Undefined variable: tabel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 37
ERROR - 2015-11-18 10:59:13 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE category LIKE '%%'  ORDER BY category_id ASC LIMIT 0, 10' at line 1
ERROR - 2015-11-18 11:00:18 --> Severity: Warning  --> Missing argument 1 for Product_collection::index() C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 9
ERROR - 2015-11-18 11:00:18 --> Severity: Notice  --> Undefined variable: tabel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 40
ERROR - 2015-11-18 11:00:18 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE category LIKE '%%'  ORDER BY category_id ASC LIMIT 0, 10' at line 1
ERROR - 2015-11-18 11:00:19 --> Severity: Warning  --> Missing argument 1 for Product_collection::index() C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 9
ERROR - 2015-11-18 11:00:19 --> Severity: Notice  --> Undefined variable: tabel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 40
ERROR - 2015-11-18 11:00:19 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE category LIKE '%%'  ORDER BY category_id ASC LIMIT 0, 10' at line 1
ERROR - 2015-11-18 11:00:19 --> Severity: Warning  --> Missing argument 1 for Product_collection::index() C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 9
ERROR - 2015-11-18 11:00:19 --> Severity: Notice  --> Undefined variable: tabel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 40
ERROR - 2015-11-18 11:00:19 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE category LIKE '%%'  ORDER BY category_id ASC LIMIT 0, 10' at line 1
ERROR - 2015-11-18 11:00:20 --> Severity: Warning  --> Missing argument 1 for Product_collection::index() C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 9
ERROR - 2015-11-18 11:00:20 --> Severity: Notice  --> Undefined variable: tabel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 40
ERROR - 2015-11-18 11:00:20 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE category LIKE '%%'  ORDER BY category_id ASC LIMIT 0, 10' at line 1
ERROR - 2015-11-18 11:00:20 --> Severity: Warning  --> Missing argument 1 for Product_collection::index() C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 9
ERROR - 2015-11-18 11:00:20 --> Severity: Notice  --> Undefined variable: tabel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 40
ERROR - 2015-11-18 11:00:20 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE category LIKE '%%'  ORDER BY category_id ASC LIMIT 0, 10' at line 1
ERROR - 2015-11-18 11:00:20 --> Severity: Warning  --> Missing argument 1 for Product_collection::index() C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 9
ERROR - 2015-11-18 11:00:20 --> Severity: Notice  --> Undefined variable: tabel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 40
ERROR - 2015-11-18 11:00:20 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE category LIKE '%%'  ORDER BY category_id ASC LIMIT 0, 10' at line 1
ERROR - 2015-11-18 11:00:20 --> Severity: Warning  --> Missing argument 1 for Product_collection::index() C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 9
ERROR - 2015-11-18 11:00:20 --> Severity: Notice  --> Undefined variable: tabel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 40
ERROR - 2015-11-18 11:00:20 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE category LIKE '%%'  ORDER BY category_id ASC LIMIT 0, 10' at line 1
ERROR - 2015-11-18 11:00:20 --> Severity: Warning  --> Missing argument 1 for Product_collection::index() C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 9
ERROR - 2015-11-18 11:00:20 --> Severity: Notice  --> Undefined variable: tabel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 40
ERROR - 2015-11-18 11:00:20 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE category LIKE '%%'  ORDER BY category_id ASC LIMIT 0, 10' at line 1
ERROR - 2015-11-18 11:00:21 --> Severity: Warning  --> Missing argument 1 for Product_collection::index() C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 9
ERROR - 2015-11-18 11:00:21 --> Severity: Notice  --> Undefined variable: tabel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 40
ERROR - 2015-11-18 11:00:21 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE category LIKE '%%'  ORDER BY category_id ASC LIMIT 0, 10' at line 1
ERROR - 2015-11-18 11:00:21 --> Severity: Warning  --> Missing argument 1 for Product_collection::index() C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 9
ERROR - 2015-11-18 11:00:21 --> Severity: Notice  --> Undefined variable: tabel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 40
ERROR - 2015-11-18 11:00:21 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE category LIKE '%%'  ORDER BY category_id ASC LIMIT 0, 10' at line 1
ERROR - 2015-11-18 11:00:21 --> Severity: Warning  --> Missing argument 1 for Product_collection::index() C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 9
ERROR - 2015-11-18 11:00:21 --> Severity: Notice  --> Undefined variable: tabel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 40
ERROR - 2015-11-18 11:00:21 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE category LIKE '%%'  ORDER BY category_id ASC LIMIT 0, 10' at line 1
ERROR - 2015-11-18 11:00:37 --> Severity: Warning  --> Missing argument 1 for Product_collection::index() C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 9
ERROR - 2015-11-18 11:00:37 --> Severity: Notice  --> Undefined variable: tabel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 40
ERROR - 2015-11-18 11:00:37 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE category LIKE '%%'  ORDER BY category_id ASC LIMIT 0, 10' at line 1
ERROR - 2015-11-18 11:00:38 --> Severity: Warning  --> Missing argument 1 for Product_collection::index() C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 9
ERROR - 2015-11-18 11:00:38 --> Severity: Notice  --> Undefined variable: tabel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 40
ERROR - 2015-11-18 11:00:38 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE category LIKE '%%'  ORDER BY category_id ASC LIMIT 0, 10' at line 1
ERROR - 2015-11-18 11:00:38 --> Severity: Warning  --> Missing argument 1 for Product_collection::index() C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 9
ERROR - 2015-11-18 11:00:38 --> Severity: Notice  --> Undefined variable: tabel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 40
ERROR - 2015-11-18 11:00:38 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE category LIKE '%%'  ORDER BY category_id ASC LIMIT 0, 10' at line 1
ERROR - 2015-11-18 11:00:39 --> Severity: Warning  --> Missing argument 1 for Product_collection::index() C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 9
ERROR - 2015-11-18 11:00:39 --> Severity: Notice  --> Undefined variable: tabel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 40
ERROR - 2015-11-18 11:00:39 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE category LIKE '%%'  ORDER BY category_id ASC LIMIT 0, 10' at line 1
ERROR - 2015-11-18 11:00:39 --> Severity: Warning  --> Missing argument 1 for Product_collection::index() C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 9
ERROR - 2015-11-18 11:00:39 --> Severity: Notice  --> Undefined variable: tabel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 40
ERROR - 2015-11-18 11:00:39 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE category LIKE '%%'  ORDER BY category_id ASC LIMIT 0, 10' at line 1
ERROR - 2015-11-18 11:00:39 --> Severity: Warning  --> Missing argument 1 for Product_collection::index() C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 9
ERROR - 2015-11-18 11:00:39 --> Severity: Notice  --> Undefined variable: tabel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 40
ERROR - 2015-11-18 11:00:39 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE category LIKE '%%'  ORDER BY category_id ASC LIMIT 0, 10' at line 1
ERROR - 2015-11-18 11:00:56 --> Severity: Notice  --> Undefined variable: tabel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 40
ERROR - 2015-11-18 11:00:56 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE category LIKE '%%'  ORDER BY category_id ASC LIMIT 0, 10' at line 1
ERROR - 2015-11-18 11:01:08 --> Severity: Warning  --> Missing argument 1 for Product_collection::index() C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 9
ERROR - 2015-11-18 11:01:08 --> Severity: Notice  --> Undefined variable: tabel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 40
ERROR - 2015-11-18 11:01:08 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE category LIKE '%%'  ORDER BY category_id ASC LIMIT 0, 10' at line 1
ERROR - 2015-11-18 11:01:09 --> Severity: Warning  --> Missing argument 1 for Product_collection::index() C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 9
ERROR - 2015-11-18 11:01:09 --> Severity: Notice  --> Undefined variable: tabel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 40
ERROR - 2015-11-18 11:01:09 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE category LIKE '%%'  ORDER BY category_id ASC LIMIT 0, 10' at line 1
ERROR - 2015-11-18 11:01:38 --> Severity: Warning  --> Missing argument 1 for Product_collection::index() C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 9
ERROR - 2015-11-18 11:01:38 --> Severity: Notice  --> Undefined variable: tabel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 40
ERROR - 2015-11-18 11:01:38 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE category LIKE '%%'  ORDER BY category_id ASC LIMIT 0, 10' at line 1
ERROR - 2015-11-18 11:01:39 --> Severity: Warning  --> Missing argument 1 for Product_collection::index() C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 9
ERROR - 2015-11-18 11:01:39 --> Severity: Notice  --> Undefined variable: tabel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 40
ERROR - 2015-11-18 11:01:39 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE category LIKE '%%'  ORDER BY category_id ASC LIMIT 0, 10' at line 1
ERROR - 2015-11-18 11:01:39 --> Severity: Warning  --> Missing argument 1 for Product_collection::index() C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 9
ERROR - 2015-11-18 11:01:39 --> Severity: Notice  --> Undefined variable: tabel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 40
ERROR - 2015-11-18 11:01:39 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE category LIKE '%%'  ORDER BY category_id ASC LIMIT 0, 10' at line 1
ERROR - 2015-11-18 11:01:39 --> Severity: Warning  --> Missing argument 1 for Product_collection::index() C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 9
ERROR - 2015-11-18 11:01:39 --> Severity: Notice  --> Undefined variable: tabel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 40
ERROR - 2015-11-18 11:01:39 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE category LIKE '%%'  ORDER BY category_id ASC LIMIT 0, 10' at line 1
ERROR - 2015-11-18 11:01:39 --> Severity: Warning  --> Missing argument 1 for Product_collection::index() C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 9
ERROR - 2015-11-18 11:01:39 --> Severity: Notice  --> Undefined variable: tabel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 40
ERROR - 2015-11-18 11:01:39 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE category LIKE '%%'  ORDER BY category_id ASC LIMIT 0, 10' at line 1
ERROR - 2015-11-18 11:02:32 --> Severity: Warning  --> Missing argument 1 for Product_collection::index() C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 9
ERROR - 2015-11-18 11:02:32 --> Severity: Notice  --> Undefined variable: tabel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 40
ERROR - 2015-11-18 11:02:32 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE category LIKE '%%'  ORDER BY category_id ASC LIMIT 0, 10' at line 1
ERROR - 2015-11-18 11:02:33 --> Severity: Warning  --> Missing argument 1 for Product_collection::index() C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 9
ERROR - 2015-11-18 11:02:33 --> Severity: Notice  --> Undefined variable: tabel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 40
ERROR - 2015-11-18 11:02:33 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE category LIKE '%%'  ORDER BY category_id ASC LIMIT 0, 10' at line 1
ERROR - 2015-11-18 11:02:33 --> Severity: Warning  --> Missing argument 1 for Product_collection::index() C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 9
ERROR - 2015-11-18 11:02:33 --> Severity: Notice  --> Undefined variable: tabel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 40
ERROR - 2015-11-18 11:02:33 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE category LIKE '%%'  ORDER BY category_id ASC LIMIT 0, 10' at line 1
ERROR - 2015-11-18 11:02:34 --> Severity: Warning  --> Missing argument 1 for Product_collection::index() C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 9
ERROR - 2015-11-18 11:02:34 --> Severity: Notice  --> Undefined variable: tabel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 40
ERROR - 2015-11-18 11:02:34 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE category LIKE '%%'  ORDER BY category_id ASC LIMIT 0, 10' at line 1
ERROR - 2015-11-18 11:02:34 --> Severity: Warning  --> Missing argument 1 for Product_collection::index() C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 9
ERROR - 2015-11-18 11:02:34 --> Severity: Notice  --> Undefined variable: tabel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 40
ERROR - 2015-11-18 11:02:34 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE category LIKE '%%'  ORDER BY category_id ASC LIMIT 0, 10' at line 1
ERROR - 2015-11-18 11:02:34 --> Severity: Warning  --> Missing argument 1 for Product_collection::index() C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 9
ERROR - 2015-11-18 11:02:34 --> Severity: Notice  --> Undefined variable: tabel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 40
ERROR - 2015-11-18 11:02:34 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE category LIKE '%%'  ORDER BY category_id ASC LIMIT 0, 10' at line 1
ERROR - 2015-11-18 11:02:35 --> Severity: Warning  --> Missing argument 1 for Product_collection::index() C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 9
ERROR - 2015-11-18 11:02:35 --> Severity: Notice  --> Undefined variable: tabel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 40
ERROR - 2015-11-18 11:02:35 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE category LIKE '%%'  ORDER BY category_id ASC LIMIT 0, 10' at line 1
ERROR - 2015-11-18 11:02:35 --> Severity: Warning  --> Missing argument 1 for Product_collection::index() C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 9
ERROR - 2015-11-18 11:02:35 --> Severity: Notice  --> Undefined variable: tabel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 40
ERROR - 2015-11-18 11:02:35 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE category LIKE '%%'  ORDER BY category_id ASC LIMIT 0, 10' at line 1
ERROR - 2015-11-18 11:02:50 --> Severity: Warning  --> Missing argument 1 for Product_collection::index() C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 9
ERROR - 2015-11-18 11:02:50 --> Severity: Notice  --> Undefined variable: tabel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 40
ERROR - 2015-11-18 11:02:50 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE category LIKE '%%'  ORDER BY category_id ASC LIMIT 0, 10' at line 1
ERROR - 2015-11-18 11:03:08 --> Severity: Warning  --> Missing argument 1 for Product_collection::index() C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 9
ERROR - 2015-11-18 11:03:08 --> Severity: Notice  --> Undefined variable: tabel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 40
ERROR - 2015-11-18 11:03:08 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE category LIKE '%%'  ORDER BY category_id ASC LIMIT 0, 10' at line 1
ERROR - 2015-11-18 11:03:09 --> Severity: Warning  --> Missing argument 1 for Product_collection::index() C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 9
ERROR - 2015-11-18 11:03:09 --> Severity: Notice  --> Undefined variable: tabel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 40
ERROR - 2015-11-18 11:03:09 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE category LIKE '%%'  ORDER BY category_id ASC LIMIT 0, 10' at line 1
ERROR - 2015-11-18 11:03:09 --> Severity: Warning  --> Missing argument 1 for Product_collection::index() C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 9
ERROR - 2015-11-18 11:03:09 --> Severity: Notice  --> Undefined variable: tabel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 40
ERROR - 2015-11-18 11:03:09 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE category LIKE '%%'  ORDER BY category_id ASC LIMIT 0, 10' at line 1
ERROR - 2015-11-18 11:03:10 --> Severity: Warning  --> Missing argument 1 for Product_collection::index() C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 9
ERROR - 2015-11-18 11:03:10 --> Severity: Notice  --> Undefined variable: tabel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 40
ERROR - 2015-11-18 11:03:10 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE category LIKE '%%'  ORDER BY category_id ASC LIMIT 0, 10' at line 1
ERROR - 2015-11-18 11:03:10 --> Severity: Warning  --> Missing argument 1 for Product_collection::index() C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 9
ERROR - 2015-11-18 11:03:10 --> Severity: Notice  --> Undefined variable: tabel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 40
ERROR - 2015-11-18 11:03:10 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE category LIKE '%%'  ORDER BY category_id ASC LIMIT 0, 10' at line 1
ERROR - 2015-11-18 11:03:30 --> Severity: Warning  --> Missing argument 1 for Product_collection::index() C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 9
ERROR - 2015-11-18 11:03:34 --> Severity: Warning  --> Missing argument 1 for Product_collection::index() C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 9
ERROR - 2015-11-18 11:03:39 --> Severity: Warning  --> Missing argument 1 for Product_collection::index() C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 9
ERROR - 2015-11-18 11:05:39 --> Severity: Warning  --> Missing argument 5 for Product_category_m::get_all(), called in C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_category.php on line 36 and defined C:\xampp\htdocs\wassuphaters.com\w4zzup\application\models\product_category_m.php 11
ERROR - 2015-11-18 11:05:39 --> Severity: Notice  --> Undefined variable: tabel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\models\product_category_m.php 24
ERROR - 2015-11-18 11:05:39 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE category LIKE '%%'  ORDER BY category_id ASC LIMIT 0, 10' at line 1
ERROR - 2015-11-18 11:07:10 --> Severity: Warning  --> Missing argument 5 for Product_category_m::get_all(), called in C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_category.php on line 36 and defined C:\xampp\htdocs\wassuphaters.com\w4zzup\application\models\product_category_m.php 11
ERROR - 2015-11-18 11:07:10 --> Severity: Notice  --> Undefined variable: tabel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\models\product_category_m.php 24
ERROR - 2015-11-18 11:07:10 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE category LIKE '%%'  ORDER BY category_id ASC LIMIT 0, 10' at line 1
ERROR - 2015-11-18 11:10:24 --> Severity: Notice  --> Undefined variable: tabel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 40
ERROR - 2015-11-18 11:10:24 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE category LIKE '%%'  ORDER BY category_id ASC LIMIT 0, 10' at line 1
ERROR - 2015-11-18 11:12:33 --> Severity: Notice  --> Undefined variable: tabel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 40
ERROR - 2015-11-18 11:12:33 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE category LIKE '%%'  ORDER BY category_id ASC LIMIT 0, 10' at line 1
ERROR - 2015-11-18 11:40:55 --> Severity: Warning  --> Missing argument 1 for Product_category_m::max_row(), called in C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php on line 41 and defined C:\xampp\htdocs\wassuphaters.com\w4zzup\application\models\product_category_m.php 32
ERROR - 2015-11-18 11:40:55 --> Query error: Table 'ozantcom_wassuphaters.$tabel' doesn't exist
ERROR - 2015-11-18 11:40:56 --> Severity: Warning  --> Missing argument 1 for Product_category_m::max_row(), called in C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php on line 41 and defined C:\xampp\htdocs\wassuphaters.com\w4zzup\application\models\product_category_m.php 32
ERROR - 2015-11-18 11:40:56 --> Query error: Table 'ozantcom_wassuphaters.$tabel' doesn't exist
ERROR - 2015-11-18 11:41:31 --> Severity: Notice  --> Undefined variable: tabel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 41
ERROR - 2015-11-18 11:41:31 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE category LIKE '%%'  ORDER BY category_id ASC LIMIT 0, 10' at line 1
ERROR - 2015-11-18 11:41:50 --> Severity: Warning  --> Missing argument 1 for Product_category_m::max_row(), called in C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php on line 41 and defined C:\xampp\htdocs\wassuphaters.com\w4zzup\application\models\product_category_m.php 32
ERROR - 2015-11-18 11:41:50 --> Query error: Table 'ozantcom_wassuphaters.$tabel' doesn't exist
ERROR - 2015-11-18 11:43:41 --> Query error: Table 'ozantcom_wassuphaters.$tabel' doesn't exist
ERROR - 2015-11-18 11:43:42 --> Query error: Table 'ozantcom_wassuphaters.$tabel' doesn't exist
ERROR - 2015-11-18 11:44:28 --> Query error: Table 'ozantcom_wassuphaters.$tabel' doesn't exist
ERROR - 2015-11-18 11:44:29 --> Query error: Table 'ozantcom_wassuphaters.$tabel' doesn't exist
ERROR - 2015-11-18 11:44:29 --> Query error: Table 'ozantcom_wassuphaters.$tabel' doesn't exist
ERROR - 2015-11-18 11:46:33 --> Query error: No tables used
ERROR - 2015-11-18 11:47:16 --> Severity: Warning  --> Missing argument 1 for Product_category_m::max_row(), called in C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php on line 41 and defined C:\xampp\htdocs\wassuphaters.com\w4zzup\application\models\product_category_m.php 32
ERROR - 2015-11-18 11:47:16 --> Severity: Notice  --> Undefined variable: tabel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\models\product_category_m.php 33
ERROR - 2015-11-18 11:47:16 --> Query error: No tables used
ERROR - 2015-11-18 11:47:18 --> Severity: Warning  --> Missing argument 1 for Product_category_m::max_row(), called in C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php on line 41 and defined C:\xampp\htdocs\wassuphaters.com\w4zzup\application\models\product_category_m.php 32
ERROR - 2015-11-18 11:47:18 --> Severity: Notice  --> Undefined variable: tabel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\models\product_category_m.php 33
ERROR - 2015-11-18 11:47:18 --> Query error: No tables used
ERROR - 2015-11-18 12:11:50 --> Severity: Notice  --> Undefined variable: tabel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 38
ERROR - 2015-11-18 12:11:50 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE category LIKE '%%'  ORDER BY category_id ASC LIMIT 0, 10' at line 1
ERROR - 2015-11-18 12:13:19 --> Severity: Notice  --> Undefined variable: tabel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 38
ERROR - 2015-11-18 12:13:19 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE category LIKE '%%'  ORDER BY category_id ASC LIMIT 0, 10' at line 1
ERROR - 2015-11-18 12:13:20 --> Severity: Notice  --> Undefined variable: tabel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 38
ERROR - 2015-11-18 12:13:20 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE category LIKE '%%'  ORDER BY category_id ASC LIMIT 0, 10' at line 1
ERROR - 2015-11-18 12:13:21 --> Severity: Notice  --> Undefined variable: tabel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 38
ERROR - 2015-11-18 12:13:21 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE category LIKE '%%'  ORDER BY category_id ASC LIMIT 0, 10' at line 1
ERROR - 2015-11-18 12:13:21 --> Severity: Notice  --> Undefined variable: tabel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 38
ERROR - 2015-11-18 12:13:21 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE category LIKE '%%'  ORDER BY category_id ASC LIMIT 0, 10' at line 1
ERROR - 2015-11-18 12:13:21 --> Severity: Notice  --> Undefined variable: tabel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 38
ERROR - 2015-11-18 12:13:21 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE category LIKE '%%'  ORDER BY category_id ASC LIMIT 0, 10' at line 1
ERROR - 2015-11-18 12:13:32 --> Severity: Notice  --> Undefined variable: tabel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 38
ERROR - 2015-11-18 12:13:32 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE category LIKE '%%'  ORDER BY category_id ASC LIMIT 0, 10' at line 1
ERROR - 2015-11-18 12:13:56 --> Severity: Notice  --> Undefined variable: tabel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 38
ERROR - 2015-11-18 12:13:56 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE category LIKE '%%'  ORDER BY category_id ASC LIMIT 0, 10' at line 1
ERROR - 2015-11-18 12:14:24 --> Severity: Notice  --> Undefined variable: tabel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 38
ERROR - 2015-11-18 12:14:24 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE category LIKE '%%'  ORDER BY category_id ASC LIMIT 0, 10' at line 1
ERROR - 2015-11-18 12:15:10 --> Severity: Notice  --> Undefined variable: tabel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 38
ERROR - 2015-11-18 12:15:10 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE category LIKE '%%'  ORDER BY category_id ASC LIMIT 0, 10' at line 1
ERROR - 2015-11-18 12:15:11 --> Severity: Notice  --> Undefined variable: tabel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 38
ERROR - 2015-11-18 12:15:11 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE category LIKE '%%'  ORDER BY category_id ASC LIMIT 0, 10' at line 1
ERROR - 2015-11-18 12:15:12 --> Severity: Notice  --> Undefined variable: tabel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 38
ERROR - 2015-11-18 12:15:12 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE category LIKE '%%'  ORDER BY category_id ASC LIMIT 0, 10' at line 1
ERROR - 2015-11-18 12:15:12 --> Severity: Notice  --> Undefined variable: tabel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 38
ERROR - 2015-11-18 12:15:12 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE category LIKE '%%'  ORDER BY category_id ASC LIMIT 0, 10' at line 1
ERROR - 2015-11-18 12:15:12 --> Severity: Notice  --> Undefined variable: tabel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 38
ERROR - 2015-11-18 12:15:12 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE category LIKE '%%'  ORDER BY category_id ASC LIMIT 0, 10' at line 1
ERROR - 2015-11-18 12:15:13 --> Severity: Notice  --> Undefined variable: tabel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 38
ERROR - 2015-11-18 12:15:13 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE category LIKE '%%'  ORDER BY category_id ASC LIMIT 0, 10' at line 1
ERROR - 2015-11-18 12:15:13 --> Severity: Notice  --> Undefined variable: tabel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 38
ERROR - 2015-11-18 12:15:13 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE category LIKE '%%'  ORDER BY category_id ASC LIMIT 0, 10' at line 1
ERROR - 2015-11-18 12:15:54 --> Severity: Notice  --> Undefined variable: tabel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 38
ERROR - 2015-11-18 12:15:54 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE category LIKE '%%'  ORDER BY category_id ASC LIMIT 0, 10' at line 1
ERROR - 2015-11-18 12:15:55 --> Severity: Notice  --> Undefined variable: tabel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 38
ERROR - 2015-11-18 12:15:55 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE category LIKE '%%'  ORDER BY category_id ASC LIMIT 0, 10' at line 1
ERROR - 2015-11-18 12:15:55 --> Severity: Notice  --> Undefined variable: tabel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 38
ERROR - 2015-11-18 12:15:55 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE category LIKE '%%'  ORDER BY category_id ASC LIMIT 0, 10' at line 1
ERROR - 2015-11-18 12:15:55 --> Severity: Notice  --> Undefined variable: tabel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 38
ERROR - 2015-11-18 12:15:56 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE category LIKE '%%'  ORDER BY category_id ASC LIMIT 0, 10' at line 1
ERROR - 2015-11-18 12:15:56 --> Severity: Notice  --> Undefined variable: tabel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 38
ERROR - 2015-11-18 12:15:56 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE category LIKE '%%'  ORDER BY category_id ASC LIMIT 0, 10' at line 1
ERROR - 2015-11-18 12:16:37 --> Severity: Notice  --> Undefined variable: tabel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 38
ERROR - 2015-11-18 12:16:37 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE category LIKE '%%'  ORDER BY category_id ASC LIMIT 0, 10' at line 1
ERROR - 2015-11-18 12:16:38 --> Severity: Notice  --> Undefined variable: tabel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 38
ERROR - 2015-11-18 12:16:38 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE category LIKE '%%'  ORDER BY category_id ASC LIMIT 0, 10' at line 1
ERROR - 2015-11-18 12:17:43 --> Severity: Notice  --> Undefined variable: tabel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 38
ERROR - 2015-11-18 12:17:44 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE category LIKE '%%'  ORDER BY category_id ASC LIMIT 0, 10' at line 1
ERROR - 2015-11-18 12:18:16 --> Severity: Notice  --> Undefined variable: tabel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 38
ERROR - 2015-11-18 12:18:16 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE category LIKE '%%'  ORDER BY category_id ASC LIMIT 0, 10' at line 1
ERROR - 2015-11-18 12:18:17 --> Severity: Notice  --> Undefined variable: tabel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 38
ERROR - 2015-11-18 12:18:17 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE category LIKE '%%'  ORDER BY category_id ASC LIMIT 0, 10' at line 1
ERROR - 2015-11-18 12:18:17 --> Severity: Notice  --> Undefined variable: tabel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 38
ERROR - 2015-11-18 12:18:17 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE category LIKE '%%'  ORDER BY category_id ASC LIMIT 0, 10' at line 1
ERROR - 2015-11-18 12:18:17 --> Severity: Notice  --> Undefined variable: tabel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 38
ERROR - 2015-11-18 12:18:17 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE category LIKE '%%'  ORDER BY category_id ASC LIMIT 0, 10' at line 1
ERROR - 2015-11-18 12:18:18 --> Severity: Notice  --> Undefined variable: tabel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 38
ERROR - 2015-11-18 12:18:18 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE category LIKE '%%'  ORDER BY category_id ASC LIMIT 0, 10' at line 1
ERROR - 2015-11-18 12:18:18 --> Severity: Notice  --> Undefined variable: tabel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 38
ERROR - 2015-11-18 12:18:18 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE category LIKE '%%'  ORDER BY category_id ASC LIMIT 0, 10' at line 1
ERROR - 2015-11-18 12:18:28 --> Severity: Notice  --> Undefined variable: tabel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 38
ERROR - 2015-11-18 12:18:28 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE category LIKE '%%'  ORDER BY category_id ASC LIMIT 0, 10' at line 1
ERROR - 2015-11-18 12:18:28 --> Severity: Notice  --> Undefined variable: tabel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 38
ERROR - 2015-11-18 12:18:28 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE category LIKE '%%'  ORDER BY category_id ASC LIMIT 0, 10' at line 1
ERROR - 2015-11-18 12:18:29 --> Severity: Notice  --> Undefined variable: tabel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 38
ERROR - 2015-11-18 12:18:29 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE category LIKE '%%'  ORDER BY category_id ASC LIMIT 0, 10' at line 1
ERROR - 2015-11-18 12:18:29 --> Severity: Notice  --> Undefined variable: tabel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 38
ERROR - 2015-11-18 12:18:29 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE category LIKE '%%'  ORDER BY category_id ASC LIMIT 0, 10' at line 1
ERROR - 2015-11-18 12:18:29 --> Severity: Notice  --> Undefined variable: tabel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 38
ERROR - 2015-11-18 12:18:29 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE category LIKE '%%'  ORDER BY category_id ASC LIMIT 0, 10' at line 1
ERROR - 2015-11-18 12:18:29 --> Severity: Notice  --> Undefined variable: tabel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 38
ERROR - 2015-11-18 12:18:29 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE category LIKE '%%'  ORDER BY category_id ASC LIMIT 0, 10' at line 1
ERROR - 2015-11-18 12:18:30 --> Severity: Notice  --> Undefined variable: tabel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 38
ERROR - 2015-11-18 12:18:30 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE category LIKE '%%'  ORDER BY category_id ASC LIMIT 0, 10' at line 1
ERROR - 2015-11-18 12:18:30 --> Severity: Notice  --> Undefined variable: tabel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 38
ERROR - 2015-11-18 12:18:30 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE category LIKE '%%'  ORDER BY category_id ASC LIMIT 0, 10' at line 1
ERROR - 2015-11-18 12:18:30 --> Severity: Notice  --> Undefined variable: tabel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 38
ERROR - 2015-11-18 12:18:30 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE category LIKE '%%'  ORDER BY category_id ASC LIMIT 0, 10' at line 1
ERROR - 2015-11-18 12:18:30 --> Severity: Notice  --> Undefined variable: tabel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 38
ERROR - 2015-11-18 12:18:30 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE category LIKE '%%'  ORDER BY category_id ASC LIMIT 0, 10' at line 1
ERROR - 2015-11-18 12:18:52 --> Severity: Notice  --> Undefined variable: tabel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 38
ERROR - 2015-11-18 12:18:52 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE category LIKE '%%'  ORDER BY category_id ASC LIMIT 0, 10' at line 1
ERROR - 2015-11-18 12:18:52 --> Severity: Notice  --> Undefined variable: tabel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 38
ERROR - 2015-11-18 12:18:52 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE category LIKE '%%'  ORDER BY category_id ASC LIMIT 0, 10' at line 1
ERROR - 2015-11-18 12:18:53 --> Severity: Notice  --> Undefined variable: tabel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 38
ERROR - 2015-11-18 12:18:53 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE category LIKE '%%'  ORDER BY category_id ASC LIMIT 0, 10' at line 1
ERROR - 2015-11-18 12:18:53 --> Severity: Notice  --> Undefined variable: tabel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 38
ERROR - 2015-11-18 12:18:53 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE category LIKE '%%'  ORDER BY category_id ASC LIMIT 0, 10' at line 1
ERROR - 2015-11-18 12:18:53 --> Severity: Notice  --> Undefined variable: tabel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 38
ERROR - 2015-11-18 12:18:53 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE category LIKE '%%'  ORDER BY category_id ASC LIMIT 0, 10' at line 1
ERROR - 2015-11-18 12:19:15 --> Severity: Notice  --> Undefined variable: tabel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 38
ERROR - 2015-11-18 12:19:15 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE category LIKE '%%'  ORDER BY category_id ASC LIMIT 0, 10' at line 1
ERROR - 2015-11-18 12:19:15 --> Severity: Notice  --> Undefined variable: tabel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 38
ERROR - 2015-11-18 12:19:15 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE category LIKE '%%'  ORDER BY category_id ASC LIMIT 0, 10' at line 1
ERROR - 2015-11-18 12:19:15 --> Severity: Notice  --> Undefined variable: tabel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 38
ERROR - 2015-11-18 12:19:15 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE category LIKE '%%'  ORDER BY category_id ASC LIMIT 0, 10' at line 1
ERROR - 2015-11-18 12:19:15 --> Severity: Notice  --> Undefined variable: tabel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 38
ERROR - 2015-11-18 12:19:15 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE category LIKE '%%'  ORDER BY category_id ASC LIMIT 0, 10' at line 1
ERROR - 2015-11-18 12:19:16 --> Severity: Notice  --> Undefined variable: tabel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 38
ERROR - 2015-11-18 12:19:16 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE category LIKE '%%'  ORDER BY category_id ASC LIMIT 0, 10' at line 1
ERROR - 2015-11-18 12:19:16 --> Severity: Notice  --> Undefined variable: tabel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 38
ERROR - 2015-11-18 12:19:16 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE category LIKE '%%'  ORDER BY category_id ASC LIMIT 0, 10' at line 1
ERROR - 2015-11-18 12:19:17 --> Severity: Notice  --> Undefined variable: tabel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 38
ERROR - 2015-11-18 12:19:17 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE category LIKE '%%'  ORDER BY category_id ASC LIMIT 0, 10' at line 1
ERROR - 2015-11-18 12:22:33 --> Severity: Notice  --> Undefined variable: view C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 68
ERROR - 2015-11-18 12:22:48 --> Severity: Notice  --> Undefined variable: view C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 68
ERROR - 2015-11-18 12:23:03 --> Severity: Notice  --> Undefined variable: view C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 68
ERROR - 2015-11-18 12:23:25 --> Severity: Notice  --> Undefined variable: view C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 68
ERROR - 2015-11-18 12:23:43 --> Severity: Notice  --> Undefined variable: view C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php 68
ERROR - 2015-11-18 12:29:29 --> Query error: Unknown column 'category' in 'where clause'
ERROR - 2015-11-18 12:29:35 --> Query error: Unknown column 'category' in 'where clause'
ERROR - 2015-11-18 12:29:36 --> Query error: Unknown column 'category' in 'where clause'
ERROR - 2015-11-18 12:29:36 --> Query error: Unknown column 'category' in 'where clause'
ERROR - 2015-11-18 12:29:36 --> Query error: Unknown column 'category' in 'where clause'
ERROR - 2015-11-18 12:29:36 --> Query error: Unknown column 'category' in 'where clause'
ERROR - 2015-11-18 12:29:36 --> Query error: Unknown column 'category' in 'where clause'
ERROR - 2015-11-18 12:29:37 --> Query error: Unknown column 'category' in 'where clause'
ERROR - 2015-11-18 12:29:37 --> Query error: Unknown column 'category' in 'where clause'
ERROR - 2015-11-18 12:32:59 --> Severity: Warning  --> Missing argument 6 for Product_category_m::get_all(), called in C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php on line 43 and defined C:\xampp\htdocs\wassuphaters.com\w4zzup\application\models\product_category_m.php 12
ERROR - 2015-11-18 12:32:59 --> Severity: Warning  --> Missing argument 7 for Product_category_m::get_all(), called in C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php on line 43 and defined C:\xampp\htdocs\wassuphaters.com\w4zzup\application\models\product_category_m.php 12
ERROR - 2015-11-18 12:32:59 --> Query error: Unknown column 'category' in 'where clause'
ERROR - 2015-11-18 12:33:01 --> Severity: Warning  --> Missing argument 6 for Product_category_m::get_all(), called in C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php on line 43 and defined C:\xampp\htdocs\wassuphaters.com\w4zzup\application\models\product_category_m.php 12
ERROR - 2015-11-18 12:33:01 --> Severity: Warning  --> Missing argument 7 for Product_category_m::get_all(), called in C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php on line 43 and defined C:\xampp\htdocs\wassuphaters.com\w4zzup\application\models\product_category_m.php 12
ERROR - 2015-11-18 12:33:01 --> Query error: Unknown column 'category' in 'where clause'
ERROR - 2015-11-18 12:33:18 --> Severity: Warning  --> Missing argument 6 for Product_category_m::get_all(), called in C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php on line 43 and defined C:\xampp\htdocs\wassuphaters.com\w4zzup\application\models\product_category_m.php 12
ERROR - 2015-11-18 12:33:18 --> Severity: Warning  --> Missing argument 7 for Product_category_m::get_all(), called in C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php on line 43 and defined C:\xampp\htdocs\wassuphaters.com\w4zzup\application\models\product_category_m.php 12
ERROR - 2015-11-18 12:33:18 --> Severity: Notice  --> Undefined variable: kategori C:\xampp\htdocs\wassuphaters.com\w4zzup\application\models\product_category_m.php 18
ERROR - 2015-11-18 12:33:18 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'ASC LIMIT 0, 10' at line 1
ERROR - 2015-11-18 12:33:19 --> Severity: Warning  --> Missing argument 6 for Product_category_m::get_all(), called in C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php on line 43 and defined C:\xampp\htdocs\wassuphaters.com\w4zzup\application\models\product_category_m.php 12
ERROR - 2015-11-18 12:33:19 --> Severity: Warning  --> Missing argument 7 for Product_category_m::get_all(), called in C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php on line 43 and defined C:\xampp\htdocs\wassuphaters.com\w4zzup\application\models\product_category_m.php 12
ERROR - 2015-11-18 12:33:19 --> Severity: Notice  --> Undefined variable: kategori C:\xampp\htdocs\wassuphaters.com\w4zzup\application\models\product_category_m.php 18
ERROR - 2015-11-18 12:33:19 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'ASC LIMIT 0, 10' at line 1
ERROR - 2015-11-18 12:33:19 --> Severity: Warning  --> Missing argument 6 for Product_category_m::get_all(), called in C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php on line 43 and defined C:\xampp\htdocs\wassuphaters.com\w4zzup\application\models\product_category_m.php 12
ERROR - 2015-11-18 12:33:19 --> Severity: Warning  --> Missing argument 7 for Product_category_m::get_all(), called in C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php on line 43 and defined C:\xampp\htdocs\wassuphaters.com\w4zzup\application\models\product_category_m.php 12
ERROR - 2015-11-18 12:33:19 --> Severity: Notice  --> Undefined variable: kategori C:\xampp\htdocs\wassuphaters.com\w4zzup\application\models\product_category_m.php 18
ERROR - 2015-11-18 12:33:19 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'ASC LIMIT 0, 10' at line 1
ERROR - 2015-11-18 12:33:19 --> Severity: Warning  --> Missing argument 6 for Product_category_m::get_all(), called in C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php on line 43 and defined C:\xampp\htdocs\wassuphaters.com\w4zzup\application\models\product_category_m.php 12
ERROR - 2015-11-18 12:33:19 --> Severity: Warning  --> Missing argument 7 for Product_category_m::get_all(), called in C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php on line 43 and defined C:\xampp\htdocs\wassuphaters.com\w4zzup\application\models\product_category_m.php 12
ERROR - 2015-11-18 12:33:19 --> Severity: Notice  --> Undefined variable: kategori C:\xampp\htdocs\wassuphaters.com\w4zzup\application\models\product_category_m.php 18
ERROR - 2015-11-18 12:33:19 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'ASC LIMIT 0, 10' at line 1
ERROR - 2015-11-18 12:33:20 --> Severity: Warning  --> Missing argument 6 for Product_category_m::get_all(), called in C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php on line 43 and defined C:\xampp\htdocs\wassuphaters.com\w4zzup\application\models\product_category_m.php 12
ERROR - 2015-11-18 12:33:20 --> Severity: Warning  --> Missing argument 7 for Product_category_m::get_all(), called in C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php on line 43 and defined C:\xampp\htdocs\wassuphaters.com\w4zzup\application\models\product_category_m.php 12
ERROR - 2015-11-18 12:33:20 --> Severity: Notice  --> Undefined variable: kategori C:\xampp\htdocs\wassuphaters.com\w4zzup\application\models\product_category_m.php 18
ERROR - 2015-11-18 12:33:20 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'ASC LIMIT 0, 10' at line 1
ERROR - 2015-11-18 12:33:20 --> Severity: Warning  --> Missing argument 6 for Product_category_m::get_all(), called in C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php on line 43 and defined C:\xampp\htdocs\wassuphaters.com\w4zzup\application\models\product_category_m.php 12
ERROR - 2015-11-18 12:33:20 --> Severity: Warning  --> Missing argument 7 for Product_category_m::get_all(), called in C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php on line 43 and defined C:\xampp\htdocs\wassuphaters.com\w4zzup\application\models\product_category_m.php 12
ERROR - 2015-11-18 12:33:20 --> Severity: Notice  --> Undefined variable: kategori C:\xampp\htdocs\wassuphaters.com\w4zzup\application\models\product_category_m.php 18
ERROR - 2015-11-18 12:33:20 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'ASC LIMIT 0, 10' at line 1
ERROR - 2015-11-18 12:33:20 --> Severity: Warning  --> Missing argument 6 for Product_category_m::get_all(), called in C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php on line 43 and defined C:\xampp\htdocs\wassuphaters.com\w4zzup\application\models\product_category_m.php 12
ERROR - 2015-11-18 12:33:20 --> Severity: Warning  --> Missing argument 7 for Product_category_m::get_all(), called in C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php on line 43 and defined C:\xampp\htdocs\wassuphaters.com\w4zzup\application\models\product_category_m.php 12
ERROR - 2015-11-18 12:33:20 --> Severity: Notice  --> Undefined variable: kategori C:\xampp\htdocs\wassuphaters.com\w4zzup\application\models\product_category_m.php 18
ERROR - 2015-11-18 12:33:20 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'ASC LIMIT 0, 10' at line 1
ERROR - 2015-11-18 12:33:21 --> Severity: Warning  --> Missing argument 6 for Product_category_m::get_all(), called in C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php on line 43 and defined C:\xampp\htdocs\wassuphaters.com\w4zzup\application\models\product_category_m.php 12
ERROR - 2015-11-18 12:33:21 --> Severity: Warning  --> Missing argument 7 for Product_category_m::get_all(), called in C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php on line 43 and defined C:\xampp\htdocs\wassuphaters.com\w4zzup\application\models\product_category_m.php 12
ERROR - 2015-11-18 12:33:21 --> Severity: Notice  --> Undefined variable: kategori C:\xampp\htdocs\wassuphaters.com\w4zzup\application\models\product_category_m.php 18
ERROR - 2015-11-18 12:33:21 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'ASC LIMIT 0, 10' at line 1
ERROR - 2015-11-18 12:33:21 --> Severity: Warning  --> Missing argument 6 for Product_category_m::get_all(), called in C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php on line 43 and defined C:\xampp\htdocs\wassuphaters.com\w4zzup\application\models\product_category_m.php 12
ERROR - 2015-11-18 12:33:21 --> Severity: Warning  --> Missing argument 7 for Product_category_m::get_all(), called in C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php on line 43 and defined C:\xampp\htdocs\wassuphaters.com\w4zzup\application\models\product_category_m.php 12
ERROR - 2015-11-18 12:33:21 --> Severity: Notice  --> Undefined variable: kategori C:\xampp\htdocs\wassuphaters.com\w4zzup\application\models\product_category_m.php 18
ERROR - 2015-11-18 12:33:21 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'ASC LIMIT 0, 10' at line 1
ERROR - 2015-11-18 12:33:21 --> Severity: Warning  --> Missing argument 6 for Product_category_m::get_all(), called in C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php on line 43 and defined C:\xampp\htdocs\wassuphaters.com\w4zzup\application\models\product_category_m.php 12
ERROR - 2015-11-18 12:33:21 --> Severity: Warning  --> Missing argument 7 for Product_category_m::get_all(), called in C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php on line 43 and defined C:\xampp\htdocs\wassuphaters.com\w4zzup\application\models\product_category_m.php 12
ERROR - 2015-11-18 12:33:21 --> Severity: Notice  --> Undefined variable: kategori C:\xampp\htdocs\wassuphaters.com\w4zzup\application\models\product_category_m.php 18
ERROR - 2015-11-18 12:33:21 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'ASC LIMIT 0, 10' at line 1
ERROR - 2015-11-18 12:33:28 --> Severity: Warning  --> Missing argument 6 for Product_category_m::get_all(), called in C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php on line 43 and defined C:\xampp\htdocs\wassuphaters.com\w4zzup\application\models\product_category_m.php 12
ERROR - 2015-11-18 12:33:28 --> Severity: Warning  --> Missing argument 7 for Product_category_m::get_all(), called in C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php on line 43 and defined C:\xampp\htdocs\wassuphaters.com\w4zzup\application\models\product_category_m.php 12
ERROR - 2015-11-18 12:33:28 --> Severity: Notice  --> Undefined variable: kategori C:\xampp\htdocs\wassuphaters.com\w4zzup\application\models\product_category_m.php 18
ERROR - 2015-11-18 12:33:28 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'ASC LIMIT 0, 10' at line 1
ERROR - 2015-11-18 12:33:30 --> Severity: Warning  --> Missing argument 6 for Product_category_m::get_all(), called in C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php on line 43 and defined C:\xampp\htdocs\wassuphaters.com\w4zzup\application\models\product_category_m.php 12
ERROR - 2015-11-18 12:33:30 --> Severity: Warning  --> Missing argument 7 for Product_category_m::get_all(), called in C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php on line 43 and defined C:\xampp\htdocs\wassuphaters.com\w4zzup\application\models\product_category_m.php 12
ERROR - 2015-11-18 12:33:30 --> Severity: Notice  --> Undefined variable: kategori C:\xampp\htdocs\wassuphaters.com\w4zzup\application\models\product_category_m.php 18
ERROR - 2015-11-18 12:33:30 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'ASC LIMIT 0, 10' at line 1
ERROR - 2015-11-18 12:34:55 --> Severity: Warning  --> Missing argument 6 for Product_category_m::get_all(), called in C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php on line 43 and defined C:\xampp\htdocs\wassuphaters.com\w4zzup\application\models\product_category_m.php 12
ERROR - 2015-11-18 12:34:55 --> Severity: Warning  --> Missing argument 7 for Product_category_m::get_all(), called in C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php on line 43 and defined C:\xampp\htdocs\wassuphaters.com\w4zzup\application\models\product_category_m.php 12
ERROR - 2015-11-18 12:34:55 --> Query error: Unknown column 'category' in 'where clause'
ERROR - 2015-11-18 12:34:55 --> Severity: Warning  --> Missing argument 6 for Product_category_m::get_all(), called in C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php on line 43 and defined C:\xampp\htdocs\wassuphaters.com\w4zzup\application\models\product_category_m.php 12
ERROR - 2015-11-18 12:34:55 --> Severity: Warning  --> Missing argument 7 for Product_category_m::get_all(), called in C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php on line 43 and defined C:\xampp\htdocs\wassuphaters.com\w4zzup\application\models\product_category_m.php 12
ERROR - 2015-11-18 12:34:55 --> Query error: Unknown column 'category' in 'where clause'
ERROR - 2015-11-18 12:34:55 --> Severity: Warning  --> Missing argument 6 for Product_category_m::get_all(), called in C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php on line 43 and defined C:\xampp\htdocs\wassuphaters.com\w4zzup\application\models\product_category_m.php 12
ERROR - 2015-11-18 12:34:55 --> Severity: Warning  --> Missing argument 7 for Product_category_m::get_all(), called in C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php on line 43 and defined C:\xampp\htdocs\wassuphaters.com\w4zzup\application\models\product_category_m.php 12
ERROR - 2015-11-18 12:34:55 --> Query error: Unknown column 'category' in 'where clause'
ERROR - 2015-11-18 12:34:56 --> Severity: Warning  --> Missing argument 6 for Product_category_m::get_all(), called in C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php on line 43 and defined C:\xampp\htdocs\wassuphaters.com\w4zzup\application\models\product_category_m.php 12
ERROR - 2015-11-18 12:34:56 --> Severity: Warning  --> Missing argument 7 for Product_category_m::get_all(), called in C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collection.php on line 43 and defined C:\xampp\htdocs\wassuphaters.com\w4zzup\application\models\product_category_m.php 12
ERROR - 2015-11-18 12:34:56 --> Query error: Unknown column 'category' in 'where clause'
ERROR - 2015-11-18 13:45:16 --> Query error: Unknown column 'category' in 'where clause'
ERROR - 2015-11-18 13:45:35 --> Severity: Notice  --> Undefined property: stdClass::$category_id C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_bag\collection.php 83
ERROR - 2015-11-18 13:45:35 --> Severity: Notice  --> Undefined property: stdClass::$category_id C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_bag\collection.php 85
ERROR - 2015-11-18 13:45:35 --> Severity: Notice  --> Undefined property: stdClass::$category C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_bag\collection.php 85
ERROR - 2015-11-18 13:45:35 --> Severity: Notice  --> Undefined property: stdClass::$category_id C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_bag\collection.php 83
ERROR - 2015-11-18 13:45:35 --> Severity: Notice  --> Undefined property: stdClass::$category_id C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_bag\collection.php 85
ERROR - 2015-11-18 13:45:35 --> Severity: Notice  --> Undefined property: stdClass::$category C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_bag\collection.php 85
ERROR - 2015-11-18 13:46:34 --> Severity: Notice  --> Undefined property: stdClass::$category C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_bag\collection.php 85
ERROR - 2015-11-18 13:46:34 --> Severity: Notice  --> Undefined property: stdClass::$category C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_bag\collection.php 85
ERROR - 2015-11-18 13:55:38 --> 404 Page Not Found --> product_bag
ERROR - 2015-11-18 14:01:33 --> 404 Page Not Found --> product_bag
ERROR - 2015-11-18 14:09:27 --> Severity: Notice  --> Undefined property: stdClass::$category_id C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_bag\edit_collection.php 37
ERROR - 2015-11-18 14:09:27 --> Severity: Notice  --> Undefined property: stdClass::$category C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_bag\edit_collection.php 43
ERROR - 2015-11-18 14:14:59 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_bag\add_collection.php 37
ERROR - 2015-11-18 14:14:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_bag\add_collection.php 37
ERROR - 2015-11-18 14:14:59 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_bag\add_collection.php 43
ERROR - 2015-11-18 14:14:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_bag\add_collection.php 43
ERROR - 2015-11-18 14:26:51 --> 404 Page Not Found --> product_type
ERROR - 2015-11-18 14:27:05 --> 404 Page Not Found --> product_type
ERROR - 2015-11-18 14:34:39 --> Severity: Notice  --> Undefined property: stdClass::$bag_collection_id C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_bag\edit_type.php 37
ERROR - 2015-11-18 14:34:39 --> Severity: Notice  --> Undefined property: stdClass::$bag_collection C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_bag\edit_type.php 43
ERROR - 2015-11-18 14:47:33 --> 404 Page Not Found --> apparel
ERROR - 2015-11-18 14:48:16 --> 404 Page Not Found --> apparel
ERROR - 2015-11-18 14:53:14 --> 404 Page Not Found --> apparel
ERROR - 2015-11-18 14:53:43 --> Severity: Notice  --> Undefined property: Product_apparel::$product_collection_m C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_apparel.php 36
ERROR - 2015-11-18 14:54:05 --> Severity: Notice  --> Undefined property: Product_apparel::$product_collection_m C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_apparel.php 36
ERROR - 2015-11-18 14:54:31 --> Severity: Notice  --> Undefined property: Product_apparel::$product_collection_m C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_apparel.php 36
ERROR - 2015-11-18 14:54:32 --> Severity: Notice  --> Undefined property: Product_apparel::$product_collection_m C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_apparel.php 36
ERROR - 2015-11-18 14:54:32 --> Severity: Notice  --> Undefined property: Product_apparel::$product_collection_m C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_apparel.php 36
ERROR - 2015-11-18 14:54:33 --> Severity: Notice  --> Undefined property: Product_apparel::$product_collection_m C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_apparel.php 36
ERROR - 2015-11-18 14:54:33 --> Severity: Notice  --> Undefined property: Product_apparel::$product_collection_m C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_apparel.php 36
ERROR - 2015-11-18 14:54:33 --> Severity: Notice  --> Undefined property: Product_apparel::$product_collection_m C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_apparel.php 36
ERROR - 2015-11-18 14:54:33 --> Severity: Notice  --> Undefined property: Product_apparel::$product_collection_m C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_apparel.php 36
ERROR - 2015-11-18 14:54:33 --> Severity: Notice  --> Undefined property: Product_apparel::$product_collection_m C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_apparel.php 36
ERROR - 2015-11-18 14:54:33 --> Severity: Notice  --> Undefined property: Product_apparel::$product_collection_m C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_apparel.php 36
ERROR - 2015-11-18 14:56:16 --> Severity: Notice  --> Undefined property: stdClass::$bag_apparel_id C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\apparel.php 83
ERROR - 2015-11-18 14:56:16 --> Severity: Notice  --> Undefined property: stdClass::$bag_apparel_id C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\apparel.php 85
ERROR - 2015-11-18 14:56:16 --> Severity: Notice  --> Undefined property: stdClass::$bag_apparel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\apparel.php 85
ERROR - 2015-11-18 14:56:16 --> Severity: Notice  --> Undefined property: stdClass::$bag_apparel_id C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\apparel.php 83
ERROR - 2015-11-18 14:56:16 --> Severity: Notice  --> Undefined property: stdClass::$bag_apparel_id C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\apparel.php 85
ERROR - 2015-11-18 14:56:16 --> Severity: Notice  --> Undefined property: stdClass::$bag_apparel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\apparel.php 85
ERROR - 2015-11-18 14:56:16 --> Severity: Notice  --> Undefined property: stdClass::$bag_apparel_id C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\apparel.php 83
ERROR - 2015-11-18 14:56:16 --> Severity: Notice  --> Undefined property: stdClass::$bag_apparel_id C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\apparel.php 85
ERROR - 2015-11-18 14:56:16 --> Severity: Notice  --> Undefined property: stdClass::$bag_apparel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\apparel.php 85
ERROR - 2015-11-18 14:56:16 --> Severity: Notice  --> Undefined property: stdClass::$bag_apparel_id C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\apparel.php 83
ERROR - 2015-11-18 14:56:16 --> Severity: Notice  --> Undefined property: stdClass::$bag_apparel_id C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\apparel.php 85
ERROR - 2015-11-18 14:56:16 --> Severity: Notice  --> Undefined property: stdClass::$bag_apparel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\apparel.php 85
ERROR - 2015-11-18 14:56:16 --> Severity: Notice  --> Undefined property: stdClass::$bag_apparel_id C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\apparel.php 83
ERROR - 2015-11-18 14:56:16 --> Severity: Notice  --> Undefined property: stdClass::$bag_apparel_id C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\apparel.php 85
ERROR - 2015-11-18 14:56:16 --> Severity: Notice  --> Undefined property: stdClass::$bag_apparel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\apparel.php 85
ERROR - 2015-11-18 14:56:16 --> Severity: Notice  --> Undefined property: stdClass::$bag_apparel_id C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\apparel.php 83
ERROR - 2015-11-18 14:56:16 --> Severity: Notice  --> Undefined property: stdClass::$bag_apparel_id C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\apparel.php 85
ERROR - 2015-11-18 14:56:16 --> Severity: Notice  --> Undefined property: stdClass::$bag_apparel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\apparel.php 85
ERROR - 2015-11-18 14:56:16 --> Severity: Notice  --> Undefined property: stdClass::$bag_apparel_id C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\apparel.php 83
ERROR - 2015-11-18 14:56:16 --> Severity: Notice  --> Undefined property: stdClass::$bag_apparel_id C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\apparel.php 85
ERROR - 2015-11-18 14:56:16 --> Severity: Notice  --> Undefined property: stdClass::$bag_apparel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\apparel.php 85
ERROR - 2015-11-18 14:57:02 --> Severity: Notice  --> Undefined property: stdClass::$apparel_id C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\apparel.php 83
ERROR - 2015-11-18 14:57:02 --> Severity: Notice  --> Undefined property: stdClass::$apparel_id C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\apparel.php 85
ERROR - 2015-11-18 14:57:02 --> Severity: Notice  --> Undefined property: stdClass::$apparel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\apparel.php 85
ERROR - 2015-11-18 14:57:02 --> Severity: Notice  --> Undefined property: stdClass::$apparel_id C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\apparel.php 83
ERROR - 2015-11-18 14:57:02 --> Severity: Notice  --> Undefined property: stdClass::$apparel_id C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\apparel.php 85
ERROR - 2015-11-18 14:57:02 --> Severity: Notice  --> Undefined property: stdClass::$apparel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\apparel.php 85
ERROR - 2015-11-18 14:57:02 --> Severity: Notice  --> Undefined property: stdClass::$apparel_id C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\apparel.php 83
ERROR - 2015-11-18 14:57:02 --> Severity: Notice  --> Undefined property: stdClass::$apparel_id C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\apparel.php 85
ERROR - 2015-11-18 14:57:02 --> Severity: Notice  --> Undefined property: stdClass::$apparel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\apparel.php 85
ERROR - 2015-11-18 14:57:02 --> Severity: Notice  --> Undefined property: stdClass::$apparel_id C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\apparel.php 83
ERROR - 2015-11-18 14:57:02 --> Severity: Notice  --> Undefined property: stdClass::$apparel_id C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\apparel.php 85
ERROR - 2015-11-18 14:57:02 --> Severity: Notice  --> Undefined property: stdClass::$apparel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\apparel.php 85
ERROR - 2015-11-18 14:57:02 --> Severity: Notice  --> Undefined property: stdClass::$apparel_id C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\apparel.php 83
ERROR - 2015-11-18 14:57:02 --> Severity: Notice  --> Undefined property: stdClass::$apparel_id C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\apparel.php 85
ERROR - 2015-11-18 14:57:02 --> Severity: Notice  --> Undefined property: stdClass::$apparel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\apparel.php 85
ERROR - 2015-11-18 14:57:02 --> Severity: Notice  --> Undefined property: stdClass::$apparel_id C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\apparel.php 83
ERROR - 2015-11-18 14:57:02 --> Severity: Notice  --> Undefined property: stdClass::$apparel_id C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\apparel.php 85
ERROR - 2015-11-18 14:57:02 --> Severity: Notice  --> Undefined property: stdClass::$apparel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\apparel.php 85
ERROR - 2015-11-18 14:57:02 --> Severity: Notice  --> Undefined property: stdClass::$apparel_id C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\apparel.php 83
ERROR - 2015-11-18 14:57:02 --> Severity: Notice  --> Undefined property: stdClass::$apparel_id C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\apparel.php 85
ERROR - 2015-11-18 14:57:02 --> Severity: Notice  --> Undefined property: stdClass::$apparel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\apparel.php 85
ERROR - 2015-11-18 14:57:04 --> Severity: Notice  --> Undefined property: stdClass::$apparel_id C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\apparel.php 83
ERROR - 2015-11-18 14:57:04 --> Severity: Notice  --> Undefined property: stdClass::$apparel_id C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\apparel.php 85
ERROR - 2015-11-18 14:57:04 --> Severity: Notice  --> Undefined property: stdClass::$apparel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\apparel.php 85
ERROR - 2015-11-18 14:57:04 --> Severity: Notice  --> Undefined property: stdClass::$apparel_id C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\apparel.php 83
ERROR - 2015-11-18 14:57:04 --> Severity: Notice  --> Undefined property: stdClass::$apparel_id C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\apparel.php 85
ERROR - 2015-11-18 14:57:04 --> Severity: Notice  --> Undefined property: stdClass::$apparel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\apparel.php 85
ERROR - 2015-11-18 14:57:04 --> Severity: Notice  --> Undefined property: stdClass::$apparel_id C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\apparel.php 83
ERROR - 2015-11-18 14:57:04 --> Severity: Notice  --> Undefined property: stdClass::$apparel_id C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\apparel.php 85
ERROR - 2015-11-18 14:57:04 --> Severity: Notice  --> Undefined property: stdClass::$apparel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\apparel.php 85
ERROR - 2015-11-18 14:57:04 --> Severity: Notice  --> Undefined property: stdClass::$apparel_id C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\apparel.php 83
ERROR - 2015-11-18 14:57:04 --> Severity: Notice  --> Undefined property: stdClass::$apparel_id C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\apparel.php 85
ERROR - 2015-11-18 14:57:04 --> Severity: Notice  --> Undefined property: stdClass::$apparel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\apparel.php 85
ERROR - 2015-11-18 14:57:04 --> Severity: Notice  --> Undefined property: stdClass::$apparel_id C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\apparel.php 83
ERROR - 2015-11-18 14:57:04 --> Severity: Notice  --> Undefined property: stdClass::$apparel_id C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\apparel.php 85
ERROR - 2015-11-18 14:57:04 --> Severity: Notice  --> Undefined property: stdClass::$apparel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\apparel.php 85
ERROR - 2015-11-18 14:57:04 --> Severity: Notice  --> Undefined property: stdClass::$apparel_id C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\apparel.php 83
ERROR - 2015-11-18 14:57:04 --> Severity: Notice  --> Undefined property: stdClass::$apparel_id C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\apparel.php 85
ERROR - 2015-11-18 14:57:04 --> Severity: Notice  --> Undefined property: stdClass::$apparel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\apparel.php 85
ERROR - 2015-11-18 14:57:04 --> Severity: Notice  --> Undefined property: stdClass::$apparel_id C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\apparel.php 83
ERROR - 2015-11-18 14:57:04 --> Severity: Notice  --> Undefined property: stdClass::$apparel_id C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\apparel.php 85
ERROR - 2015-11-18 14:57:04 --> Severity: Notice  --> Undefined property: stdClass::$apparel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\apparel.php 85
ERROR - 2015-11-18 14:57:04 --> Severity: Notice  --> Undefined property: stdClass::$apparel_id C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\apparel.php 83
ERROR - 2015-11-18 14:57:04 --> Severity: Notice  --> Undefined property: stdClass::$apparel_id C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\apparel.php 85
ERROR - 2015-11-18 14:57:04 --> Severity: Notice  --> Undefined property: stdClass::$apparel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\apparel.php 85
ERROR - 2015-11-18 14:57:04 --> Severity: Notice  --> Undefined property: stdClass::$apparel_id C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\apparel.php 83
ERROR - 2015-11-18 14:57:04 --> Severity: Notice  --> Undefined property: stdClass::$apparel_id C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\apparel.php 85
ERROR - 2015-11-18 14:57:04 --> Severity: Notice  --> Undefined property: stdClass::$apparel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\apparel.php 85
ERROR - 2015-11-18 14:57:04 --> Severity: Notice  --> Undefined property: stdClass::$apparel_id C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\apparel.php 83
ERROR - 2015-11-18 14:57:04 --> Severity: Notice  --> Undefined property: stdClass::$apparel_id C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\apparel.php 85
ERROR - 2015-11-18 14:57:04 --> Severity: Notice  --> Undefined property: stdClass::$apparel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\apparel.php 85
ERROR - 2015-11-18 14:57:04 --> Severity: Notice  --> Undefined property: stdClass::$apparel_id C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\apparel.php 83
ERROR - 2015-11-18 14:57:04 --> Severity: Notice  --> Undefined property: stdClass::$apparel_id C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\apparel.php 85
ERROR - 2015-11-18 14:57:04 --> Severity: Notice  --> Undefined property: stdClass::$apparel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\apparel.php 85
ERROR - 2015-11-18 14:57:04 --> Severity: Notice  --> Undefined property: stdClass::$apparel_id C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\apparel.php 83
ERROR - 2015-11-18 14:57:04 --> Severity: Notice  --> Undefined property: stdClass::$apparel_id C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\apparel.php 85
ERROR - 2015-11-18 14:57:04 --> Severity: Notice  --> Undefined property: stdClass::$apparel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\apparel.php 85
ERROR - 2015-11-18 14:57:04 --> Severity: Notice  --> Undefined property: stdClass::$apparel_id C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\apparel.php 83
ERROR - 2015-11-18 14:57:04 --> Severity: Notice  --> Undefined property: stdClass::$apparel_id C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\apparel.php 83
ERROR - 2015-11-18 14:57:04 --> Severity: Notice  --> Undefined property: stdClass::$apparel_id C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\apparel.php 85
ERROR - 2015-11-18 14:57:04 --> Severity: Notice  --> Undefined property: stdClass::$apparel_id C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\apparel.php 85
ERROR - 2015-11-18 14:57:04 --> Severity: Notice  --> Undefined property: stdClass::$apparel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\apparel.php 85
ERROR - 2015-11-18 14:57:04 --> Severity: Notice  --> Undefined property: stdClass::$apparel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\apparel.php 85
ERROR - 2015-11-18 14:57:05 --> Severity: Notice  --> Undefined property: stdClass::$apparel_id C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\apparel.php 83
ERROR - 2015-11-18 14:57:05 --> Severity: Notice  --> Undefined property: stdClass::$apparel_id C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\apparel.php 83
ERROR - 2015-11-18 14:57:05 --> Severity: Notice  --> Undefined property: stdClass::$apparel_id C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\apparel.php 85
ERROR - 2015-11-18 14:57:05 --> Severity: Notice  --> Undefined property: stdClass::$apparel_id C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\apparel.php 85
ERROR - 2015-11-18 14:57:05 --> Severity: Notice  --> Undefined property: stdClass::$apparel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\apparel.php 85
ERROR - 2015-11-18 14:57:05 --> Severity: Notice  --> Undefined property: stdClass::$apparel_id C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\apparel.php 83
ERROR - 2015-11-18 14:57:05 --> Severity: Notice  --> Undefined property: stdClass::$apparel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\apparel.php 85
ERROR - 2015-11-18 14:57:05 --> Severity: Notice  --> Undefined property: stdClass::$apparel_id C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\apparel.php 85
ERROR - 2015-11-18 14:57:05 --> Severity: Notice  --> Undefined property: stdClass::$apparel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\apparel.php 85
ERROR - 2015-11-18 14:57:05 --> Severity: Notice  --> Undefined property: stdClass::$apparel_id C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\apparel.php 83
ERROR - 2015-11-18 14:57:05 --> Severity: Notice  --> Undefined property: stdClass::$apparel_id C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\apparel.php 85
ERROR - 2015-11-18 14:57:05 --> Severity: Notice  --> Undefined property: stdClass::$apparel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\apparel.php 85
ERROR - 2015-11-18 14:57:05 --> Severity: Notice  --> Undefined property: stdClass::$apparel_id C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\apparel.php 83
ERROR - 2015-11-18 14:57:05 --> Severity: Notice  --> Undefined property: stdClass::$apparel_id C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\apparel.php 85
ERROR - 2015-11-18 14:57:05 --> Severity: Notice  --> Undefined property: stdClass::$apparel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\apparel.php 85
ERROR - 2015-11-18 14:57:05 --> Severity: Notice  --> Undefined property: stdClass::$apparel_id C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\apparel.php 83
ERROR - 2015-11-18 14:57:05 --> Severity: Notice  --> Undefined property: stdClass::$apparel_id C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\apparel.php 83
ERROR - 2015-11-18 14:57:05 --> Severity: Notice  --> Undefined property: stdClass::$apparel_id C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\apparel.php 85
ERROR - 2015-11-18 14:57:05 --> Severity: Notice  --> Undefined property: stdClass::$apparel_id C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\apparel.php 85
ERROR - 2015-11-18 14:57:05 --> Severity: Notice  --> Undefined property: stdClass::$apparel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\apparel.php 85
ERROR - 2015-11-18 14:57:05 --> Severity: Notice  --> Undefined property: stdClass::$apparel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\apparel.php 85
ERROR - 2015-11-18 14:57:05 --> Severity: Notice  --> Undefined property: stdClass::$apparel_id C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\apparel.php 83
ERROR - 2015-11-18 14:57:05 --> Severity: Notice  --> Undefined property: stdClass::$apparel_id C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\apparel.php 83
ERROR - 2015-11-18 14:57:05 --> Severity: Notice  --> Undefined property: stdClass::$apparel_id C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\apparel.php 85
ERROR - 2015-11-18 14:57:05 --> Severity: Notice  --> Undefined property: stdClass::$apparel_id C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\apparel.php 85
ERROR - 2015-11-18 14:57:05 --> Severity: Notice  --> Undefined property: stdClass::$apparel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\apparel.php 85
ERROR - 2015-11-18 14:57:05 --> Severity: Notice  --> Undefined property: stdClass::$apparel_id C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\apparel.php 83
ERROR - 2015-11-18 14:57:05 --> Severity: Notice  --> Undefined property: stdClass::$apparel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\apparel.php 85
ERROR - 2015-11-18 14:57:05 --> Severity: Notice  --> Undefined property: stdClass::$apparel_id C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\apparel.php 85
ERROR - 2015-11-18 14:57:05 --> Severity: Notice  --> Undefined property: stdClass::$apparel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\apparel.php 85
ERROR - 2015-11-18 14:57:05 --> Severity: Notice  --> Undefined property: stdClass::$apparel_id C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\apparel.php 83
ERROR - 2015-11-18 14:57:05 --> Severity: Notice  --> Undefined property: stdClass::$apparel_id C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\apparel.php 85
ERROR - 2015-11-18 14:57:05 --> Severity: Notice  --> Undefined property: stdClass::$apparel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\apparel.php 85
ERROR - 2015-11-18 14:57:05 --> Severity: Notice  --> Undefined property: stdClass::$apparel_id C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\apparel.php 83
ERROR - 2015-11-18 14:57:05 --> Severity: Notice  --> Undefined property: stdClass::$apparel_id C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\apparel.php 85
ERROR - 2015-11-18 14:57:05 --> Severity: Notice  --> Undefined property: stdClass::$apparel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\apparel.php 85
ERROR - 2015-11-18 14:57:05 --> Severity: Notice  --> Undefined property: stdClass::$apparel_id C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\apparel.php 83
ERROR - 2015-11-18 14:57:05 --> Severity: Notice  --> Undefined property: stdClass::$apparel_id C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\apparel.php 85
ERROR - 2015-11-18 14:57:05 --> Severity: Notice  --> Undefined property: stdClass::$apparel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\apparel.php 85
ERROR - 2015-11-18 14:57:05 --> Severity: Notice  --> Undefined property: stdClass::$apparel_id C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\apparel.php 83
ERROR - 2015-11-18 14:57:05 --> Severity: Notice  --> Undefined property: stdClass::$apparel_id C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\apparel.php 85
ERROR - 2015-11-18 14:57:05 --> Severity: Notice  --> Undefined property: stdClass::$apparel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\apparel.php 85
ERROR - 2015-11-18 15:00:36 --> Query error: Unknown column 'bag_apparel' in 'field list'
ERROR - 2015-11-18 15:01:11 --> Query error: Unknown column 'bag_apparel' in 'field list'
