<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-06-02 12:19:38 --> 404 Page Not Found --> template
ERROR - 2015-06-02 12:19:40 --> 404 Page Not Found --> template
ERROR - 2015-06-02 12:19:44 --> 404 Page Not Found --> template
ERROR - 2015-06-02 12:19:44 --> 404 Page Not Found --> template
ERROR - 2015-06-02 12:19:49 --> 404 Page Not Found --> template
ERROR - 2015-06-02 12:19:49 --> 404 Page Not Found --> template
ERROR - 2015-06-02 12:19:55 --> 404 Page Not Found --> template
ERROR - 2015-06-02 12:19:56 --> 404 Page Not Found --> template
ERROR - 2015-06-02 12:20:27 --> 404 Page Not Found --> template
ERROR - 2015-06-02 12:20:27 --> 404 Page Not Found --> template
ERROR - 2015-06-02 12:20:43 --> 404 Page Not Found --> template
ERROR - 2015-06-02 12:20:43 --> 404 Page Not Found --> template
ERROR - 2015-06-02 12:21:09 --> 404 Page Not Found --> template
ERROR - 2015-06-02 12:21:10 --> 404 Page Not Found --> template
ERROR - 2015-06-02 12:21:22 --> 404 Page Not Found --> template
ERROR - 2015-06-02 12:21:31 --> 404 Page Not Found --> template
ERROR - 2015-06-02 12:21:53 --> 404 Page Not Found --> template
ERROR - 2015-06-02 12:22:02 --> 404 Page Not Found --> template
ERROR - 2015-06-02 12:22:39 --> 404 Page Not Found --> template
ERROR - 2015-06-02 12:22:46 --> 404 Page Not Found --> template
ERROR - 2015-06-02 12:49:23 --> 404 Page Not Found --> template
ERROR - 2015-06-02 12:49:23 --> 404 Page Not Found --> template
ERROR - 2015-06-02 12:49:26 --> 404 Page Not Found --> template
ERROR - 2015-06-02 12:49:26 --> 404 Page Not Found --> template
ERROR - 2015-06-02 12:49:29 --> 404 Page Not Found --> template
ERROR - 2015-06-02 12:49:29 --> 404 Page Not Found --> template
ERROR - 2015-06-02 12:49:33 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2015-06-02 12:49:33 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2015-06-02 12:49:33 --> 404 Page Not Found --> template
ERROR - 2015-06-02 12:49:33 --> 404 Page Not Found --> template
ERROR - 2015-06-02 12:49:45 --> 404 Page Not Found --> template
ERROR - 2015-06-02 12:49:45 --> 404 Page Not Found --> template
ERROR - 2015-06-02 12:49:53 --> 404 Page Not Found --> template
ERROR - 2015-06-02 12:49:53 --> 404 Page Not Found --> template
ERROR - 2015-06-02 12:49:56 --> 404 Page Not Found --> template
ERROR - 2015-06-02 12:49:56 --> 404 Page Not Found --> template
ERROR - 2015-06-02 12:50:23 --> 404 Page Not Found --> template
ERROR - 2015-06-02 12:50:23 --> 404 Page Not Found --> template
ERROR - 2015-06-02 12:50:35 --> 404 Page Not Found --> template
ERROR - 2015-06-02 12:50:35 --> 404 Page Not Found --> template
ERROR - 2015-06-02 12:50:46 --> Severity: Warning  --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\wamp\www\Esgotado\system\libraries\Email.php 1553
ERROR - 2015-06-02 12:50:46 --> 404 Page Not Found --> template
ERROR - 2015-06-02 12:50:46 --> 404 Page Not Found --> template
ERROR - 2015-06-02 12:52:44 --> 404 Page Not Found --> template
ERROR - 2015-06-02 12:52:44 --> 404 Page Not Found --> template
ERROR - 2015-06-02 12:52:46 --> 404 Page Not Found --> template
ERROR - 2015-06-02 12:52:46 --> 404 Page Not Found --> template
ERROR - 2015-06-02 12:52:48 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2015-06-02 12:52:48 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2015-06-02 12:52:48 --> 404 Page Not Found --> template
ERROR - 2015-06-02 12:52:48 --> 404 Page Not Found --> template
ERROR - 2015-06-02 12:52:50 --> 404 Page Not Found --> template
ERROR - 2015-06-02 12:52:50 --> 404 Page Not Found --> template
ERROR - 2015-06-02 12:52:53 --> 404 Page Not Found --> template
ERROR - 2015-06-02 12:52:53 --> 404 Page Not Found --> template
ERROR - 2015-06-02 12:53:00 --> Severity: Warning  --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\wamp\www\Esgotado\system\libraries\Email.php 1553
ERROR - 2015-06-02 12:53:01 --> 404 Page Not Found --> template
ERROR - 2015-06-02 12:53:01 --> 404 Page Not Found --> template
ERROR - 2015-06-02 12:53:46 --> 404 Page Not Found --> template
ERROR - 2015-06-02 12:53:46 --> 404 Page Not Found --> template
ERROR - 2015-06-02 12:53:48 --> 404 Page Not Found --> template
ERROR - 2015-06-02 12:53:48 --> 404 Page Not Found --> template
ERROR - 2015-06-02 12:53:51 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2015-06-02 12:53:51 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2015-06-02 12:53:51 --> 404 Page Not Found --> template
ERROR - 2015-06-02 12:53:51 --> 404 Page Not Found --> template
ERROR - 2015-06-02 12:53:53 --> 404 Page Not Found --> template
ERROR - 2015-06-02 12:53:53 --> 404 Page Not Found --> template
ERROR - 2015-06-02 12:53:55 --> 404 Page Not Found --> template
ERROR - 2015-06-02 12:53:56 --> 404 Page Not Found --> template
ERROR - 2015-06-02 12:55:08 --> 404 Page Not Found --> template
ERROR - 2015-06-02 12:55:10 --> 404 Page Not Found --> template
ERROR - 2015-06-02 12:55:18 --> Severity: Warning  --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\wamp\www\Esgotado\system\libraries\Email.php 1553
ERROR - 2015-06-02 12:55:18 --> 404 Page Not Found --> template
ERROR - 2015-06-02 12:55:18 --> 404 Page Not Found --> template
ERROR - 2015-06-02 13:03:57 --> 404 Page Not Found --> template
ERROR - 2015-06-02 13:03:57 --> 404 Page Not Found --> template
ERROR - 2015-06-02 13:03:59 --> 404 Page Not Found --> template
ERROR - 2015-06-02 13:03:59 --> 404 Page Not Found --> template
ERROR - 2015-06-02 13:04:01 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2015-06-02 13:04:01 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2015-06-02 13:04:01 --> 404 Page Not Found --> template
ERROR - 2015-06-02 13:04:02 --> 404 Page Not Found --> template
ERROR - 2015-06-02 13:04:22 --> 404 Page Not Found --> template
ERROR - 2015-06-02 13:04:22 --> 404 Page Not Found --> template
ERROR - 2015-06-02 13:04:25 --> 404 Page Not Found --> template
ERROR - 2015-06-02 13:04:25 --> 404 Page Not Found --> template
ERROR - 2015-06-02 13:04:28 --> Severity: Warning  --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\wamp\www\Esgotado\system\libraries\Email.php 1553
ERROR - 2015-06-02 13:04:29 --> 404 Page Not Found --> template
ERROR - 2015-06-02 13:04:29 --> 404 Page Not Found --> template
ERROR - 2015-06-02 13:04:32 --> 404 Page Not Found --> template
ERROR - 2015-06-02 13:04:32 --> 404 Page Not Found --> template
ERROR - 2015-06-02 13:04:34 --> 404 Page Not Found --> template
ERROR - 2015-06-02 13:04:34 --> 404 Page Not Found --> template
ERROR - 2015-06-02 13:04:37 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2015-06-02 13:04:37 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2015-06-02 13:04:37 --> 404 Page Not Found --> template
ERROR - 2015-06-02 13:04:37 --> 404 Page Not Found --> template
ERROR - 2015-06-02 13:04:39 --> 404 Page Not Found --> template
ERROR - 2015-06-02 13:04:39 --> 404 Page Not Found --> template
ERROR - 2015-06-02 13:04:42 --> 404 Page Not Found --> template
ERROR - 2015-06-02 13:04:42 --> 404 Page Not Found --> template
ERROR - 2015-06-02 13:04:50 --> Severity: Warning  --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\wamp\www\Esgotado\system\libraries\Email.php 1553
ERROR - 2015-06-02 13:04:50 --> 404 Page Not Found --> template
ERROR - 2015-06-02 13:04:50 --> 404 Page Not Found --> template
ERROR - 2015-06-02 13:07:39 --> 404 Page Not Found --> template
ERROR - 2015-06-02 13:07:39 --> 404 Page Not Found --> template
ERROR - 2015-06-02 13:07:41 --> 404 Page Not Found --> template
ERROR - 2015-06-02 13:07:41 --> 404 Page Not Found --> template
ERROR - 2015-06-02 13:07:46 --> 404 Page Not Found --> template
ERROR - 2015-06-02 13:07:57 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2015-06-02 13:07:57 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2015-06-02 13:07:57 --> 404 Page Not Found --> template
ERROR - 2015-06-02 13:07:57 --> 404 Page Not Found --> template
ERROR - 2015-06-02 13:07:59 --> 404 Page Not Found --> template
ERROR - 2015-06-02 13:07:59 --> 404 Page Not Found --> template
ERROR - 2015-06-02 13:08:02 --> 404 Page Not Found --> template
ERROR - 2015-06-02 13:08:02 --> 404 Page Not Found --> template
ERROR - 2015-06-02 13:08:06 --> 404 Page Not Found --> template
ERROR - 2015-06-02 13:08:06 --> 404 Page Not Found --> template
ERROR - 2015-06-02 13:08:20 --> 404 Page Not Found --> template
ERROR - 2015-06-02 13:08:20 --> 404 Page Not Found --> template
ERROR - 2015-06-02 13:08:31 --> 404 Page Not Found --> template
ERROR - 2015-06-02 13:08:31 --> 404 Page Not Found --> template
ERROR - 2015-06-02 13:08:34 --> 404 Page Not Found --> template
ERROR - 2015-06-02 13:08:34 --> 404 Page Not Found --> template
ERROR - 2015-06-02 13:08:39 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2015-06-02 13:08:39 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2015-06-02 13:08:40 --> 404 Page Not Found --> template
ERROR - 2015-06-02 13:08:40 --> 404 Page Not Found --> template
ERROR - 2015-06-02 13:08:43 --> 404 Page Not Found --> template
ERROR - 2015-06-02 13:08:44 --> 404 Page Not Found --> template
ERROR - 2015-06-02 13:08:51 --> Severity: Warning  --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\wamp\www\Esgotado\system\libraries\Email.php 1553
ERROR - 2015-06-02 13:08:52 --> 404 Page Not Found --> template
ERROR - 2015-06-02 13:08:52 --> 404 Page Not Found --> template
ERROR - 2015-06-02 13:09:09 --> 404 Page Not Found --> template
ERROR - 2015-06-02 13:09:09 --> 404 Page Not Found --> template
ERROR - 2015-06-02 13:09:19 --> 404 Page Not Found --> template
ERROR - 2015-06-02 13:09:22 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2015-06-02 13:09:22 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2015-06-02 13:09:22 --> 404 Page Not Found --> template
ERROR - 2015-06-02 13:09:22 --> 404 Page Not Found --> template
ERROR - 2015-06-02 13:09:24 --> 404 Page Not Found --> template
ERROR - 2015-06-02 13:09:24 --> 404 Page Not Found --> template
ERROR - 2015-06-02 13:09:27 --> 404 Page Not Found --> template
ERROR - 2015-06-02 13:09:27 --> 404 Page Not Found --> template
ERROR - 2015-06-02 13:09:31 --> Severity: Warning  --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\wamp\www\Esgotado\system\libraries\Email.php 1553
ERROR - 2015-06-02 13:09:31 --> 404 Page Not Found --> template
ERROR - 2015-06-02 13:09:31 --> 404 Page Not Found --> template
ERROR - 2015-06-02 13:09:33 --> 404 Page Not Found --> template
ERROR - 2015-06-02 13:09:33 --> 404 Page Not Found --> template
ERROR - 2015-06-02 13:09:39 --> 404 Page Not Found --> template
ERROR - 2015-06-02 13:09:39 --> 404 Page Not Found --> template
ERROR - 2015-06-02 13:09:41 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2015-06-02 13:09:41 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2015-06-02 13:09:41 --> 404 Page Not Found --> template
ERROR - 2015-06-02 13:09:41 --> 404 Page Not Found --> template
ERROR - 2015-06-02 13:09:43 --> 404 Page Not Found --> template
ERROR - 2015-06-02 13:09:43 --> 404 Page Not Found --> template
ERROR - 2015-06-02 13:09:46 --> 404 Page Not Found --> template
ERROR - 2015-06-02 13:09:46 --> 404 Page Not Found --> template
ERROR - 2015-06-02 13:09:54 --> Severity: Warning  --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\wamp\www\Esgotado\system\libraries\Email.php 1553
ERROR - 2015-06-02 13:09:54 --> 404 Page Not Found --> template
ERROR - 2015-06-02 13:09:54 --> 404 Page Not Found --> template
ERROR - 2015-06-02 13:55:56 --> 404 Page Not Found --> template
ERROR - 2015-06-02 13:55:56 --> 404 Page Not Found --> template
ERROR - 2015-06-02 13:55:58 --> 404 Page Not Found --> template
ERROR - 2015-06-02 13:55:58 --> 404 Page Not Found --> template
ERROR - 2015-06-02 13:56:31 --> 404 Page Not Found --> template
ERROR - 2015-06-02 13:56:32 --> 404 Page Not Found --> template
ERROR - 2015-06-02 13:56:35 --> 404 Page Not Found --> template
ERROR - 2015-06-02 13:56:35 --> 404 Page Not Found --> template
ERROR - 2015-06-02 13:56:37 --> 404 Page Not Found --> template
ERROR - 2015-06-02 13:56:37 --> 404 Page Not Found --> template
ERROR - 2015-06-02 13:56:39 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2015-06-02 13:56:39 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2015-06-02 13:56:39 --> 404 Page Not Found --> template
ERROR - 2015-06-02 13:56:39 --> 404 Page Not Found --> template
ERROR - 2015-06-02 13:56:49 --> 404 Page Not Found --> template
ERROR - 2015-06-02 13:56:49 --> 404 Page Not Found --> template
ERROR - 2015-06-02 13:56:51 --> 404 Page Not Found --> template
ERROR - 2015-06-02 13:56:52 --> 404 Page Not Found --> template
ERROR - 2015-06-02 14:02:59 --> 404 Page Not Found --> template
ERROR - 2015-06-02 14:04:36 --> 404 Page Not Found --> template
ERROR - 2015-06-02 14:04:36 --> 404 Page Not Found --> template
ERROR - 2015-06-02 14:05:19 --> 404 Page Not Found --> template
ERROR - 2015-06-02 14:05:19 --> 404 Page Not Found --> template
ERROR - 2015-06-02 14:05:39 --> 404 Page Not Found --> template
ERROR - 2015-06-02 14:05:39 --> 404 Page Not Found --> template
ERROR - 2015-06-02 14:06:00 --> 404 Page Not Found --> template
ERROR - 2015-06-02 14:06:00 --> 404 Page Not Found --> template
ERROR - 2015-06-02 14:06:07 --> 404 Page Not Found --> template
ERROR - 2015-06-02 14:06:07 --> 404 Page Not Found --> template
ERROR - 2015-06-02 14:06:10 --> 404 Page Not Found --> template
ERROR - 2015-06-02 14:06:10 --> 404 Page Not Found --> template
ERROR - 2015-06-02 14:06:16 --> 404 Page Not Found --> template
ERROR - 2015-06-02 14:06:16 --> 404 Page Not Found --> template
ERROR - 2015-06-02 14:06:21 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2015-06-02 14:06:21 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2015-06-02 14:06:21 --> 404 Page Not Found --> template
ERROR - 2015-06-02 14:06:21 --> 404 Page Not Found --> template
ERROR - 2015-06-02 14:06:23 --> 404 Page Not Found --> template
ERROR - 2015-06-02 14:06:23 --> 404 Page Not Found --> template
ERROR - 2015-06-02 14:06:25 --> 404 Page Not Found --> template
ERROR - 2015-06-02 14:06:25 --> 404 Page Not Found --> template
ERROR - 2015-06-02 14:07:11 --> 404 Page Not Found --> template
ERROR - 2015-06-02 14:07:11 --> 404 Page Not Found --> template
ERROR - 2015-06-02 14:08:02 --> 404 Page Not Found --> template
ERROR - 2015-06-02 14:08:03 --> 404 Page Not Found --> template
ERROR - 2015-06-02 14:08:05 --> 404 Page Not Found --> template
ERROR - 2015-06-02 14:08:05 --> 404 Page Not Found --> template
ERROR - 2015-06-02 14:08:12 --> 404 Page Not Found --> template
ERROR - 2015-06-02 14:08:12 --> 404 Page Not Found --> template
ERROR - 2015-06-02 14:08:14 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2015-06-02 14:08:14 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2015-06-02 14:08:14 --> 404 Page Not Found --> template
ERROR - 2015-06-02 14:08:14 --> 404 Page Not Found --> template
ERROR - 2015-06-02 14:08:16 --> 404 Page Not Found --> template
ERROR - 2015-06-02 14:08:16 --> 404 Page Not Found --> template
ERROR - 2015-06-02 14:08:18 --> 404 Page Not Found --> template
ERROR - 2015-06-02 14:08:18 --> 404 Page Not Found --> template
ERROR - 2015-06-02 14:08:45 --> 404 Page Not Found --> template
ERROR - 2015-06-02 14:08:45 --> 404 Page Not Found --> template
ERROR - 2015-06-02 14:08:59 --> 404 Page Not Found --> template
ERROR - 2015-06-02 14:08:59 --> 404 Page Not Found --> template
ERROR - 2015-06-02 14:09:41 --> 404 Page Not Found --> template
ERROR - 2015-06-02 14:09:41 --> 404 Page Not Found --> template
ERROR - 2015-06-02 14:10:18 --> 404 Page Not Found --> template
ERROR - 2015-06-02 14:10:19 --> 404 Page Not Found --> template
ERROR - 2015-06-02 14:10:33 --> 404 Page Not Found --> template
ERROR - 2015-06-02 14:10:33 --> 404 Page Not Found --> template
ERROR - 2015-06-02 14:11:01 --> 404 Page Not Found --> template
ERROR - 2015-06-02 14:11:01 --> 404 Page Not Found --> template
ERROR - 2015-06-02 14:11:53 --> 404 Page Not Found --> template
ERROR - 2015-06-02 14:11:53 --> 404 Page Not Found --> template
ERROR - 2015-06-02 14:12:11 --> 404 Page Not Found --> template
ERROR - 2015-06-02 14:12:12 --> 404 Page Not Found --> template
