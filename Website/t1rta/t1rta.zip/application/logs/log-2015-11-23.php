<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-11-23 06:18:43 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-23 06:18:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-23 06:18:43 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-23 06:18:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-23 06:18:43 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-23 06:18:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-23 06:18:43 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-23 06:18:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-23 06:18:43 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-23 06:18:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-23 06:18:43 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-23 06:18:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-23 06:18:43 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:18:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:18:43 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:18:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:18:43 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:18:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:18:43 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:18:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:18:43 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:18:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:18:43 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:18:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:18:43 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:18:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:18:43 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:18:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:18:43 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:18:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:18:43 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:18:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:18:43 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:18:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:18:43 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:18:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:18:43 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:18:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:18:43 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:18:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:18:43 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:18:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:18:43 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:18:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:18:43 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:18:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:18:43 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:18:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:18:43 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:18:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:18:43 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:18:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:19:21 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-23 06:19:21 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-23 06:19:21 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-23 06:19:21 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-23 06:19:21 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-23 06:19:21 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-23 06:19:21 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-23 06:19:21 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-23 06:19:21 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-23 06:19:21 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-23 06:19:21 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-23 06:19:21 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-23 06:19:21 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:19:21 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:19:21 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:19:21 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:19:21 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:19:21 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:19:21 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:19:21 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:19:21 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:19:21 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:19:21 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:19:21 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:19:21 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:19:21 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:19:21 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:19:21 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:19:21 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:19:21 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:19:21 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:19:21 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:19:21 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:19:21 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:19:21 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:19:21 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:19:21 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:19:21 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:19:21 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:19:21 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:19:21 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:19:21 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:19:21 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:19:21 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:19:21 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:19:21 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:19:21 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:19:21 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:19:21 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:19:21 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:19:21 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:19:21 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:20:12 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-23 06:20:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-23 06:20:13 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-23 06:20:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-23 06:20:13 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-23 06:20:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-23 06:20:13 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-23 06:20:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-23 06:20:13 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-23 06:20:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-23 06:20:13 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-23 06:20:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-23 06:20:13 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:20:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:20:13 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:20:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:20:13 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:20:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:20:13 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:20:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:20:13 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:20:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:20:13 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:20:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:20:13 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:20:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:20:13 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:20:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:20:13 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:20:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:20:13 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:20:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:20:13 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:20:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:20:13 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:20:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:20:13 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:20:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:20:13 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:20:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:20:13 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:20:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:20:13 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:20:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:20:13 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:20:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:20:13 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:20:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:20:13 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:20:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:20:13 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:20:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:20:41 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-23 06:20:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-23 06:20:41 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-23 06:20:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-23 06:20:41 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-23 06:20:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-23 06:20:41 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-23 06:20:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-23 06:20:41 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-23 06:20:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-23 06:20:41 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-23 06:20:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-23 06:20:41 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:20:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:20:41 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:20:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:20:41 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:20:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:20:41 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:20:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:20:41 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:20:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:20:41 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:20:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:20:41 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:20:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:20:42 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:20:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:20:42 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:20:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:20:42 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:20:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:20:42 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:20:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:20:42 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:20:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:20:42 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:20:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:20:42 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:20:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:20:42 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:20:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:20:42 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:20:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:20:42 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:20:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:20:42 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:20:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:20:42 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:20:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:20:42 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:20:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:23:06 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-23 06:23:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-23 06:23:06 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-23 06:23:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-23 06:23:06 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-23 06:23:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-23 06:23:06 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-23 06:23:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-23 06:23:06 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-23 06:23:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-23 06:23:06 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-23 06:23:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-23 06:23:06 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:23:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:23:06 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:23:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:23:06 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:23:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:23:06 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:23:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:23:06 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:23:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:23:06 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:23:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:23:06 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:23:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:23:06 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:23:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:23:06 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:23:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:23:06 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:23:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:23:06 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:23:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:23:06 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:23:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:23:06 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:23:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:23:06 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:23:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:23:06 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:23:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:23:06 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:23:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:23:06 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:23:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:23:06 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:23:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:23:06 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:23:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:23:06 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-23 06:23:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
