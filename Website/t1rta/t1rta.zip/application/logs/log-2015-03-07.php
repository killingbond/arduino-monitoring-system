<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-03-07 03:34:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 03:34:41 --> 404 Page Not Found --> template
ERROR - 2015-03-07 03:34:41 --> 404 Page Not Found --> template
ERROR - 2015-03-07 03:34:41 --> 404 Page Not Found --> template
ERROR - 2015-03-07 03:34:41 --> 404 Page Not Found --> template
ERROR - 2015-03-07 03:34:41 --> 404 Page Not Found --> template
ERROR - 2015-03-07 03:34:41 --> 404 Page Not Found --> template
ERROR - 2015-03-07 03:34:41 --> 404 Page Not Found --> template
ERROR - 2015-03-07 03:34:41 --> 404 Page Not Found --> template
ERROR - 2015-03-07 03:34:41 --> 404 Page Not Found --> template
ERROR - 2015-03-07 03:34:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 03:34:46 --> 404 Page Not Found --> template
ERROR - 2015-03-07 03:34:46 --> 404 Page Not Found --> template
ERROR - 2015-03-07 03:34:46 --> 404 Page Not Found --> template
ERROR - 2015-03-07 03:34:46 --> 404 Page Not Found --> template
ERROR - 2015-03-07 03:34:46 --> 404 Page Not Found --> template
ERROR - 2015-03-07 03:34:46 --> 404 Page Not Found --> template
ERROR - 2015-03-07 03:34:46 --> 404 Page Not Found --> template
ERROR - 2015-03-07 03:34:46 --> 404 Page Not Found --> template
ERROR - 2015-03-07 03:34:46 --> 404 Page Not Found --> template
ERROR - 2015-03-07 03:36:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 03:36:57 --> 404 Page Not Found --> template
ERROR - 2015-03-07 03:36:57 --> 404 Page Not Found --> template
ERROR - 2015-03-07 03:36:57 --> 404 Page Not Found --> template
ERROR - 2015-03-07 03:36:57 --> 404 Page Not Found --> template
ERROR - 2015-03-07 03:36:57 --> 404 Page Not Found --> template
ERROR - 2015-03-07 03:36:57 --> 404 Page Not Found --> template
ERROR - 2015-03-07 03:36:57 --> 404 Page Not Found --> template
ERROR - 2015-03-07 03:36:57 --> 404 Page Not Found --> template
ERROR - 2015-03-07 03:36:57 --> 404 Page Not Found --> template
ERROR - 2015-03-07 03:37:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 03:42:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 03:42:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 03:42:35 --> 404 Page Not Found --> template
ERROR - 2015-03-07 03:48:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 03:48:27 --> 404 Page Not Found --> template
ERROR - 2015-03-07 03:50:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 03:50:32 --> 404 Page Not Found --> template
ERROR - 2015-03-07 03:52:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 03:52:04 --> 404 Page Not Found --> template
ERROR - 2015-03-07 03:52:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 03:52:20 --> 404 Page Not Found --> template
ERROR - 2015-03-07 03:53:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 03:53:22 --> 404 Page Not Found --> template
ERROR - 2015-03-07 03:57:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 03:57:22 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:01:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:01:01 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:01:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:01:23 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:01:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:01:38 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:01:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:01:50 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:02:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:02:07 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:02:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:02:16 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:02:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:02:22 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:02:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:02:27 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:02:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:02:32 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:02:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:02:42 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:04:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:04:27 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:04:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:04:58 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:05:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:05:09 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:06:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:06:07 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:06:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:06:25 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:06:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:06:31 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:06:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:06:40 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:06:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:06:47 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:07:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:07:41 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:07:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:07:53 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:08:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:08:55 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:09:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:09:04 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:09:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:09:13 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:09:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:09:19 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:09:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:09:58 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:10:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:10:04 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:10:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:10:25 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:10:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:10:38 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:10:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:10:48 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:10:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:10:53 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:14:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:14:37 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:15:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:15:04 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:15:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:15:22 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:15:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:15:47 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:19:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:19:00 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:19:00 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:19:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:19:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:19:42 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:20:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:20:18 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:20:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:20:23 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:20:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:20:29 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:20:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:20:34 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:20:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:20:35 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:20:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:20:35 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:20:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:20:36 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:20:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:20:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:20:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:21:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:21:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:21:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:23:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:23:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:24:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:25:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:25:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:26:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:26:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:26:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:28:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:28:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:29:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:29:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:31:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:32:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:32:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:32:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:33:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:33:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:33:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:33:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:33:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:34:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:34:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:35:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:35:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:35:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:35:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:35:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:35:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:36:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:36:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:36:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:36:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:36:50 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:39:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:39:14 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:39:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:39:21 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:39:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:39:28 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:39:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:39:38 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:39:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:39:58 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:40:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:40:04 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:40:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:40:16 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:40:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:40:27 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:40:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:40:31 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:40:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:40:34 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:40:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:40:39 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:40:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:40:43 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:41:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:41:02 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:41:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:41:07 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:41:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:41:08 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:41:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:41:22 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:41:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:41:26 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:41:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:41:31 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:41:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:41:46 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:41:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:41:59 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:42:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:42:05 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:42:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:42:13 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:42:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:42:24 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:43:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:43:06 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:43:06 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:43:06 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:43:06 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:43:06 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:43:06 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:43:06 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:43:06 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:43:06 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:43:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:43:20 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:43:20 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:43:20 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:43:20 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:43:20 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:43:20 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:43:20 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:43:20 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:43:20 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:43:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:43:23 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:43:23 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:43:23 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:43:23 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:43:23 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:43:23 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:43:23 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:43:23 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:43:23 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:43:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:43:25 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:43:25 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:43:25 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:43:25 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:43:25 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:43:25 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:43:25 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:43:25 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:43:25 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:43:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:43:38 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:43:38 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:43:38 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:43:38 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:43:38 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:43:38 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:43:38 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:43:38 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:43:38 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:43:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:43:41 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:43:41 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:43:41 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:43:41 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:43:41 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:43:41 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:43:41 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:43:41 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:43:41 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:43:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:43:45 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:43:45 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:43:45 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:43:45 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:43:45 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:43:45 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:43:45 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:43:45 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:43:45 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:43:45 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:43:45 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:43:45 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:43:45 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:43:45 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:43:45 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:43:45 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:43:45 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:43:45 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:43:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:43:47 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:43:47 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:43:47 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:43:47 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:43:47 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:43:47 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:43:47 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:43:47 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:43:47 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:43:47 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:43:47 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:43:47 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:43:47 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:43:47 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:43:47 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:43:47 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:43:47 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:43:47 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:44:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:44:14 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:44:14 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:44:14 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:44:14 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:44:14 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:44:14 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:44:14 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:44:14 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:44:14 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:44:14 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:44:14 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:44:14 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:44:14 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:44:14 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:44:14 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:44:14 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:44:14 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:44:14 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:44:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:44:26 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:44:26 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:44:26 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:44:26 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:44:26 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:44:26 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:44:26 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:44:26 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:44:26 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:44:26 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:44:26 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:44:26 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:44:26 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:44:26 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:44:26 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:44:26 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:44:26 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:44:26 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:44:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:44:50 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:44:50 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:44:50 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:44:50 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:44:50 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:44:50 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:44:50 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:44:50 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:44:50 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:44:50 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:44:50 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:44:50 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:44:50 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:44:50 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:44:50 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:44:50 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:44:50 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:44:50 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:45:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:45:03 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:45:03 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:45:03 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:45:03 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:45:03 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:45:03 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:45:03 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:45:03 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:45:03 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:45:03 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:45:03 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:45:03 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:45:03 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:45:03 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:45:03 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:45:03 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:45:03 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:45:03 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:45:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:45:14 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:45:14 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:45:14 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:45:14 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:45:14 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:45:14 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:45:14 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:45:14 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:45:14 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:45:14 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:45:14 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:45:14 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:45:14 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:45:14 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:45:14 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:45:14 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:45:14 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:45:14 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:45:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:45:38 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:45:38 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:45:38 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:45:38 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:45:38 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:45:38 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:45:38 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:45:38 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:45:38 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:45:38 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:45:38 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:45:39 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:45:39 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:45:39 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:45:39 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:45:39 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:45:39 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:45:39 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:45:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:45:40 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:45:40 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:45:40 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:45:40 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:45:40 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:45:40 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:45:40 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:45:40 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:45:40 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:45:40 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:45:40 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:45:40 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:45:40 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:45:40 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:45:40 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:45:40 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:45:40 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:45:40 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:45:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:45:49 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:45:49 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:45:49 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:45:49 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:45:49 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:45:49 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:45:49 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:45:49 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:45:49 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:45:49 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:45:49 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:45:49 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:45:49 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:45:49 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:45:49 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:45:49 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:45:49 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:45:49 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:46:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:46:00 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:46:00 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:46:00 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:46:00 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:46:00 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:46:00 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:46:00 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:46:00 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:46:00 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:46:00 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:46:00 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:46:00 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:46:00 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:46:00 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:46:00 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:46:00 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:46:00 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:46:00 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:46:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:46:12 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:46:12 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:46:12 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:46:12 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:46:12 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:46:12 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:46:12 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:46:12 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:46:12 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:46:12 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:46:12 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:46:13 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:46:13 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:46:13 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:46:13 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:46:13 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:46:13 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:46:13 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:46:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:46:20 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:46:20 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:46:20 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:46:20 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:46:20 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:46:20 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:46:20 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:46:20 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:46:20 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:46:20 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:46:20 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:46:20 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:46:20 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:46:20 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:46:20 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:46:20 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:46:20 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:46:20 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:46:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:46:48 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:46:48 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:46:48 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:46:48 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:46:48 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:46:48 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:46:48 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:46:48 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:46:48 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:46:48 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:46:48 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:46:48 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:46:48 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:46:48 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:46:48 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:46:48 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:46:48 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:46:48 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:47:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:47:11 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:47:11 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:47:11 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:47:11 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:47:11 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:47:11 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:47:11 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:47:11 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:47:11 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:47:11 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:47:11 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:47:11 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:47:11 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:47:11 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:47:11 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:47:11 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:47:11 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:47:11 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:47:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:47:13 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:47:13 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:47:13 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:47:13 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:47:13 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:47:13 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:47:13 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:47:13 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:47:13 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:47:13 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:47:13 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:47:13 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:47:13 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:47:13 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:47:13 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:47:13 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:47:13 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:47:13 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:47:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:47:55 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:47:55 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:49:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:49:19 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:49:19 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:49:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:49:28 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:49:28 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:49:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:49:38 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:49:38 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:49:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:49:43 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:49:43 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:50:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:50:10 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:50:10 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:50:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:50:45 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:50:45 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:50:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:50:55 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:50:56 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:51:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:51:16 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:51:16 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:52:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:52:09 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:52:09 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:52:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:52:45 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:52:45 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:53:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:53:06 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:53:06 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:53:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:53:14 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:53:15 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:53:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:53:18 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:53:19 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:53:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:53:23 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:53:24 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:53:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:53:43 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:53:43 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:54:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:54:02 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:54:03 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:54:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:54:15 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:54:15 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:55:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:55:02 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:55:02 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:55:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:55:44 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:55:44 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:56:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:56:14 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:56:14 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:56:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:56:31 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:56:31 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:56:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:56:38 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:56:38 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:56:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:56:55 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:56:55 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:57:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:57:34 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:57:34 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:58:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:58:42 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:58:42 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:58:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:58:57 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:58:57 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:59:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:59:09 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:59:09 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:59:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:59:21 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:59:21 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:59:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:59:35 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:59:35 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:59:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 04:59:44 --> 404 Page Not Found --> template
ERROR - 2015-03-07 04:59:44 --> 404 Page Not Found --> template
ERROR - 2015-03-07 05:00:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 05:00:01 --> 404 Page Not Found --> template
ERROR - 2015-03-07 05:00:01 --> 404 Page Not Found --> template
ERROR - 2015-03-07 05:00:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 05:00:07 --> 404 Page Not Found --> template
ERROR - 2015-03-07 05:00:07 --> 404 Page Not Found --> template
ERROR - 2015-03-07 05:00:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 05:00:18 --> 404 Page Not Found --> template
ERROR - 2015-03-07 05:00:18 --> 404 Page Not Found --> template
ERROR - 2015-03-07 05:00:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 05:00:31 --> 404 Page Not Found --> template
ERROR - 2015-03-07 05:00:31 --> 404 Page Not Found --> template
ERROR - 2015-03-07 05:00:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 05:00:41 --> 404 Page Not Found --> template
ERROR - 2015-03-07 05:00:41 --> 404 Page Not Found --> template
ERROR - 2015-03-07 05:00:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 05:00:48 --> 404 Page Not Found --> template
ERROR - 2015-03-07 05:00:48 --> 404 Page Not Found --> template
ERROR - 2015-03-07 05:00:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 05:00:55 --> 404 Page Not Found --> template
ERROR - 2015-03-07 05:00:55 --> 404 Page Not Found --> template
ERROR - 2015-03-07 05:01:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 05:01:03 --> 404 Page Not Found --> template
ERROR - 2015-03-07 05:01:03 --> 404 Page Not Found --> template
ERROR - 2015-03-07 05:01:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 05:01:58 --> 404 Page Not Found --> template
ERROR - 2015-03-07 05:01:58 --> 404 Page Not Found --> template
ERROR - 2015-03-07 05:02:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 05:02:59 --> 404 Page Not Found --> template
ERROR - 2015-03-07 05:02:59 --> 404 Page Not Found --> template
ERROR - 2015-03-07 05:03:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 05:03:36 --> 404 Page Not Found --> template
ERROR - 2015-03-07 05:03:37 --> 404 Page Not Found --> template
ERROR - 2015-03-07 05:04:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 05:04:17 --> 404 Page Not Found --> template
ERROR - 2015-03-07 05:04:17 --> 404 Page Not Found --> template
ERROR - 2015-03-07 05:04:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 05:04:28 --> 404 Page Not Found --> template
ERROR - 2015-03-07 05:04:28 --> 404 Page Not Found --> template
ERROR - 2015-03-07 05:04:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 05:04:32 --> 404 Page Not Found --> template
ERROR - 2015-03-07 05:04:32 --> 404 Page Not Found --> template
ERROR - 2015-03-07 05:04:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 05:04:54 --> 404 Page Not Found --> template
ERROR - 2015-03-07 05:04:54 --> 404 Page Not Found --> template
ERROR - 2015-03-07 05:05:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 05:05:10 --> 404 Page Not Found --> template
ERROR - 2015-03-07 05:05:10 --> 404 Page Not Found --> template
ERROR - 2015-03-07 05:05:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 05:05:22 --> 404 Page Not Found --> template
ERROR - 2015-03-07 05:05:22 --> 404 Page Not Found --> template
ERROR - 2015-03-07 05:07:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 05:07:53 --> 404 Page Not Found --> template
ERROR - 2015-03-07 05:07:54 --> 404 Page Not Found --> template
ERROR - 2015-03-07 05:09:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 05:09:38 --> 404 Page Not Found --> template
ERROR - 2015-03-07 05:09:38 --> 404 Page Not Found --> template
ERROR - 2015-03-07 05:10:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 05:10:07 --> 404 Page Not Found --> template
ERROR - 2015-03-07 05:12:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 05:12:13 --> 404 Page Not Found --> template
ERROR - 2015-03-07 05:12:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 05:12:40 --> 404 Page Not Found --> template
ERROR - 2015-03-07 05:12:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 05:12:41 --> 404 Page Not Found --> template
ERROR - 2015-03-07 05:12:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 05:12:57 --> 404 Page Not Found --> template
ERROR - 2015-03-07 05:12:57 --> 404 Page Not Found --> template
ERROR - 2015-03-07 05:13:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 05:13:29 --> 404 Page Not Found --> template
ERROR - 2015-03-07 05:13:29 --> 404 Page Not Found --> template
ERROR - 2015-03-07 05:14:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 05:14:22 --> 404 Page Not Found --> template
ERROR - 2015-03-07 05:14:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 05:14:48 --> 404 Page Not Found --> template
ERROR - 2015-03-07 05:15:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 05:15:11 --> 404 Page Not Found --> template
ERROR - 2015-03-07 06:21:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 06:21:36 --> 404 Page Not Found --> template
ERROR - 2015-03-07 06:25:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 06:25:14 --> 404 Page Not Found --> template
ERROR - 2015-03-07 06:25:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 06:25:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 06:25:42 --> 404 Page Not Found --> template
ERROR - 2015-03-07 06:27:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 06:27:46 --> 404 Page Not Found --> template
ERROR - 2015-03-07 06:27:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 06:27:49 --> 404 Page Not Found --> template
ERROR - 2015-03-07 06:27:59 --> 404 Page Not Found --> template
ERROR - 2015-03-07 06:28:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 06:28:39 --> 404 Page Not Found --> template
ERROR - 2015-03-07 06:28:41 --> 404 Page Not Found --> template
ERROR - 2015-03-07 06:28:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 06:28:57 --> 404 Page Not Found --> template
ERROR - 2015-03-07 06:29:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 06:29:34 --> 404 Page Not Found --> template
ERROR - 2015-03-07 06:30:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 06:30:21 --> 404 Page Not Found --> template
ERROR - 2015-03-07 06:30:23 --> 404 Page Not Found --> template
ERROR - 2015-03-07 06:30:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 06:30:36 --> 404 Page Not Found --> template
ERROR - 2015-03-07 14:08:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 14:08:57 --> 404 Page Not Found --> template
ERROR - 2015-03-07 14:09:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 14:09:00 --> 404 Page Not Found --> template
ERROR - 2015-03-07 14:09:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 14:09:47 --> 404 Page Not Found --> template
ERROR - 2015-03-07 14:10:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 14:10:05 --> 404 Page Not Found --> template
ERROR - 2015-03-07 14:12:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 14:12:54 --> 404 Page Not Found --> template
ERROR - 2015-03-07 14:13:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 14:13:25 --> 404 Page Not Found --> template
ERROR - 2015-03-07 14:13:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 14:13:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 14:13:38 --> 404 Page Not Found --> template
ERROR - 2015-03-07 14:13:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 14:13:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 14:13:44 --> 404 Page Not Found --> template
ERROR - 2015-03-07 14:13:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 14:13:46 --> 404 Page Not Found --> template
ERROR - 2015-03-07 14:13:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 14:13:59 --> Severity: Notice  --> Undefined variable: is_register /Applications/MAMP/htdocs/Esgotado/application/views/forget_password.php 82
ERROR - 2015-03-07 14:13:59 --> 404 Page Not Found --> template
ERROR - 2015-03-07 14:14:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 14:14:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 14:14:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 14:14:28 --> 404 Page Not Found --> template
ERROR - 2015-03-07 14:14:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 14:14:45 --> 404 Page Not Found --> template
ERROR - 2015-03-07 14:14:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 14:14:59 --> 404 Page Not Found --> template
ERROR - 2015-03-07 14:15:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 14:15:03 --> 404 Page Not Found --> template
ERROR - 2015-03-07 14:15:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 14:15:09 --> Severity: Notice  --> Undefined variable: is_register /Applications/MAMP/htdocs/Esgotado/application/views/forget_password.php 82
ERROR - 2015-03-07 14:15:09 --> 404 Page Not Found --> template
ERROR - 2015-03-07 14:16:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 14:16:54 --> Severity: Notice  --> Undefined variable: is_checkout /Applications/MAMP/htdocs/Esgotado/application/views/forget_password.php 46
ERROR - 2015-03-07 14:16:54 --> Severity: Notice  --> Undefined variable: is_register /Applications/MAMP/htdocs/Esgotado/application/views/forget_password.php 133
ERROR - 2015-03-07 14:16:54 --> 404 Page Not Found --> template
ERROR - 2015-03-07 14:17:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 14:17:21 --> Severity: Notice  --> Undefined variable: is_register /Applications/MAMP/htdocs/Esgotado/application/views/forget_password.php 123
ERROR - 2015-03-07 14:17:21 --> 404 Page Not Found --> template
ERROR - 2015-03-07 14:17:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 14:17:41 --> Severity: Notice  --> Undefined variable: is_register /Applications/MAMP/htdocs/Esgotado/application/views/forget_password.php 123
ERROR - 2015-03-07 14:17:41 --> 404 Page Not Found --> template
ERROR - 2015-03-07 14:18:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 14:18:02 --> Severity: Notice  --> Undefined variable: is_register /Applications/MAMP/htdocs/Esgotado/application/views/forget_password.php 91
ERROR - 2015-03-07 14:18:02 --> 404 Page Not Found --> template
ERROR - 2015-03-07 14:18:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 14:18:16 --> 404 Page Not Found --> template
ERROR - 2015-03-07 14:19:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 14:19:10 --> 404 Page Not Found --> template
ERROR - 2015-03-07 14:19:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 14:19:21 --> 404 Page Not Found --> template
ERROR - 2015-03-07 14:19:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 14:19:23 --> 404 Page Not Found --> template
ERROR - 2015-03-07 14:19:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 14:19:25 --> 404 Page Not Found --> template
ERROR - 2015-03-07 14:19:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 14:19:26 --> 404 Page Not Found --> template
ERROR - 2015-03-07 14:19:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 14:19:28 --> 404 Page Not Found --> template
ERROR - 2015-03-07 14:19:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 14:19:30 --> 404 Page Not Found --> template
ERROR - 2015-03-07 14:19:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 14:19:32 --> 404 Page Not Found --> template
ERROR - 2015-03-07 14:19:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 14:19:34 --> 404 Page Not Found --> template
ERROR - 2015-03-07 14:19:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 14:19:35 --> 404 Page Not Found --> template
ERROR - 2015-03-07 14:19:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 14:19:36 --> 404 Page Not Found --> template
ERROR - 2015-03-07 14:19:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 14:19:37 --> 404 Page Not Found --> template
ERROR - 2015-03-07 14:19:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 14:19:39 --> 404 Page Not Found --> template
ERROR - 2015-03-07 14:19:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 14:19:41 --> 404 Page Not Found --> template
ERROR - 2015-03-07 14:21:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 14:21:19 --> 404 Page Not Found --> template
ERROR - 2015-03-07 14:21:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 14:21:30 --> Severity: Notice  --> Undefined variable: is_register /Applications/MAMP/htdocs/Esgotado/application/views/forget_password.php 91
ERROR - 2015-03-07 14:21:30 --> 404 Page Not Found --> template
ERROR - 2015-03-07 14:21:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 14:21:40 --> Severity: Notice  --> Undefined variable: is_register /Applications/MAMP/htdocs/Esgotado/application/views/forget_password.php 91
ERROR - 2015-03-07 14:21:40 --> 404 Page Not Found --> template
ERROR - 2015-03-07 14:21:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 14:21:44 --> 404 Page Not Found --> template
ERROR - 2015-03-07 14:22:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 14:22:29 --> 404 Page Not Found --> template
ERROR - 2015-03-07 14:24:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 14:24:35 --> 404 Page Not Found --> template
ERROR - 2015-03-07 14:25:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 14:25:25 --> 404 Page Not Found --> template
ERROR - 2015-03-07 14:26:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 14:26:01 --> 404 Page Not Found --> template
ERROR - 2015-03-07 14:26:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 14:26:31 --> 404 Page Not Found --> template
ERROR - 2015-03-07 14:27:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 14:27:39 --> 404 Page Not Found --> template
ERROR - 2015-03-07 14:27:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 14:27:53 --> 404 Page Not Found --> template
ERROR - 2015-03-07 14:28:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 14:28:25 --> 404 Page Not Found --> template
ERROR - 2015-03-07 14:28:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 14:28:39 --> 404 Page Not Found --> template
ERROR - 2015-03-07 14:28:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 14:28:53 --> 404 Page Not Found --> template
ERROR - 2015-03-07 14:28:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 14:28:58 --> 404 Page Not Found --> template
ERROR - 2015-03-07 14:29:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 14:29:05 --> 404 Page Not Found --> template
ERROR - 2015-03-07 14:31:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 14:31:36 --> 404 Page Not Found --> template
ERROR - 2015-03-07 14:31:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 14:31:52 --> 404 Page Not Found --> template
ERROR - 2015-03-07 14:32:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 14:32:12 --> 404 Page Not Found --> template
ERROR - 2015-03-07 14:34:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 14:34:05 --> 404 Page Not Found --> template
ERROR - 2015-03-07 14:34:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 14:34:24 --> 404 Page Not Found --> template
ERROR - 2015-03-07 14:35:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 14:35:01 --> 404 Page Not Found --> template
ERROR - 2015-03-07 14:35:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 14:35:23 --> 404 Page Not Found --> template
ERROR - 2015-03-07 14:35:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 14:35:56 --> 404 Page Not Found --> template
ERROR - 2015-03-07 14:37:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 14:37:06 --> 404 Page Not Found --> template
ERROR - 2015-03-07 14:39:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 14:39:12 --> 404 Page Not Found --> template
ERROR - 2015-03-07 14:42:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 14:42:23 --> 404 Page Not Found --> template
ERROR - 2015-03-07 14:45:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 14:45:25 --> 404 Page Not Found --> template
ERROR - 2015-03-07 14:46:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 14:46:12 --> 404 Page Not Found --> template
ERROR - 2015-03-07 14:47:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 14:47:15 --> 404 Page Not Found --> template
ERROR - 2015-03-07 14:48:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 14:48:24 --> 404 Page Not Found --> template
ERROR - 2015-03-07 14:48:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 14:48:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 14:49:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 14:49:02 --> 404 Page Not Found --> template
ERROR - 2015-03-07 14:49:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 14:49:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 14:49:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 14:49:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 14:49:36 --> 404 Page Not Found --> template
ERROR - 2015-03-07 14:49:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 14:49:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 14:49:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 14:49:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 14:49:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 14:51:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 14:51:03 --> 404 Page Not Found --> template
ERROR - 2015-03-07 14:55:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 14:55:38 --> Severity: Notice  --> Undefined variable: password /Applications/MAMP/htdocs/Esgotado/application/views/login.php 317
ERROR - 2015-03-07 14:55:38 --> Severity: Notice  --> Undefined variable: password /Applications/MAMP/htdocs/Esgotado/application/views/login.php 325
ERROR - 2015-03-07 14:55:38 --> 404 Page Not Found --> template
ERROR - 2015-03-07 14:55:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 14:55:57 --> 404 Page Not Found --> template
ERROR - 2015-03-07 14:56:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 14:56:22 --> 404 Page Not Found --> template
ERROR - 2015-03-07 15:03:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 15:03:02 --> 404 Page Not Found --> template
ERROR - 2015-03-07 15:03:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 15:03:33 --> 404 Page Not Found --> template
ERROR - 2015-03-07 15:10:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 15:10:50 --> 404 Page Not Found --> template
ERROR - 2015-03-07 15:12:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 15:12:37 --> 404 Page Not Found --> template
ERROR - 2015-03-07 15:13:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 15:13:09 --> 404 Page Not Found --> template
ERROR - 2015-03-07 15:13:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 15:13:30 --> 404 Page Not Found --> template
ERROR - 2015-03-07 15:13:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 15:13:40 --> 404 Page Not Found --> template
ERROR - 2015-03-07 15:14:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 15:14:41 --> 404 Page Not Found --> template
ERROR - 2015-03-07 15:15:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 15:15:22 --> 404 Page Not Found --> template
ERROR - 2015-03-07 15:16:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 15:16:39 --> 404 Page Not Found --> template
ERROR - 2015-03-07 15:17:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 15:17:03 --> 404 Page Not Found --> template
ERROR - 2015-03-07 15:17:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 15:17:26 --> 404 Page Not Found --> template
ERROR - 2015-03-07 15:18:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-07 15:18:29 --> 404 Page Not Found --> template
