<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-03-12 00:29:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 00:29:54 --> 404 Page Not Found --> template
ERROR - 2015-03-12 02:29:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 02:29:05 --> 404 Page Not Found --> template
ERROR - 2015-03-12 02:29:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 02:29:09 --> 404 Page Not Found --> template
ERROR - 2015-03-12 02:30:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 02:30:34 --> 404 Page Not Found --> template
ERROR - 2015-03-12 02:30:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 02:30:50 --> You did not select a file to upload.
ERROR - 2015-03-12 02:30:51 --> Severity: Warning  --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\wamp\www\Esgotado\system\libraries\Email.php 1553
ERROR - 2015-03-12 02:30:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 02:30:51 --> 404 Page Not Found --> template
ERROR - 2015-03-12 02:31:29 --> 404 Page Not Found --> check_ongkir
ERROR - 2015-03-12 02:31:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 02:31:36 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 33
ERROR - 2015-03-12 02:31:36 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 33
ERROR - 2015-03-12 02:31:36 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 33
ERROR - 2015-03-12 02:31:36 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 33
ERROR - 2015-03-12 02:31:36 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 33
ERROR - 2015-03-12 02:31:36 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 33
ERROR - 2015-03-12 02:31:36 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 33
ERROR - 2015-03-12 02:31:36 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 33
ERROR - 2015-03-12 02:31:36 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 33
ERROR - 2015-03-12 02:31:36 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 33
ERROR - 2015-03-12 02:31:36 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 33
ERROR - 2015-03-12 02:31:36 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 33
ERROR - 2015-03-12 02:31:36 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 33
ERROR - 2015-03-12 02:31:36 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 33
ERROR - 2015-03-12 02:31:36 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 33
ERROR - 2015-03-12 02:31:36 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 33
ERROR - 2015-03-12 02:31:36 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 33
ERROR - 2015-03-12 02:31:36 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 33
ERROR - 2015-03-12 02:31:36 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 33
ERROR - 2015-03-12 02:31:36 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 33
ERROR - 2015-03-12 02:31:36 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 33
ERROR - 2015-03-12 02:31:36 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 33
ERROR - 2015-03-12 02:31:36 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 33
ERROR - 2015-03-12 02:31:36 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 33
ERROR - 2015-03-12 02:31:36 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 33
ERROR - 2015-03-12 02:31:36 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 33
ERROR - 2015-03-12 02:31:36 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 33
ERROR - 2015-03-12 02:31:36 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 33
ERROR - 2015-03-12 02:31:36 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 33
ERROR - 2015-03-12 02:31:36 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 33
ERROR - 2015-03-12 02:31:36 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 33
ERROR - 2015-03-12 02:31:36 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 33
ERROR - 2015-03-12 02:31:36 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 33
ERROR - 2015-03-12 02:31:36 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 33
ERROR - 2015-03-12 02:31:36 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 33
ERROR - 2015-03-12 02:31:36 --> Severity: Notice  --> Undefined variable: city C:\wamp\www\Esgotado\application\views\ongkir.php 48
ERROR - 2015-03-12 02:31:36 --> Severity: Notice  --> Undefined variable: district C:\wamp\www\Esgotado\application\views\ongkir.php 66
ERROR - 2015-03-12 02:31:36 --> 404 Page Not Found --> template
ERROR - 2015-03-12 02:31:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 02:31:51 --> 404 Page Not Found --> template
ERROR - 2015-03-12 03:33:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 03:33:54 --> 404 Page Not Found --> template
ERROR - 2015-03-12 03:33:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 03:33:56 --> 404 Page Not Found --> template
ERROR - 2015-03-12 03:34:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 03:34:50 --> Severity: Notice  --> Undefined variable: member_id C:\wamp\www\Esgotado\application\views\confirm_payment.php 41
ERROR - 2015-03-12 03:34:50 --> Severity: Notice  --> Undefined variable: name C:\wamp\www\Esgotado\application\views\confirm_payment.php 52
ERROR - 2015-03-12 03:34:50 --> Severity: Notice  --> Undefined variable: email C:\wamp\www\Esgotado\application\views\confirm_payment.php 63
ERROR - 2015-03-12 03:34:50 --> Severity: Notice  --> Undefined variable: gender C:\wamp\www\Esgotado\application\views\confirm_payment.php 78
ERROR - 2015-03-12 03:34:50 --> Severity: Notice  --> Undefined variable: gender C:\wamp\www\Esgotado\application\views\confirm_payment.php 79
ERROR - 2015-03-12 03:34:50 --> Severity: Notice  --> Undefined variable: date C:\wamp\www\Esgotado\application\views\confirm_payment.php 95
ERROR - 2015-03-12 03:34:50 --> Severity: Notice  --> Undefined variable: date C:\wamp\www\Esgotado\application\views\confirm_payment.php 95
ERROR - 2015-03-12 03:34:50 --> Severity: Notice  --> Undefined variable: date C:\wamp\www\Esgotado\application\views\confirm_payment.php 95
ERROR - 2015-03-12 03:34:50 --> Severity: Notice  --> Undefined variable: date C:\wamp\www\Esgotado\application\views\confirm_payment.php 95
ERROR - 2015-03-12 03:34:50 --> Severity: Notice  --> Undefined variable: date C:\wamp\www\Esgotado\application\views\confirm_payment.php 95
ERROR - 2015-03-12 03:34:50 --> Severity: Notice  --> Undefined variable: date C:\wamp\www\Esgotado\application\views\confirm_payment.php 95
ERROR - 2015-03-12 03:34:50 --> Severity: Notice  --> Undefined variable: date C:\wamp\www\Esgotado\application\views\confirm_payment.php 95
ERROR - 2015-03-12 03:34:50 --> Severity: Notice  --> Undefined variable: date C:\wamp\www\Esgotado\application\views\confirm_payment.php 95
ERROR - 2015-03-12 03:34:50 --> Severity: Notice  --> Undefined variable: date C:\wamp\www\Esgotado\application\views\confirm_payment.php 95
ERROR - 2015-03-12 03:34:50 --> Severity: Notice  --> Undefined variable: date C:\wamp\www\Esgotado\application\views\confirm_payment.php 95
ERROR - 2015-03-12 03:34:50 --> Severity: Notice  --> Undefined variable: date C:\wamp\www\Esgotado\application\views\confirm_payment.php 95
ERROR - 2015-03-12 03:34:50 --> Severity: Notice  --> Undefined variable: date C:\wamp\www\Esgotado\application\views\confirm_payment.php 95
ERROR - 2015-03-12 03:34:50 --> Severity: Notice  --> Undefined variable: date C:\wamp\www\Esgotado\application\views\confirm_payment.php 95
ERROR - 2015-03-12 03:34:50 --> Severity: Notice  --> Undefined variable: date C:\wamp\www\Esgotado\application\views\confirm_payment.php 95
ERROR - 2015-03-12 03:34:50 --> Severity: Notice  --> Undefined variable: date C:\wamp\www\Esgotado\application\views\confirm_payment.php 95
ERROR - 2015-03-12 03:34:50 --> Severity: Notice  --> Undefined variable: date C:\wamp\www\Esgotado\application\views\confirm_payment.php 95
ERROR - 2015-03-12 03:34:50 --> Severity: Notice  --> Undefined variable: date C:\wamp\www\Esgotado\application\views\confirm_payment.php 95
ERROR - 2015-03-12 03:34:50 --> Severity: Notice  --> Undefined variable: date C:\wamp\www\Esgotado\application\views\confirm_payment.php 95
ERROR - 2015-03-12 03:34:50 --> Severity: Notice  --> Undefined variable: date C:\wamp\www\Esgotado\application\views\confirm_payment.php 95
ERROR - 2015-03-12 03:34:50 --> Severity: Notice  --> Undefined variable: date C:\wamp\www\Esgotado\application\views\confirm_payment.php 95
ERROR - 2015-03-12 03:34:50 --> Severity: Notice  --> Undefined variable: date C:\wamp\www\Esgotado\application\views\confirm_payment.php 95
ERROR - 2015-03-12 03:34:50 --> Severity: Notice  --> Undefined variable: date C:\wamp\www\Esgotado\application\views\confirm_payment.php 95
ERROR - 2015-03-12 03:34:50 --> Severity: Notice  --> Undefined variable: date C:\wamp\www\Esgotado\application\views\confirm_payment.php 95
ERROR - 2015-03-12 03:34:50 --> Severity: Notice  --> Undefined variable: date C:\wamp\www\Esgotado\application\views\confirm_payment.php 95
ERROR - 2015-03-12 03:34:50 --> Severity: Notice  --> Undefined variable: date C:\wamp\www\Esgotado\application\views\confirm_payment.php 95
ERROR - 2015-03-12 03:34:50 --> Severity: Notice  --> Undefined variable: date C:\wamp\www\Esgotado\application\views\confirm_payment.php 95
ERROR - 2015-03-12 03:34:50 --> Severity: Notice  --> Undefined variable: date C:\wamp\www\Esgotado\application\views\confirm_payment.php 95
ERROR - 2015-03-12 03:34:50 --> Severity: Notice  --> Undefined variable: date C:\wamp\www\Esgotado\application\views\confirm_payment.php 95
ERROR - 2015-03-12 03:34:50 --> Severity: Notice  --> Undefined variable: date C:\wamp\www\Esgotado\application\views\confirm_payment.php 95
ERROR - 2015-03-12 03:34:50 --> Severity: Notice  --> Undefined variable: date C:\wamp\www\Esgotado\application\views\confirm_payment.php 95
ERROR - 2015-03-12 03:34:50 --> Severity: Notice  --> Undefined variable: date C:\wamp\www\Esgotado\application\views\confirm_payment.php 95
ERROR - 2015-03-12 03:34:50 --> Severity: Notice  --> Undefined variable: month C:\wamp\www\Esgotado\application\views\confirm_payment.php 113
ERROR - 2015-03-12 03:34:50 --> Severity: Notice  --> Undefined variable: month C:\wamp\www\Esgotado\application\views\confirm_payment.php 113
ERROR - 2015-03-12 03:34:50 --> Severity: Notice  --> Undefined variable: month C:\wamp\www\Esgotado\application\views\confirm_payment.php 113
ERROR - 2015-03-12 03:34:50 --> Severity: Notice  --> Undefined variable: month C:\wamp\www\Esgotado\application\views\confirm_payment.php 113
ERROR - 2015-03-12 03:34:50 --> Severity: Notice  --> Undefined variable: month C:\wamp\www\Esgotado\application\views\confirm_payment.php 113
ERROR - 2015-03-12 03:34:50 --> Severity: Notice  --> Undefined variable: month C:\wamp\www\Esgotado\application\views\confirm_payment.php 113
ERROR - 2015-03-12 03:34:50 --> Severity: Notice  --> Undefined variable: month C:\wamp\www\Esgotado\application\views\confirm_payment.php 113
ERROR - 2015-03-12 03:34:50 --> Severity: Notice  --> Undefined variable: month C:\wamp\www\Esgotado\application\views\confirm_payment.php 113
ERROR - 2015-03-12 03:34:50 --> Severity: Notice  --> Undefined variable: month C:\wamp\www\Esgotado\application\views\confirm_payment.php 113
ERROR - 2015-03-12 03:34:50 --> Severity: Notice  --> Undefined variable: month C:\wamp\www\Esgotado\application\views\confirm_payment.php 113
ERROR - 2015-03-12 03:34:50 --> Severity: Notice  --> Undefined variable: month C:\wamp\www\Esgotado\application\views\confirm_payment.php 113
ERROR - 2015-03-12 03:34:50 --> Severity: Notice  --> Undefined variable: month C:\wamp\www\Esgotado\application\views\confirm_payment.php 113
ERROR - 2015-03-12 03:34:50 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 130
ERROR - 2015-03-12 03:34:50 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 130
ERROR - 2015-03-12 03:34:50 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 130
ERROR - 2015-03-12 03:34:50 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 130
ERROR - 2015-03-12 03:34:50 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 130
ERROR - 2015-03-12 03:34:50 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 130
ERROR - 2015-03-12 03:34:50 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 130
ERROR - 2015-03-12 03:34:50 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 130
ERROR - 2015-03-12 03:34:50 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 130
ERROR - 2015-03-12 03:34:50 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 130
ERROR - 2015-03-12 03:34:50 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 130
ERROR - 2015-03-12 03:34:50 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 130
ERROR - 2015-03-12 03:34:50 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 130
ERROR - 2015-03-12 03:34:50 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 130
ERROR - 2015-03-12 03:34:50 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 130
ERROR - 2015-03-12 03:34:50 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 130
ERROR - 2015-03-12 03:34:50 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 130
ERROR - 2015-03-12 03:34:50 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 130
ERROR - 2015-03-12 03:34:50 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 130
ERROR - 2015-03-12 03:34:50 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 130
ERROR - 2015-03-12 03:34:50 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 130
ERROR - 2015-03-12 03:34:50 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 130
ERROR - 2015-03-12 03:34:50 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 130
ERROR - 2015-03-12 03:34:50 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 130
ERROR - 2015-03-12 03:34:50 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 130
ERROR - 2015-03-12 03:34:50 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 130
ERROR - 2015-03-12 03:34:50 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 130
ERROR - 2015-03-12 03:34:50 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 130
ERROR - 2015-03-12 03:34:50 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 130
ERROR - 2015-03-12 03:34:50 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 130
ERROR - 2015-03-12 03:34:50 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 130
ERROR - 2015-03-12 03:34:50 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 130
ERROR - 2015-03-12 03:34:50 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 130
ERROR - 2015-03-12 03:34:50 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 130
ERROR - 2015-03-12 03:34:50 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 130
ERROR - 2015-03-12 03:34:50 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 130
ERROR - 2015-03-12 03:34:50 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 130
ERROR - 2015-03-12 03:34:50 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 130
ERROR - 2015-03-12 03:34:50 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 130
ERROR - 2015-03-12 03:34:50 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 130
ERROR - 2015-03-12 03:34:50 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 130
ERROR - 2015-03-12 03:34:50 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 130
ERROR - 2015-03-12 03:34:50 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 130
ERROR - 2015-03-12 03:34:50 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 130
ERROR - 2015-03-12 03:34:50 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 130
ERROR - 2015-03-12 03:34:50 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 130
ERROR - 2015-03-12 03:34:50 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 130
ERROR - 2015-03-12 03:34:50 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 130
ERROR - 2015-03-12 03:34:50 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 130
ERROR - 2015-03-12 03:34:50 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 130
ERROR - 2015-03-12 03:34:50 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 130
ERROR - 2015-03-12 03:34:50 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 130
ERROR - 2015-03-12 03:34:50 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 130
ERROR - 2015-03-12 03:34:50 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 130
ERROR - 2015-03-12 03:34:50 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 130
ERROR - 2015-03-12 03:34:50 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 130
ERROR - 2015-03-12 03:34:51 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 130
ERROR - 2015-03-12 03:34:51 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 130
ERROR - 2015-03-12 03:34:51 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 130
ERROR - 2015-03-12 03:34:51 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 130
ERROR - 2015-03-12 03:34:51 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 130
ERROR - 2015-03-12 03:34:51 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 130
ERROR - 2015-03-12 03:34:51 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 130
ERROR - 2015-03-12 03:34:51 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 130
ERROR - 2015-03-12 03:34:51 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 130
ERROR - 2015-03-12 03:34:51 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 130
ERROR - 2015-03-12 03:34:51 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 130
ERROR - 2015-03-12 03:34:51 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 130
ERROR - 2015-03-12 03:34:51 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 130
ERROR - 2015-03-12 03:34:51 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 130
ERROR - 2015-03-12 03:34:51 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 130
ERROR - 2015-03-12 03:34:51 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 130
ERROR - 2015-03-12 03:34:51 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 130
ERROR - 2015-03-12 03:34:51 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 130
ERROR - 2015-03-12 03:34:51 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 130
ERROR - 2015-03-12 03:34:51 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 130
ERROR - 2015-03-12 03:34:51 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 130
ERROR - 2015-03-12 03:34:51 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 130
ERROR - 2015-03-12 03:34:51 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 130
ERROR - 2015-03-12 03:34:51 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 130
ERROR - 2015-03-12 03:34:51 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 130
ERROR - 2015-03-12 03:34:51 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 130
ERROR - 2015-03-12 03:34:51 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 130
ERROR - 2015-03-12 03:34:51 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 130
ERROR - 2015-03-12 03:34:51 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 130
ERROR - 2015-03-12 03:34:51 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 130
ERROR - 2015-03-12 03:34:51 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 130
ERROR - 2015-03-12 03:34:51 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 130
ERROR - 2015-03-12 03:34:51 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 130
ERROR - 2015-03-12 03:34:51 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 130
ERROR - 2015-03-12 03:34:51 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 130
ERROR - 2015-03-12 03:34:51 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 130
ERROR - 2015-03-12 03:34:51 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 130
ERROR - 2015-03-12 03:34:51 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 130
ERROR - 2015-03-12 03:34:51 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 130
ERROR - 2015-03-12 03:34:51 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 130
ERROR - 2015-03-12 03:34:51 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 130
ERROR - 2015-03-12 03:34:51 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 130
ERROR - 2015-03-12 03:34:51 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 130
ERROR - 2015-03-12 03:34:51 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 130
ERROR - 2015-03-12 03:34:51 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 130
ERROR - 2015-03-12 03:34:51 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 130
ERROR - 2015-03-12 03:34:51 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 130
ERROR - 2015-03-12 03:34:51 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 130
ERROR - 2015-03-12 03:34:51 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 130
ERROR - 2015-03-12 03:34:51 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 130
ERROR - 2015-03-12 03:34:51 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 130
ERROR - 2015-03-12 03:34:51 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 130
ERROR - 2015-03-12 03:34:51 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 130
ERROR - 2015-03-12 03:34:51 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 130
ERROR - 2015-03-12 03:34:51 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 130
ERROR - 2015-03-12 03:34:51 --> Severity: Notice  --> Undefined variable: phone C:\wamp\www\Esgotado\application\views\confirm_payment.php 147
ERROR - 2015-03-12 03:34:51 --> Severity: Notice  --> Undefined variable: address C:\wamp\www\Esgotado\application\views\confirm_payment.php 158
ERROR - 2015-03-12 03:34:51 --> Severity: Notice  --> Undefined variable: country C:\wamp\www\Esgotado\application\views\confirm_payment.php 172
ERROR - 2015-03-12 03:34:51 --> Severity: Notice  --> Undefined variable: province C:\wamp\www\Esgotado\application\views\confirm_payment.php 195
ERROR - 2015-03-12 03:34:51 --> Severity: Notice  --> Undefined variable: city C:\wamp\www\Esgotado\application\views\confirm_payment.php 221
ERROR - 2015-03-12 03:34:51 --> Severity: Notice  --> Undefined variable: district C:\wamp\www\Esgotado\application\views\confirm_payment.php 247
ERROR - 2015-03-12 03:34:51 --> Severity: Notice  --> Undefined variable: postcode C:\wamp\www\Esgotado\application\views\confirm_payment.php 270
ERROR - 2015-03-12 03:34:51 --> 404 Page Not Found --> template
ERROR - 2015-03-12 03:35:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 03:35:22 --> Severity: Notice  --> Undefined variable: name C:\wamp\www\Esgotado\application\views\confirm_payment.php 50
ERROR - 2015-03-12 03:35:22 --> Severity: Notice  --> Undefined variable: email C:\wamp\www\Esgotado\application\views\confirm_payment.php 61
ERROR - 2015-03-12 03:35:22 --> Severity: Notice  --> Undefined variable: gender C:\wamp\www\Esgotado\application\views\confirm_payment.php 76
ERROR - 2015-03-12 03:35:22 --> Severity: Notice  --> Undefined variable: gender C:\wamp\www\Esgotado\application\views\confirm_payment.php 77
ERROR - 2015-03-12 03:35:22 --> Severity: Notice  --> Undefined variable: date C:\wamp\www\Esgotado\application\views\confirm_payment.php 93
ERROR - 2015-03-12 03:35:22 --> Severity: Notice  --> Undefined variable: date C:\wamp\www\Esgotado\application\views\confirm_payment.php 93
ERROR - 2015-03-12 03:35:22 --> Severity: Notice  --> Undefined variable: date C:\wamp\www\Esgotado\application\views\confirm_payment.php 93
ERROR - 2015-03-12 03:35:22 --> Severity: Notice  --> Undefined variable: date C:\wamp\www\Esgotado\application\views\confirm_payment.php 93
ERROR - 2015-03-12 03:35:22 --> Severity: Notice  --> Undefined variable: date C:\wamp\www\Esgotado\application\views\confirm_payment.php 93
ERROR - 2015-03-12 03:35:22 --> Severity: Notice  --> Undefined variable: date C:\wamp\www\Esgotado\application\views\confirm_payment.php 93
ERROR - 2015-03-12 03:35:22 --> Severity: Notice  --> Undefined variable: date C:\wamp\www\Esgotado\application\views\confirm_payment.php 93
ERROR - 2015-03-12 03:35:22 --> Severity: Notice  --> Undefined variable: date C:\wamp\www\Esgotado\application\views\confirm_payment.php 93
ERROR - 2015-03-12 03:35:22 --> Severity: Notice  --> Undefined variable: date C:\wamp\www\Esgotado\application\views\confirm_payment.php 93
ERROR - 2015-03-12 03:35:22 --> Severity: Notice  --> Undefined variable: date C:\wamp\www\Esgotado\application\views\confirm_payment.php 93
ERROR - 2015-03-12 03:35:22 --> Severity: Notice  --> Undefined variable: date C:\wamp\www\Esgotado\application\views\confirm_payment.php 93
ERROR - 2015-03-12 03:35:22 --> Severity: Notice  --> Undefined variable: date C:\wamp\www\Esgotado\application\views\confirm_payment.php 93
ERROR - 2015-03-12 03:35:22 --> Severity: Notice  --> Undefined variable: date C:\wamp\www\Esgotado\application\views\confirm_payment.php 93
ERROR - 2015-03-12 03:35:22 --> Severity: Notice  --> Undefined variable: date C:\wamp\www\Esgotado\application\views\confirm_payment.php 93
ERROR - 2015-03-12 03:35:22 --> Severity: Notice  --> Undefined variable: date C:\wamp\www\Esgotado\application\views\confirm_payment.php 93
ERROR - 2015-03-12 03:35:22 --> Severity: Notice  --> Undefined variable: date C:\wamp\www\Esgotado\application\views\confirm_payment.php 93
ERROR - 2015-03-12 03:35:22 --> Severity: Notice  --> Undefined variable: date C:\wamp\www\Esgotado\application\views\confirm_payment.php 93
ERROR - 2015-03-12 03:35:22 --> Severity: Notice  --> Undefined variable: date C:\wamp\www\Esgotado\application\views\confirm_payment.php 93
ERROR - 2015-03-12 03:35:22 --> Severity: Notice  --> Undefined variable: date C:\wamp\www\Esgotado\application\views\confirm_payment.php 93
ERROR - 2015-03-12 03:35:22 --> Severity: Notice  --> Undefined variable: date C:\wamp\www\Esgotado\application\views\confirm_payment.php 93
ERROR - 2015-03-12 03:35:22 --> Severity: Notice  --> Undefined variable: date C:\wamp\www\Esgotado\application\views\confirm_payment.php 93
ERROR - 2015-03-12 03:35:22 --> Severity: Notice  --> Undefined variable: date C:\wamp\www\Esgotado\application\views\confirm_payment.php 93
ERROR - 2015-03-12 03:35:22 --> Severity: Notice  --> Undefined variable: date C:\wamp\www\Esgotado\application\views\confirm_payment.php 93
ERROR - 2015-03-12 03:35:22 --> Severity: Notice  --> Undefined variable: date C:\wamp\www\Esgotado\application\views\confirm_payment.php 93
ERROR - 2015-03-12 03:35:22 --> Severity: Notice  --> Undefined variable: date C:\wamp\www\Esgotado\application\views\confirm_payment.php 93
ERROR - 2015-03-12 03:35:22 --> Severity: Notice  --> Undefined variable: date C:\wamp\www\Esgotado\application\views\confirm_payment.php 93
ERROR - 2015-03-12 03:35:22 --> Severity: Notice  --> Undefined variable: date C:\wamp\www\Esgotado\application\views\confirm_payment.php 93
ERROR - 2015-03-12 03:35:22 --> Severity: Notice  --> Undefined variable: date C:\wamp\www\Esgotado\application\views\confirm_payment.php 93
ERROR - 2015-03-12 03:35:22 --> Severity: Notice  --> Undefined variable: date C:\wamp\www\Esgotado\application\views\confirm_payment.php 93
ERROR - 2015-03-12 03:35:22 --> Severity: Notice  --> Undefined variable: date C:\wamp\www\Esgotado\application\views\confirm_payment.php 93
ERROR - 2015-03-12 03:35:22 --> Severity: Notice  --> Undefined variable: date C:\wamp\www\Esgotado\application\views\confirm_payment.php 93
ERROR - 2015-03-12 03:35:22 --> Severity: Notice  --> Undefined variable: month C:\wamp\www\Esgotado\application\views\confirm_payment.php 111
ERROR - 2015-03-12 03:35:22 --> Severity: Notice  --> Undefined variable: month C:\wamp\www\Esgotado\application\views\confirm_payment.php 111
ERROR - 2015-03-12 03:35:22 --> Severity: Notice  --> Undefined variable: month C:\wamp\www\Esgotado\application\views\confirm_payment.php 111
ERROR - 2015-03-12 03:35:22 --> Severity: Notice  --> Undefined variable: month C:\wamp\www\Esgotado\application\views\confirm_payment.php 111
ERROR - 2015-03-12 03:35:22 --> Severity: Notice  --> Undefined variable: month C:\wamp\www\Esgotado\application\views\confirm_payment.php 111
ERROR - 2015-03-12 03:35:22 --> Severity: Notice  --> Undefined variable: month C:\wamp\www\Esgotado\application\views\confirm_payment.php 111
ERROR - 2015-03-12 03:35:22 --> Severity: Notice  --> Undefined variable: month C:\wamp\www\Esgotado\application\views\confirm_payment.php 111
ERROR - 2015-03-12 03:35:22 --> Severity: Notice  --> Undefined variable: month C:\wamp\www\Esgotado\application\views\confirm_payment.php 111
ERROR - 2015-03-12 03:35:22 --> Severity: Notice  --> Undefined variable: month C:\wamp\www\Esgotado\application\views\confirm_payment.php 111
ERROR - 2015-03-12 03:35:22 --> Severity: Notice  --> Undefined variable: month C:\wamp\www\Esgotado\application\views\confirm_payment.php 111
ERROR - 2015-03-12 03:35:22 --> Severity: Notice  --> Undefined variable: month C:\wamp\www\Esgotado\application\views\confirm_payment.php 111
ERROR - 2015-03-12 03:35:22 --> Severity: Notice  --> Undefined variable: month C:\wamp\www\Esgotado\application\views\confirm_payment.php 111
ERROR - 2015-03-12 03:35:22 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 128
ERROR - 2015-03-12 03:35:22 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 128
ERROR - 2015-03-12 03:35:22 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 128
ERROR - 2015-03-12 03:35:22 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 128
ERROR - 2015-03-12 03:35:22 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 128
ERROR - 2015-03-12 03:35:22 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 128
ERROR - 2015-03-12 03:35:22 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 128
ERROR - 2015-03-12 03:35:22 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 128
ERROR - 2015-03-12 03:35:22 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 128
ERROR - 2015-03-12 03:35:22 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 128
ERROR - 2015-03-12 03:35:22 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 128
ERROR - 2015-03-12 03:35:22 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 128
ERROR - 2015-03-12 03:35:22 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 128
ERROR - 2015-03-12 03:35:22 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 128
ERROR - 2015-03-12 03:35:22 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 128
ERROR - 2015-03-12 03:35:22 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 128
ERROR - 2015-03-12 03:35:22 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 128
ERROR - 2015-03-12 03:35:22 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 128
ERROR - 2015-03-12 03:35:22 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 128
ERROR - 2015-03-12 03:35:22 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 128
ERROR - 2015-03-12 03:35:23 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 128
ERROR - 2015-03-12 03:35:23 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 128
ERROR - 2015-03-12 03:35:23 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 128
ERROR - 2015-03-12 03:35:23 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 128
ERROR - 2015-03-12 03:35:23 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 128
ERROR - 2015-03-12 03:35:23 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 128
ERROR - 2015-03-12 03:35:23 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 128
ERROR - 2015-03-12 03:35:23 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 128
ERROR - 2015-03-12 03:35:23 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 128
ERROR - 2015-03-12 03:35:23 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 128
ERROR - 2015-03-12 03:35:23 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 128
ERROR - 2015-03-12 03:35:23 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 128
ERROR - 2015-03-12 03:35:23 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 128
ERROR - 2015-03-12 03:35:23 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 128
ERROR - 2015-03-12 03:35:23 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 128
ERROR - 2015-03-12 03:35:23 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 128
ERROR - 2015-03-12 03:35:23 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 128
ERROR - 2015-03-12 03:35:23 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 128
ERROR - 2015-03-12 03:35:23 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 128
ERROR - 2015-03-12 03:35:23 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 128
ERROR - 2015-03-12 03:35:23 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 128
ERROR - 2015-03-12 03:35:23 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 128
ERROR - 2015-03-12 03:35:23 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 128
ERROR - 2015-03-12 03:35:23 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 128
ERROR - 2015-03-12 03:35:23 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 128
ERROR - 2015-03-12 03:35:23 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 128
ERROR - 2015-03-12 03:35:23 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 128
ERROR - 2015-03-12 03:35:23 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 128
ERROR - 2015-03-12 03:35:23 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 128
ERROR - 2015-03-12 03:35:23 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 128
ERROR - 2015-03-12 03:35:23 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 128
ERROR - 2015-03-12 03:35:23 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 128
ERROR - 2015-03-12 03:35:23 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 128
ERROR - 2015-03-12 03:35:23 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 128
ERROR - 2015-03-12 03:35:23 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 128
ERROR - 2015-03-12 03:35:23 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 128
ERROR - 2015-03-12 03:35:23 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 128
ERROR - 2015-03-12 03:35:23 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 128
ERROR - 2015-03-12 03:35:23 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 128
ERROR - 2015-03-12 03:35:23 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 128
ERROR - 2015-03-12 03:35:23 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 128
ERROR - 2015-03-12 03:35:23 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 128
ERROR - 2015-03-12 03:35:23 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 128
ERROR - 2015-03-12 03:35:23 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 128
ERROR - 2015-03-12 03:35:23 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 128
ERROR - 2015-03-12 03:35:23 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 128
ERROR - 2015-03-12 03:35:23 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 128
ERROR - 2015-03-12 03:35:23 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 128
ERROR - 2015-03-12 03:35:23 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 128
ERROR - 2015-03-12 03:35:23 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 128
ERROR - 2015-03-12 03:35:23 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 128
ERROR - 2015-03-12 03:35:23 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 128
ERROR - 2015-03-12 03:35:23 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 128
ERROR - 2015-03-12 03:35:23 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 128
ERROR - 2015-03-12 03:35:23 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 128
ERROR - 2015-03-12 03:35:23 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 128
ERROR - 2015-03-12 03:35:23 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 128
ERROR - 2015-03-12 03:35:23 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 128
ERROR - 2015-03-12 03:35:23 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 128
ERROR - 2015-03-12 03:35:23 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 128
ERROR - 2015-03-12 03:35:23 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 128
ERROR - 2015-03-12 03:35:23 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 128
ERROR - 2015-03-12 03:35:23 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 128
ERROR - 2015-03-12 03:35:23 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 128
ERROR - 2015-03-12 03:35:23 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 128
ERROR - 2015-03-12 03:35:23 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 128
ERROR - 2015-03-12 03:35:23 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 128
ERROR - 2015-03-12 03:35:23 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 128
ERROR - 2015-03-12 03:35:23 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 128
ERROR - 2015-03-12 03:35:23 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 128
ERROR - 2015-03-12 03:35:23 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 128
ERROR - 2015-03-12 03:35:23 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 128
ERROR - 2015-03-12 03:35:23 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 128
ERROR - 2015-03-12 03:35:23 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 128
ERROR - 2015-03-12 03:35:23 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 128
ERROR - 2015-03-12 03:35:23 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 128
ERROR - 2015-03-12 03:35:23 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 128
ERROR - 2015-03-12 03:35:23 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 128
ERROR - 2015-03-12 03:35:23 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 128
ERROR - 2015-03-12 03:35:23 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 128
ERROR - 2015-03-12 03:35:23 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 128
ERROR - 2015-03-12 03:35:23 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 128
ERROR - 2015-03-12 03:35:23 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 128
ERROR - 2015-03-12 03:35:23 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 128
ERROR - 2015-03-12 03:35:23 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 128
ERROR - 2015-03-12 03:35:23 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 128
ERROR - 2015-03-12 03:35:23 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 128
ERROR - 2015-03-12 03:35:23 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 128
ERROR - 2015-03-12 03:35:23 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 128
ERROR - 2015-03-12 03:35:23 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 128
ERROR - 2015-03-12 03:35:23 --> Severity: Notice  --> Undefined variable: year C:\wamp\www\Esgotado\application\views\confirm_payment.php 128
ERROR - 2015-03-12 03:35:23 --> Severity: Notice  --> Undefined variable: phone C:\wamp\www\Esgotado\application\views\confirm_payment.php 145
ERROR - 2015-03-12 03:35:23 --> Severity: Notice  --> Undefined variable: address C:\wamp\www\Esgotado\application\views\confirm_payment.php 156
ERROR - 2015-03-12 03:35:23 --> Severity: Notice  --> Undefined variable: country C:\wamp\www\Esgotado\application\views\confirm_payment.php 170
ERROR - 2015-03-12 03:35:23 --> Severity: Notice  --> Undefined variable: province C:\wamp\www\Esgotado\application\views\confirm_payment.php 193
ERROR - 2015-03-12 03:35:23 --> Severity: Notice  --> Undefined variable: city C:\wamp\www\Esgotado\application\views\confirm_payment.php 219
ERROR - 2015-03-12 03:35:23 --> Severity: Notice  --> Undefined variable: district C:\wamp\www\Esgotado\application\views\confirm_payment.php 245
ERROR - 2015-03-12 03:35:23 --> Severity: Notice  --> Undefined variable: postcode C:\wamp\www\Esgotado\application\views\confirm_payment.php 268
ERROR - 2015-03-12 03:35:23 --> 404 Page Not Found --> template
ERROR - 2015-03-12 03:36:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 03:36:48 --> Severity: Notice  --> Undefined variable: name C:\wamp\www\Esgotado\application\views\confirm_payment.php 50
ERROR - 2015-03-12 03:36:48 --> Severity: Notice  --> Undefined variable: email C:\wamp\www\Esgotado\application\views\confirm_payment.php 61
ERROR - 2015-03-12 03:36:48 --> Severity: Notice  --> Undefined variable: postcode C:\wamp\www\Esgotado\application\views\confirm_payment.php 109
ERROR - 2015-03-12 03:36:48 --> 404 Page Not Found --> template
ERROR - 2015-03-12 03:37:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 03:37:01 --> Severity: Notice  --> Undefined variable: postcode C:\wamp\www\Esgotado\application\views\confirm_payment.php 109
ERROR - 2015-03-12 03:37:01 --> 404 Page Not Found --> template
ERROR - 2015-03-12 03:37:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 03:37:17 --> 404 Page Not Found --> template
ERROR - 2015-03-12 03:37:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 03:37:56 --> 404 Page Not Found --> template
ERROR - 2015-03-12 03:38:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 03:38:04 --> 404 Page Not Found --> template
ERROR - 2015-03-12 03:38:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 03:38:13 --> 404 Page Not Found --> template
ERROR - 2015-03-12 03:38:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 03:38:21 --> 404 Page Not Found --> template
ERROR - 2015-03-12 03:40:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 03:40:00 --> 404 Page Not Found --> template
ERROR - 2015-03-12 03:40:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 03:40:28 --> 404 Page Not Found --> template
ERROR - 2015-03-12 03:40:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 03:40:50 --> 404 Page Not Found --> template
ERROR - 2015-03-12 03:40:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 03:40:59 --> 404 Page Not Found --> template
ERROR - 2015-03-12 03:41:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 03:41:14 --> 404 Page Not Found --> template
ERROR - 2015-03-12 03:41:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 03:41:33 --> 404 Page Not Found --> template
ERROR - 2015-03-12 03:41:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 03:41:52 --> 404 Page Not Found --> template
ERROR - 2015-03-12 03:41:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 03:41:57 --> 404 Page Not Found --> template
ERROR - 2015-03-12 03:42:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 03:42:11 --> 404 Page Not Found --> template
ERROR - 2015-03-12 03:42:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 03:42:15 --> 404 Page Not Found --> template
ERROR - 2015-03-12 03:43:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 03:43:18 --> 404 Page Not Found --> template
ERROR - 2015-03-12 03:43:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 03:43:25 --> 404 Page Not Found --> template
ERROR - 2015-03-12 03:45:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 03:45:55 --> 404 Page Not Found --> template
ERROR - 2015-03-12 03:47:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 03:47:19 --> 404 Page Not Found --> template
ERROR - 2015-03-12 03:47:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 03:47:32 --> 404 Page Not Found --> template
ERROR - 2015-03-12 03:48:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 03:48:09 --> 404 Page Not Found --> template
ERROR - 2015-03-12 03:48:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 03:48:17 --> 404 Page Not Found --> template
ERROR - 2015-03-12 03:48:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 03:48:55 --> 404 Page Not Found --> template
ERROR - 2015-03-12 03:49:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 03:49:11 --> 404 Page Not Found --> template
ERROR - 2015-03-12 03:49:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 03:49:18 --> 404 Page Not Found --> template
ERROR - 2015-03-12 03:49:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 03:49:36 --> 404 Page Not Found --> template
ERROR - 2015-03-12 03:50:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 03:50:52 --> 404 Page Not Found --> template
ERROR - 2015-03-12 03:51:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 03:51:01 --> 404 Page Not Found --> template
ERROR - 2015-03-12 03:51:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 03:51:03 --> 404 Page Not Found --> template
ERROR - 2015-03-12 03:51:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 03:51:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 03:51:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 03:51:50 --> 404 Page Not Found --> template
ERROR - 2015-03-12 03:55:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 03:55:35 --> 404 Page Not Found --> template
ERROR - 2015-03-12 03:56:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 03:56:34 --> 404 Page Not Found --> template
ERROR - 2015-03-12 03:56:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 03:56:53 --> 404 Page Not Found --> template
ERROR - 2015-03-12 03:57:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 03:57:25 --> 404 Page Not Found --> template
ERROR - 2015-03-12 03:59:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 03:59:48 --> 404 Page Not Found --> template
ERROR - 2015-03-12 04:00:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 04:00:02 --> 404 Page Not Found --> template
ERROR - 2015-03-12 04:02:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 04:02:33 --> 404 Page Not Found --> template
ERROR - 2015-03-12 04:03:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 04:03:37 --> 404 Page Not Found --> template
ERROR - 2015-03-12 04:03:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 04:03:41 --> You did not select a file to upload.
ERROR - 2015-03-12 04:03:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 04:03:41 --> 404 Page Not Found --> template
ERROR - 2015-03-12 04:04:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 04:04:10 --> 404 Page Not Found --> template
ERROR - 2015-03-12 04:04:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 04:04:14 --> 404 Page Not Found --> template
ERROR - 2015-03-12 04:05:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 04:05:13 --> 404 Page Not Found --> template
ERROR - 2015-03-12 04:05:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 04:05:51 --> 404 Page Not Found --> template
ERROR - 2015-03-12 04:07:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 04:07:23 --> You did not select a file to upload.
ERROR - 2015-03-12 04:07:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 04:07:23 --> 404 Page Not Found --> template
ERROR - 2015-03-12 04:08:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 04:08:02 --> You did not select a file to upload.
ERROR - 2015-03-12 04:08:03 --> Severity: Warning  --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\wamp\www\Esgotado\system\libraries\Email.php 1553
ERROR - 2015-03-12 04:08:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 04:08:03 --> 404 Page Not Found --> template
ERROR - 2015-03-12 04:08:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 04:08:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 04:08:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 04:08:30 --> 404 Page Not Found --> template
ERROR - 2015-03-12 04:09:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 04:09:00 --> You did not select a file to upload.
ERROR - 2015-03-12 04:09:01 --> Severity: Warning  --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\wamp\www\Esgotado\system\libraries\Email.php 1553
ERROR - 2015-03-12 04:09:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 04:09:01 --> 404 Page Not Found --> template
ERROR - 2015-03-12 04:09:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 04:09:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 04:09:38 --> Severity: Warning  --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\wamp\www\Esgotado\system\libraries\Email.php 1553
ERROR - 2015-03-12 04:09:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 04:09:38 --> 404 Page Not Found --> template
ERROR - 2015-03-12 04:09:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 04:10:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 04:10:05 --> 404 Page Not Found --> template
ERROR - 2015-03-12 04:10:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 04:10:20 --> 404 Page Not Found --> template
ERROR - 2015-03-12 04:10:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 04:10:50 --> Severity: Warning  --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\wamp\www\Esgotado\system\libraries\Email.php 1553
ERROR - 2015-03-12 04:10:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 04:10:50 --> 404 Page Not Found --> template
ERROR - 2015-03-12 04:11:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 04:11:20 --> 404 Page Not Found --> check_ongkir
ERROR - 2015-03-12 04:11:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 04:11:24 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 33
ERROR - 2015-03-12 04:11:24 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 33
ERROR - 2015-03-12 04:11:24 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 33
ERROR - 2015-03-12 04:11:24 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 33
ERROR - 2015-03-12 04:11:24 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 33
ERROR - 2015-03-12 04:11:24 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 33
ERROR - 2015-03-12 04:11:24 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 33
ERROR - 2015-03-12 04:11:24 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 33
ERROR - 2015-03-12 04:11:24 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 33
ERROR - 2015-03-12 04:11:24 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 33
ERROR - 2015-03-12 04:11:24 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 33
ERROR - 2015-03-12 04:11:24 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 33
ERROR - 2015-03-12 04:11:24 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 33
ERROR - 2015-03-12 04:11:24 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 33
ERROR - 2015-03-12 04:11:24 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 33
ERROR - 2015-03-12 04:11:24 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 33
ERROR - 2015-03-12 04:11:24 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 33
ERROR - 2015-03-12 04:11:24 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 33
ERROR - 2015-03-12 04:11:24 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 33
ERROR - 2015-03-12 04:11:24 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 33
ERROR - 2015-03-12 04:11:24 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 33
ERROR - 2015-03-12 04:11:24 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 33
ERROR - 2015-03-12 04:11:24 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 33
ERROR - 2015-03-12 04:11:24 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 33
ERROR - 2015-03-12 04:11:24 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 33
ERROR - 2015-03-12 04:11:24 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 33
ERROR - 2015-03-12 04:11:24 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 33
ERROR - 2015-03-12 04:11:24 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 33
ERROR - 2015-03-12 04:11:24 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 33
ERROR - 2015-03-12 04:11:24 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 33
ERROR - 2015-03-12 04:11:24 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 33
ERROR - 2015-03-12 04:11:24 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 33
ERROR - 2015-03-12 04:11:24 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 33
ERROR - 2015-03-12 04:11:24 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 33
ERROR - 2015-03-12 04:11:24 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 33
ERROR - 2015-03-12 04:11:24 --> Severity: Notice  --> Undefined variable: city C:\wamp\www\Esgotado\application\views\ongkir.php 48
ERROR - 2015-03-12 04:11:24 --> Severity: Notice  --> Undefined variable: district C:\wamp\www\Esgotado\application\views\ongkir.php 66
ERROR - 2015-03-12 04:11:24 --> 404 Page Not Found --> template
ERROR - 2015-03-12 04:12:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 04:12:52 --> Severity: Notice  --> Undefined variable: country C:\wamp\www\Esgotado\application\views\ongkir.php 45
ERROR - 2015-03-12 04:12:52 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 70
ERROR - 2015-03-12 04:12:52 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 70
ERROR - 2015-03-12 04:12:52 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 70
ERROR - 2015-03-12 04:12:52 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 70
ERROR - 2015-03-12 04:12:52 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 70
ERROR - 2015-03-12 04:12:52 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 70
ERROR - 2015-03-12 04:12:52 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 70
ERROR - 2015-03-12 04:12:52 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 70
ERROR - 2015-03-12 04:12:52 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 70
ERROR - 2015-03-12 04:12:52 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 70
ERROR - 2015-03-12 04:12:52 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 70
ERROR - 2015-03-12 04:12:52 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 70
ERROR - 2015-03-12 04:12:52 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 70
ERROR - 2015-03-12 04:12:52 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 70
ERROR - 2015-03-12 04:12:52 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 70
ERROR - 2015-03-12 04:12:52 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 70
ERROR - 2015-03-12 04:12:52 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 70
ERROR - 2015-03-12 04:12:52 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 70
ERROR - 2015-03-12 04:12:52 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 70
ERROR - 2015-03-12 04:12:52 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 70
ERROR - 2015-03-12 04:12:52 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 70
ERROR - 2015-03-12 04:12:52 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 70
ERROR - 2015-03-12 04:12:52 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 70
ERROR - 2015-03-12 04:12:52 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 70
ERROR - 2015-03-12 04:12:52 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 70
ERROR - 2015-03-12 04:12:52 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 70
ERROR - 2015-03-12 04:12:52 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 70
ERROR - 2015-03-12 04:12:52 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 70
ERROR - 2015-03-12 04:12:52 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 70
ERROR - 2015-03-12 04:12:52 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 70
ERROR - 2015-03-12 04:12:52 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 70
ERROR - 2015-03-12 04:12:52 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 70
ERROR - 2015-03-12 04:12:52 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 70
ERROR - 2015-03-12 04:12:52 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 70
ERROR - 2015-03-12 04:12:52 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 70
ERROR - 2015-03-12 04:12:52 --> Severity: Notice  --> Undefined variable: city C:\wamp\www\Esgotado\application\views\ongkir.php 94
ERROR - 2015-03-12 04:12:52 --> Severity: Notice  --> Undefined variable: district C:\wamp\www\Esgotado\application\views\ongkir.php 120
ERROR - 2015-03-12 04:12:52 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 157
ERROR - 2015-03-12 04:12:52 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 157
ERROR - 2015-03-12 04:12:52 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 157
ERROR - 2015-03-12 04:12:52 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 157
ERROR - 2015-03-12 04:12:52 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 157
ERROR - 2015-03-12 04:12:52 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 157
ERROR - 2015-03-12 04:12:52 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 157
ERROR - 2015-03-12 04:12:52 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 157
ERROR - 2015-03-12 04:12:52 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 157
ERROR - 2015-03-12 04:12:52 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 157
ERROR - 2015-03-12 04:12:52 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 157
ERROR - 2015-03-12 04:12:52 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 157
ERROR - 2015-03-12 04:12:52 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 157
ERROR - 2015-03-12 04:12:52 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 157
ERROR - 2015-03-12 04:12:52 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 157
ERROR - 2015-03-12 04:12:52 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 157
ERROR - 2015-03-12 04:12:52 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 157
ERROR - 2015-03-12 04:12:52 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 157
ERROR - 2015-03-12 04:12:52 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 157
ERROR - 2015-03-12 04:12:52 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 157
ERROR - 2015-03-12 04:12:52 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 157
ERROR - 2015-03-12 04:12:52 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 157
ERROR - 2015-03-12 04:12:52 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 157
ERROR - 2015-03-12 04:12:52 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 157
ERROR - 2015-03-12 04:12:52 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 157
ERROR - 2015-03-12 04:12:52 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 157
ERROR - 2015-03-12 04:12:52 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 157
ERROR - 2015-03-12 04:12:52 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 157
ERROR - 2015-03-12 04:12:52 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 157
ERROR - 2015-03-12 04:12:52 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 157
ERROR - 2015-03-12 04:12:52 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 157
ERROR - 2015-03-12 04:12:52 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 157
ERROR - 2015-03-12 04:12:52 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 157
ERROR - 2015-03-12 04:12:52 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 157
ERROR - 2015-03-12 04:12:52 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 157
ERROR - 2015-03-12 04:12:52 --> Severity: Notice  --> Undefined variable: city C:\wamp\www\Esgotado\application\views\ongkir.php 172
ERROR - 2015-03-12 04:12:52 --> Severity: Notice  --> Undefined variable: district C:\wamp\www\Esgotado\application\views\ongkir.php 190
ERROR - 2015-03-12 04:12:52 --> 404 Page Not Found --> template
ERROR - 2015-03-12 04:13:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 04:13:14 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:13:14 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:13:14 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:13:14 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:13:14 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:13:14 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:13:14 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:13:14 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:13:14 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:13:14 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:13:14 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:13:14 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:13:14 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:13:14 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:13:14 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:13:14 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:13:14 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:13:14 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:13:14 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:13:14 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:13:14 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:13:14 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:13:14 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:13:14 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:13:14 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:13:14 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:13:14 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:13:14 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:13:14 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:13:14 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:13:14 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:13:14 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:13:14 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:13:14 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:13:14 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:13:14 --> Severity: Notice  --> Undefined variable: city C:\wamp\www\Esgotado\application\views\ongkir.php 71
ERROR - 2015-03-12 04:13:14 --> Severity: Notice  --> Undefined variable: district C:\wamp\www\Esgotado\application\views\ongkir.php 97
ERROR - 2015-03-12 04:13:14 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 134
ERROR - 2015-03-12 04:13:14 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 134
ERROR - 2015-03-12 04:13:14 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 134
ERROR - 2015-03-12 04:13:14 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 134
ERROR - 2015-03-12 04:13:14 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 134
ERROR - 2015-03-12 04:13:14 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 134
ERROR - 2015-03-12 04:13:14 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 134
ERROR - 2015-03-12 04:13:14 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 134
ERROR - 2015-03-12 04:13:14 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 134
ERROR - 2015-03-12 04:13:14 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 134
ERROR - 2015-03-12 04:13:14 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 134
ERROR - 2015-03-12 04:13:14 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 134
ERROR - 2015-03-12 04:13:14 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 134
ERROR - 2015-03-12 04:13:14 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 134
ERROR - 2015-03-12 04:13:14 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 134
ERROR - 2015-03-12 04:13:14 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 134
ERROR - 2015-03-12 04:13:14 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 134
ERROR - 2015-03-12 04:13:14 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 134
ERROR - 2015-03-12 04:13:14 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 134
ERROR - 2015-03-12 04:13:14 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 134
ERROR - 2015-03-12 04:13:14 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 134
ERROR - 2015-03-12 04:13:14 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 134
ERROR - 2015-03-12 04:13:14 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 134
ERROR - 2015-03-12 04:13:14 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 134
ERROR - 2015-03-12 04:13:14 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 134
ERROR - 2015-03-12 04:13:14 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 134
ERROR - 2015-03-12 04:13:14 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 134
ERROR - 2015-03-12 04:13:14 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 134
ERROR - 2015-03-12 04:13:14 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 134
ERROR - 2015-03-12 04:13:14 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 134
ERROR - 2015-03-12 04:13:14 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 134
ERROR - 2015-03-12 04:13:14 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 134
ERROR - 2015-03-12 04:13:14 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 134
ERROR - 2015-03-12 04:13:14 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 134
ERROR - 2015-03-12 04:13:14 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 134
ERROR - 2015-03-12 04:13:14 --> Severity: Notice  --> Undefined variable: city C:\wamp\www\Esgotado\application\views\ongkir.php 149
ERROR - 2015-03-12 04:13:14 --> Severity: Notice  --> Undefined variable: district C:\wamp\www\Esgotado\application\views\ongkir.php 167
ERROR - 2015-03-12 04:13:14 --> 404 Page Not Found --> template
ERROR - 2015-03-12 04:14:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 04:14:08 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:14:08 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:14:08 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:14:08 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:14:08 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:14:08 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:14:08 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:14:08 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:14:08 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:14:08 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:14:08 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:14:08 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:14:08 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:14:08 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:14:08 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:14:08 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:14:08 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:14:08 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:14:08 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:14:08 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:14:08 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:14:08 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:14:08 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:14:08 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:14:08 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:14:08 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:14:08 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:14:08 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:14:08 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:14:08 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:14:08 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:14:08 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:14:08 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:14:08 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:14:08 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:14:08 --> Severity: Notice  --> Undefined variable: city C:\wamp\www\Esgotado\application\views\ongkir.php 71
ERROR - 2015-03-12 04:14:08 --> Severity: Notice  --> Undefined variable: district C:\wamp\www\Esgotado\application\views\ongkir.php 97
ERROR - 2015-03-12 04:14:08 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 134
ERROR - 2015-03-12 04:14:08 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 134
ERROR - 2015-03-12 04:14:08 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 134
ERROR - 2015-03-12 04:14:08 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 134
ERROR - 2015-03-12 04:14:08 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 134
ERROR - 2015-03-12 04:14:08 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 134
ERROR - 2015-03-12 04:14:08 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 134
ERROR - 2015-03-12 04:14:08 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 134
ERROR - 2015-03-12 04:14:08 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 134
ERROR - 2015-03-12 04:14:08 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 134
ERROR - 2015-03-12 04:14:08 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 134
ERROR - 2015-03-12 04:14:08 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 134
ERROR - 2015-03-12 04:14:08 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 134
ERROR - 2015-03-12 04:14:08 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 134
ERROR - 2015-03-12 04:14:08 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 134
ERROR - 2015-03-12 04:14:08 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 134
ERROR - 2015-03-12 04:14:08 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 134
ERROR - 2015-03-12 04:14:08 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 134
ERROR - 2015-03-12 04:14:08 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 134
ERROR - 2015-03-12 04:14:08 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 134
ERROR - 2015-03-12 04:14:08 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 134
ERROR - 2015-03-12 04:14:08 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 134
ERROR - 2015-03-12 04:14:08 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 134
ERROR - 2015-03-12 04:14:08 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 134
ERROR - 2015-03-12 04:14:08 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 134
ERROR - 2015-03-12 04:14:08 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 134
ERROR - 2015-03-12 04:14:08 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 134
ERROR - 2015-03-12 04:14:08 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 134
ERROR - 2015-03-12 04:14:08 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 134
ERROR - 2015-03-12 04:14:08 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 134
ERROR - 2015-03-12 04:14:08 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 134
ERROR - 2015-03-12 04:14:08 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 134
ERROR - 2015-03-12 04:14:08 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 134
ERROR - 2015-03-12 04:14:08 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 134
ERROR - 2015-03-12 04:14:08 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 134
ERROR - 2015-03-12 04:14:08 --> Severity: Notice  --> Undefined variable: city C:\wamp\www\Esgotado\application\views\ongkir.php 149
ERROR - 2015-03-12 04:14:08 --> Severity: Notice  --> Undefined variable: district C:\wamp\www\Esgotado\application\views\ongkir.php 167
ERROR - 2015-03-12 04:14:08 --> 404 Page Not Found --> template
ERROR - 2015-03-12 04:15:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 04:15:01 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:15:01 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:15:01 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:15:01 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:15:01 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:15:01 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:15:01 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:15:01 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:15:01 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:15:01 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:15:01 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:15:01 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:15:01 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:15:01 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:15:01 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:15:01 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:15:01 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:15:01 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:15:01 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:15:01 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:15:01 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:15:01 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:15:01 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:15:01 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:15:01 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:15:01 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:15:01 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:15:01 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:15:01 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:15:01 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:15:01 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:15:01 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:15:01 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:15:01 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:15:02 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:15:02 --> Severity: Notice  --> Undefined variable: city C:\wamp\www\Esgotado\application\views\ongkir.php 71
ERROR - 2015-03-12 04:15:02 --> Severity: Notice  --> Undefined variable: district C:\wamp\www\Esgotado\application\views\ongkir.php 97
ERROR - 2015-03-12 04:15:02 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 134
ERROR - 2015-03-12 04:15:02 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 134
ERROR - 2015-03-12 04:15:02 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 134
ERROR - 2015-03-12 04:15:02 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 134
ERROR - 2015-03-12 04:15:02 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 134
ERROR - 2015-03-12 04:15:02 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 134
ERROR - 2015-03-12 04:15:02 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 134
ERROR - 2015-03-12 04:15:02 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 134
ERROR - 2015-03-12 04:15:02 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 134
ERROR - 2015-03-12 04:15:02 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 134
ERROR - 2015-03-12 04:15:02 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 134
ERROR - 2015-03-12 04:15:02 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 134
ERROR - 2015-03-12 04:15:02 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 134
ERROR - 2015-03-12 04:15:02 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 134
ERROR - 2015-03-12 04:15:02 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 134
ERROR - 2015-03-12 04:15:02 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 134
ERROR - 2015-03-12 04:15:02 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 134
ERROR - 2015-03-12 04:15:02 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 134
ERROR - 2015-03-12 04:15:02 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 134
ERROR - 2015-03-12 04:15:02 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 134
ERROR - 2015-03-12 04:15:02 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 134
ERROR - 2015-03-12 04:15:02 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 134
ERROR - 2015-03-12 04:15:02 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 134
ERROR - 2015-03-12 04:15:02 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 134
ERROR - 2015-03-12 04:15:02 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 134
ERROR - 2015-03-12 04:15:02 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 134
ERROR - 2015-03-12 04:15:02 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 134
ERROR - 2015-03-12 04:15:02 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 134
ERROR - 2015-03-12 04:15:02 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 134
ERROR - 2015-03-12 04:15:02 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 134
ERROR - 2015-03-12 04:15:02 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 134
ERROR - 2015-03-12 04:15:02 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 134
ERROR - 2015-03-12 04:15:02 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 134
ERROR - 2015-03-12 04:15:02 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 134
ERROR - 2015-03-12 04:15:02 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 134
ERROR - 2015-03-12 04:15:02 --> Severity: Notice  --> Undefined variable: city C:\wamp\www\Esgotado\application\views\ongkir.php 149
ERROR - 2015-03-12 04:15:02 --> Severity: Notice  --> Undefined variable: district C:\wamp\www\Esgotado\application\views\ongkir.php 167
ERROR - 2015-03-12 04:15:02 --> 404 Page Not Found --> template
ERROR - 2015-03-12 04:16:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 04:16:14 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:16:14 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:16:14 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:16:14 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:16:14 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:16:14 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:16:14 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:16:15 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:16:15 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:16:15 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:16:15 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:16:15 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:16:15 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:16:15 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:16:15 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:16:15 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:16:15 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:16:15 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:16:15 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:16:15 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:16:15 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:16:15 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:16:15 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:16:15 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:16:15 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:16:15 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:16:15 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:16:15 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:16:15 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:16:15 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:16:15 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:16:15 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:16:15 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:16:15 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:16:15 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:16:15 --> Severity: Notice  --> Undefined variable: city C:\wamp\www\Esgotado\application\views\ongkir.php 71
ERROR - 2015-03-12 04:16:15 --> Severity: Notice  --> Undefined variable: district C:\wamp\www\Esgotado\application\views\ongkir.php 97
ERROR - 2015-03-12 04:16:15 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 141
ERROR - 2015-03-12 04:16:15 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 141
ERROR - 2015-03-12 04:16:15 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 141
ERROR - 2015-03-12 04:16:15 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 141
ERROR - 2015-03-12 04:16:15 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 141
ERROR - 2015-03-12 04:16:15 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 141
ERROR - 2015-03-12 04:16:15 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 141
ERROR - 2015-03-12 04:16:15 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 141
ERROR - 2015-03-12 04:16:15 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 141
ERROR - 2015-03-12 04:16:15 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 141
ERROR - 2015-03-12 04:16:15 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 141
ERROR - 2015-03-12 04:16:15 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 141
ERROR - 2015-03-12 04:16:15 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 141
ERROR - 2015-03-12 04:16:15 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 141
ERROR - 2015-03-12 04:16:15 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 141
ERROR - 2015-03-12 04:16:15 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 141
ERROR - 2015-03-12 04:16:15 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 141
ERROR - 2015-03-12 04:16:15 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 141
ERROR - 2015-03-12 04:16:15 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 141
ERROR - 2015-03-12 04:16:15 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 141
ERROR - 2015-03-12 04:16:15 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 141
ERROR - 2015-03-12 04:16:15 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 141
ERROR - 2015-03-12 04:16:15 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 141
ERROR - 2015-03-12 04:16:15 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 141
ERROR - 2015-03-12 04:16:15 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 141
ERROR - 2015-03-12 04:16:15 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 141
ERROR - 2015-03-12 04:16:15 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 141
ERROR - 2015-03-12 04:16:15 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 141
ERROR - 2015-03-12 04:16:15 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 141
ERROR - 2015-03-12 04:16:15 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 141
ERROR - 2015-03-12 04:16:15 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 141
ERROR - 2015-03-12 04:16:15 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 141
ERROR - 2015-03-12 04:16:15 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 141
ERROR - 2015-03-12 04:16:15 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 141
ERROR - 2015-03-12 04:16:15 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 141
ERROR - 2015-03-12 04:16:15 --> Severity: Notice  --> Undefined variable: city C:\wamp\www\Esgotado\application\views\ongkir.php 156
ERROR - 2015-03-12 04:16:15 --> Severity: Notice  --> Undefined variable: district C:\wamp\www\Esgotado\application\views\ongkir.php 174
ERROR - 2015-03-12 04:16:15 --> 404 Page Not Found --> template
ERROR - 2015-03-12 04:16:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 04:16:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 04:16:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 04:16:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 04:16:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 04:17:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 04:17:01 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:17:01 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:17:01 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:17:01 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:17:01 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:17:01 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:17:01 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:17:01 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:17:01 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:17:01 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:17:01 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:17:01 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:17:01 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:17:01 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:17:01 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:17:01 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:17:01 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:17:01 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:17:01 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:17:01 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:17:01 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:17:01 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:17:01 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:17:01 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:17:01 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:17:01 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:17:01 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:17:01 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:17:01 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:17:01 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:17:01 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:17:01 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:17:01 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:17:01 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:17:01 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:17:01 --> Severity: Notice  --> Undefined variable: city C:\wamp\www\Esgotado\application\views\ongkir.php 71
ERROR - 2015-03-12 04:17:01 --> Severity: Notice  --> Undefined variable: district C:\wamp\www\Esgotado\application\views\ongkir.php 97
ERROR - 2015-03-12 04:17:01 --> 404 Page Not Found --> template
ERROR - 2015-03-12 04:17:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 04:17:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 04:17:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 04:17:17 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:17:17 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:17:17 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:17:17 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:17:17 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:17:17 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:17:17 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:17:17 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:17:18 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:17:18 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:17:18 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:17:18 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:17:18 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:17:18 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:17:18 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:17:18 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:17:18 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:17:18 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:17:18 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:17:18 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:17:18 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:17:18 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:17:18 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:17:18 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:17:18 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:17:18 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:17:18 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:17:18 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:17:18 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:17:18 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:17:18 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:17:18 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:17:18 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:17:18 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:17:18 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:17:18 --> Severity: Notice  --> Undefined variable: city C:\wamp\www\Esgotado\application\views\ongkir.php 71
ERROR - 2015-03-12 04:17:18 --> Severity: Notice  --> Undefined variable: district C:\wamp\www\Esgotado\application\views\ongkir.php 97
ERROR - 2015-03-12 04:17:18 --> 404 Page Not Found --> template
ERROR - 2015-03-12 04:17:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 04:17:40 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:17:40 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:17:40 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:17:40 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:17:40 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:17:40 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:17:40 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:17:40 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:17:40 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:17:40 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:17:40 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:17:40 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:17:40 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:17:40 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:17:40 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:17:40 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:17:40 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:17:40 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:17:40 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:17:40 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:17:40 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:17:40 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:17:40 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:17:40 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:17:40 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:17:40 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:17:40 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:17:40 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:17:40 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:17:40 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:17:40 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:17:40 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:17:40 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:17:40 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:17:40 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:17:40 --> Severity: Notice  --> Undefined variable: city C:\wamp\www\Esgotado\application\views\ongkir.php 71
ERROR - 2015-03-12 04:17:40 --> Severity: Notice  --> Undefined variable: district C:\wamp\www\Esgotado\application\views\ongkir.php 97
ERROR - 2015-03-12 04:17:41 --> 404 Page Not Found --> template
ERROR - 2015-03-12 04:17:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 04:17:47 --> 404 Page Not Found --> template
ERROR - 2015-03-12 04:18:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 04:18:06 --> 404 Page Not Found --> template
ERROR - 2015-03-12 04:18:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 04:18:11 --> 404 Page Not Found --> template
ERROR - 2015-03-12 04:18:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 04:18:18 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:18:18 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:18:18 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:18:18 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:18:18 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:18:18 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:18:18 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:18:18 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:18:18 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:18:18 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:18:18 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:18:18 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:18:18 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:18:18 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:18:18 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:18:18 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:18:18 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:18:18 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:18:18 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:18:18 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:18:18 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:18:18 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:18:18 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:18:18 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:18:18 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:18:18 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:18:18 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:18:18 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:18:18 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:18:18 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:18:18 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:18:19 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:18:19 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:18:19 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:18:19 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:18:19 --> Severity: Notice  --> Undefined variable: city C:\wamp\www\Esgotado\application\views\ongkir.php 71
ERROR - 2015-03-12 04:18:19 --> Severity: Notice  --> Undefined variable: district C:\wamp\www\Esgotado\application\views\ongkir.php 97
ERROR - 2015-03-12 04:18:19 --> 404 Page Not Found --> template
ERROR - 2015-03-12 04:21:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 04:21:02 --> 404 Page Not Found --> template
ERROR - 2015-03-12 04:21:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 04:21:24 --> 404 Page Not Found --> template
ERROR - 2015-03-12 04:22:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 04:22:22 --> 404 Page Not Found --> template
ERROR - 2015-03-12 04:22:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 04:22:39 --> 404 Page Not Found --> template
ERROR - 2015-03-12 04:22:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 04:22:51 --> 404 Page Not Found --> template
ERROR - 2015-03-12 04:23:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 04:23:08 --> 404 Page Not Found --> template
ERROR - 2015-03-12 04:24:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 04:24:25 --> 404 Page Not Found --> template
ERROR - 2015-03-12 04:24:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 04:24:33 --> 404 Page Not Found --> template
ERROR - 2015-03-12 04:24:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 04:24:48 --> 404 Page Not Found --> template
ERROR - 2015-03-12 04:24:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 04:24:54 --> 404 Page Not Found --> template
ERROR - 2015-03-12 04:25:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 04:25:14 --> 404 Page Not Found --> template
ERROR - 2015-03-12 04:25:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 04:25:18 --> 404 Page Not Found --> template
ERROR - 2015-03-12 04:25:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 04:25:38 --> 404 Page Not Found --> template
ERROR - 2015-03-12 04:25:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 04:25:44 --> 404 Page Not Found --> template
ERROR - 2015-03-12 04:25:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 04:25:47 --> 404 Page Not Found --> template
ERROR - 2015-03-12 04:26:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 04:26:00 --> 404 Page Not Found --> template
ERROR - 2015-03-12 04:26:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 04:26:14 --> 404 Page Not Found --> template
ERROR - 2015-03-12 04:26:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 04:26:21 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:26:21 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:26:21 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:26:21 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:26:21 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:26:21 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:26:21 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:26:21 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:26:21 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:26:21 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:26:21 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:26:21 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:26:21 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:26:21 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:26:21 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:26:21 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:26:21 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:26:21 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:26:21 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:26:21 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:26:21 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:26:21 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:26:21 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:26:21 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:26:21 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:26:21 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:26:21 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:26:21 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:26:21 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:26:21 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:26:21 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:26:21 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:26:22 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:26:22 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:26:22 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:26:22 --> Severity: Notice  --> Undefined variable: city C:\wamp\www\Esgotado\application\views\ongkir.php 71
ERROR - 2015-03-12 04:26:22 --> Severity: Notice  --> Undefined variable: district C:\wamp\www\Esgotado\application\views\ongkir.php 97
ERROR - 2015-03-12 04:26:22 --> 404 Page Not Found --> template
ERROR - 2015-03-12 04:26:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 04:26:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 04:26:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 04:26:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 04:26:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 04:26:44 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:26:44 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:26:44 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:26:44 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:26:44 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:26:44 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:26:44 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:26:44 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:26:44 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:26:44 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:26:44 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:26:44 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:26:44 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:26:44 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:26:44 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:26:44 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:26:44 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:26:44 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:26:44 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:26:44 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:26:44 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:26:44 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:26:44 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:26:44 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:26:44 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:26:44 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:26:44 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:26:44 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:26:44 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:26:44 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:26:44 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:26:44 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:26:44 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:26:44 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:26:44 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:26:44 --> Severity: Notice  --> Undefined variable: city C:\wamp\www\Esgotado\application\views\ongkir.php 71
ERROR - 2015-03-12 04:26:44 --> Severity: Notice  --> Undefined variable: district C:\wamp\www\Esgotado\application\views\ongkir.php 97
ERROR - 2015-03-12 04:26:44 --> 404 Page Not Found --> template
ERROR - 2015-03-12 04:26:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 04:26:48 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:26:48 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:26:48 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:26:48 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:26:49 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:26:49 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:26:49 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:26:49 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:26:49 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:26:49 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:26:49 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:26:49 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:26:49 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:26:49 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:26:49 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:26:49 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:26:49 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:26:49 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:26:49 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:26:49 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:26:49 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:26:49 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:26:49 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:26:49 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:26:49 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:26:49 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:26:49 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:26:49 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:26:49 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:26:49 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:26:49 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:26:49 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:26:49 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:26:49 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:26:49 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:26:49 --> Severity: Notice  --> Undefined variable: city C:\wamp\www\Esgotado\application\views\ongkir.php 71
ERROR - 2015-03-12 04:26:49 --> Severity: Notice  --> Undefined variable: district C:\wamp\www\Esgotado\application\views\ongkir.php 97
ERROR - 2015-03-12 04:26:49 --> 404 Page Not Found --> template
ERROR - 2015-03-12 04:26:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 04:26:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 04:26:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 04:27:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 04:27:45 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:27:45 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:27:45 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:27:45 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:27:45 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:27:45 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:27:45 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:27:45 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:27:45 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:27:45 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:27:45 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:27:45 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:27:45 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:27:45 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:27:45 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:27:45 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:27:45 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:27:45 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:27:45 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:27:45 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:27:45 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:27:45 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:27:45 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:27:45 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:27:45 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:27:45 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:27:45 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:27:45 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:27:45 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:27:45 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:27:45 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:27:45 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:27:45 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:27:45 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:27:45 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:27:45 --> Severity: Notice  --> Undefined variable: city C:\wamp\www\Esgotado\application\views\ongkir.php 71
ERROR - 2015-03-12 04:27:45 --> Severity: Notice  --> Undefined variable: district C:\wamp\www\Esgotado\application\views\ongkir.php 97
ERROR - 2015-03-12 04:27:45 --> 404 Page Not Found --> template
ERROR - 2015-03-12 04:28:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 04:28:57 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:28:57 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:28:57 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:28:57 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:28:57 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:28:57 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:28:57 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:28:57 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:28:58 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:28:58 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:28:58 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:28:58 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:28:58 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:28:58 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:28:58 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:28:58 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:28:58 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:28:58 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:28:58 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:28:58 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:28:58 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:28:58 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:28:58 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:28:58 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:28:58 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:28:58 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:28:58 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:28:58 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:28:58 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:28:58 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:28:58 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:28:58 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:28:58 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:28:58 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:28:58 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:28:58 --> Severity: Notice  --> Undefined variable: city C:\wamp\www\Esgotado\application\views\ongkir.php 71
ERROR - 2015-03-12 04:28:58 --> Severity: Notice  --> Undefined variable: district C:\wamp\www\Esgotado\application\views\ongkir.php 97
ERROR - 2015-03-12 04:28:58 --> 404 Page Not Found --> template
ERROR - 2015-03-12 04:29:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 04:29:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 04:29:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 04:30:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 04:30:02 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:30:02 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:30:02 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:30:02 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:30:02 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:30:02 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:30:02 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:30:02 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:30:02 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:30:02 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:30:02 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:30:02 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:30:02 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:30:02 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:30:02 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:30:02 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:30:02 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:30:02 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:30:02 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:30:02 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:30:02 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:30:02 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:30:02 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:30:02 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:30:02 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:30:03 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:30:03 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:30:03 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:30:03 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:30:03 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:30:03 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:30:03 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:30:03 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:30:03 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:30:03 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:30:03 --> Severity: Notice  --> Undefined variable: city C:\wamp\www\Esgotado\application\views\ongkir.php 71
ERROR - 2015-03-12 04:30:03 --> Severity: Notice  --> Undefined variable: district C:\wamp\www\Esgotado\application\views\ongkir.php 97
ERROR - 2015-03-12 04:30:03 --> 404 Page Not Found --> template
ERROR - 2015-03-12 04:30:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 04:30:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 04:30:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 04:32:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 04:32:13 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:32:13 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:32:13 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:32:13 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:32:13 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:32:13 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:32:13 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:32:13 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:32:13 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:32:13 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:32:13 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:32:13 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:32:13 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:32:13 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:32:13 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:32:13 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:32:13 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:32:13 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:32:13 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:32:13 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:32:13 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:32:13 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:32:13 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:32:13 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:32:13 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:32:13 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:32:13 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:32:13 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:32:13 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:32:13 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:32:13 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:32:13 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:32:13 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:32:13 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:32:13 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:32:13 --> Severity: Notice  --> Undefined variable: city C:\wamp\www\Esgotado\application\views\ongkir.php 71
ERROR - 2015-03-12 04:32:13 --> Severity: Notice  --> Undefined variable: district C:\wamp\www\Esgotado\application\views\ongkir.php 97
ERROR - 2015-03-12 04:32:13 --> 404 Page Not Found --> template
ERROR - 2015-03-12 04:32:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 04:32:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 04:32:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 04:32:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 04:32:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 04:32:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 04:32:47 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:32:47 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:32:47 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:32:47 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:32:47 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:32:47 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:32:48 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:32:48 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:32:48 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:32:48 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:32:48 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:32:48 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:32:48 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:32:48 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:32:48 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:32:48 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:32:48 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:32:48 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:32:48 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:32:48 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:32:48 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:32:48 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:32:48 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:32:48 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:32:48 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:32:48 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:32:48 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:32:48 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:32:48 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:32:48 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:32:48 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:32:48 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:32:48 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:32:48 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:32:48 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:32:48 --> Severity: Notice  --> Undefined variable: city C:\wamp\www\Esgotado\application\views\ongkir.php 71
ERROR - 2015-03-12 04:32:48 --> Severity: Notice  --> Undefined variable: district C:\wamp\www\Esgotado\application\views\ongkir.php 97
ERROR - 2015-03-12 04:32:48 --> 404 Page Not Found --> template
ERROR - 2015-03-12 04:32:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 04:32:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 04:32:53 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:32:53 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:32:53 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:32:53 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:32:53 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:32:53 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:32:53 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:32:53 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:32:53 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:32:53 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:32:53 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:32:53 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:32:53 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:32:53 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:32:53 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:32:53 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:32:53 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:32:53 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:32:53 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:32:53 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:32:53 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:32:53 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:32:53 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:32:53 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:32:53 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:32:53 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:32:53 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:32:53 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:32:53 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:32:53 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:32:53 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:32:53 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:32:53 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:32:53 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:32:53 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:32:53 --> Severity: Notice  --> Undefined variable: city C:\wamp\www\Esgotado\application\views\ongkir.php 71
ERROR - 2015-03-12 04:32:53 --> Severity: Notice  --> Undefined variable: district C:\wamp\www\Esgotado\application\views\ongkir.php 97
ERROR - 2015-03-12 04:32:53 --> 404 Page Not Found --> template
ERROR - 2015-03-12 04:32:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 04:33:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 04:33:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 04:33:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 04:33:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 04:33:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 04:33:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 04:33:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 04:33:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 04:33:26 --> 404 Page Not Found --> template
ERROR - 2015-03-12 04:33:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 04:33:31 --> 404 Page Not Found --> template
ERROR - 2015-03-12 04:33:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 04:33:33 --> 404 Page Not Found --> template
ERROR - 2015-03-12 04:33:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 04:33:38 --> 404 Page Not Found --> template
ERROR - 2015-03-12 04:33:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 04:33:47 --> 404 Page Not Found --> template
ERROR - 2015-03-12 04:33:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 04:33:49 --> 404 Page Not Found --> template
ERROR - 2015-03-12 04:33:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 04:33:54 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:33:54 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:33:54 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:33:54 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:33:54 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:33:54 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:33:54 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:33:54 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:33:54 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:33:54 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:33:54 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:33:54 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:33:54 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:33:54 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:33:54 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:33:54 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:33:54 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:33:54 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:33:54 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:33:55 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:33:55 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:33:55 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:33:55 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:33:55 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:33:55 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:33:55 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:33:55 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:33:55 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:33:55 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:33:55 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:33:55 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:33:55 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:33:55 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:33:55 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:33:55 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 47
ERROR - 2015-03-12 04:33:55 --> Severity: Notice  --> Undefined variable: city C:\wamp\www\Esgotado\application\views\ongkir.php 71
ERROR - 2015-03-12 04:33:55 --> Severity: Notice  --> Undefined variable: district C:\wamp\www\Esgotado\application\views\ongkir.php 97
ERROR - 2015-03-12 04:33:55 --> 404 Page Not Found --> template
ERROR - 2015-03-12 04:33:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 04:34:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 04:34:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 04:34:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 04:34:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 04:34:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 04:34:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 04:34:20 --> 404 Page Not Found --> template
ERROR - 2015-03-12 04:35:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 04:35:19 --> Severity: Warning  --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\wamp\www\Esgotado\system\libraries\Email.php 1553
ERROR - 2015-03-12 04:35:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 04:35:19 --> 404 Page Not Found --> template
ERROR - 2015-03-12 04:35:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 04:35:39 --> 404 Page Not Found --> template
ERROR - 2015-03-12 04:36:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 04:36:01 --> 404 Page Not Found --> template
ERROR - 2015-03-12 04:38:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 04:38:41 --> 404 Page Not Found --> template
ERROR - 2015-03-12 04:38:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 04:38:51 --> 404 Page Not Found --> template
ERROR - 2015-03-12 04:38:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 04:38:55 --> 404 Page Not Found --> template
ERROR - 2015-03-12 04:39:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 04:39:24 --> 404 Page Not Found --> template
ERROR - 2015-03-12 04:39:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 04:39:30 --> 404 Page Not Found --> template
ERROR - 2015-03-12 04:39:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 04:40:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 04:40:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 04:40:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 04:40:34 --> Severity: Warning  --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\wamp\www\Esgotado\system\libraries\Email.php 1553
ERROR - 2015-03-12 04:40:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 04:40:34 --> 404 Page Not Found --> template
ERROR - 2015-03-12 04:40:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 04:40:53 --> 404 Page Not Found --> template
ERROR - 2015-03-12 04:40:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 04:40:55 --> 404 Page Not Found --> template
ERROR - 2015-03-12 04:41:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 04:41:02 --> 404 Page Not Found --> template
ERROR - 2015-03-12 04:41:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 04:41:06 --> 404 Page Not Found --> template
ERROR - 2015-03-12 04:41:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 04:41:08 --> 404 Page Not Found --> template
ERROR - 2015-03-12 04:41:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 04:41:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 04:41:14 --> 404 Page Not Found --> template
ERROR - 2015-03-12 04:41:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 04:41:23 --> 404 Page Not Found --> template
ERROR - 2015-03-12 04:41:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 04:41:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 04:41:33 --> 404 Page Not Found --> template
ERROR - 2015-03-12 04:41:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 04:41:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 04:41:50 --> 404 Page Not Found --> template
ERROR - 2015-03-12 04:41:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 04:41:52 --> 404 Page Not Found --> template
ERROR - 2015-03-12 04:47:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 04:47:02 --> 404 Page Not Found --> template
ERROR - 2015-03-12 04:47:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 04:47:07 --> 404 Page Not Found --> template
ERROR - 2015-03-12 16:30:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 16:30:46 --> Severity: Warning  --> mysql_pconnect(): No connection could be made because the target machine actively refused it.
 C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 16:30:46 --> Unable to connect to the database
ERROR - 2015-03-12 16:30:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 16:30:55 --> 404 Page Not Found --> template
ERROR - 2015-03-12 16:46:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 16:46:11 --> 404 Page Not Found --> template
ERROR - 2015-03-12 16:46:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 16:46:19 --> 404 Page Not Found --> template
ERROR - 2015-03-12 16:46:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 16:46:20 --> 404 Page Not Found --> template
ERROR - 2015-03-12 16:46:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 16:46:22 --> 404 Page Not Found --> template
ERROR - 2015-03-12 16:46:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 16:46:23 --> 404 Page Not Found --> template
ERROR - 2015-03-12 16:46:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 16:46:24 --> 404 Page Not Found --> template
ERROR - 2015-03-12 16:46:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 16:46:26 --> 404 Page Not Found --> template
ERROR - 2015-03-12 16:46:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 16:46:31 --> 404 Page Not Found --> template
ERROR - 2015-03-12 16:46:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 16:46:37 --> 404 Page Not Found --> template
ERROR - 2015-03-12 16:46:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 16:46:39 --> 404 Page Not Found --> template
ERROR - 2015-03-12 16:46:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 16:46:41 --> 404 Page Not Found --> template
ERROR - 2015-03-12 16:46:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 16:46:52 --> 404 Page Not Found --> template
ERROR - 2015-03-12 16:46:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 16:46:54 --> 404 Page Not Found --> template
ERROR - 2015-03-12 16:47:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-12 16:47:06 --> 404 Page Not Found --> template
