<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-11-20 03:44:14 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-20 03:44:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-20 03:44:14 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-20 03:44:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-20 03:44:14 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-20 03:44:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-20 03:44:14 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-20 03:44:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-20 03:44:14 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-20 03:44:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-20 03:44:14 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-20 03:44:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-20 03:44:58 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-20 03:44:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-20 03:44:58 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-20 03:44:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-20 03:44:58 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-20 03:44:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-20 03:44:58 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-20 03:44:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-20 03:44:58 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-20 03:44:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-20 03:44:58 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-20 03:44:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-20 03:44:58 --> Severity: Notice  --> Undefined variable: sub_category C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 88
ERROR - 2015-11-20 03:44:59 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-20 03:44:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-20 03:44:59 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-20 03:44:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-20 03:44:59 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-20 03:44:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-20 03:44:59 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-20 03:44:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-20 03:44:59 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-20 03:44:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-20 03:44:59 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-20 03:44:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-20 03:44:59 --> Severity: Notice  --> Undefined variable: sub_category C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 88
ERROR - 2015-11-20 03:45:34 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-20 03:45:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-20 03:45:34 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-20 03:45:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-20 03:45:34 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-20 03:45:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-20 03:45:34 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-20 03:45:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-20 03:45:34 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-20 03:45:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-20 03:45:34 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-20 03:45:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-20 03:45:34 --> Severity: Notice  --> Undefined variable: sub_category C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 88
ERROR - 2015-11-20 03:46:49 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-20 03:46:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-20 03:46:49 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-20 03:46:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-20 03:46:49 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-20 03:46:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-20 03:46:49 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-20 03:46:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-20 03:46:49 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-20 03:46:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-20 03:46:49 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-20 03:46:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 69
ERROR - 2015-11-20 03:46:49 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-20 03:46:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-20 03:46:49 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-20 03:46:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-20 03:46:49 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-20 03:46:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-20 03:46:49 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-20 03:46:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-20 03:46:49 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-20 03:46:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-20 03:46:49 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-20 03:46:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-20 03:46:49 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-20 03:46:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-20 03:46:49 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-20 03:46:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-20 03:46:49 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-20 03:46:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-20 03:46:49 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-20 03:46:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-20 03:46:49 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-20 03:46:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-20 03:46:49 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-20 03:46:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-20 03:46:49 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-20 03:46:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-20 03:46:49 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-20 03:46:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-20 03:46:49 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-20 03:46:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-20 03:46:49 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-20 03:46:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-20 03:46:49 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-20 03:46:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-20 03:46:49 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-20 03:46:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-20 03:46:49 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
ERROR - 2015-11-20 03:46:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\add_product.php 90
