<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-12-23 05:12:28 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-23 05:12:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-23 05:12:28 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-23 05:12:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-23 05:12:28 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-23 05:12:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-23 05:12:28 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-23 05:12:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-23 05:12:28 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-23 05:12:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-23 05:12:28 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-23 05:12:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-23 05:12:29 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-23 05:12:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-23 05:12:29 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-23 05:12:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-23 05:12:29 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-23 05:12:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-23 05:12:29 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-23 05:12:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-23 05:12:29 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-23 05:12:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-23 05:12:29 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-23 05:12:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-23 05:12:29 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-23 05:12:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-23 05:12:29 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-23 05:12:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-23 05:12:29 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-23 05:12:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-23 05:12:29 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-23 05:12:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-23 05:12:29 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-23 05:12:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-23 05:12:29 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-23 05:12:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-23 05:12:29 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-23 05:12:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-23 05:12:29 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-23 05:12:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-23 05:12:29 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-23 05:12:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-23 05:12:29 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-23 05:12:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-23 05:12:29 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-23 05:12:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-23 05:12:29 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-23 05:12:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-23 05:12:29 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-23 05:12:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-23 05:12:29 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-23 05:12:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-23 05:12:29 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-23 05:12:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-23 05:12:56 --> Query error: Unknown column 'weight' in 'field list'
ERROR - 2015-12-23 05:14:00 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-23 05:14:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-23 05:14:00 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-23 05:14:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-23 05:14:00 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-23 05:14:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-23 05:14:00 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-23 05:14:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-23 05:14:00 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-23 05:14:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-23 05:14:00 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-23 05:14:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-23 05:14:00 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-23 05:14:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-23 05:14:00 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-23 05:14:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-23 05:14:00 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-23 05:14:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-23 05:14:00 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-23 05:14:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-23 05:14:00 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-23 05:14:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-23 05:14:00 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-23 05:14:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-23 05:14:00 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-23 05:14:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-23 05:14:00 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-23 05:14:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-23 05:14:00 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-23 05:14:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-23 05:14:00 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-23 05:14:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-23 05:14:00 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-23 05:14:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-23 05:14:00 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-23 05:14:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-23 05:14:00 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-23 05:14:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-23 05:14:00 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-23 05:14:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-23 05:14:00 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-23 05:14:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-23 05:14:00 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-23 05:14:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-23 05:14:00 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-23 05:14:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-23 05:14:00 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-23 05:14:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-23 05:14:00 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-23 05:14:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-23 05:14:00 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-23 05:14:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-23 05:14:00 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-23 05:14:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-23 05:14:27 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-23 05:14:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-23 05:14:27 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-23 05:14:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-23 05:14:27 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-23 05:14:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-23 05:14:27 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-23 05:14:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-23 05:14:27 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-23 05:14:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-23 05:14:27 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-23 05:14:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-23 05:14:27 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-23 05:14:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-23 05:14:27 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-23 05:14:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-23 05:14:27 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-23 05:14:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-23 05:14:27 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-23 05:14:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-23 05:14:27 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-23 05:14:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-23 05:14:27 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-23 05:14:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-23 05:14:27 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-23 05:14:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-23 05:14:27 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-23 05:14:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-23 05:14:27 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-23 05:14:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-23 05:14:27 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-23 05:14:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-23 05:14:27 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-23 05:14:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-23 05:14:27 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-23 05:14:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-23 05:14:27 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-23 05:14:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-23 05:14:27 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-23 05:14:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-23 05:14:27 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-23 05:14:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-23 05:14:27 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-23 05:14:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-23 05:14:27 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-23 05:14:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-23 05:14:27 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-23 05:14:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-23 05:14:27 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-23 05:14:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-23 05:14:27 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-23 05:14:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-23 05:14:27 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-23 05:14:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
