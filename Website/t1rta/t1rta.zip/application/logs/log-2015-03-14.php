<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-03-14 01:19:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-14 01:19:25 --> 404 Page Not Found --> template
ERROR - 2015-03-14 01:19:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-14 01:20:00 --> 404 Page Not Found --> template
ERROR - 2015-03-14 01:20:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-14 01:20:27 --> 404 Page Not Found --> template
ERROR - 2015-03-14 01:20:28 --> 404 Page Not Found --> my_js
ERROR - 2015-03-14 01:21:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-14 01:21:20 --> 404 Page Not Found --> template
ERROR - 2015-03-14 01:21:20 --> 404 Page Not Found --> my_js
ERROR - 2015-03-14 01:22:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-14 01:22:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-14 01:22:43 --> 404 Page Not Found --> template
ERROR - 2015-03-14 01:22:43 --> 404 Page Not Found --> my_js
ERROR - 2015-03-14 01:22:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-14 01:22:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-14 01:22:47 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2015-03-14 01:22:47 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2015-03-14 01:22:47 --> 404 Page Not Found --> template
ERROR - 2015-03-14 01:22:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-14 01:22:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-14 01:22:52 --> 404 Page Not Found --> template
ERROR - 2015-03-14 01:22:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-14 01:22:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-14 01:22:58 --> 404 Page Not Found --> template
ERROR - 2015-03-14 01:22:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-14 01:22:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-14 01:23:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-14 01:23:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-14 01:23:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-14 01:23:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-14 01:24:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-14 01:24:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-14 01:24:08 --> 404 Page Not Found --> template
ERROR - 2015-03-14 01:24:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-14 01:24:29 --> Severity: Warning  --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\wamp\www\Esgotado\system\libraries\Email.php 1553
ERROR - 2015-03-14 01:24:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-14 01:24:30 --> 404 Page Not Found --> template
ERROR - 2015-03-14 01:25:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-14 01:25:18 --> 404 Page Not Found --> template
ERROR - 2015-03-14 01:25:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-14 01:25:36 --> 404 Page Not Found --> template
ERROR - 2015-03-14 01:25:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-14 01:25:37 --> 404 Page Not Found --> template
ERROR - 2015-03-14 01:25:37 --> 404 Page Not Found --> my_js
ERROR - 2015-03-14 01:25:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-14 01:25:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-14 01:25:41 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2015-03-14 01:25:41 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2015-03-14 01:25:41 --> 404 Page Not Found --> template
ERROR - 2015-03-14 01:25:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-14 01:25:44 --> 404 Page Not Found --> template
ERROR - 2015-03-14 01:25:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-14 01:25:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-14 01:25:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-14 01:25:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-14 01:25:50 --> 404 Page Not Found --> template
ERROR - 2015-03-14 01:27:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-14 01:27:02 --> 404 Page Not Found --> template
ERROR - 2015-03-14 01:27:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-14 01:27:04 --> 404 Page Not Found --> template
ERROR - 2015-03-14 01:27:04 --> 404 Page Not Found --> my_js
ERROR - 2015-03-14 01:27:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-14 01:27:10 --> 404 Page Not Found --> template
ERROR - 2015-03-14 01:27:10 --> 404 Page Not Found --> my_js
ERROR - 2015-03-14 01:27:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-14 01:27:20 --> 404 Page Not Found --> template
ERROR - 2015-03-14 01:27:20 --> 404 Page Not Found --> my_js
ERROR - 2015-03-14 01:35:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-14 01:35:33 --> 404 Page Not Found --> template
ERROR - 2015-03-14 01:35:33 --> 404 Page Not Found --> my_js
