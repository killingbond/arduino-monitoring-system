<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2014-09-06 11:46:10 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
ERROR - 2014-09-06 11:52:39 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-09-06 11:52:39 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-09-06 11:52:39 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-09-06 11:52:39 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-09-06 11:52:47 --> Severity: Warning  --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\wamp\www\Galaxia-Store\system\libraries\Email.php 1553
ERROR - 2014-09-06 11:53:44 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-09-06 11:53:44 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-09-06 11:53:44 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-09-06 11:53:44 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-09-06 11:53:51 --> Severity: Warning  --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\wamp\www\Galaxia-Store\system\libraries\Email.php 1553
ERROR - 2014-09-06 11:54:21 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-09-06 11:54:21 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-09-06 11:54:21 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-09-06 11:54:21 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-09-06 11:54:28 --> Severity: Warning  --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\wamp\www\Galaxia-Store\system\libraries\Email.php 1553
ERROR - 2014-09-06 11:56:08 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-09-06 11:56:08 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-09-06 11:56:08 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-09-06 11:56:08 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-09-06 11:56:14 --> Severity: Warning  --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\wamp\www\Galaxia-Store\system\libraries\Email.php 1553
ERROR - 2014-09-06 11:59:29 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-09-06 11:59:29 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-09-06 11:59:29 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-09-06 11:59:29 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-09-06 11:59:56 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-09-06 11:59:56 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-09-06 11:59:56 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-09-06 11:59:56 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-09-06 12:01:15 --> Severity: Warning  --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\wamp\www\Galaxia-Store\system\libraries\Email.php 1553
