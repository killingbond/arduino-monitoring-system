<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2014-09-08 14:56:15 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
