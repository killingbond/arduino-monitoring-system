<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2014-09-25 00:30:15 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-09-25 00:30:15 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-09-25 00:30:16 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-09-25 00:30:16 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-09-25 00:31:15 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-09-25 00:31:15 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-09-25 00:49:18 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-09-25 00:49:18 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-09-25 00:49:51 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-09-25 00:49:51 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-09-25 00:49:51 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-09-25 00:49:51 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-09-25 00:56:25 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-09-25 00:56:25 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-09-25 00:56:39 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-09-25 00:56:39 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-09-25 00:56:40 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-09-25 00:56:40 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-09-25 00:56:43 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-09-25 00:56:43 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-09-25 00:56:44 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-09-25 00:56:44 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-09-25 00:56:50 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-09-25 00:56:50 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-09-25 00:57:03 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-09-25 00:57:03 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-09-25 00:57:37 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-09-25 00:57:37 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-09-25 00:57:37 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-09-25 00:57:37 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-09-25 00:58:16 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-09-25 00:58:16 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-09-25 00:58:56 --> Severity: Warning  --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\wamp\www\Galaxia-Store\system\libraries\Email.php 1553
ERROR - 2014-09-25 00:59:17 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-09-25 00:59:17 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-09-25 00:59:17 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-09-25 00:59:17 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-09-25 00:59:32 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-09-25 00:59:32 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-09-25 00:59:32 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-09-25 00:59:32 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-09-25 00:59:55 --> Severity: Warning  --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\wamp\www\Galaxia-Store\system\libraries\Email.php 1553
ERROR - 2014-09-25 19:27:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Galaxia-Store\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-09-25 19:27:50 --> Unable to select database: galaxia_store
ERROR - 2014-09-25 19:29:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Galaxia-Store\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-09-25 19:29:48 --> Unable to select database: galaxia_store
ERROR - 2014-09-25 19:32:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Galaxia-Store\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-09-25 19:32:49 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
ERROR - 2014-09-25 19:42:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Galaxia-Store\system\database\drivers\mysql\mysql_driver.php 91
