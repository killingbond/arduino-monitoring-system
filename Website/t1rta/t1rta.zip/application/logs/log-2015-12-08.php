<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-12-08 10:41:55 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:41:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:41:55 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:41:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:41:55 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:41:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:41:55 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:41:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:41:55 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:41:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:41:55 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:41:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:41:55 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:41:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:41:55 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:41:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:41:55 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:41:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:41:55 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:41:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:41:55 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:41:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:41:55 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:41:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:41:55 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:41:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:41:55 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:41:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:41:55 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:41:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:41:55 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:41:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:41:55 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:41:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:41:55 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:41:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:41:55 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:41:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:41:55 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:41:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:41:55 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:41:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:41:55 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:41:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:41:55 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:41:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:41:55 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:41:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:41:55 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:41:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:41:55 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:41:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:43:52 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:43:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:43:52 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:43:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:43:52 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:43:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:43:52 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:43:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:43:52 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:43:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:43:52 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:43:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:43:52 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:43:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:43:52 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:43:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:43:52 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:43:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:43:52 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:43:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:43:52 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:43:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:43:52 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:43:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:43:52 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:43:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:43:52 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:43:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:43:52 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:43:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:43:52 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:43:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:43:52 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:43:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:43:52 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:43:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:43:52 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:43:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:43:52 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:43:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:43:52 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:43:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:43:52 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:43:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:43:52 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:43:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:43:52 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:43:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:43:52 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:43:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:43:52 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:43:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:44:59 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:44:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:44:59 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:44:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:44:59 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:44:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:44:59 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:44:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:44:59 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:44:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:44:59 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:44:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:44:59 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:44:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:44:59 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:44:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:44:59 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:44:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:44:59 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:44:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:44:59 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:44:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:44:59 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:44:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:44:59 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:44:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:44:59 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:44:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:44:59 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:44:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:44:59 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:44:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:44:59 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:44:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:44:59 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:44:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:44:59 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:44:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:44:59 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:44:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:44:59 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:44:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:44:59 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:44:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:44:59 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:44:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:44:59 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:44:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:44:59 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:44:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:44:59 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:44:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:45:43 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:45:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:45:43 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:45:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:45:43 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:45:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:45:43 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:45:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:45:43 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:45:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:45:43 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:45:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:45:43 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:45:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:45:43 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:45:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:45:43 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:45:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:45:43 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:45:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:45:43 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:45:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:45:43 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:45:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:45:43 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:45:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:45:43 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:45:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:45:43 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:45:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:45:43 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:45:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:45:43 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:45:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:45:43 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:45:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:45:43 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:45:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:45:43 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:45:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:45:43 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:45:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:45:43 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:45:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:45:43 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:45:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:45:43 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:45:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:45:43 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:45:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:45:43 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:45:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:45:46 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:45:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:45:46 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:45:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:45:46 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:45:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:45:46 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:45:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:45:46 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:45:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:45:46 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:45:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:45:46 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:45:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:45:46 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:45:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:45:46 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:45:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:45:46 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:45:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:45:46 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:45:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:45:46 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:45:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:45:46 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:45:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:45:46 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:45:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:45:46 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:45:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:45:46 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:45:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:45:46 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:45:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:45:46 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:45:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:45:46 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:45:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:45:46 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:45:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:45:46 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:45:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:45:46 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:45:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:45:46 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:45:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:45:46 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:45:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:45:46 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:45:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:45:46 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:45:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:46:46 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:46:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:46:46 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:46:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:46:46 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:46:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:46:46 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:46:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:46:46 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:46:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:46:46 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:46:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:46:46 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:46:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:46:46 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:46:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:46:46 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:46:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:46:46 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:46:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:46:46 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:46:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:46:46 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:46:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:46:46 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:46:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:46:46 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:46:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:46:46 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:46:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:46:46 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:46:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:46:46 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:46:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:46:46 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:46:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:46:46 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:46:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:46:46 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:46:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:46:46 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:46:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:46:46 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:46:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:46:46 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:46:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:46:46 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:46:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:46:46 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:46:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:46:46 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:46:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:33 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:47:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:47:33 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:47:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:47:33 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:47:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:47:33 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:47:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:47:33 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:47:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:47:33 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:47:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:47:33 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:33 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:33 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:33 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:33 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:33 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:33 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:33 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:33 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:33 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:33 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:33 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:33 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:33 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:33 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:33 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:33 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:33 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:33 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:33 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:34 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:47:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:47:34 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:47:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:47:34 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:47:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:47:34 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:47:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:47:34 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:47:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:47:34 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:47:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:47:34 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:34 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:34 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:34 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:34 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:34 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:34 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:34 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:34 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:34 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:34 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:34 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:34 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:34 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:34 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:34 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:34 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:34 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:34 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:34 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:47 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:47:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:47:47 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:47:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:47:47 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:47:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:47:47 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:47:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:47:47 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:47:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:47:47 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:47:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:47:47 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:47 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:47 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:47 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:47 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:47 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:47 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:47 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:47 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:47 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:47 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:47 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:47 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:47 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:47 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:47 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:47 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:47 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:47 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:47 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:51 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:47:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:47:51 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:47:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:47:51 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:47:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:47:51 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:47:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:47:51 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:47:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:47:51 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:47:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:47:51 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:51 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:51 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:51 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:51 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:51 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:51 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:51 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:51 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:51 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:51 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:51 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:51 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:51 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:51 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:51 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:51 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:51 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:51 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:51 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:47:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:48:03 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:48:03 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:48:03 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:48:03 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:48:03 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:48:03 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:48:03 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:48:03 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:48:03 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:48:03 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:48:03 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:48:03 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:48:03 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:48:03 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:48:03 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:48:03 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:48:03 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:48:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:48:04 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:48:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:48:04 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:48:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:48:04 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:48:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:48:04 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:48:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:48:04 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:48:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:48:04 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:48:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:48:04 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:48:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:48:04 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:48:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:48:04 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:48:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:48:04 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:48:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:48:04 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:48:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:48:04 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:48:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:48:04 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:48:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:48:04 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:48:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:48:04 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:48:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:48:04 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:48:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:48:04 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:48:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:48:23 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:48:23 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:48:23 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:48:23 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:48:23 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:48:23 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:48:23 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:48:23 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:48:23 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:48:23 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:48:23 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:48:23 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:48:23 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:48:23 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:48:23 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:48:23 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:48:23 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:48:23 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:48:23 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:48:23 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:48:23 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:48:23 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:48:23 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:48:23 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:48:23 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:48:23 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:48:23 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:48:23 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:48:23 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:48:23 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:48:23 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:48:24 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:48:24 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:48:24 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:48:24 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:48:24 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:48:24 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:48:24 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:48:24 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:48:24 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:48:24 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:48:24 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:48:24 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:48:24 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:48:24 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:48:24 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:48:24 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:48:24 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:48:24 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:48:24 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:48:24 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:48:24 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:48:53 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:48:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:48:53 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:48:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:48:53 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:48:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:48:53 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:48:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:48:53 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:48:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:48:53 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:48:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:48:53 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:48:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:48:53 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:48:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:48:54 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:48:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:48:54 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:48:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:48:54 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:48:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:48:54 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:48:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:48:54 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:48:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:48:54 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:48:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:48:54 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:48:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:48:54 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:48:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:48:54 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:48:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:48:54 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:48:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:48:54 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:48:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:48:54 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:48:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:48:54 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:48:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:48:54 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:48:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:48:54 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:48:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:48:54 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:48:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:48:54 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:48:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:48:54 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:48:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:49:04 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:49:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:49:04 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:49:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:49:04 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:49:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:49:04 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:49:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:49:04 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:49:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:49:04 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:49:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:49:04 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:49:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:49:04 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:49:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:49:04 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:49:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:49:04 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:49:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:49:04 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:49:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:49:04 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:49:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:49:04 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:49:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:49:04 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:49:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:49:04 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:49:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:49:04 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:49:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:49:04 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:49:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:49:04 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:49:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:49:04 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:49:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:49:04 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:49:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:49:04 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:49:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:49:04 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:49:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:49:04 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:49:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:49:04 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:49:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:49:04 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:49:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:49:04 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:49:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:51:24 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:51:24 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:51:24 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:51:24 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:51:24 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:51:24 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:51:24 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:51:24 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:51:24 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:51:24 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:51:24 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:51:24 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:51:24 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:51:24 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:51:24 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:51:24 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:51:24 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:51:24 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:51:24 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:51:24 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:51:24 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:51:24 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:51:24 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:51:24 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:51:24 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:51:24 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:51:24 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:51:24 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:51:24 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:51:24 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:51:24 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:51:24 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:51:24 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:51:24 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:51:24 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:51:24 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:51:24 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:51:24 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:51:24 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:51:24 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:51:24 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:51:24 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:51:24 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:51:24 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:51:24 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:51:24 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:51:24 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:51:24 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:51:24 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:51:24 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:51:24 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:51:24 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:54:06 --> Severity: Notice  --> Undefined property: stdClass::$description C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\edit_product.php 109
ERROR - 2015-12-08 10:55:26 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:55:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:55:26 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:55:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:55:26 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:55:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:55:26 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:55:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:55:26 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:55:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:55:26 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:55:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:55:26 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:55:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:55:26 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:55:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:55:26 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:55:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:55:26 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:55:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:55:26 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:55:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:55:26 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:55:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:55:26 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:55:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:55:26 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:55:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:55:26 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:55:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:55:26 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:55:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:55:26 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:55:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:55:27 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:55:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:55:27 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:55:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:55:27 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:55:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:55:27 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:55:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:55:27 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:55:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:55:27 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:55:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:55:27 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:55:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:55:27 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:55:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:55:27 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:55:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:56:03 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:56:03 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:56:03 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:56:03 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:56:03 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:56:03 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:56:03 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:56:03 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:56:03 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:56:03 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:56:03 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:56:03 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:56:03 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:56:03 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:56:03 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:56:03 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:56:03 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:56:03 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:56:03 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:56:03 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:56:03 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:56:03 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:56:03 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:56:03 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:56:03 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:56:03 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:56:03 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:56:03 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:56:03 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:56:03 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:56:03 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:56:03 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:56:03 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:56:03 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:56:03 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:56:03 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:56:03 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:56:03 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:56:03 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:56:03 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:56:03 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:56:03 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:56:03 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:56:03 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:56:03 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:56:03 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:56:03 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:56:03 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:56:03 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:56:03 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:56:03 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:56:03 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:59:05 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:59:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:59:05 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:59:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:59:05 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:59:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:59:05 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:59:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:59:05 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:59:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:59:05 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:59:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 10:59:05 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:59:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:59:05 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:59:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:59:05 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:59:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:59:05 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:59:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:59:05 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:59:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:59:05 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:59:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:59:05 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:59:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:59:05 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:59:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:59:05 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:59:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:59:05 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:59:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:59:05 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:59:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:59:06 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:59:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:59:06 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:59:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:59:06 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:59:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:59:06 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:59:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:59:06 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:59:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:59:06 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:59:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:59:06 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:59:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:59:06 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:59:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:59:06 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 10:59:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:02:41 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:02:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:02:41 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:02:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:02:42 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:02:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:02:42 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:02:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:02:42 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:02:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:02:42 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:02:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:02:42 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:02:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:02:42 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:02:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:02:42 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:02:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:02:42 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:02:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:02:42 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:02:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:02:42 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:02:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:02:42 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:02:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:02:42 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:02:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:02:42 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:02:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:02:42 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:02:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:02:42 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:02:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:02:42 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:02:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:02:42 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:02:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:02:42 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:02:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:02:42 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:02:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:02:42 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:02:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:02:42 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:02:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:02:42 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:02:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:02:42 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:02:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:02:42 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:02:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:04:12 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:04:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:04:12 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:04:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:04:12 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:04:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:04:12 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:04:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:04:12 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:04:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:04:12 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:04:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:04:12 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:04:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:04:12 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:04:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:04:12 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:04:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:04:12 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:04:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:04:12 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:04:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:04:12 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:04:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:04:12 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:04:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:04:12 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:04:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:04:12 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:04:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:04:12 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:04:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:04:12 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:04:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:04:12 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:04:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:04:12 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:04:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:04:12 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:04:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:04:12 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:04:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:04:12 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:04:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:04:12 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:04:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:04:12 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:04:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:04:12 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:04:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:04:12 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:04:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:05:10 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:05:10 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:05:10 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:05:10 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:05:10 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:05:10 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:05:10 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:05:10 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:05:10 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:05:10 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:05:10 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:05:10 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:05:10 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:05:10 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:05:10 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:05:10 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:05:10 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:05:10 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:05:10 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:05:10 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:05:10 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:05:10 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:05:10 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:05:10 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:05:10 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:05:10 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:05:10 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:05:10 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:05:10 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:05:10 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:05:10 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:05:10 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:05:10 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:05:10 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:05:10 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:05:10 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:05:10 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:05:10 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:05:10 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:05:10 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:05:11 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:05:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:05:11 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:05:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:05:11 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:05:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:05:11 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:05:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:05:11 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:05:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:05:11 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:05:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:10:18 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:10:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:10:18 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:10:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:10:18 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:10:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:10:18 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:10:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:10:18 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:10:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:10:18 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:10:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:10:18 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:10:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:10:18 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:10:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:10:18 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:10:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:10:18 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:10:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:10:18 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:10:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:10:18 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:10:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:10:18 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:10:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:10:18 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:10:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:10:18 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:10:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:10:18 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:10:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:10:18 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:10:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:10:18 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:10:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:10:18 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:10:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:10:18 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:10:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:10:18 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:10:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:10:18 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:10:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:10:18 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:10:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:10:18 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:10:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:10:18 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:10:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:10:18 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:10:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:11:39 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:11:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:11:39 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:11:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:11:39 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:11:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:11:39 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:11:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:11:39 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:11:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:11:39 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:11:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:11:39 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:11:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:11:39 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:11:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:11:39 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:11:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:11:39 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:11:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:11:39 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:11:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:11:39 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:11:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:11:39 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:11:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:11:39 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:11:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:11:39 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:11:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:11:39 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:11:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:11:39 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:11:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:11:39 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:11:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:11:39 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:11:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:11:39 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:11:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:11:39 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:11:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:11:39 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:11:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:11:39 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:11:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:11:39 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:11:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:11:39 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:11:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:11:39 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:11:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:13:17 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:13:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:13:17 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:13:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:13:17 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:13:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:13:17 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:13:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:13:17 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:13:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:13:17 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:13:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:13:17 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:13:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:13:17 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:13:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:13:17 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:13:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:13:17 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:13:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:13:17 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:13:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:13:17 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:13:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:13:17 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:13:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:13:17 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:13:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:13:17 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:13:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:13:17 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:13:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:13:17 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:13:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:13:17 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:13:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:13:17 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:13:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:13:17 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:13:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:13:17 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:13:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:13:17 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:13:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:13:17 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:13:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:13:17 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:13:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:13:17 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:13:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:13:17 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:13:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:14:08 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:14:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:14:08 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:14:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:14:08 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:14:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:14:08 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:14:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:14:08 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:14:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:14:08 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:14:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:14:08 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:14:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:14:08 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:14:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:14:08 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:14:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:14:08 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:14:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:14:08 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:14:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:14:08 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:14:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:14:08 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:14:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:14:08 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:14:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:14:08 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:14:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:14:08 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:14:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:14:08 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:14:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:14:08 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:14:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:14:08 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:14:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:14:08 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:14:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:14:08 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:14:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:14:09 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:14:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:14:09 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:14:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:14:09 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:14:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:14:09 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:14:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:14:09 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:14:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:15:04 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:15:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:15:04 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:15:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:15:04 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:15:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:15:04 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:15:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:15:04 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:15:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:15:04 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:15:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:15:04 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:15:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:15:04 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:15:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:15:04 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:15:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:15:04 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:15:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:15:04 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:15:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:15:04 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:15:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:15:04 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:15:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:15:04 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:15:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:15:04 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:15:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:15:04 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:15:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:15:04 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:15:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:15:04 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:15:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:15:04 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:15:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:15:04 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:15:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:15:04 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:15:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:15:04 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:15:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:15:04 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:15:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:15:04 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:15:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:15:04 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:15:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:15:04 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:15:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:15:32 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:15:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:15:32 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:15:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:15:32 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:15:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:15:32 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:15:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:15:32 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:15:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:15:32 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:15:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:15:32 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:15:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:15:32 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:15:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:15:32 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:15:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:15:32 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:15:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:15:32 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:15:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:15:32 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:15:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:15:32 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:15:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:15:32 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:15:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:15:32 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:15:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:15:32 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:15:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:15:32 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:15:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:15:32 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:15:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:15:32 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:15:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:15:32 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:15:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:15:32 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:15:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:15:32 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:15:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:15:32 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:15:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:15:32 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:15:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:15:32 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:15:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:15:32 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:15:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:16:27 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:16:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:16:27 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:16:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:16:27 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:16:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:16:27 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:16:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:16:27 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:16:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:16:27 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:16:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:16:27 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:16:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:16:27 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:16:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:16:27 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:16:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:16:27 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:16:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:16:27 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:16:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:16:27 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:16:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:16:27 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:16:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:16:28 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:16:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:16:28 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:16:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:16:28 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:16:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:16:28 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:16:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:16:28 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:16:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:16:28 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:16:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:16:28 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:16:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:16:28 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:16:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:16:28 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:16:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:16:28 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:16:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:16:28 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:16:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:16:28 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:16:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:16:28 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:16:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:17:18 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:17:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:17:18 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:17:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:17:18 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:17:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:17:18 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:17:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:17:18 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:17:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:17:18 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:17:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:17:18 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:17:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:17:18 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:17:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:17:18 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:17:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:17:18 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:17:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:17:18 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:17:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:17:18 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:17:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:17:18 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:17:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:17:18 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:17:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:17:18 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:17:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:17:18 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:17:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:17:18 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:17:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:17:18 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:17:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:17:18 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:17:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:17:18 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:17:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:17:18 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:17:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:17:18 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:17:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:17:18 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:17:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:17:18 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:17:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:17:18 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:17:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:17:18 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:17:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:17:52 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:17:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:17:52 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:17:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:17:52 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:17:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:17:52 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:17:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:17:52 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:17:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:17:52 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:17:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:17:52 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:17:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:17:52 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:17:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:17:52 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:17:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:17:52 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:17:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:17:52 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:17:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:17:52 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:17:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:17:52 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:17:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:17:52 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:17:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:17:52 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:17:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:17:52 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:17:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:17:52 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:17:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:17:52 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:17:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:17:52 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:17:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:17:52 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:17:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:17:52 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:17:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:17:52 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:17:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:17:52 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:17:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:17:52 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:17:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:17:52 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:17:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:17:52 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:17:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:17:59 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:18:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:18:00 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:18:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:18:00 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:18:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:18:00 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:18:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:18:00 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:18:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:18:00 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:18:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:18:00 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:00 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:00 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:00 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:00 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:00 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:00 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:00 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:00 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:00 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:00 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:00 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:00 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:00 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:00 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:00 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:00 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:00 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:00 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:00 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:31 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:18:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:18:31 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:18:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:18:31 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:18:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:18:31 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:18:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:18:31 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:18:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:18:31 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:18:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:18:31 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:31 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:31 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:31 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:31 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:32 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:32 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:32 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:32 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:32 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:32 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:32 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:32 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:32 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:32 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:32 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:32 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:32 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:32 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:32 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:37 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:18:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:18:37 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:18:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:18:37 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:18:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:18:37 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:18:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:18:37 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:18:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:18:37 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:18:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:18:37 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:37 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:37 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:37 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:37 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:37 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:37 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:37 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:37 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:37 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:37 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:37 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:37 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:37 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:37 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:37 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:37 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:37 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:37 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:37 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:42 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:18:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:18:42 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:18:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:18:42 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:18:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:18:42 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:18:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:18:42 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:18:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:18:42 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:18:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:18:42 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:42 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:42 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:42 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:42 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:42 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:42 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:42 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:42 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:42 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:42 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:42 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:42 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:42 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:42 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:42 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:42 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:42 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:42 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:42 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:18:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:19:09 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:19:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:19:09 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:19:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:19:09 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:19:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:19:09 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:19:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:19:09 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:19:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:19:09 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:19:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:19:09 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:19:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:19:09 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:19:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:19:09 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:19:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:19:09 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:19:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:19:09 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:19:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:19:09 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:19:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:19:09 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:19:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:19:09 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:19:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:19:09 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:19:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:19:09 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:19:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:19:09 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:19:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:19:09 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:19:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:19:09 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:19:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:19:09 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:19:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:19:09 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:19:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:19:09 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:19:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:19:09 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:19:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:19:09 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:19:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:19:09 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:19:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:19:09 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:19:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:19:20 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:19:20 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:19:20 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:19:20 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:19:20 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:19:20 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:19:21 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:19:21 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:19:21 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:19:21 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:19:21 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:19:21 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:19:21 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:19:21 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:19:21 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:19:21 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:19:21 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:19:21 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:19:21 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:19:21 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:19:21 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:19:21 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:19:21 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:19:21 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:19:21 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:19:21 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:19:21 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:19:21 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:19:21 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:19:21 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:19:21 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:19:21 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:19:21 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:19:21 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:19:21 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:19:21 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:19:21 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:19:21 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:19:21 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:19:21 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:19:21 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:19:21 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:19:21 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:19:21 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:19:21 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:19:21 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:19:21 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:19:21 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:19:21 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:19:21 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:19:21 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:19:21 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:20:00 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:20:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:20:00 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:20:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:20:00 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:20:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:20:00 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:20:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:20:00 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:20:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:20:00 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:20:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:20:00 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:20:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:20:00 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:20:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:20:00 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:20:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:20:00 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:20:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:20:00 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:20:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:20:00 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:20:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:20:00 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:20:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:20:00 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:20:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:20:00 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:20:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:20:00 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:20:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:20:00 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:20:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:20:00 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:20:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:20:00 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:20:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:20:00 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:20:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:20:00 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:20:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:20:00 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:20:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:20:00 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:20:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:20:00 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:20:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:20:00 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:20:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:20:00 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:20:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:20:04 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:20:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:20:04 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:20:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:20:04 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:20:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:20:04 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:20:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:20:04 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:20:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:20:04 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:20:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:20:04 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:20:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:20:04 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:20:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:20:04 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:20:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:20:04 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:20:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:20:04 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:20:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:20:04 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:20:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:20:04 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:20:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:20:04 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:20:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:20:04 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:20:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:20:04 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:20:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:20:04 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:20:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:20:04 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:20:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:20:04 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:20:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:20:04 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:20:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:20:04 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:20:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:20:04 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:20:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:20:04 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:20:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:20:05 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:20:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:20:05 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:20:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:20:05 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:20:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:21:30 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:21:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:21:30 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:21:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:21:30 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:21:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:21:30 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:21:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:21:30 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:21:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:21:30 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:21:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-08 11:21:30 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:21:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:21:30 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:21:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:21:30 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:21:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:21:30 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:21:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:21:30 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:21:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:21:30 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:21:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:21:30 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:21:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:21:30 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:21:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:21:30 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:21:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:21:30 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:21:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:21:30 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:21:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:21:30 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:21:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:21:31 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:21:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:21:31 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:21:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:21:31 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:21:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:21:31 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:21:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:21:31 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:21:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:21:31 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:21:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:21:31 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:21:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:21:31 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-08 11:21:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
