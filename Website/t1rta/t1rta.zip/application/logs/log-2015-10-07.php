<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-10-07 08:38:42 --> 404 Page Not Found --> index2.html
ERROR - 2015-10-07 08:38:48 --> 404 Page Not Found --> index2.html
ERROR - 2015-10-07 08:38:49 --> 404 Page Not Found --> index2.html
ERROR - 2015-10-07 10:20:19 --> Query error: Table 'ozantcom_wassuphaters.notification' doesn't exist
ERROR - 2015-10-07 12:06:25 --> Severity: Warning  --> escapeshellarg() has been disabled for security reasons /home/ozantcom/public_html/wassuphaters.com/w4zzup/system/libraries/Upload.php 1066
ERROR - 2015-10-07 12:08:26 --> You did not select a file to upload.
ERROR - 2015-10-07 12:11:00 --> Severity: Warning  --> escapeshellarg() has been disabled for security reasons /home/ozantcom/public_html/wassuphaters.com/w4zzup/system/libraries/Upload.php 1066
ERROR - 2015-10-07 12:12:20 --> You did not select a file to upload.
ERROR - 2015-10-07 12:13:00 --> You did not select a file to upload.
ERROR - 2015-10-07 12:14:08 --> You did not select a file to upload.
ERROR - 2015-10-07 12:15:45 --> You did not select a file to upload.
ERROR - 2015-10-07 12:17:56 --> You did not select a file to upload.
ERROR - 2015-10-07 12:19:56 --> You did not select a file to upload.
