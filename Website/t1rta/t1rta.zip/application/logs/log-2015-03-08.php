<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-03-08 02:58:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 02:58:55 --> 404 Page Not Found --> template
ERROR - 2015-03-08 02:58:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 02:58:59 --> 404 Page Not Found --> template
ERROR - 2015-03-08 02:59:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 02:59:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 02:59:11 --> 404 Page Not Found --> template
ERROR - 2015-03-08 02:59:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 02:59:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 02:59:21 --> 404 Page Not Found --> template
ERROR - 2015-03-08 02:59:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 02:59:24 --> 404 Page Not Found --> template
ERROR - 2015-03-08 02:59:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 03:00:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 03:00:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 03:02:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 03:02:44 --> 404 Page Not Found --> template
ERROR - 2015-03-08 03:04:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 03:04:41 --> 404 Page Not Found --> template
ERROR - 2015-03-08 03:08:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 03:08:09 --> 404 Page Not Found --> template
ERROR - 2015-03-08 03:09:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 03:09:27 --> 404 Page Not Found --> template
ERROR - 2015-03-08 03:10:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 03:10:43 --> 404 Page Not Found --> template
ERROR - 2015-03-08 03:11:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 03:11:45 --> 404 Page Not Found --> template
ERROR - 2015-03-08 03:13:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 03:13:20 --> 404 Page Not Found --> template
ERROR - 2015-03-08 03:14:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 03:14:38 --> 404 Page Not Found --> template
ERROR - 2015-03-08 03:15:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 03:15:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 03:15:32 --> 404 Page Not Found --> template
ERROR - 2015-03-08 03:18:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 03:18:33 --> Severity: Notice  --> unserialize(): Error at offset 0 of 415 bytes /Applications/MAMP/htdocs/Esgotado/system/libraries/Session.php 724
ERROR - 2015-03-08 03:18:33 --> 404 Page Not Found --> template
ERROR - 2015-03-08 03:18:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 03:18:36 --> 404 Page Not Found --> template
ERROR - 2015-03-08 03:18:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 03:18:49 --> 404 Page Not Found --> template
ERROR - 2015-03-08 03:18:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 03:18:52 --> 404 Page Not Found --> template
ERROR - 2015-03-08 03:18:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 03:18:56 --> 404 Page Not Found --> template
ERROR - 2015-03-08 03:18:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 03:18:59 --> 404 Page Not Found --> template
ERROR - 2015-03-08 03:19:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 03:19:05 --> 404 Page Not Found --> template
ERROR - 2015-03-08 03:19:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 03:19:09 --> 404 Page Not Found --> template
ERROR - 2015-03-08 03:19:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 03:19:24 --> 404 Page Not Found --> template
ERROR - 2015-03-08 03:19:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 03:19:26 --> 404 Page Not Found --> template
ERROR - 2015-03-08 03:19:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 03:19:36 --> 404 Page Not Found --> template
ERROR - 2015-03-08 03:22:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 03:22:33 --> 404 Page Not Found --> template
ERROR - 2015-03-08 03:22:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 03:22:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 03:22:36 --> 404 Page Not Found --> template
ERROR - 2015-03-08 03:22:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 03:22:58 --> 404 Page Not Found --> template
ERROR - 2015-03-08 03:28:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 03:28:39 --> 404 Page Not Found --> template
ERROR - 2015-03-08 03:28:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 03:28:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 03:28:41 --> 404 Page Not Found --> template
ERROR - 2015-03-08 03:28:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 03:28:57 --> 404 Page Not Found --> template
ERROR - 2015-03-08 03:28:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 03:28:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 03:29:00 --> 404 Page Not Found --> template
ERROR - 2015-03-08 03:30:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 03:30:10 --> 404 Page Not Found --> template
ERROR - 2015-03-08 03:30:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 03:30:18 --> 404 Page Not Found --> template
ERROR - 2015-03-08 03:30:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 03:30:26 --> 404 Page Not Found --> template
ERROR - 2015-03-08 03:30:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 03:30:51 --> 404 Page Not Found --> template
ERROR - 2015-03-08 03:31:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 03:31:32 --> 404 Page Not Found --> template
ERROR - 2015-03-08 03:31:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 03:31:35 --> 404 Page Not Found --> template
ERROR - 2015-03-08 03:34:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 03:34:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 03:34:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 03:38:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 03:38:13 --> 404 Page Not Found --> template
ERROR - 2015-03-08 03:43:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 03:43:25 --> 404 Page Not Found --> template
ERROR - 2015-03-08 03:44:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 03:44:01 --> 404 Page Not Found --> template
ERROR - 2015-03-08 03:44:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 03:44:07 --> 404 Page Not Found --> template
ERROR - 2015-03-08 03:44:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 03:44:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 03:44:44 --> 404 Page Not Found --> template
ERROR - 2015-03-08 03:44:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 03:44:49 --> 404 Page Not Found --> template
ERROR - 2015-03-08 03:44:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 03:44:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 03:44:52 --> 404 Page Not Found --> template
ERROR - 2015-03-08 03:45:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 03:45:25 --> 404 Page Not Found --> template
ERROR - 2015-03-08 03:45:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 03:45:59 --> 404 Page Not Found --> template
ERROR - 2015-03-08 03:46:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 03:46:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 03:46:02 --> 404 Page Not Found --> template
ERROR - 2015-03-08 03:46:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 03:46:08 --> 404 Page Not Found --> template
ERROR - 2015-03-08 03:50:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 03:50:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 03:50:45 --> 404 Page Not Found --> template
ERROR - 2015-03-08 03:51:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 03:51:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 03:51:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 03:52:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 03:52:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 03:52:04 --> 404 Page Not Found --> template
ERROR - 2015-03-08 03:53:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 03:53:40 --> 404 Page Not Found --> template
ERROR - 2015-03-08 03:53:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 03:53:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 03:53:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 03:54:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 03:54:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 03:54:02 --> 404 Page Not Found --> template
ERROR - 2015-03-08 03:54:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 03:54:52 --> 404 Page Not Found --> template
ERROR - 2015-03-08 03:54:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 03:55:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 03:55:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 03:55:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 03:55:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 03:55:08 --> 404 Page Not Found --> template
ERROR - 2015-03-08 03:59:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 03:59:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 03:59:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 03:59:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 04:04:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 04:04:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 04:07:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 04:07:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 04:07:46 --> 404 Page Not Found --> template
ERROR - 2015-03-08 04:07:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 04:07:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 04:07:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 04:08:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 04:08:36 --> 404 Page Not Found --> template
ERROR - 2015-03-08 04:08:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 04:08:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 04:08:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 04:08:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 04:09:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 04:09:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 04:09:13 --> 404 Page Not Found --> template
ERROR - 2015-03-08 04:14:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 04:14:54 --> 404 Page Not Found --> template
ERROR - 2015-03-08 04:14:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 04:14:57 --> 404 Page Not Found --> template
ERROR - 2015-03-08 04:17:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 04:17:14 --> 404 Page Not Found --> template
ERROR - 2015-03-08 04:17:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 04:17:32 --> 404 Page Not Found --> template
ERROR - 2015-03-08 04:17:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 04:17:40 --> 404 Page Not Found --> template
ERROR - 2015-03-08 04:18:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 04:18:49 --> 404 Page Not Found --> template
ERROR - 2015-03-08 04:18:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 04:18:51 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/Esgotado/application/controllers/autoload.php:35) /Applications/MAMP/htdocs/Esgotado/system/core/Output.php 391
ERROR - 2015-03-08 04:18:51 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/Esgotado/application/controllers/autoload.php:35) /Applications/MAMP/htdocs/Esgotado/system/core/Output.php 391
ERROR - 2015-03-08 04:18:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 04:18:52 --> 404 Page Not Found --> template
ERROR - 2015-03-08 04:18:52 --> 404 Page Not Found --> my_js
ERROR - 2015-03-08 04:19:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 04:19:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 04:19:00 --> Severity: Notice  --> Undefined variable: percent_ppn /Applications/MAMP/htdocs/Esgotado/application/views/cart.php 137
ERROR - 2015-03-08 04:19:00 --> Severity: Notice  --> Undefined variable: ppn /Applications/MAMP/htdocs/Esgotado/application/views/cart.php 137
ERROR - 2015-03-08 04:19:01 --> 404 Page Not Found --> template
ERROR - 2015-03-08 04:19:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 04:19:06 --> 404 Page Not Found --> template
ERROR - 2015-03-08 04:19:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 04:19:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 04:19:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 04:19:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 04:19:10 --> 404 Page Not Found --> template
ERROR - 2015-03-08 04:19:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 04:19:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 04:19:14 --> 404 Page Not Found --> template
ERROR - 2015-03-08 04:19:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 04:19:20 --> 404 Page Not Found --> template
ERROR - 2015-03-08 04:19:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 04:19:22 --> 404 Page Not Found --> template
ERROR - 2015-03-08 04:19:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 04:19:39 --> 404 Page Not Found --> template
ERROR - 2015-03-08 04:20:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 04:20:07 --> 404 Page Not Found --> template
ERROR - 2015-03-08 04:21:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 04:21:34 --> 404 Page Not Found --> template
ERROR - 2015-03-08 04:21:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 04:21:51 --> 404 Page Not Found --> template
ERROR - 2015-03-08 04:24:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 04:24:02 --> 404 Page Not Found --> template
ERROR - 2015-03-08 04:24:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 04:24:24 --> 404 Page Not Found --> template
ERROR - 2015-03-08 04:24:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 04:24:52 --> 404 Page Not Found --> template
ERROR - 2015-03-08 04:25:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 04:25:14 --> 404 Page Not Found --> template
ERROR - 2015-03-08 04:25:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 04:25:40 --> 404 Page Not Found --> template
ERROR - 2015-03-08 04:26:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 04:26:08 --> 404 Page Not Found --> template
ERROR - 2015-03-08 04:26:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 04:26:20 --> 404 Page Not Found --> template
ERROR - 2015-03-08 04:26:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 04:26:37 --> 404 Page Not Found --> template
ERROR - 2015-03-08 04:27:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 04:27:01 --> 404 Page Not Found --> template
ERROR - 2015-03-08 04:27:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 04:27:17 --> 404 Page Not Found --> template
ERROR - 2015-03-08 04:27:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 04:27:31 --> 404 Page Not Found --> template
ERROR - 2015-03-08 04:27:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 04:27:47 --> 404 Page Not Found --> template
ERROR - 2015-03-08 04:28:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 04:28:01 --> 404 Page Not Found --> template
ERROR - 2015-03-08 04:28:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 04:28:18 --> 404 Page Not Found --> template
ERROR - 2015-03-08 04:28:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 04:28:36 --> 404 Page Not Found --> template
ERROR - 2015-03-08 04:28:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 04:28:46 --> 404 Page Not Found --> template
ERROR - 2015-03-08 04:28:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 04:28:59 --> 404 Page Not Found --> template
ERROR - 2015-03-08 04:29:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 04:29:18 --> 404 Page Not Found --> template
ERROR - 2015-03-08 04:29:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 04:29:34 --> 404 Page Not Found --> template
ERROR - 2015-03-08 04:29:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 04:29:58 --> 404 Page Not Found --> template
ERROR - 2015-03-08 04:30:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 04:30:01 --> 404 Page Not Found --> template
ERROR - 2015-03-08 04:31:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 04:31:23 --> 404 Page Not Found --> template
ERROR - 2015-03-08 04:36:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 04:36:08 --> Severity: Notice  --> unserialize(): Error at offset 0 of 415 bytes /Applications/MAMP/htdocs/Esgotado/system/libraries/Session.php 724
ERROR - 2015-03-08 04:36:08 --> 404 Page Not Found --> template
ERROR - 2015-03-08 04:36:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 04:36:11 --> 404 Page Not Found --> template
ERROR - 2015-03-08 04:36:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 04:36:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 04:36:15 --> 404 Page Not Found --> template
ERROR - 2015-03-08 04:36:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 04:36:19 --> 404 Page Not Found --> template
ERROR - 2015-03-08 04:36:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 04:36:20 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/Esgotado/application/controllers/autoload.php:35) /Applications/MAMP/htdocs/Esgotado/system/core/Output.php 391
ERROR - 2015-03-08 04:36:20 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/Esgotado/application/controllers/autoload.php:35) /Applications/MAMP/htdocs/Esgotado/system/core/Output.php 391
ERROR - 2015-03-08 04:36:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 04:36:21 --> 404 Page Not Found --> template
ERROR - 2015-03-08 04:36:21 --> 404 Page Not Found --> my_js
ERROR - 2015-03-08 04:36:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 04:36:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 04:36:23 --> Severity: Notice  --> Undefined variable: percent_ppn /Applications/MAMP/htdocs/Esgotado/application/views/cart.php 137
ERROR - 2015-03-08 04:36:23 --> Severity: Notice  --> Undefined variable: ppn /Applications/MAMP/htdocs/Esgotado/application/views/cart.php 137
ERROR - 2015-03-08 04:36:23 --> 404 Page Not Found --> template
ERROR - 2015-03-08 04:36:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 04:36:25 --> 404 Page Not Found --> template
ERROR - 2015-03-08 04:36:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 04:36:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 04:40:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 04:40:44 --> 404 Page Not Found --> template
ERROR - 2015-03-08 04:41:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 04:41:50 --> 404 Page Not Found --> template
ERROR - 2015-03-08 04:41:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 04:41:52 --> 404 Page Not Found --> template
ERROR - 2015-03-08 04:42:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 04:42:25 --> 404 Page Not Found --> template
ERROR - 2015-03-08 04:42:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 04:42:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 04:42:31 --> 404 Page Not Found --> template
ERROR - 2015-03-08 04:42:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 04:42:33 --> 404 Page Not Found --> template
ERROR - 2015-03-08 04:42:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 04:42:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 04:42:40 --> 404 Page Not Found --> template
ERROR - 2015-03-08 04:42:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 04:42:42 --> 404 Page Not Found --> template
ERROR - 2015-03-08 04:43:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 04:43:15 --> 404 Page Not Found --> template
ERROR - 2015-03-08 04:43:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 04:43:59 --> 404 Page Not Found --> template
ERROR - 2015-03-08 04:44:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 04:44:34 --> 404 Page Not Found --> template
ERROR - 2015-03-08 04:45:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 04:45:05 --> 404 Page Not Found --> template
ERROR - 2015-03-08 04:45:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 04:45:11 --> 404 Page Not Found --> template
ERROR - 2015-03-08 04:45:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 04:45:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 04:45:55 --> 404 Page Not Found --> template
ERROR - 2015-03-08 04:46:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 04:46:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 04:46:00 --> 404 Page Not Found --> template
ERROR - 2015-03-08 04:46:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 04:46:04 --> 404 Page Not Found --> template
ERROR - 2015-03-08 04:47:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 04:47:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 04:47:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 04:47:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 04:47:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 04:47:41 --> 404 Page Not Found --> template
ERROR - 2015-03-08 04:51:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 04:51:58 --> 404 Page Not Found --> template
ERROR - 2015-03-08 04:52:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 04:52:12 --> 404 Page Not Found --> template
ERROR - 2015-03-08 04:52:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 04:52:15 --> 404 Page Not Found --> template
ERROR - 2015-03-08 05:07:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 05:07:40 --> Severity: Notice  --> unserialize(): Error at offset 0 of 412 bytes /Applications/MAMP/htdocs/Esgotado/system/libraries/Session.php 724
ERROR - 2015-03-08 05:07:40 --> 404 Page Not Found --> template
ERROR - 2015-03-08 05:07:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 05:07:45 --> 404 Page Not Found --> template
ERROR - 2015-03-08 05:07:45 --> 404 Page Not Found --> my_js
ERROR - 2015-03-08 05:08:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 05:08:03 --> 404 Page Not Found --> my_js
ERROR - 2015-03-08 05:08:03 --> 404 Page Not Found --> template
ERROR - 2015-03-08 05:08:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 05:08:38 --> 404 Page Not Found --> template
ERROR - 2015-03-08 05:08:38 --> 404 Page Not Found --> my_js
ERROR - 2015-03-08 05:08:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 05:08:50 --> 404 Page Not Found --> template
ERROR - 2015-03-08 05:08:50 --> 404 Page Not Found --> my_js
ERROR - 2015-03-08 05:09:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 05:09:20 --> 404 Page Not Found --> my_js
ERROR - 2015-03-08 05:09:20 --> 404 Page Not Found --> template
ERROR - 2015-03-08 05:11:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 05:11:42 --> Severity: Notice  --> Undefined property: stdClass::$description /Applications/MAMP/htdocs/Esgotado/application/views/product_detail.php 69
ERROR - 2015-03-08 05:11:42 --> Severity: Notice  --> Undefined property: stdClass::$description /Applications/MAMP/htdocs/Esgotado/application/views/product_detail.php 69
ERROR - 2015-03-08 05:11:43 --> 404 Page Not Found --> template
ERROR - 2015-03-08 05:11:43 --> 404 Page Not Found --> my_js
ERROR - 2015-03-08 05:12:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 05:12:05 --> 404 Page Not Found --> template
ERROR - 2015-03-08 05:12:05 --> 404 Page Not Found --> my_js
ERROR - 2015-03-08 05:15:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 05:15:04 --> 404 Page Not Found --> template
ERROR - 2015-03-08 05:15:04 --> 404 Page Not Found --> my_js
ERROR - 2015-03-08 05:15:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 05:15:18 --> 404 Page Not Found --> template
ERROR - 2015-03-08 05:15:18 --> 404 Page Not Found --> my_js
ERROR - 2015-03-08 05:16:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 05:16:11 --> 404 Page Not Found --> template
ERROR - 2015-03-08 05:16:11 --> 404 Page Not Found --> my_js
ERROR - 2015-03-08 05:17:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 05:17:11 --> 404 Page Not Found --> template
ERROR - 2015-03-08 05:17:11 --> 404 Page Not Found --> my_js
ERROR - 2015-03-08 05:18:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 05:18:14 --> 404 Page Not Found --> my_js
ERROR - 2015-03-08 05:18:14 --> 404 Page Not Found --> template
ERROR - 2015-03-08 05:18:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 05:18:25 --> 404 Page Not Found --> template
ERROR - 2015-03-08 05:18:25 --> 404 Page Not Found --> my_js
ERROR - 2015-03-08 05:19:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 05:19:13 --> 404 Page Not Found --> my_js
ERROR - 2015-03-08 05:19:13 --> 404 Page Not Found --> template
ERROR - 2015-03-08 05:21:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 05:21:43 --> 404 Page Not Found --> template
ERROR - 2015-03-08 05:21:50 --> 404 Page Not Found --> template
ERROR - 2015-03-08 05:25:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 05:25:12 --> Severity: Notice  --> unserialize(): Error at offset 0 of 319 bytes /Applications/MAMP/htdocs/Esgotado/system/libraries/Session.php 724
ERROR - 2015-03-08 05:25:13 --> 404 Page Not Found --> template
ERROR - 2015-03-08 05:26:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 05:26:09 --> 404 Page Not Found --> template
ERROR - 2015-03-08 05:26:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 05:26:21 --> 404 Page Not Found --> template
ERROR - 2015-03-08 05:26:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 05:26:23 --> 404 Page Not Found --> template
ERROR - 2015-03-08 05:26:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 05:26:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 05:26:29 --> 404 Page Not Found --> template
ERROR - 2015-03-08 05:48:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 05:48:51 --> 404 Page Not Found --> template
ERROR - 2015-03-08 05:48:51 --> 404 Page Not Found --> template
ERROR - 2015-03-08 05:48:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 05:48:57 --> 404 Page Not Found --> template
ERROR - 2015-03-08 05:48:57 --> 404 Page Not Found --> template
ERROR - 2015-03-08 05:49:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 05:49:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 05:49:08 --> 404 Page Not Found --> template
ERROR - 2015-03-08 05:49:08 --> 404 Page Not Found --> template
ERROR - 2015-03-08 05:49:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 05:49:41 --> 404 Page Not Found --> template
ERROR - 2015-03-08 05:49:41 --> 404 Page Not Found --> template
ERROR - 2015-03-08 05:49:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 05:49:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 05:57:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 05:57:14 --> Severity: Notice  --> Undefined property: Checker::$session /Applications/MAMP/htdocs/Esgotado/application/libraries/Checker.php 15
ERROR - 2015-03-08 05:57:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 05:58:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 05:58:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 05:58:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 06:01:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 06:01:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 06:01:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 06:13:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 06:14:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 06:14:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 06:14:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 06:14:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 06:14:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 06:15:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 06:15:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 06:15:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 06:15:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 06:15:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 06:15:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 06:15:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 06:15:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 06:15:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 06:17:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 06:17:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 06:17:06 --> 404 Page Not Found --> template
ERROR - 2015-03-08 06:17:08 --> 404 Page Not Found --> template
ERROR - 2015-03-08 06:17:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 06:17:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 06:17:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 06:17:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 06:18:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 06:18:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 06:18:09 --> 404 Page Not Found --> template
ERROR - 2015-03-08 06:18:19 --> 404 Page Not Found --> template
ERROR - 2015-03-08 06:18:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 06:18:55 --> 404 Page Not Found --> template
ERROR - 2015-03-08 06:18:55 --> 404 Page Not Found --> template
ERROR - 2015-03-08 06:18:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 06:18:56 --> 404 Page Not Found --> template
ERROR - 2015-03-08 06:18:56 --> 404 Page Not Found --> template
ERROR - 2015-03-08 06:18:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 06:19:00 --> 404 Page Not Found --> template
ERROR - 2015-03-08 06:19:00 --> 404 Page Not Found --> template
ERROR - 2015-03-08 06:19:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 06:19:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 06:20:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 06:20:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 06:20:46 --> 404 Page Not Found --> template
ERROR - 2015-03-08 06:20:46 --> 404 Page Not Found --> template
ERROR - 2015-03-08 06:30:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 06:30:38 --> 404 Page Not Found --> template
ERROR - 2015-03-08 06:30:38 --> 404 Page Not Found --> template
ERROR - 2015-03-08 06:31:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 06:31:52 --> 404 Page Not Found --> template
ERROR - 2015-03-08 06:31:52 --> 404 Page Not Found --> template
ERROR - 2015-03-08 06:41:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 06:41:04 --> 404 Page Not Found --> template
ERROR - 2015-03-08 06:41:04 --> 404 Page Not Found --> template
ERROR - 2015-03-08 06:41:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 06:41:07 --> 404 Page Not Found --> template
ERROR - 2015-03-08 06:41:07 --> 404 Page Not Found --> template
ERROR - 2015-03-08 06:41:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 06:41:09 --> 404 Page Not Found --> template
ERROR - 2015-03-08 06:41:09 --> 404 Page Not Found --> template
ERROR - 2015-03-08 06:41:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 06:41:14 --> 404 Page Not Found --> template
ERROR - 2015-03-08 06:41:14 --> 404 Page Not Found --> template
ERROR - 2015-03-08 06:51:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 06:51:49 --> 404 Page Not Found --> template
ERROR - 2015-03-08 06:51:49 --> 404 Page Not Found --> template
ERROR - 2015-03-08 06:51:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 06:51:54 --> 404 Page Not Found --> template
ERROR - 2015-03-08 06:51:54 --> 404 Page Not Found --> template
ERROR - 2015-03-08 06:51:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 06:51:56 --> 404 Page Not Found --> template
ERROR - 2015-03-08 06:51:56 --> 404 Page Not Found --> template
ERROR - 2015-03-08 06:51:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 06:51:58 --> 404 Page Not Found --> template
ERROR - 2015-03-08 06:51:58 --> 404 Page Not Found --> template
ERROR - 2015-03-08 06:51:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 06:51:59 --> 404 Page Not Found --> template
ERROR - 2015-03-08 06:51:59 --> 404 Page Not Found --> template
ERROR - 2015-03-08 06:53:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 06:53:08 --> 404 Page Not Found --> template
ERROR - 2015-03-08 06:53:09 --> 404 Page Not Found --> template
ERROR - 2015-03-08 06:53:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 06:53:18 --> 404 Page Not Found --> template
ERROR - 2015-03-08 06:53:18 --> 404 Page Not Found --> template
ERROR - 2015-03-08 06:53:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 06:53:40 --> 404 Page Not Found --> template
ERROR - 2015-03-08 06:53:40 --> 404 Page Not Found --> template
ERROR - 2015-03-08 06:53:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 06:53:57 --> 404 Page Not Found --> template
ERROR - 2015-03-08 06:53:57 --> 404 Page Not Found --> template
ERROR - 2015-03-08 06:54:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 06:54:10 --> 404 Page Not Found --> template
ERROR - 2015-03-08 06:54:11 --> 404 Page Not Found --> template
ERROR - 2015-03-08 06:54:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 06:54:28 --> 404 Page Not Found --> template
ERROR - 2015-03-08 06:54:28 --> 404 Page Not Found --> template
ERROR - 2015-03-08 06:55:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 06:55:15 --> 404 Page Not Found --> template
ERROR - 2015-03-08 06:55:15 --> 404 Page Not Found --> template
ERROR - 2015-03-08 06:55:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 06:55:24 --> 404 Page Not Found --> template
ERROR - 2015-03-08 06:55:24 --> 404 Page Not Found --> template
ERROR - 2015-03-08 06:55:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 06:55:58 --> 404 Page Not Found --> template
ERROR - 2015-03-08 06:55:59 --> 404 Page Not Found --> template
ERROR - 2015-03-08 06:56:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 06:56:49 --> 404 Page Not Found --> template
ERROR - 2015-03-08 06:56:49 --> 404 Page Not Found --> template
ERROR - 2015-03-08 07:09:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 07:09:42 --> 404 Page Not Found --> template
ERROR - 2015-03-08 07:24:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 07:37:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 07:37:53 --> 404 Page Not Found --> template
ERROR - 2015-03-08 07:37:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 07:37:57 --> 404 Page Not Found --> template
ERROR - 2015-03-08 07:54:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 07:54:56 --> 404 Page Not Found --> template
ERROR - 2015-03-08 11:20:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 11:20:54 --> 404 Page Not Found --> template
ERROR - 2015-03-08 11:21:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 11:21:52 --> 404 Page Not Found --> template
ERROR - 2015-03-08 11:21:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 11:21:57 --> 404 Page Not Found --> template
ERROR - 2015-03-08 11:22:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 11:22:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 11:22:05 --> 404 Page Not Found --> template
ERROR - 2015-03-08 11:22:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 11:22:08 --> 404 Page Not Found --> template
ERROR - 2015-03-08 11:22:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 11:22:09 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/Esgotado/application/controllers/autoload.php:33) /Applications/MAMP/htdocs/Esgotado/system/core/Output.php 391
ERROR - 2015-03-08 11:22:09 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/Esgotado/application/controllers/autoload.php:33) /Applications/MAMP/htdocs/Esgotado/system/core/Output.php 391
ERROR - 2015-03-08 11:22:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 11:22:10 --> 404 Page Not Found --> template
ERROR - 2015-03-08 11:22:10 --> 404 Page Not Found --> my_js
ERROR - 2015-03-08 11:22:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 11:22:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 11:22:16 --> Severity: Notice  --> Undefined variable: percent_ppn /Applications/MAMP/htdocs/Esgotado/application/views/cart.php 137
ERROR - 2015-03-08 11:22:16 --> Severity: Notice  --> Undefined variable: ppn /Applications/MAMP/htdocs/Esgotado/application/views/cart.php 137
ERROR - 2015-03-08 11:22:16 --> 404 Page Not Found --> template
ERROR - 2015-03-08 11:22:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 11:22:19 --> 404 Page Not Found --> template
ERROR - 2015-03-08 11:22:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 11:22:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 11:27:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 11:27:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 11:27:34 --> 404 Page Not Found --> template
ERROR - 2015-03-08 11:27:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 11:27:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 11:27:37 --> 404 Page Not Found --> template
ERROR - 2015-03-08 13:44:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 13:44:04 --> 404 Page Not Found --> template
ERROR - 2015-03-08 15:08:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 15:08:09 --> 404 Page Not Found --> template
ERROR - 2015-03-08 15:08:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-08 15:08:17 --> 404 Page Not Found --> template
