<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-12-19 07:27:18 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-19 07:27:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-19 07:27:18 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-19 07:27:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-19 07:27:18 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-19 07:27:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-19 07:27:18 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-19 07:27:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-19 07:27:18 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-19 07:27:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-19 07:27:18 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-19 07:27:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-19 07:27:18 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 07:27:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 07:27:18 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 07:27:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 07:27:18 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 07:27:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 07:27:18 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 07:27:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 07:27:18 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 07:27:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 07:27:18 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 07:27:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 07:27:18 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 07:27:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 07:27:18 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 07:27:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 07:27:18 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 07:27:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 07:27:18 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 07:27:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 07:27:18 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 07:27:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 07:27:19 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 07:27:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 07:27:19 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 07:27:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 07:27:19 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 07:27:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 07:27:19 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 07:27:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 07:27:19 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 07:27:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 07:27:19 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 07:27:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 07:27:19 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 07:27:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 07:27:19 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 07:27:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 07:27:19 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 07:27:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 07:27:41 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-19 07:27:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-19 07:27:41 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-19 07:27:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-19 07:27:41 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-19 07:27:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-19 07:27:41 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-19 07:27:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-19 07:27:41 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-19 07:27:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-19 07:27:41 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-19 07:27:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-19 07:27:41 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 07:27:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 07:27:41 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 07:27:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 07:27:41 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 07:27:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 07:27:41 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 07:27:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 07:27:41 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 07:27:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 07:27:41 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 07:27:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 07:27:41 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 07:27:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 07:27:41 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 07:27:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 07:27:41 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 07:27:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 07:27:41 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 07:27:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 07:27:41 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 07:27:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 07:27:41 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 07:27:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 07:27:41 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 07:27:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 07:27:41 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 07:27:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 07:27:41 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 07:27:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 07:27:41 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 07:27:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 07:27:41 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 07:27:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 07:27:41 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 07:27:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 07:27:41 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 07:27:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 07:27:41 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 07:27:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 09:50:43 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-19 09:50:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-19 09:50:43 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-19 09:50:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-19 09:50:44 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-19 09:50:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-19 09:50:44 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-19 09:50:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-19 09:50:44 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-19 09:50:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-19 09:50:44 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-19 09:50:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-19 09:50:44 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 09:50:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 09:50:44 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 09:50:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 09:50:44 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 09:50:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 09:50:44 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 09:50:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 09:50:44 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 09:50:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 09:50:44 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 09:50:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 09:50:44 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 09:50:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 09:50:44 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 09:50:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 09:50:44 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 09:50:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 09:50:44 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 09:50:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 09:50:44 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 09:50:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 09:50:44 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 09:50:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 09:50:44 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 09:50:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 09:50:44 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 09:50:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 09:50:44 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 09:50:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 09:50:44 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 09:50:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 09:50:44 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 09:50:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 09:50:44 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 09:50:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 09:50:44 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 09:50:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 09:50:44 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 09:50:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 09:55:27 --> The uploaded file exceeds the maximum allowed size in your PHP configuration file.
ERROR - 2015-12-19 09:55:39 --> The uploaded file exceeds the maximum allowed size in your PHP configuration file.
ERROR - 2015-12-19 09:55:53 --> The uploaded file exceeds the maximum allowed size in your PHP configuration file.
ERROR - 2015-12-19 10:00:52 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-19 10:00:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-19 10:00:52 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-19 10:00:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-19 10:00:52 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-19 10:00:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-19 10:00:52 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-19 10:00:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-19 10:00:52 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-19 10:00:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-19 10:00:52 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-19 10:00:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-19 10:00:52 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 10:00:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 10:00:52 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 10:00:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 10:00:52 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 10:00:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 10:00:52 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 10:00:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 10:00:52 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 10:00:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 10:00:52 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 10:00:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 10:00:52 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 10:00:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 10:00:52 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 10:00:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 10:00:52 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 10:00:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 10:00:52 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 10:00:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 10:00:52 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 10:00:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 10:00:52 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 10:00:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 10:00:52 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 10:00:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 10:00:52 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 10:00:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 10:00:52 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 10:00:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 10:00:52 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 10:00:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 10:00:52 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 10:00:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 10:00:52 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 10:00:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 10:00:52 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 10:00:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 10:00:52 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 10:00:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 10:12:54 --> The uploaded file exceeds the maximum allowed size in your PHP configuration file.
ERROR - 2015-12-19 10:16:36 --> Severity: Notice  --> Undefined variable: max C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\slidecollection\slidecollection.php 50
ERROR - 2015-12-19 10:16:36 --> Severity: Notice  --> Undefined variable: max C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\slidecollection\slidecollection.php 51
ERROR - 2015-12-19 10:16:36 --> Severity: Notice  --> Undefined variable: max C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\slidecollection\slidecollection.php 52
ERROR - 2015-12-19 10:16:36 --> Severity: Notice  --> Undefined variable: max C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\slidecollection\slidecollection.php 53
ERROR - 2015-12-19 10:16:36 --> Severity: Notice  --> Undefined variable: max C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\slidecollection\slidecollection.php 54
ERROR - 2015-12-19 10:16:36 --> Severity: Notice  --> Undefined variable: search C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\slidecollection\slidecollection.php 59
ERROR - 2015-12-19 10:16:36 --> Severity: Notice  --> Undefined variable: page C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\slidecollection\slidecollection.php 207
ERROR - 2015-12-19 10:16:36 --> Severity: Notice  --> Undefined variable: order C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\slidecollection\slidecollection.php 208
ERROR - 2015-12-19 10:18:15 --> Severity: Notice  --> Undefined variable: max C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\slidecollection\slidecollection.php 50
ERROR - 2015-12-19 10:18:15 --> Severity: Notice  --> Undefined variable: max C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\slidecollection\slidecollection.php 51
ERROR - 2015-12-19 10:18:15 --> Severity: Notice  --> Undefined variable: max C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\slidecollection\slidecollection.php 52
ERROR - 2015-12-19 10:18:15 --> Severity: Notice  --> Undefined variable: max C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\slidecollection\slidecollection.php 53
ERROR - 2015-12-19 10:18:15 --> Severity: Notice  --> Undefined variable: max C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\slidecollection\slidecollection.php 54
ERROR - 2015-12-19 10:18:15 --> Severity: Notice  --> Undefined variable: search C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\slidecollection\slidecollection.php 59
ERROR - 2015-12-19 10:18:15 --> Severity: Notice  --> Undefined variable: page C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\slidecollection\slidecollection.php 207
ERROR - 2015-12-19 10:18:15 --> Severity: Notice  --> Undefined variable: order C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\slidecollection\slidecollection.php 208
ERROR - 2015-12-19 11:18:14 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-19 11:18:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-19 11:18:14 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-19 11:18:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-19 11:18:14 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-19 11:18:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-19 11:18:14 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-19 11:18:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-19 11:18:14 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-19 11:18:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-19 11:18:14 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-19 11:18:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-19 11:18:14 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 11:18:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 11:18:14 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 11:18:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 11:18:14 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 11:18:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 11:18:14 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 11:18:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 11:18:14 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 11:18:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 11:18:14 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 11:18:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 11:18:14 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 11:18:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 11:18:14 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 11:18:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 11:18:14 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 11:18:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 11:18:14 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 11:18:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 11:18:14 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 11:18:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 11:18:14 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 11:18:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 11:18:14 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 11:18:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 11:18:14 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 11:18:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 11:18:14 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 11:18:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 11:18:14 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 11:18:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 11:18:14 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 11:18:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 11:18:14 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 11:18:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 11:18:14 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 11:18:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 11:18:14 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 11:18:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 11:18:14 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 11:18:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-19 11:27:40 --> You did not select a file to upload.
ERROR - 2015-12-19 11:33:23 --> Severity: Notice  --> Undefined variable: max C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\slidecollection\slidecollection.php 50
ERROR - 2015-12-19 11:33:23 --> Severity: Notice  --> Undefined variable: max C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\slidecollection\slidecollection.php 51
ERROR - 2015-12-19 11:33:23 --> Severity: Notice  --> Undefined variable: max C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\slidecollection\slidecollection.php 52
ERROR - 2015-12-19 11:33:23 --> Severity: Notice  --> Undefined variable: max C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\slidecollection\slidecollection.php 53
ERROR - 2015-12-19 11:33:23 --> Severity: Notice  --> Undefined variable: max C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\slidecollection\slidecollection.php 54
ERROR - 2015-12-19 11:33:23 --> Severity: Notice  --> Undefined variable: search C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\slidecollection\slidecollection.php 59
ERROR - 2015-12-19 11:33:23 --> Severity: Notice  --> Undefined variable: page C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\slidecollection\slidecollection.php 207
ERROR - 2015-12-19 11:33:23 --> Severity: Notice  --> Undefined variable: order C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\slidecollection\slidecollection.php 208
ERROR - 2015-12-19 11:33:49 --> Severity: Notice  --> Undefined variable: max C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\slidecollection\slidecollection.php 50
ERROR - 2015-12-19 11:33:49 --> Severity: Notice  --> Undefined variable: max C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\slidecollection\slidecollection.php 51
ERROR - 2015-12-19 11:33:49 --> Severity: Notice  --> Undefined variable: max C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\slidecollection\slidecollection.php 52
ERROR - 2015-12-19 11:33:49 --> Severity: Notice  --> Undefined variable: max C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\slidecollection\slidecollection.php 53
ERROR - 2015-12-19 11:33:49 --> Severity: Notice  --> Undefined variable: max C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\slidecollection\slidecollection.php 54
ERROR - 2015-12-19 11:33:49 --> Severity: Notice  --> Undefined variable: search C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\slidecollection\slidecollection.php 59
ERROR - 2015-12-19 11:33:49 --> Severity: Notice  --> Undefined variable: page C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\slidecollection\slidecollection.php 207
ERROR - 2015-12-19 11:33:49 --> Severity: Notice  --> Undefined variable: order C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\slidecollection\slidecollection.php 208
ERROR - 2015-12-19 11:34:12 --> You did not select a file to upload.
ERROR - 2015-12-19 11:34:12 --> Severity: Notice  --> Undefined variable: max C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\slidecollection\slidecollection.php 50
ERROR - 2015-12-19 11:34:12 --> Severity: Notice  --> Undefined variable: max C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\slidecollection\slidecollection.php 51
ERROR - 2015-12-19 11:34:12 --> Severity: Notice  --> Undefined variable: max C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\slidecollection\slidecollection.php 52
ERROR - 2015-12-19 11:34:12 --> Severity: Notice  --> Undefined variable: max C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\slidecollection\slidecollection.php 53
ERROR - 2015-12-19 11:34:12 --> Severity: Notice  --> Undefined variable: max C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\slidecollection\slidecollection.php 54
ERROR - 2015-12-19 11:34:12 --> Severity: Notice  --> Undefined variable: search C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\slidecollection\slidecollection.php 59
ERROR - 2015-12-19 11:34:12 --> Severity: Notice  --> Undefined variable: page C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\slidecollection\slidecollection.php 207
ERROR - 2015-12-19 11:34:12 --> Severity: Notice  --> Undefined variable: order C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\slidecollection\slidecollection.php 208
