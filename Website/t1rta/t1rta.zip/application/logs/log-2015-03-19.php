<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-03-19 02:28:36 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-19 02:28:36 --> 404 Page Not Found --> template
ERROR - 2015-03-19 02:29:03 --> 404 Page Not Found --> template
ERROR - 2015-03-19 02:29:10 --> 404 Page Not Found --> template
ERROR - 2015-03-19 02:29:18 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2015-03-19 02:29:18 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2015-03-19 02:29:18 --> 404 Page Not Found --> template
ERROR - 2015-03-19 02:29:29 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2015-03-19 02:29:29 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2015-03-19 02:29:29 --> 404 Page Not Found --> template
ERROR - 2015-03-19 02:29:43 --> 404 Page Not Found --> template
ERROR - 2015-03-19 02:29:53 --> 404 Page Not Found --> template
ERROR - 2015-03-19 02:30:23 --> Severity: Warning  --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\wamp\www\Esgotado\system\libraries\Email.php 1553
ERROR - 2015-03-19 02:30:23 --> 404 Page Not Found --> template
ERROR - 2015-03-19 02:42:09 --> 404 Page Not Found --> template
ERROR - 2015-03-19 02:42:12 --> 404 Page Not Found --> template
ERROR - 2015-03-19 02:42:12 --> 404 Page Not Found --> my_js
ERROR - 2015-03-19 02:42:14 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-19 02:42:14 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2015-03-19 02:42:14 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2015-03-19 02:42:15 --> 404 Page Not Found --> template
ERROR - 2015-03-19 02:42:16 --> 404 Page Not Found --> template
ERROR - 2015-03-19 02:42:19 --> 404 Page Not Found --> template
ERROR - 2015-03-19 02:42:37 --> Severity: Warning  --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\wamp\www\Esgotado\system\libraries\Email.php 1553
ERROR - 2015-03-19 02:42:37 --> 404 Page Not Found --> template
ERROR - 2015-03-19 02:42:55 --> 404 Page Not Found --> template
ERROR - 2015-03-19 02:42:57 --> 404 Page Not Found --> template
ERROR - 2015-03-19 08:46:23 --> 404 Page Not Found --> template
ERROR - 2015-03-19 08:46:27 --> 404 Page Not Found --> template
ERROR - 2015-03-19 08:46:39 --> 404 Page Not Found --> template
ERROR - 2015-03-19 08:46:54 --> Severity: Notice  --> Undefined variable: is_register C:\wamp\www\Esgotado\application\views\forget_password.php 91
ERROR - 2015-03-19 08:46:54 --> 404 Page Not Found --> template
ERROR - 2015-03-19 08:46:58 --> 404 Page Not Found --> template
ERROR - 2015-03-19 08:50:47 --> 404 Page Not Found --> template
ERROR - 2015-03-19 08:50:49 --> 404 Page Not Found --> template
ERROR - 2015-03-19 08:50:51 --> 404 Page Not Found --> template
ERROR - 2015-03-19 08:53:28 --> 404 Page Not Found --> template
ERROR - 2015-03-19 08:53:46 --> 404 Page Not Found --> template
ERROR - 2015-03-19 08:53:54 --> 404 Page Not Found --> template
ERROR - 2015-03-19 08:54:24 --> 404 Page Not Found --> template
ERROR - 2015-03-19 08:54:58 --> 404 Page Not Found --> template
ERROR - 2015-03-19 08:55:13 --> 404 Page Not Found --> template
ERROR - 2015-03-19 08:55:17 --> 404 Page Not Found --> template
ERROR - 2015-03-19 08:55:28 --> 404 Page Not Found --> template
ERROR - 2015-03-19 08:55:29 --> 404 Page Not Found --> template
ERROR - 2015-03-19 08:55:31 --> 404 Page Not Found --> template
ERROR - 2015-03-19 08:55:38 --> 404 Page Not Found --> template
ERROR - 2015-03-19 08:55:40 --> 404 Page Not Found --> template
ERROR - 2015-03-19 08:56:13 --> 404 Page Not Found --> template
ERROR - 2015-03-19 08:56:16 --> 404 Page Not Found --> template
ERROR - 2015-03-19 08:56:19 --> 404 Page Not Found --> template
ERROR - 2015-03-19 08:56:46 --> 404 Page Not Found --> template
ERROR - 2015-03-19 08:56:48 --> 404 Page Not Found --> template
ERROR - 2015-03-19 08:56:49 --> 404 Page Not Found --> template
ERROR - 2015-03-19 08:56:51 --> 404 Page Not Found --> template
ERROR - 2015-03-19 08:56:52 --> 404 Page Not Found --> template
ERROR - 2015-03-19 08:57:16 --> 404 Page Not Found --> template
ERROR - 2015-03-19 08:57:18 --> 404 Page Not Found --> template
ERROR - 2015-03-19 08:57:22 --> 404 Page Not Found --> template
ERROR - 2015-03-19 08:57:24 --> 404 Page Not Found --> template
ERROR - 2015-03-19 08:57:26 --> 404 Page Not Found --> template
ERROR - 2015-03-19 08:57:27 --> 404 Page Not Found --> template
ERROR - 2015-03-19 08:57:28 --> 404 Page Not Found --> template
ERROR - 2015-03-19 08:57:29 --> 404 Page Not Found --> template
ERROR - 2015-03-19 08:57:30 --> 404 Page Not Found --> template
ERROR - 2015-03-19 08:57:33 --> 404 Page Not Found --> template
ERROR - 2015-03-19 08:57:34 --> 404 Page Not Found --> template
ERROR - 2015-03-19 08:57:36 --> 404 Page Not Found --> template
ERROR - 2015-03-19 08:57:40 --> 404 Page Not Found --> template
ERROR - 2015-03-19 08:57:41 --> 404 Page Not Found --> template
ERROR - 2015-03-19 08:57:43 --> 404 Page Not Found --> template
ERROR - 2015-03-19 08:57:56 --> 404 Page Not Found --> template
ERROR - 2015-03-19 12:53:11 --> 404 Page Not Found --> template
ERROR - 2015-03-19 12:53:14 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-19 12:53:15 --> 404 Page Not Found --> template
ERROR - 2015-03-19 12:53:16 --> 404 Page Not Found --> template
ERROR - 2015-03-19 12:54:20 --> 404 Page Not Found --> template
ERROR - 2015-03-19 12:54:32 --> 404 Page Not Found --> template
ERROR - 2015-03-19 12:54:33 --> 404 Page Not Found --> template
ERROR - 2015-03-19 12:54:38 --> 404 Page Not Found --> template
ERROR - 2015-03-19 12:54:43 --> 404 Page Not Found --> template
ERROR - 2015-03-19 12:54:59 --> 404 Page Not Found --> template
ERROR - 2015-03-19 12:55:00 --> 404 Page Not Found --> template
ERROR - 2015-03-19 12:55:59 --> 404 Page Not Found --> template
ERROR - 2015-03-19 12:56:01 --> 404 Page Not Found --> template
ERROR - 2015-03-19 12:56:23 --> 404 Page Not Found --> template
ERROR - 2015-03-19 12:56:46 --> 404 Page Not Found --> template
ERROR - 2015-03-19 12:58:41 --> 404 Page Not Found --> template
ERROR - 2015-03-19 12:58:46 --> 404 Page Not Found --> template
ERROR - 2015-03-19 12:58:47 --> 404 Page Not Found --> template
ERROR - 2015-03-19 12:58:48 --> 404 Page Not Found --> template
ERROR - 2015-03-19 12:58:49 --> 404 Page Not Found --> template
ERROR - 2015-03-19 12:58:50 --> 404 Page Not Found --> template
ERROR - 2015-03-19 12:58:52 --> 404 Page Not Found --> template
ERROR - 2015-03-19 12:58:53 --> 404 Page Not Found --> template
ERROR - 2015-03-19 12:58:55 --> 404 Page Not Found --> template
ERROR - 2015-03-19 12:58:56 --> 404 Page Not Found --> template
ERROR - 2015-03-19 23:25:56 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-19 23:25:56 --> 404 Page Not Found --> template
ERROR - 2015-03-19 23:25:58 --> 404 Page Not Found --> template
ERROR - 2015-03-19 23:26:42 --> 404 Page Not Found --> template
ERROR - 2015-03-19 23:30:58 --> Query error: Table 'galaxia_store.gxa_bank' doesn't exist
ERROR - 2015-03-19 23:31:59 --> 404 Page Not Found --> template
ERROR - 2015-03-19 23:32:09 --> 404 Page Not Found --> template
ERROR - 2015-03-19 23:36:24 --> Query error: Table 'galaxia_store.gxa_ads' doesn't exist
ERROR - 2015-03-19 23:36:33 --> Query error: Table 'galaxia_store.gxa_ads' doesn't exist
ERROR - 2015-03-19 23:37:05 --> 404 Page Not Found --> template
ERROR - 2015-03-19 23:37:31 --> 404 Page Not Found --> template
ERROR - 2015-03-19 23:50:19 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-19 23:50:19 --> 404 Page Not Found --> contact/captcha
ERROR - 2015-03-19 23:50:30 --> Severity: Warning  --> imagettftext(): Invalid font filename C:\wamp\www\Esgotado\application\controllers\contact.php 51
ERROR - 2015-03-19 23:56:43 --> 404 Page Not Found --> template
ERROR - 2015-03-19 23:57:29 --> 404 Page Not Found --> template
ERROR - 2015-03-19 23:57:41 --> 404 Page Not Found --> template
ERROR - 2015-03-19 23:58:08 --> 404 Page Not Found --> template
ERROR - 2015-03-19 23:58:15 --> 404 Page Not Found --> template
ERROR - 2015-03-19 23:58:32 --> 404 Page Not Found --> template
ERROR - 2015-03-19 23:58:42 --> 404 Page Not Found --> template
ERROR - 2015-03-19 23:59:16 --> 404 Page Not Found --> template
ERROR - 2015-03-19 23:59:28 --> 404 Page Not Found --> template
ERROR - 2015-03-19 23:59:44 --> 404 Page Not Found --> template
ERROR - 2015-03-19 23:59:55 --> 404 Page Not Found --> template
