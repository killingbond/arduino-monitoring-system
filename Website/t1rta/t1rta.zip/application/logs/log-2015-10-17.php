<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-10-17 08:01:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/ozantcom/public_html/wassuphaters.com/w4zzup/application/models/product_m.php 27
ERROR - 2015-10-17 08:10:18 --> Severity: Warning  --> escapeshellarg() has been disabled for security reasons /home/ozantcom/public_html/wassuphaters.com/w4zzup/system/libraries/Upload.php 1066
