<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2014-10-18 14:55:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 14:55:56 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 14:57:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 14:57:04 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 14:57:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 14:57:05 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 14:57:57 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: HTTP request failed!  C:\wamp\www\Esgotado\application\views\block\footer.php 71
ERROR - 2014-10-18 14:58:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 14:58:29 --> 404 Page Not Found --> template
ERROR - 2014-10-18 14:58:29 --> 404 Page Not Found --> template
ERROR - 2014-10-18 14:58:29 --> 404 Page Not Found --> template
ERROR - 2014-10-18 14:58:29 --> 404 Page Not Found --> template
ERROR - 2014-10-18 14:58:29 --> 404 Page Not Found --> template
ERROR - 2014-10-18 14:58:29 --> 404 Page Not Found --> template
ERROR - 2014-10-18 14:58:29 --> 404 Page Not Found --> template
ERROR - 2014-10-18 14:58:29 --> 404 Page Not Found --> template
ERROR - 2014-10-18 14:58:29 --> 404 Page Not Found --> template
ERROR - 2014-10-18 14:58:29 --> 404 Page Not Found --> template
ERROR - 2014-10-18 14:58:29 --> 404 Page Not Found --> template
ERROR - 2014-10-18 14:58:29 --> 404 Page Not Found --> template
ERROR - 2014-10-18 14:58:29 --> 404 Page Not Found --> template
ERROR - 2014-10-18 14:58:29 --> 404 Page Not Found --> template
ERROR - 2014-10-18 14:58:29 --> 404 Page Not Found --> template
ERROR - 2014-10-18 14:58:29 --> 404 Page Not Found --> template
ERROR - 2014-10-18 14:58:29 --> 404 Page Not Found --> template
ERROR - 2014-10-18 14:58:29 --> 404 Page Not Found --> template
ERROR - 2014-10-18 14:58:29 --> 404 Page Not Found --> template
ERROR - 2014-10-18 14:58:29 --> 404 Page Not Found --> template
ERROR - 2014-10-18 14:58:29 --> 404 Page Not Found --> template
ERROR - 2014-10-18 14:58:29 --> 404 Page Not Found --> template
ERROR - 2014-10-18 14:58:29 --> 404 Page Not Found --> template
ERROR - 2014-10-18 14:58:29 --> 404 Page Not Found --> template
ERROR - 2014-10-18 14:58:29 --> 404 Page Not Found --> template
ERROR - 2014-10-18 14:58:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 14:58:29 --> 404 Page Not Found --> template
ERROR - 2014-10-18 14:58:29 --> 404 Page Not Found --> template
ERROR - 2014-10-18 14:58:29 --> 404 Page Not Found --> template
ERROR - 2014-10-18 14:58:29 --> 404 Page Not Found --> template
ERROR - 2014-10-18 14:58:29 --> 404 Page Not Found --> template
ERROR - 2014-10-18 14:58:29 --> 404 Page Not Found --> template
ERROR - 2014-10-18 14:58:29 --> 404 Page Not Found --> template
ERROR - 2014-10-18 14:58:29 --> 404 Page Not Found --> template
ERROR - 2014-10-18 14:58:29 --> 404 Page Not Found --> template
ERROR - 2014-10-18 14:58:29 --> 404 Page Not Found --> template
ERROR - 2014-10-18 14:58:29 --> 404 Page Not Found --> template
ERROR - 2014-10-18 14:58:29 --> 404 Page Not Found --> template
ERROR - 2014-10-18 14:58:29 --> 404 Page Not Found --> template
ERROR - 2014-10-18 14:58:29 --> 404 Page Not Found --> template
ERROR - 2014-10-18 14:58:29 --> 404 Page Not Found --> template
ERROR - 2014-10-18 14:58:29 --> 404 Page Not Found --> template
ERROR - 2014-10-18 14:58:29 --> 404 Page Not Found --> template
ERROR - 2014-10-18 14:58:29 --> 404 Page Not Found --> template
ERROR - 2014-10-18 14:58:29 --> 404 Page Not Found --> template
ERROR - 2014-10-18 14:58:29 --> 404 Page Not Found --> template
ERROR - 2014-10-18 14:58:29 --> 404 Page Not Found --> template
ERROR - 2014-10-18 14:59:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:02:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:03:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:08:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:08:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:08:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:08:58 --> 404 Page Not Found --> css
ERROR - 2014-10-18 15:08:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:08:58 --> 404 Page Not Found --> css
ERROR - 2014-10-18 15:09:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:09:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:09:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:09:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:09:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:09:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:09:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:09:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:09:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:09:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:09:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:09:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:09:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:09:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:09:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:09:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:09:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:09:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:09:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:09:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:09:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:09:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:09:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:09:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:09:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:09:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:09:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:09:40 --> 404 Page Not Found --> css
ERROR - 2014-10-18 15:09:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:09:40 --> 404 Page Not Found --> css
ERROR - 2014-10-18 15:10:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:10:03 --> 404 Page Not Found --> css
ERROR - 2014-10-18 15:10:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:10:03 --> 404 Page Not Found --> css
ERROR - 2014-10-18 15:10:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:10:22 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:10:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:10:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:10:30 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:10:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:10:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:10:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:10:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:10:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:10:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:10:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:10:45 --> 404 Page Not Found --> css
ERROR - 2014-10-18 15:10:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:10:45 --> 404 Page Not Found --> css
ERROR - 2014-10-18 15:10:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:10:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:10:50 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 15:10:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:10:51 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 15:11:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:11:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:11:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:11:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:11:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:11:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:11:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:11:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:11:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:11:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:11:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:11:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:11:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:11:32 --> 404 Page Not Found --> css
ERROR - 2014-10-18 15:11:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:11:32 --> 404 Page Not Found --> css
ERROR - 2014-10-18 15:11:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:12:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:12:54 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 15:12:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:12:54 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 15:13:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:13:04 --> 404 Page Not Found --> css
ERROR - 2014-10-18 15:13:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:13:04 --> 404 Page Not Found --> css
ERROR - 2014-10-18 15:13:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:13:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:13:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:13:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:15:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:16:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:16:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:16:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:16:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:16:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:16:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:16:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:16:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:17:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:17:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:17:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:17:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:17:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:18:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:18:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:18:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:18:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:18:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:18:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:18:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:18:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:18:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:18:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:19:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:19:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:19:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:19:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:19:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:19:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:20:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:20:23 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:20:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:20:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:20:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:20:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:20:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:20:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:21:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:21:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:21:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:21:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:21:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:21:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:21:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:22:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:22:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:22:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:22:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:23:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:23:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:23:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:23:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:23:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:23:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:23:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:23:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:23:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:23:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:23:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:23:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:23:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:23:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:23:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:23:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:23:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:23:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:24:00 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 15:24:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:24:00 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 15:25:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:25:28 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 15:25:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:25:28 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 15:25:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:25:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:25:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:25:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:25:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:25:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:26:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:26:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:26:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:26:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:26:07 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 15:26:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:26:07 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 15:26:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:26:38 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 15:26:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:26:38 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 15:27:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:27:11 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 15:27:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:27:11 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 15:27:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:27:20 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 15:27:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:27:20 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 15:27:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:27:40 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 15:27:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:27:40 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 15:27:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:27:49 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 15:27:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:27:49 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 15:30:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:30:30 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 15:30:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:30:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:30:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:30:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:30:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:30:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:30:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:30:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:30:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:30:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:30:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:30:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:30:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:30:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:30:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:30:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:30:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:30:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:30:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:30:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:30:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:30:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:30:30 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:30:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:30:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:30:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:30:30 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 15:30:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:30:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:30:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:30:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:30:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:30:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:30:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:30:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:30:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:30:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:30:31 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:30:31 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:30:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:30:31 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:30:31 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:30:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:30:31 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:30:31 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:30:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:30:31 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:30:31 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:31:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:31:13 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 15:31:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:31:13 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:31:13 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:31:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:31:13 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:31:13 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:31:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:31:13 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:31:13 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:31:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:31:13 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:31:13 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:31:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:31:13 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:31:13 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:31:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:31:13 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:31:13 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:31:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:31:13 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:31:13 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:31:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:31:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:31:13 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:31:13 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:31:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:31:13 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:31:13 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:31:13 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 15:31:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:31:13 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:31:13 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:31:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:31:13 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:31:13 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:31:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:31:13 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:31:13 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:31:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:31:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:31:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:31:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:31:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:31:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:31:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:31:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:31:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:31:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:31:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:31:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:31:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:31:14 --> 404 Page Not Found --> template
ERROR - 2014-10-18 15:31:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:31:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:31:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:31:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:31:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:31:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:31:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:31:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:31:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:31:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:31:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:31:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:31:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:31:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:31:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:31:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:31:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:31:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:31:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:31:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:31:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:31:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:31:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:32:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:32:45 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 15:32:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:32:45 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:32:45 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:32:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:32:46 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:32:46 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:32:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:32:46 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:32:46 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:32:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:32:46 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:32:46 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:32:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:32:46 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:32:46 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:32:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:32:46 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:32:46 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:32:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:32:46 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:32:46 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:32:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:32:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:32:46 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:32:46 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:32:46 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 15:32:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:32:46 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:32:46 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:32:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:32:46 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:32:46 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:32:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:32:46 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:32:46 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:32:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:32:46 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:32:46 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:32:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:32:46 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:32:46 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:32:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:32:47 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:32:47 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:32:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:32:47 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:32:47 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:32:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:32:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:32:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:33:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:33:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:33:00 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 15:33:00 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:33:00 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:33:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:33:00 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:33:00 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:33:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:33:00 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:33:00 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:33:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:33:00 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:33:00 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:33:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:33:00 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:33:00 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:33:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:33:00 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:33:00 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:33:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:33:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:33:00 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:33:00 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:33:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:33:00 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:33:00 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:33:01 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 15:33:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:33:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:33:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:33:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:33:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:33:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:33:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:33:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:33:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:33:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:33:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:33:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:33:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:33:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:33:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:33:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:33:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:33:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:33:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:33:55 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 15:33:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:33:55 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:33:55 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:33:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:33:55 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:33:55 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:33:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:33:55 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:33:55 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:33:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:33:55 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:33:55 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:33:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:33:55 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:33:55 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:33:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:33:55 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:33:55 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:33:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:33:56 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:33:56 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:33:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:33:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:33:56 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:33:56 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:33:56 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 15:33:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:33:56 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:33:56 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:33:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:33:56 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:33:56 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:33:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:33:56 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:33:56 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:33:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:33:56 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:33:56 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:33:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:33:56 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:33:56 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:33:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:33:56 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:33:56 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:33:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:33:56 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:33:56 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:33:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:34:00 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 15:34:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:34:00 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:34:00 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:34:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:34:00 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:34:00 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:34:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:34:00 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:34:00 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:34:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:34:00 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:34:00 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:34:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:34:00 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:34:00 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:34:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:34:00 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:34:00 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:34:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:34:00 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:34:00 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:34:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:34:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:34:00 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:34:00 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:34:00 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 15:34:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:34:00 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:34:00 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:34:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:34:00 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:34:00 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:34:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:34:00 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:34:00 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:34:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:34:00 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:34:00 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:34:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:34:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:34:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:34:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:34:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:34:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:34:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:34:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:34:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:34:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:34:56 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 15:34:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:34:56 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:34:56 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:34:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:34:56 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:34:56 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:34:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:34:56 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:34:56 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:34:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:34:56 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:34:56 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:34:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:34:56 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:34:56 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:34:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:34:56 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:34:56 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:34:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:34:56 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:34:56 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:34:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:34:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:34:56 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:34:56 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:34:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:34:56 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:34:56 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 15:34:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:34:56 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:34:56 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:34:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:34:57 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:34:57 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:34:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:34:57 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:34:57 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:34:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:34:57 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:34:57 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:34:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:34:57 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:34:57 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:34:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:34:57 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:34:57 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:34:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:34:57 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:34:57 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:34:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:34:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:34:57 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:34:57 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:34:57 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 15:34:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:34:57 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:34:57 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:34:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:34:57 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:34:57 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:34:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:34:57 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:34:57 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:34:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:34:57 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:34:57 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:34:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:34:57 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:34:57 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:34:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:34:58 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:34:58 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:34:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:34:58 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:34:58 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:35:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:35:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:35:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:35:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:35:02 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:35:02 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 15:35:02 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:35:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:35:02 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:35:02 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:35:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:35:02 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:35:02 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:35:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:35:02 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:35:02 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:35:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:35:02 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:35:02 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:35:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:35:02 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:35:02 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:35:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:35:02 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:35:02 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:35:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:35:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:35:02 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:35:02 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:35:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:35:02 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:35:02 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:35:02 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 15:35:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:35:03 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:35:03 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:35:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:35:03 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:35:03 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:35:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:35:03 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:35:03 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:35:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:35:03 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:35:03 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:35:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:35:03 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:35:03 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:35:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:35:03 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:35:03 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:39:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:39:10 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 15:39:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:39:11 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:39:11 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:39:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:39:11 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:39:11 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:39:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:39:11 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:39:11 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:39:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:39:11 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:39:11 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:39:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:39:11 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:39:11 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:39:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:39:11 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:39:11 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:39:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:39:11 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:39:11 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:39:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:39:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:39:11 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:39:11 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:39:11 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 15:39:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:39:11 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:39:11 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:39:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:39:11 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:39:11 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:39:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:39:12 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:39:12 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:39:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:39:12 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:39:12 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:39:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:39:12 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:39:12 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:39:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:39:12 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:39:12 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:39:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:39:12 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:39:12 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:39:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:39:18 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 15:39:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:39:18 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:39:18 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:39:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:39:18 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:39:18 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:39:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:39:18 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:39:18 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:39:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:39:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:39:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:39:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:39:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:39:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:39:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:39:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:39:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:39:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:39:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:39:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:39:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:39:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:39:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:39:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:39:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:39:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:39:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:39:19 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 15:39:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:39:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:39:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:39:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:39:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:39:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:39:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:39:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:39:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:39:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:39:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:39:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:39:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:39:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:39:20 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:39:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:39:20 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:39:20 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:39:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:39:53 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 15:39:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:39:54 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:39:54 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:39:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:39:54 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:39:54 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:39:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:39:54 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:39:54 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:39:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:39:54 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:39:54 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:39:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:39:54 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:39:54 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:39:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:39:54 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:39:54 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:39:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:39:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:39:54 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:39:54 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:39:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:39:54 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 15:39:54 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:39:54 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:39:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:39:54 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:39:54 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:39:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:39:54 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:39:54 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:39:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:39:54 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:39:54 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:39:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:39:55 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:39:55 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:39:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:39:55 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:39:55 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:39:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:39:55 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:39:55 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:40:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:40:10 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 15:40:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:40:10 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:40:10 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:40:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:40:10 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:40:10 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:40:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:40:10 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:40:10 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:40:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:40:10 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:40:10 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:40:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:40:10 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:40:10 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:40:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:40:10 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:40:10 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:40:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:40:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:40:10 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:40:10 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:40:10 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 15:40:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:40:10 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:40:10 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:40:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:40:10 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:40:10 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:40:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:40:11 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:40:11 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:40:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:40:11 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:40:11 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:40:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:40:11 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:40:11 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:40:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:40:11 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:40:11 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:40:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:40:11 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:40:11 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:41:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:41:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:41:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:41:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:41:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:41:22 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 15:41:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:41:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:41:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:41:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:41:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:41:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:41:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:41:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:41:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:41:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:41:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:41:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:41:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:41:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:41:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:41:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:41:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:41:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:41:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:41:23 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:41:23 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:41:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:41:23 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:41:23 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:41:23 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 15:41:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:41:23 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:41:23 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:41:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:41:23 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:41:23 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:41:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:41:23 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:41:23 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:41:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:41:23 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:41:23 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:41:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:41:23 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:41:23 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:41:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:41:23 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:41:23 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:42:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:42:46 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 15:42:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:42:46 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:42:46 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:42:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:42:46 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:42:46 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:42:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:42:46 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:42:46 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:42:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:42:46 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:42:46 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:42:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:42:47 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:42:47 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:42:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:42:47 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:42:47 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:42:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:42:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:42:47 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:42:47 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:42:47 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 15:42:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:42:47 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:42:47 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:42:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:42:47 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:42:47 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:42:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:42:47 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:42:47 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:42:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:42:47 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:42:47 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:42:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:42:47 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:42:47 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:42:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:42:47 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:42:47 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:42:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:42:47 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:42:47 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:43:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:43:06 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 15:43:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:43:06 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:43:06 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:43:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:43:06 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:43:06 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:43:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:43:06 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:43:06 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:43:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:43:06 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:43:06 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:43:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:43:06 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:43:06 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:43:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:43:06 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:43:06 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:43:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:43:07 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:43:07 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:43:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:43:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:43:07 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:43:07 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:43:07 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 15:43:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:43:07 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:43:07 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:43:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:43:07 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:43:07 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:43:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:43:07 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:43:07 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:43:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:43:07 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:43:07 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:43:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:43:07 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:43:07 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:43:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:43:07 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:43:07 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:43:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:43:07 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:43:07 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:43:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:43:28 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 15:43:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:43:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:43:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:43:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:43:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:43:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:43:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:43:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:43:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:43:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:43:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:43:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:43:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:43:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:43:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:43:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:43:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:43:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:43:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:43:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:43:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:43:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:43:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:43:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:43:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:43:29 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 15:43:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:43:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:43:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:43:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:43:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:43:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:43:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:43:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:43:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:43:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:43:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:43:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:43:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:43:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:43:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:43:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:43:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:43:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:43:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:43:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:43:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:43:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:43:39 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 15:43:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:43:39 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:43:39 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:43:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:43:39 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:43:39 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:43:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:43:39 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:43:39 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:43:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:43:39 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:43:39 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:43:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:43:39 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:43:39 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:43:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:43:39 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:43:39 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:43:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:43:39 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:43:40 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:43:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:43:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:43:40 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:43:40 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:43:40 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 15:43:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:43:40 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:43:40 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:43:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:43:40 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:43:40 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:43:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:43:40 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:43:40 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:43:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:43:40 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:43:40 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:43:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:43:40 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:43:40 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:43:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:43:40 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:43:40 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:43:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:43:40 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:43:40 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:43:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:43:51 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 15:43:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:43:51 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:43:51 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:43:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:43:52 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:43:52 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:43:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:43:52 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:43:52 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:43:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:43:52 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:43:52 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:43:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:43:52 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:43:52 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:43:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:43:52 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:43:52 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:43:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:43:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:43:52 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:43:52 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:43:52 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 15:43:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:43:52 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:43:52 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:43:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:43:52 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:43:52 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:43:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:43:52 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:43:52 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:43:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:43:52 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:43:52 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:43:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:43:52 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:43:52 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:43:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:43:53 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:43:53 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:43:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:43:53 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:43:53 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:45:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:45:18 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 15:45:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:45:18 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:45:18 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:45:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:45:18 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:45:18 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:45:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:45:18 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:45:18 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:45:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:45:18 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:45:18 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:45:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:45:18 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:45:18 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:45:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:45:18 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:45:18 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:45:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:45:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:45:18 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:45:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:45:19 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 15:45:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:45:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:45:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:45:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:45:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:45:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:45:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:45:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:45:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:45:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:45:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:45:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:45:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:45:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:45:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:45:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:45:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:45:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:45:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:45:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:45:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:46:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:46:50 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 15:46:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:46:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:46:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:46:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:46:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:46:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:46:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:46:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:46:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:46:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:46:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:46:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:46:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:46:51 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:46:51 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:46:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:46:51 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:46:51 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:46:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:46:51 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:46:51 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:46:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:46:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:46:51 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:46:51 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:46:51 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 15:46:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:46:51 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:46:51 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:46:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:46:51 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:46:51 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:46:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:46:51 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:46:51 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:46:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:46:51 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:46:51 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:46:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:46:51 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:46:51 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:46:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:46:51 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:46:51 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:46:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:46:51 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:46:51 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:47:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:47:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:47:43 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:47:43 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:47:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:47:43 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 15:47:43 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:47:43 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:47:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:47:43 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:47:43 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:47:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:47:43 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:47:43 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:47:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:47:43 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:47:44 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:47:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:47:44 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:47:44 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:47:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:47:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:47:44 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:47:44 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:47:44 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 15:47:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:47:44 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:47:44 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:47:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:47:44 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:47:44 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:47:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:47:44 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:47:44 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:47:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:47:44 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:47:44 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:47:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:47:44 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:47:44 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:47:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:47:44 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:47:44 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:47:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:47:44 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:47:44 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:47:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:47:52 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 15:47:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:47:52 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:47:52 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:47:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:47:52 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:47:52 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:47:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:47:52 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:47:52 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:47:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:47:52 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:47:52 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:47:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:47:52 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:47:52 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:47:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:47:52 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:47:52 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:47:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:47:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:47:53 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:47:53 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:47:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:47:53 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 15:47:53 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:47:53 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:47:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:47:53 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:47:53 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:47:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:47:53 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:47:53 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:47:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:47:53 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:47:53 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:47:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:47:53 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:47:53 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:47:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:47:53 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:47:53 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:47:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:47:53 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:47:53 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:48:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:48:28 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 15:48:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:48:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:48:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:48:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:48:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:48:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:48:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:48:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:48:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:48:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:48:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:48:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:48:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:48:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:48:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:48:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:48:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:48:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:48:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:48:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:48:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:48:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:48:29 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 15:48:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:48:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:48:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:48:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:48:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:48:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:48:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:48:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:48:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:48:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:48:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:48:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:48:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:48:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:48:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:48:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:48:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:48:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:48:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:48:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:48:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:48:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:48:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:48:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:48:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:48:33 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:48:33 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:48:33 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 15:48:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:48:33 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:48:33 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:48:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:48:33 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:48:33 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:48:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:48:33 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:48:33 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:48:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:48:33 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:48:33 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:48:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:48:33 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:48:34 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:48:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:48:34 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:48:34 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:48:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:48:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:48:34 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:48:34 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:48:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:48:34 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:48:34 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:48:34 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 15:48:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:48:34 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:48:34 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:48:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:48:34 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:48:34 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:48:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:48:34 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:48:34 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:48:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:48:34 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:48:34 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:48:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:48:34 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:48:34 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:48:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:48:34 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:48:34 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:48:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:48:59 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 15:48:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:48:59 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:48:59 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:48:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:48:59 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:48:59 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:48:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:48:59 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:48:59 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:48:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:48:59 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:48:59 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:48:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:48:59 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:48:59 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:48:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:48:59 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:48:59 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:48:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:49:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:49:00 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:49:00 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:49:00 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 15:49:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:49:00 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:49:00 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:49:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:49:00 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:49:00 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:49:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:49:00 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:49:00 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:49:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:49:00 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:49:00 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:49:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:49:00 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:49:00 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:49:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:49:00 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:49:00 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:49:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:49:00 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:49:00 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:49:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:49:54 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 15:49:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:49:54 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:49:54 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:49:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:49:54 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:49:54 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:49:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:49:54 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:49:54 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:49:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:49:54 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:49:54 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:49:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:49:55 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:49:55 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:49:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:49:55 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:49:55 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:49:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:49:55 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:49:55 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:49:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:49:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:49:55 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:49:55 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:49:55 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 15:49:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:49:55 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:49:55 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:49:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:49:55 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:49:55 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:49:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:49:55 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:49:55 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:49:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:49:55 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:49:55 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:49:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:49:55 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:49:55 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:49:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:49:55 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:49:55 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:49:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:49:55 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:49:55 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:50:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:50:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:50:31 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 15:50:31 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:50:31 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:50:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:50:31 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:50:31 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:50:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:50:32 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:50:32 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:50:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:50:32 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:50:32 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:50:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:50:32 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:50:32 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:50:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:50:32 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:50:32 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:50:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:50:32 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:50:32 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:50:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:50:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:50:32 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:50:32 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:50:32 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 15:50:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:50:32 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:50:32 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:50:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:50:32 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:50:32 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:50:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:50:32 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:50:32 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:50:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:50:32 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:50:32 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:50:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:50:32 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:50:32 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:50:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:50:33 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:50:33 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:50:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:50:33 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:50:33 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:51:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:51:13 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 15:51:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:51:13 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:51:13 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:51:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:51:13 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:51:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:51:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:51:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:51:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:51:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:51:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:51:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:51:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:51:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:51:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:51:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:51:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:51:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:51:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:51:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:51:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:51:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:51:14 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 15:51:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:51:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:51:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:51:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:51:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:51:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:51:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:51:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:51:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:51:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:51:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:51:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:51:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:51:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:51:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:51:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:51:15 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:51:15 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:51:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:51:15 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:51:15 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:51:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:51:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:51:36 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:51:36 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:51:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:51:36 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 15:51:36 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:51:36 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:51:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:51:36 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:51:36 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:51:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:51:36 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:51:36 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:51:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:51:36 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:51:36 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:51:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:51:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:51:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:51:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:51:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:51:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:51:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:51:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:51:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:51:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:51:37 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 15:51:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:51:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:51:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:51:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:51:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:51:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:51:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:51:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:51:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:51:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:51:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:51:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:51:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:51:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:51:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:51:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:51:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:51:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:51:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:51:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:51:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:52:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:52:44 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 15:52:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:52:44 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:52:44 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:52:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:52:44 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:52:44 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:52:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:52:44 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:52:44 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:52:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:52:44 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:52:44 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:52:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:52:45 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:52:45 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:52:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:52:45 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:52:45 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:52:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:52:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:52:45 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:52:45 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:52:45 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 15:52:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:52:45 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:52:45 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:52:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:52:45 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:52:45 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:52:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:52:45 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:52:45 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:52:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:52:45 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:52:45 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:52:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:52:45 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:52:45 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:52:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:52:45 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:52:45 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:52:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:52:45 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:52:45 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:53:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:53:00 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 15:53:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:53:00 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:53:00 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:53:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:53:00 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:53:00 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:53:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:53:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:53:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:53:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:53:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:53:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:53:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:53:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:53:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:53:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:53:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:53:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:53:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:53:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:53:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:53:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:53:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:53:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:53:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:53:01 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 15:53:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:53:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:53:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:53:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:53:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:53:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:53:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:53:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:53:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:53:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:53:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:53:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:53:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:53:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:53:02 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:53:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:53:02 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:53:02 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:53:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:53:02 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:53:02 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:53:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:53:07 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 15:53:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:53:07 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:53:07 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:53:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:53:07 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:53:07 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:53:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:53:07 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:53:07 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:53:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:53:07 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:53:07 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:53:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:53:07 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:53:07 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:53:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:53:07 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:53:07 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:53:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:53:07 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:53:07 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:53:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:53:07 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:53:07 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:53:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:53:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:53:08 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:53:08 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:53:08 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 15:53:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:53:08 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:53:08 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:53:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:53:08 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:53:08 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:53:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:53:08 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:53:08 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:53:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:53:08 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:53:08 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:53:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:53:08 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:53:08 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:53:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:53:08 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:53:08 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:53:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:53:08 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:53:08 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:53:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:53:18 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 15:53:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:53:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:53:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:53:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:53:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:53:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:53:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:53:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:53:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:53:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:53:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:53:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:53:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:53:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:53:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:53:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:53:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:53:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:53:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:53:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:53:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:53:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:53:19 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 15:53:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:53:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:53:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:53:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:53:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:53:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:53:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:53:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:53:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:53:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:53:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:53:20 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:53:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:53:20 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:53:20 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:53:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:53:20 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:53:20 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:53:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:53:20 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:53:20 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:53:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:53:28 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 15:53:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:53:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:53:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:53:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:53:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:53:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:53:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:53:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:53:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:53:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:53:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:53:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:53:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:53:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:53:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:53:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:53:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:53:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:53:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:53:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:53:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:53:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:53:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:53:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:53:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:53:29 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 15:53:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:53:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:53:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:53:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:53:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:53:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:53:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:53:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:53:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:53:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:53:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:53:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:53:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:53:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:53:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:53:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:53:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:53:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:53:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:53:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:53:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:54:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:54:23 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 15:54:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:54:23 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:54:23 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:54:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:54:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:54:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:54:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:54:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:54:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:54:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:54:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:54:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:54:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:54:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:54:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:54:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:54:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:54:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:54:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:54:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:54:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:54:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:54:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:54:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:54:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:54:24 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 15:54:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:54:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:54:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:54:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:54:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:54:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:54:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:54:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:54:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:54:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:54:25 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:54:25 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:54:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:54:25 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:54:25 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:54:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:54:25 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:54:25 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:54:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:54:25 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:54:25 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:54:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:54:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:54:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:54:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:54:30 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 15:54:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:54:31 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:54:31 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:54:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:54:31 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:54:31 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:54:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:54:31 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:54:31 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:54:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:54:31 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:54:31 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:54:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:54:31 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:54:31 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:54:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:54:31 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:54:31 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:54:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:54:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:54:31 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:54:31 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:54:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:54:31 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:54:31 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:54:31 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 15:54:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:54:31 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:54:31 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:54:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:54:32 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:54:32 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:54:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:54:32 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:54:32 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:54:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:54:32 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:54:32 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:54:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:54:32 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:54:32 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:54:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:54:32 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:54:32 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:55:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:55:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:55:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:55:09 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 15:55:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:55:09 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:55:09 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:55:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:55:09 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:55:09 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:55:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:55:09 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:55:09 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:55:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:55:09 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:55:09 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:55:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:55:09 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:55:09 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:55:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:55:09 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:55:10 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:55:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:55:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:55:10 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:55:10 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:55:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:55:10 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:55:10 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:55:10 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 15:55:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:55:10 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:55:10 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:55:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:55:10 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:55:10 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:55:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:55:10 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:55:10 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:55:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:55:10 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:55:10 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:55:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:55:10 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:55:10 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:55:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:55:10 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:55:10 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:55:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:55:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:56:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:56:52 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
ERROR - 2014-10-18 15:56:52 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 15:56:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:56:53 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:56:53 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:56:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:56:53 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:56:53 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:56:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:56:53 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:56:53 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:56:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:56:53 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:56:53 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:56:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:56:53 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:56:53 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:56:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:56:53 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:56:53 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:56:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:56:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:56:53 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:56:53 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:56:53 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 15:56:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:56:53 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:56:53 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:56:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:56:53 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:56:53 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:56:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:56:53 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:56:53 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:56:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:56:54 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:56:54 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:56:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:56:54 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:56:54 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:56:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:56:54 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:56:54 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:56:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:56:54 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:56:54 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:57:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:57:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:57:00 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:57:00 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:57:00 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 15:57:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:57:00 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:57:00 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:57:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:57:00 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:57:00 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:57:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:57:00 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:57:00 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:57:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:57:00 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:57:00 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:57:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:57:00 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:57:00 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:57:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:57:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:57:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:57:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:57:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:57:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:57:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:57:01 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 15:57:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:57:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:57:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:57:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:57:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:57:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:57:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:57:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:57:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:57:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:57:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:57:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:57:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:57:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:57:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:57:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:57:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:57:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:57:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:57:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:57:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:57:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:57:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:57:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:57:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:57:08 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 15:57:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:57:08 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:57:08 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:57:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:57:08 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:57:08 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:57:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:57:08 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:57:08 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:57:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:57:08 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:57:08 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:57:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:57:08 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:57:08 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:57:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:57:08 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:57:08 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:57:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:57:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:57:08 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:57:08 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:57:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:57:08 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:57:08 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:57:08 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 15:57:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:57:09 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:57:09 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:57:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:57:09 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:57:09 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:57:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:57:09 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:57:09 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:57:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:57:09 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:57:09 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:57:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:57:09 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:57:09 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:57:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:57:09 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:57:09 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:57:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:57:13 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 15:57:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:57:13 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:57:13 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:57:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:57:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:57:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:57:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:57:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:57:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:57:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:57:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:57:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:57:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:57:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:57:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:57:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:57:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:57:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:57:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:57:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:57:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:57:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:57:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:57:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:57:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:57:14 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 15:57:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:57:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:57:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:57:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:57:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:57:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:57:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:57:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:57:15 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:57:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:57:15 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:57:15 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:57:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:57:15 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:57:15 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:57:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:57:15 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:57:15 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:57:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:57:15 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:57:15 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:57:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:57:32 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 15:57:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:57:33 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:57:33 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:57:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:57:33 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:57:33 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:57:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:57:33 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:57:33 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:57:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:57:33 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:57:33 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:57:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:57:33 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:57:33 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:57:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:57:33 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:57:33 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:57:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:57:33 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:57:33 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:57:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:57:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:57:33 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:57:33 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:57:33 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 15:57:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:57:33 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:57:33 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:57:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:57:34 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:57:34 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:57:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:57:34 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:57:34 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:57:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:57:34 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:57:34 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:57:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:57:34 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:57:34 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:57:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:57:34 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:57:34 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:57:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:57:34 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:57:34 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:58:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:58:00 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 15:58:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:58:00 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:58:00 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:58:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:58:00 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:58:00 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:58:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:58:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:58:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:58:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:58:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:58:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:58:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:58:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:58:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:58:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:58:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:58:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:58:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:58:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:58:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:58:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:58:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:58:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:58:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:58:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:58:01 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 15:58:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:58:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:58:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:58:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:58:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:58:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:58:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:58:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:58:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:58:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:58:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:58:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:58:02 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:58:02 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:58:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:58:02 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:58:02 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:58:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:58:02 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:58:02 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:58:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:58:30 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 15:58:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:58:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:58:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:58:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:58:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:58:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:58:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:58:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:58:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:58:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:58:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:58:31 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:58:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:58:31 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:58:31 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:58:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:58:31 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:58:31 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:58:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:58:31 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:58:31 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:58:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:58:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:58:31 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:58:31 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:58:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:58:31 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 15:58:31 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:58:31 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:58:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:58:31 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:58:31 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:58:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:58:31 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:58:31 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:58:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:58:31 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:58:31 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:58:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:58:31 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:58:31 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:58:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:58:32 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:58:32 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:58:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:58:32 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:58:32 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:58:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:58:49 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 15:58:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:58:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:58:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:58:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:58:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:58:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:58:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:58:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:58:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:58:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:58:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:58:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:58:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:58:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:58:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:58:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:58:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:58:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:58:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:58:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:58:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:58:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:58:49 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 15:58:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:58:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:58:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:58:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:58:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:58:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:58:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:58:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:58:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:58:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:58:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:58:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:58:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:58:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:58:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:58:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:58:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:58:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:58:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:58:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:58:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:59:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:59:17 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 15:59:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:59:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:59:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:59:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:59:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:59:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:59:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:59:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:59:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:59:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:59:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:59:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:59:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:59:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:59:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:59:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:59:18 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:59:18 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:59:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:59:18 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:59:18 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:59:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:59:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:59:18 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:59:18 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:59:18 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 15:59:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:59:18 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:59:18 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:59:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:59:18 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:59:18 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:59:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:59:18 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:59:18 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:59:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:59:18 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:59:18 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:59:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:59:18 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:59:18 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:59:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:59:18 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:59:18 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 15:59:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 15:59:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 15:59:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:00:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:00:19 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 16:00:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:00:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:00:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:00:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:00:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:00:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:00:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:00:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:00:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:00:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:00:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:00:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:00:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:00:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:00:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:00:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:00:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:00:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:00:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:00:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:00:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:00:20 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:00:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:00:20 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 16:00:20 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:00:20 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:00:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:00:20 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:00:20 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:00:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:00:20 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:00:20 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:00:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:00:20 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:00:20 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:00:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:00:20 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:00:20 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:00:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:00:20 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:00:20 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:00:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:00:20 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:00:20 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:00:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:00:45 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 16:00:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:00:45 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:00:45 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:00:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:00:45 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:00:45 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:00:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:00:45 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:00:45 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:00:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:00:46 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:00:46 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:00:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:00:46 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:00:46 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:00:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:00:46 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:00:46 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:00:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:00:46 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:00:46 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:00:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:00:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:00:46 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:00:46 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:00:46 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 16:00:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:00:46 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:00:46 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:00:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:00:46 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:00:46 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:00:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:00:46 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:00:46 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:00:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:00:46 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:00:46 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:00:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:00:46 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:00:46 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:00:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:00:47 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:00:47 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:00:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:00:47 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:00:47 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:01:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:01:02 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 16:01:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:01:03 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:01:03 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:01:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:01:03 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:01:03 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:01:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:01:03 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:01:03 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:01:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:01:03 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:01:03 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:01:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:01:03 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:01:03 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:01:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:01:03 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:01:03 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:01:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:01:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:01:03 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:01:03 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:01:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:01:03 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 16:01:03 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:01:03 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:01:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:01:03 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:01:03 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:01:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:01:04 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:01:04 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:01:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:01:04 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:01:04 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:01:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:01:04 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:01:04 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:01:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:01:04 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:01:04 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:01:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:01:04 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:01:04 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:01:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:01:42 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 16:01:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:01:42 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:01:42 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:01:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:01:42 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:01:42 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:01:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:01:43 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:01:43 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:01:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:01:43 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:01:43 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:01:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:01:43 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:01:43 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:01:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:01:43 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:01:43 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:01:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:01:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:01:43 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:01:43 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:01:43 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 16:01:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:01:43 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:01:43 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:01:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:01:43 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:01:43 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:01:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:01:43 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:01:43 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:01:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:01:43 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:01:43 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:01:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:01:44 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:01:44 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:01:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:01:44 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:01:44 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:01:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:01:44 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:01:44 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:01:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:01:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:01:47 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2014-10-18 16:01:47 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2014-10-18 16:01:47 --> 404 Page Not Found --> images
ERROR - 2014-10-18 16:01:47 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 16:01:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:01:47 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2014-10-18 16:01:47 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2014-10-18 16:01:47 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 16:01:47 --> 404 Page Not Found --> images
ERROR - 2014-10-18 16:01:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:01:51 --> 404 Page Not Found --> images
ERROR - 2014-10-18 16:01:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:01:51 --> 404 Page Not Found --> images
ERROR - 2014-10-18 16:01:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:01:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:01:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:01:54 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 16:01:54 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:01:54 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:01:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:01:55 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:01:55 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:01:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:01:55 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:01:55 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:01:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:01:55 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:01:55 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:01:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:01:55 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:01:55 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:01:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:01:55 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:01:55 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:01:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:01:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:01:55 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:01:55 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:01:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:01:55 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:01:55 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:01:55 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 16:01:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:01:55 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:01:55 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:01:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:01:55 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:01:55 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:01:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:01:56 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:01:56 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:01:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:01:56 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:01:56 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:01:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:01:56 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:01:56 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:01:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:01:56 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:01:56 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:01:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:01:56 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:01:56 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:02:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:02:30 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 16:02:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:02:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:02:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:02:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:02:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:02:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:02:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:02:31 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:02:31 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:02:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:02:31 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:02:31 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:02:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:02:31 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:02:31 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:02:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:02:31 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:02:31 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:02:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:02:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:02:31 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:02:31 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:02:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:02:31 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 16:02:31 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:02:31 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:02:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:02:31 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:02:31 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:02:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:02:31 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:02:31 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:02:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:02:31 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:02:31 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:02:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:02:32 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:02:32 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:02:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:02:32 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:02:32 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:02:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:02:32 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:02:32 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:02:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:02:32 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:02:32 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:03:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:03:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:03:33 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:03:33 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:03:33 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 16:03:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:03:33 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:03:33 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:03:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:03:33 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:03:33 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:03:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:03:34 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:03:34 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:03:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:03:34 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:03:34 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:03:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:03:34 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:03:34 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:03:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:03:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:03:34 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:03:34 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:03:34 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 16:03:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:03:34 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:03:34 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:03:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:03:34 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:03:34 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:03:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:03:34 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:03:34 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:03:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:03:34 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:03:34 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:03:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:03:35 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:03:35 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:03:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:03:35 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:03:35 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:03:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:03:35 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:03:35 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:03:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:03:35 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:03:35 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:03:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:03:56 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 16:03:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:03:56 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:03:56 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:03:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:03:56 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:03:56 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:03:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:03:56 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:03:56 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:03:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:03:56 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:03:56 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:03:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:03:56 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:03:56 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:03:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:03:57 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:03:57 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:03:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:03:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:03:57 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:03:57 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:03:57 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 16:03:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:03:57 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:03:57 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:03:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:03:57 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:03:57 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:03:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:03:57 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:03:57 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:03:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:03:57 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:03:57 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:03:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:03:57 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:03:57 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:03:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:03:57 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:03:57 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:03:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:03:57 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:03:57 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:03:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:03:58 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:03:58 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:04:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:04:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:04:03 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:04:03 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:04:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:04:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:04:03 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:04:03 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:04:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:04:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:04:11 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 16:04:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:04:11 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:04:11 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:04:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:04:11 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:04:11 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:04:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:04:11 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:04:11 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:04:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:04:12 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:04:12 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:04:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:04:12 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:04:12 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:04:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:04:12 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:04:12 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:04:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:04:12 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:04:12 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:04:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:04:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:04:12 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:04:12 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:04:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:04:12 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:04:12 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:04:12 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 16:04:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:04:12 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:04:12 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:04:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:04:12 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:04:12 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:04:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:04:12 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:04:12 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:04:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:04:12 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:04:13 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:04:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:04:13 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:04:13 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:04:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:04:13 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:04:13 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:04:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:04:13 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:04:13 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:05:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:05:50 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 16:05:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:05:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:05:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:05:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:05:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:05:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:05:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:05:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:05:51 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:05:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:05:51 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:05:51 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:05:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:05:51 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:05:51 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:05:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:05:51 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:05:51 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:05:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:05:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:05:51 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:05:51 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:05:51 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 16:05:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:05:51 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:05:51 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:05:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:05:51 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:05:51 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:05:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:05:51 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:05:51 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:05:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:05:51 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:05:51 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:05:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:05:52 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:05:52 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:05:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:05:52 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:05:52 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:05:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:05:52 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:05:52 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:05:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:05:52 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:05:52 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:06:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:06:24 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 16:06:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:06:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:06:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:06:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:06:25 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:06:25 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:06:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:06:25 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:06:25 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:06:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:06:25 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:06:25 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:06:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:06:25 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:06:25 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:06:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:06:25 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:06:25 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:06:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:06:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:06:25 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:06:25 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:06:25 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 16:06:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:06:25 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:06:25 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:06:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:06:25 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:06:25 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:06:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:06:25 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:06:25 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:06:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:06:26 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:06:26 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:06:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:06:26 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:06:26 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:06:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:06:26 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:06:26 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:06:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:06:26 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:06:26 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:06:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:06:26 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:06:26 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:06:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:06:42 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 16:06:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:06:43 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:06:43 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:06:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:06:43 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:06:43 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:06:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:06:43 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:06:43 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:06:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:06:43 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:06:43 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:06:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:06:43 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:06:43 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:06:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:06:43 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:06:43 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:06:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:06:43 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:06:43 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:06:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:06:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:06:43 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:06:43 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:06:43 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 16:06:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:06:43 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:06:43 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:06:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:06:44 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:06:44 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:06:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:06:44 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:06:44 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:06:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:06:44 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:06:44 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:06:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:06:44 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:06:44 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:06:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:06:44 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:06:44 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:06:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:06:44 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:06:44 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:06:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:06:44 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:06:44 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:07:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:07:13 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 16:07:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:07:13 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:07:13 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:07:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:07:13 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:07:13 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:07:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:07:13 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:07:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:07:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:07:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:07:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:07:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:07:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:07:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:07:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:07:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:07:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:07:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:07:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:07:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:07:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:07:14 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 16:07:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:07:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:07:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:07:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:07:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:07:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:07:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:07:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:07:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:07:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:07:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:07:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:07:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:07:15 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:07:15 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:07:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:07:15 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:07:15 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:07:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:07:15 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:07:15 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:07:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:07:15 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:07:15 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:07:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:07:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:07:18 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2014-10-18 16:07:18 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2014-10-18 16:07:18 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 16:07:18 --> 404 Page Not Found --> images
ERROR - 2014-10-18 16:07:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:07:18 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2014-10-18 16:07:18 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2014-10-18 16:07:18 --> 404 Page Not Found --> images
ERROR - 2014-10-18 16:07:18 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 16:07:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:07:21 --> 404 Page Not Found --> images
ERROR - 2014-10-18 16:07:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:07:22 --> 404 Page Not Found --> images
ERROR - 2014-10-18 16:07:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:07:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:07:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:07:25 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:07:25 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:07:25 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 16:07:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:07:25 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:07:25 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:07:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:07:25 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:07:25 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:07:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:07:25 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:07:25 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:07:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:07:25 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:07:25 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:07:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:07:25 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:07:25 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:07:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:07:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:07:25 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:07:25 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:07:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:07:26 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:07:26 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:07:26 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 16:07:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:07:26 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:07:26 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:07:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:07:26 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:07:26 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:07:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:07:26 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:07:26 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:07:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:07:26 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:07:26 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:07:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:07:26 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:07:26 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:07:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:07:26 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:07:26 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:07:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:07:26 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:07:26 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:07:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:07:46 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 16:07:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:07:47 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:07:47 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:07:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:07:47 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:07:47 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:07:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:07:47 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:07:47 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:07:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:07:47 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:07:47 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:07:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:07:47 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:07:47 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:07:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:07:47 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:07:47 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:07:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:07:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:07:47 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:07:47 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:07:47 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 16:07:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:07:47 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:07:47 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:07:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:07:48 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:07:48 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:07:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:07:48 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:07:48 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:07:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:07:48 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:07:48 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:07:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:07:48 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:07:48 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:07:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:07:48 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:07:48 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:07:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:07:48 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:07:48 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:07:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:07:48 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:07:48 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:08:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:08:11 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 16:08:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:08:11 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:08:11 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:08:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:08:11 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:08:11 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:08:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:08:11 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:08:11 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:08:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:08:12 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:08:12 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:08:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:08:12 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:08:12 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:08:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:08:12 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:08:12 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:08:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:08:12 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:08:12 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:08:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:08:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:08:12 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:08:12 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:08:12 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 16:08:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:08:12 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:08:12 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:08:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:08:12 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:08:12 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:08:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:08:12 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:08:12 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:08:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:08:12 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:08:12 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:08:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:08:13 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:08:13 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:08:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:08:13 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:08:13 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:08:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:08:13 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:08:13 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:08:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:08:13 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:08:13 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:08:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:08:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:08:36 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:08:36 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:08:36 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 16:08:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:08:36 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:08:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:08:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:08:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:08:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:08:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:08:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:08:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:08:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:08:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:08:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:08:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:08:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:08:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:08:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:08:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:08:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:08:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:08:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:08:37 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 16:08:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:08:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:08:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:08:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:08:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:08:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:08:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:08:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:08:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:08:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:08:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:08:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:08:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:08:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:08:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:08:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:08:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:08:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:08:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:08:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:08:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:08:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:08:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:08:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:08:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:08:46 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 16:08:46 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:08:46 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:08:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:08:46 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:08:46 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:08:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:08:46 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:08:46 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:08:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:08:46 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:08:46 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:08:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:08:46 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:08:46 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:08:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:08:46 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:08:46 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:08:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:08:46 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:08:46 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:08:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:08:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:08:47 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:08:47 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:08:47 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 16:08:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:08:47 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:08:47 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:08:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:08:47 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:08:47 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:08:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:08:47 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:08:47 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:08:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:08:47 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:08:47 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:08:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:08:47 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:08:47 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:08:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:08:47 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:08:47 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:08:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:08:47 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:08:47 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:08:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:08:47 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:08:47 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:11:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:11:07 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 16:11:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:11:07 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:11:07 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:11:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:11:07 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 16:11:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:11:07 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:11:07 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:11:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:11:31 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 16:11:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:11:31 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:11:31 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:11:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:11:31 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 16:11:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:11:31 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:11:31 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:12:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:12:45 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 16:12:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:12:45 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:12:45 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:12:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:12:45 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:12:45 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:12:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:12:45 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:12:45 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:12:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:12:45 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:12:45 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:12:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:12:45 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:12:45 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:12:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:12:45 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:12:45 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:12:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:12:45 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:12:45 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:12:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:12:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:12:46 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:12:46 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:12:46 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 16:12:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:12:46 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:12:46 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:12:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:12:46 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:12:46 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:12:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:12:46 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:12:46 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:12:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:12:46 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:12:46 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:12:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:12:46 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:12:46 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:12:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:12:46 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:12:46 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:12:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:12:46 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:12:46 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:12:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:12:47 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:12:47 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:13:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:13:03 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 16:13:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:13:03 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:13:03 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:13:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:13:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:13:03 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 16:13:03 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:13:03 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:13:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:13:08 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 16:13:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:13:08 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:13:08 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:13:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:13:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:13:08 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:13:08 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:13:08 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 16:13:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:13:39 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 16:13:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:13:39 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:13:39 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:13:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:13:39 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 16:13:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:13:40 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:13:40 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:14:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:14:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:14:25 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 16:14:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:14:25 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:14:25 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:14:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:14:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:14:25 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 16:14:25 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:14:25 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:14:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:14:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:14:30 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2014-10-18 16:14:30 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2014-10-18 16:14:30 --> 404 Page Not Found --> images
ERROR - 2014-10-18 16:14:30 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 16:14:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:14:30 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2014-10-18 16:14:30 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2014-10-18 16:14:30 --> 404 Page Not Found --> images
ERROR - 2014-10-18 16:14:31 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 16:14:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:14:39 --> 404 Page Not Found --> images
ERROR - 2014-10-18 16:14:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:14:40 --> 404 Page Not Found --> images
ERROR - 2014-10-18 16:14:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:14:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:14:43 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 16:14:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:14:43 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:14:43 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:14:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:14:44 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 16:14:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:14:44 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:14:44 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:27:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:27:35 --> 404 Page Not Found --> images
ERROR - 2014-10-18 16:27:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:27:36 --> 404 Page Not Found --> images
ERROR - 2014-10-18 16:27:45 --> 404 Page Not Found --> cek_ongkir
ERROR - 2014-10-18 16:27:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:27:52 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 33
ERROR - 2014-10-18 16:27:52 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 33
ERROR - 2014-10-18 16:27:52 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 33
ERROR - 2014-10-18 16:27:52 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 33
ERROR - 2014-10-18 16:27:52 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 33
ERROR - 2014-10-18 16:27:52 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 33
ERROR - 2014-10-18 16:27:52 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 33
ERROR - 2014-10-18 16:27:52 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 33
ERROR - 2014-10-18 16:27:52 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 33
ERROR - 2014-10-18 16:27:52 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 33
ERROR - 2014-10-18 16:27:52 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 33
ERROR - 2014-10-18 16:27:52 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 33
ERROR - 2014-10-18 16:27:52 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 33
ERROR - 2014-10-18 16:27:52 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 33
ERROR - 2014-10-18 16:27:52 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 33
ERROR - 2014-10-18 16:27:52 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 33
ERROR - 2014-10-18 16:27:52 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 33
ERROR - 2014-10-18 16:27:52 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 33
ERROR - 2014-10-18 16:27:52 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 33
ERROR - 2014-10-18 16:27:52 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 33
ERROR - 2014-10-18 16:27:52 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 33
ERROR - 2014-10-18 16:27:52 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 33
ERROR - 2014-10-18 16:27:52 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 33
ERROR - 2014-10-18 16:27:52 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 33
ERROR - 2014-10-18 16:27:52 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 33
ERROR - 2014-10-18 16:27:52 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 33
ERROR - 2014-10-18 16:27:52 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 33
ERROR - 2014-10-18 16:27:52 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 33
ERROR - 2014-10-18 16:27:52 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 33
ERROR - 2014-10-18 16:27:52 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 33
ERROR - 2014-10-18 16:27:52 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 33
ERROR - 2014-10-18 16:27:52 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 33
ERROR - 2014-10-18 16:27:52 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 33
ERROR - 2014-10-18 16:27:52 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 33
ERROR - 2014-10-18 16:27:52 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 33
ERROR - 2014-10-18 16:27:52 --> Severity: Notice  --> Undefined variable: city C:\wamp\www\Esgotado\application\views\ongkir.php 48
ERROR - 2014-10-18 16:27:52 --> Severity: Notice  --> Undefined variable: district C:\wamp\www\Esgotado\application\views\ongkir.php 66
ERROR - 2014-10-18 16:27:52 --> 404 Page Not Found --> images
ERROR - 2014-10-18 16:27:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:27:53 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 33
ERROR - 2014-10-18 16:27:53 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 33
ERROR - 2014-10-18 16:27:53 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 33
ERROR - 2014-10-18 16:27:53 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 33
ERROR - 2014-10-18 16:27:53 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 33
ERROR - 2014-10-18 16:27:53 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 33
ERROR - 2014-10-18 16:27:53 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 33
ERROR - 2014-10-18 16:27:53 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 33
ERROR - 2014-10-18 16:27:53 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 33
ERROR - 2014-10-18 16:27:53 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 33
ERROR - 2014-10-18 16:27:53 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 33
ERROR - 2014-10-18 16:27:53 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 33
ERROR - 2014-10-18 16:27:53 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 33
ERROR - 2014-10-18 16:27:53 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 33
ERROR - 2014-10-18 16:27:53 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 33
ERROR - 2014-10-18 16:27:53 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 33
ERROR - 2014-10-18 16:27:53 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 33
ERROR - 2014-10-18 16:27:53 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 33
ERROR - 2014-10-18 16:27:53 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 33
ERROR - 2014-10-18 16:27:53 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 33
ERROR - 2014-10-18 16:27:53 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 33
ERROR - 2014-10-18 16:27:53 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 33
ERROR - 2014-10-18 16:27:53 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 33
ERROR - 2014-10-18 16:27:53 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 33
ERROR - 2014-10-18 16:27:53 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 33
ERROR - 2014-10-18 16:27:53 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 33
ERROR - 2014-10-18 16:27:53 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 33
ERROR - 2014-10-18 16:27:53 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 33
ERROR - 2014-10-18 16:27:53 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 33
ERROR - 2014-10-18 16:27:53 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 33
ERROR - 2014-10-18 16:27:53 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 33
ERROR - 2014-10-18 16:27:53 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 33
ERROR - 2014-10-18 16:27:53 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 33
ERROR - 2014-10-18 16:27:53 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 33
ERROR - 2014-10-18 16:27:53 --> Severity: Notice  --> Undefined variable: province_id C:\wamp\www\Esgotado\application\views\ongkir.php 33
ERROR - 2014-10-18 16:27:53 --> Severity: Notice  --> Undefined variable: city C:\wamp\www\Esgotado\application\views\ongkir.php 48
ERROR - 2014-10-18 16:27:53 --> Severity: Notice  --> Undefined variable: district C:\wamp\www\Esgotado\application\views\ongkir.php 66
ERROR - 2014-10-18 16:27:53 --> 404 Page Not Found --> images
ERROR - 2014-10-18 16:28:02 --> 404 Page Not Found --> order_tracking
ERROR - 2014-10-18 16:28:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:28:07 --> 404 Page Not Found --> images
ERROR - 2014-10-18 16:28:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:28:08 --> 404 Page Not Found --> images
ERROR - 2014-10-18 16:28:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:28:16 --> 404 Page Not Found --> images
ERROR - 2014-10-18 16:28:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:28:16 --> 404 Page Not Found --> images
ERROR - 2014-10-18 16:28:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:28:21 --> 404 Page Not Found --> images
ERROR - 2014-10-18 16:28:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:28:22 --> 404 Page Not Found --> images
ERROR - 2014-10-18 16:32:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:32:28 --> 404 Page Not Found --> images
ERROR - 2014-10-18 16:32:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:32:28 --> 404 Page Not Found --> images
ERROR - 2014-10-18 16:32:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:32:30 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 16:32:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:32:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:32:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:32:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:32:31 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 16:32:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:32:31 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:32:31 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:33:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:33:05 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 16:33:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:33:05 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:33:05 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:33:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:33:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:33:13 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:33:13 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:33:18 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 16:33:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:33:18 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 16:33:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:33:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:33:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:33:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:33:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:33:20 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:33:20 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:33:24 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 16:33:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:33:33 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 16:33:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:33:33 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:33:33 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:33:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:33:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:33:34 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:33:34 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:33:37 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 16:33:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:33:49 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 16:33:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:33:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:33:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:33:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:33:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:33:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:33:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:33:52 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 16:35:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:35:29 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 16:35:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:35:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:35:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:35:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:35:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:35:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:35:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:35:34 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 16:35:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:35:53 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 16:35:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:35:53 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:35:53 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:35:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:35:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:35:53 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:35:53 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:35:59 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 16:36:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:36:13 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 16:36:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:36:13 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:36:13 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:36:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:36:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:36:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:36:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:36:17 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 16:36:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:36:50 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 16:36:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:36:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:36:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:36:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:36:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:36:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:36:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:36:54 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 16:37:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:37:11 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 16:37:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:37:11 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:37:11 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:37:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:37:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:37:11 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:37:11 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:37:14 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 16:37:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:37:26 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 16:37:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:37:26 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:37:26 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:37:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:37:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:37:26 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:37:26 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:37:29 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 16:39:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:39:49 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 16:39:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:39:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:39:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:39:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:39:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:39:52 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:39:52 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:39:54 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 16:42:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:42:19 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 16:42:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:42:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:42:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:42:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:42:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:42:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:42:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:42:36 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 16:43:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:43:32 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 16:43:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:43:32 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:43:32 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:43:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:43:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:43:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:43:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:43:40 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 16:44:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:44:07 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 16:44:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:44:07 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:44:07 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:44:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:44:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:44:08 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:44:08 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:44:17 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 16:45:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:45:02 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 16:45:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:45:02 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:45:02 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:45:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:45:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:45:04 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:45:04 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:45:05 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 16:45:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:45:16 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 16:45:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:45:16 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:45:16 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:45:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:45:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:45:16 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:45:16 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:45:19 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 16:45:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:45:39 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 16:45:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:45:39 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:45:39 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:45:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:45:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:45:40 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:45:40 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:45:42 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 16:46:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:46:05 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 16:46:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:46:05 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:46:05 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:46:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:46:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:46:05 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:46:05 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:46:21 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 16:46:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:46:41 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 16:46:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:46:41 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:46:41 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:46:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:46:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:46:42 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:46:42 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:46:44 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 16:46:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:46:54 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 16:46:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:46:54 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:46:54 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:47:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:47:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:47:02 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:47:02 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:47:14 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 16:47:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:47:15 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 16:47:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:47:15 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:47:15 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:47:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:47:15 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 16:47:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:47:15 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:47:15 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:47:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:47:18 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 16:47:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:47:18 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:47:18 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:47:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:47:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:47:18 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:47:18 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:47:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:47:28 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 16:47:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:47:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:47:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:47:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:47:28 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 16:47:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:47:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:47:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:47:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:47:44 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 16:47:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:47:44 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:47:44 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:47:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:47:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:47:45 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:47:45 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:48:06 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 16:48:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:48:07 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 16:48:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:48:07 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:48:07 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:48:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:48:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:48:07 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:48:07 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:48:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:48:12 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 16:48:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:48:12 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:48:12 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:48:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:48:13 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 16:48:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:48:13 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:48:13 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:49:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:49:04 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 16:49:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:49:05 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:49:05 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:49:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:49:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:49:05 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 16:49:05 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:49:05 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:49:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:49:19 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 16:49:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:49:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:49:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:49:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:49:19 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 16:49:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:49:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:49:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:50:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:50:18 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 16:50:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:50:18 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:50:18 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:50:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:50:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:50:18 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 16:50:18 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:50:18 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:50:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:50:24 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 16:50:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:50:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:50:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:50:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:50:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:50:25 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 16:50:25 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:50:25 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:50:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:50:53 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 16:50:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:50:53 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:50:53 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:50:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:50:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:50:53 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 16:50:53 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:50:53 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:51:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:51:02 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 16:51:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:51:02 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:51:02 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:51:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:51:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:51:02 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 16:51:02 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:51:02 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:51:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:51:15 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 16:51:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:51:15 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:51:15 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:51:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:51:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:51:15 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 16:51:15 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:51:15 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:51:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:51:57 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 16:51:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:51:57 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:51:57 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:51:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:51:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:51:57 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 16:51:57 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:51:57 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:52:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:52:17 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 16:52:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:52:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:52:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:52:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:52:18 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 16:52:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:52:18 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:52:18 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:52:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:52:32 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 16:52:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:52:32 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:52:32 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:52:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:52:32 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 16:52:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:52:32 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:52:32 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:52:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:52:45 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 16:52:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:52:45 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:52:45 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:52:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:52:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:52:45 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 16:52:45 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:52:45 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:52:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:52:53 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 16:52:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:52:53 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:52:53 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:52:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:52:53 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 16:52:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:52:54 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:52:54 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:53:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:53:03 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 16:53:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:53:03 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:53:03 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:53:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:53:03 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 16:53:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:53:03 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:53:03 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:53:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:53:07 --> 404 Page Not Found --> images
ERROR - 2014-10-18 16:53:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:53:08 --> 404 Page Not Found --> images
ERROR - 2014-10-18 16:53:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:53:42 --> 404 Page Not Found --> images
ERROR - 2014-10-18 16:53:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:53:42 --> 404 Page Not Found --> images
ERROR - 2014-10-18 16:53:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:53:45 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 16:53:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:53:45 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:53:45 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:53:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:53:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:53:45 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 16:53:45 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:53:45 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:53:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:53:52 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 16:53:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:53:52 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:53:52 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:53:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:53:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:53:52 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:53:52 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 16:53:52 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:53:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:53:58 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 16:53:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:53:58 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:53:58 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:53:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:53:58 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 16:53:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:53:58 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:53:58 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:54:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:54:50 --> 404 Page Not Found --> images
ERROR - 2014-10-18 16:54:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:54:50 --> 404 Page Not Found --> images
ERROR - 2014-10-18 16:54:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:54:52 --> 404 Page Not Found --> images
ERROR - 2014-10-18 16:54:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:54:52 --> 404 Page Not Found --> images
ERROR - 2014-10-18 16:54:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:54:54 --> 404 Page Not Found --> images
ERROR - 2014-10-18 16:54:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:54:54 --> 404 Page Not Found --> images
ERROR - 2014-10-18 16:55:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:55:07 --> 404 Page Not Found --> images
ERROR - 2014-10-18 16:55:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:55:10 --> 404 Page Not Found --> images
ERROR - 2014-10-18 16:55:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:55:48 --> 404 Page Not Found --> images
ERROR - 2014-10-18 16:55:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:55:50 --> 404 Page Not Found --> images
ERROR - 2014-10-18 16:56:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:56:13 --> 404 Page Not Found --> images
ERROR - 2014-10-18 16:56:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:56:47 --> 404 Page Not Found --> images
ERROR - 2014-10-18 16:56:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:56:48 --> 404 Page Not Found --> images
ERROR - 2014-10-18 16:57:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:57:36 --> 404 Page Not Found --> images
ERROR - 2014-10-18 16:57:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:57:39 --> 404 Page Not Found --> images
ERROR - 2014-10-18 16:57:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:57:45 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 16:57:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:57:46 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:57:46 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:57:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:57:46 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 16:57:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:57:46 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:57:46 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:57:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:57:59 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 16:57:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:57:59 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:57:59 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:57:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:57:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:57:59 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:57:59 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:58:04 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 16:58:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:58:18 --> 404 Page Not Found --> images
ERROR - 2014-10-18 16:58:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:58:19 --> 404 Page Not Found --> images
ERROR - 2014-10-18 16:58:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:58:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:58:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:58:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:58:26 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 16:58:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:58:26 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:58:26 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:58:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:58:27 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 16:58:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:58:27 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 16:58:27 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 16:58:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:58:46 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2014-10-18 16:58:46 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2014-10-18 16:58:46 --> 404 Page Not Found --> images
ERROR - 2014-10-18 16:58:46 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 16:58:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 16:58:47 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2014-10-18 16:58:47 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2014-10-18 16:58:47 --> 404 Page Not Found --> images
ERROR - 2014-10-18 16:58:47 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 17:23:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 17:23:08 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2014-10-18 17:23:08 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2014-10-18 17:23:08 --> 404 Page Not Found --> images
ERROR - 2014-10-18 17:23:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 17:23:08 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2014-10-18 17:23:08 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2014-10-18 17:23:08 --> 404 Page Not Found --> images
ERROR - 2014-10-18 17:23:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 17:23:11 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2014-10-18 17:23:11 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2014-10-18 17:23:11 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 17:23:11 --> 404 Page Not Found --> images
ERROR - 2014-10-18 17:23:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 17:23:13 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2014-10-18 17:23:13 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2014-10-18 17:23:13 --> 404 Page Not Found --> images
ERROR - 2014-10-18 17:23:13 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 17:23:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 17:23:14 --> 404 Page Not Found --> images
ERROR - 2014-10-18 17:23:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 17:23:14 --> 404 Page Not Found --> images
ERROR - 2014-10-18 17:23:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 17:23:21 --> 404 Page Not Found --> images
ERROR - 2014-10-18 17:23:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 17:23:22 --> 404 Page Not Found --> images
ERROR - 2014-10-18 17:29:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 17:29:18 --> 404 Page Not Found --> images
ERROR - 2014-10-18 17:29:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 17:29:18 --> 404 Page Not Found --> images
ERROR - 2014-10-18 17:29:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 17:29:20 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 17:29:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 17:29:20 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 17:29:20 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-18 17:29:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 17:29:20 --> 404 Page Not Found --> my_js
ERROR - 2014-10-18 17:29:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-18 17:29:20 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-18 17:29:20 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
