<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-03-27 00:35:42 --> 404 Page Not Found --> template
ERROR - 2015-03-27 00:35:46 --> 404 Page Not Found --> template
ERROR - 2015-03-27 00:35:49 --> You did not select a file to upload.
ERROR - 2015-03-27 00:35:49 --> 404 Page Not Found --> template
