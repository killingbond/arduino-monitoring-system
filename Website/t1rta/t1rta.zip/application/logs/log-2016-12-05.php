<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2016-12-05 11:38:54 --> Severity: Notice  --> Undefined variable: notification_order /home/tirtadah/public_html/t1rta/application/views/slices/sidebar.php 85
ERROR - 2016-12-05 11:38:54 --> Severity: Notice  --> Undefined variable: notification_order /home/tirtadah/public_html/t1rta/application/views/slices/sidebar.php 98
