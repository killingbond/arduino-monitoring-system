<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-03-04 17:29:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-04 17:29:32 --> 404 Page Not Found --> template
ERROR - 2015-03-04 17:33:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-04 17:33:52 --> 404 Page Not Found --> template
ERROR - 2015-03-04 17:34:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-04 17:34:24 --> 404 Page Not Found --> template
ERROR - 2015-03-04 17:34:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-04 17:34:59 --> 404 Page Not Found --> template
ERROR - 2015-03-04 17:35:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-04 17:35:20 --> 404 Page Not Found --> template
ERROR - 2015-03-04 17:35:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-04 17:35:32 --> 404 Page Not Found --> template
ERROR - 2015-03-04 17:36:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-04 17:36:15 --> 404 Page Not Found --> template
ERROR - 2015-03-04 17:36:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-04 17:36:58 --> 404 Page Not Found --> template
ERROR - 2015-03-04 17:37:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-04 17:37:10 --> 404 Page Not Found --> template
ERROR - 2015-03-04 17:37:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-04 17:37:24 --> 404 Page Not Found --> template
ERROR - 2015-03-04 17:38:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-04 17:38:59 --> 404 Page Not Found --> template
ERROR - 2015-03-04 17:39:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-04 17:39:19 --> 404 Page Not Found --> template
ERROR - 2015-03-04 17:39:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-04 17:39:34 --> 404 Page Not Found --> template
ERROR - 2015-03-04 17:39:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-04 17:39:42 --> 404 Page Not Found --> template
ERROR - 2015-03-04 17:39:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-04 17:39:53 --> 404 Page Not Found --> template
ERROR - 2015-03-04 17:40:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-04 17:40:04 --> 404 Page Not Found --> template
ERROR - 2015-03-04 17:50:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-04 17:50:43 --> 404 Page Not Found --> template
ERROR - 2015-03-04 17:51:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-04 17:51:10 --> 404 Page Not Found --> template
ERROR - 2015-03-04 17:53:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-04 17:53:54 --> 404 Page Not Found --> template
ERROR - 2015-03-04 17:53:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-04 17:53:57 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/Esgotado/application/controllers/autoload.php:35) /Applications/MAMP/htdocs/Esgotado/system/core/Output.php 391
ERROR - 2015-03-04 17:53:57 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/Esgotado/application/controllers/autoload.php:35) /Applications/MAMP/htdocs/Esgotado/system/core/Output.php 391
ERROR - 2015-03-04 17:54:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-04 17:54:00 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/Esgotado/application/controllers/autoload.php:35) /Applications/MAMP/htdocs/Esgotado/system/core/Output.php 391
ERROR - 2015-03-04 17:54:00 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/Esgotado/application/controllers/autoload.php:35) /Applications/MAMP/htdocs/Esgotado/system/core/Output.php 391
ERROR - 2015-03-04 17:54:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-04 17:54:03 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/Esgotado/application/controllers/autoload.php:35) /Applications/MAMP/htdocs/Esgotado/system/core/Output.php 391
ERROR - 2015-03-04 17:54:03 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/Esgotado/application/controllers/autoload.php:35) /Applications/MAMP/htdocs/Esgotado/system/core/Output.php 391
ERROR - 2015-03-04 17:54:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-04 17:54:04 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/Esgotado/application/controllers/autoload.php:35) /Applications/MAMP/htdocs/Esgotado/system/core/Output.php 391
ERROR - 2015-03-04 17:54:04 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/Esgotado/application/controllers/autoload.php:35) /Applications/MAMP/htdocs/Esgotado/system/core/Output.php 391
ERROR - 2015-03-04 17:54:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-04 17:54:04 --> 404 Page Not Found --> template
ERROR - 2015-03-04 17:54:04 --> 404 Page Not Found --> my_js
ERROR - 2015-03-04 17:54:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-04 17:54:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-04 17:54:15 --> 404 Page Not Found --> my_js
ERROR - 2015-03-04 17:54:15 --> 404 Page Not Found --> template
ERROR - 2015-03-04 17:54:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-04 17:54:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-04 17:54:25 --> Severity: Notice  --> Undefined variable: percent_ppn /Applications/MAMP/htdocs/Esgotado/application/views/cart.php 137
ERROR - 2015-03-04 17:54:25 --> Severity: Notice  --> Undefined variable: ppn /Applications/MAMP/htdocs/Esgotado/application/views/cart.php 137
ERROR - 2015-03-04 17:54:25 --> 404 Page Not Found --> template
ERROR - 2015-03-04 17:55:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-04 17:55:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-04 17:55:23 --> 404 Page Not Found --> template
ERROR - 2015-03-04 17:56:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-04 17:56:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-04 17:56:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-04 17:56:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-04 17:56:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-04 17:56:27 --> 404 Page Not Found --> template
ERROR - 2015-03-04 17:56:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-04 17:56:43 --> 404 Page Not Found --> template
ERROR - 2015-03-04 17:56:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-04 17:56:44 --> 404 Page Not Found --> template
ERROR - 2015-03-04 17:56:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-04 17:56:46 --> 404 Page Not Found --> template
ERROR - 2015-03-04 17:57:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-04 17:57:46 --> 404 Page Not Found --> template
ERROR - 2015-03-04 17:58:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-04 17:58:08 --> 404 Page Not Found --> template
ERROR - 2015-03-04 17:58:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-04 17:58:12 --> 404 Page Not Found --> template
ERROR - 2015-03-04 17:58:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-04 17:58:13 --> 404 Page Not Found --> template
ERROR - 2015-03-04 17:58:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-04 17:58:14 --> 404 Page Not Found --> template
ERROR - 2015-03-04 17:58:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-04 17:58:15 --> 404 Page Not Found --> template
ERROR - 2015-03-04 17:58:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-04 17:58:16 --> 404 Page Not Found --> template
ERROR - 2015-03-04 17:58:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-04 17:58:18 --> 404 Page Not Found --> template
ERROR - 2015-03-04 17:58:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-04 17:58:19 --> 404 Page Not Found --> template
ERROR - 2015-03-04 17:58:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-04 17:58:21 --> 404 Page Not Found --> template
ERROR - 2015-03-04 17:58:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-04 17:58:22 --> 404 Page Not Found --> template
ERROR - 2015-03-04 18:00:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-04 18:00:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-04 18:00:08 --> 404 Page Not Found --> template
ERROR - 2015-03-04 18:00:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-04 18:00:13 --> Severity: Notice  --> Undefined variable: percent_ppn /Applications/MAMP/htdocs/Esgotado/application/views/cart.php 137
ERROR - 2015-03-04 18:00:13 --> Severity: Notice  --> Undefined variable: ppn /Applications/MAMP/htdocs/Esgotado/application/views/cart.php 137
ERROR - 2015-03-04 18:00:13 --> 404 Page Not Found --> template
ERROR - 2015-03-04 18:11:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-04 18:11:47 --> Severity: Notice  --> unserialize(): Error at offset 0 of 415 bytes /Applications/MAMP/htdocs/Esgotado/system/libraries/Session.php 724
ERROR - 2015-03-04 18:11:48 --> 404 Page Not Found --> template
ERROR - 2015-03-04 18:11:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-04 18:11:59 --> Severity: Notice  --> Undefined variable: percent_ppn /Applications/MAMP/htdocs/Esgotado/application/views/cart.php 137
ERROR - 2015-03-04 18:11:59 --> Severity: Notice  --> Undefined variable: ppn /Applications/MAMP/htdocs/Esgotado/application/views/cart.php 137
ERROR - 2015-03-04 18:11:59 --> 404 Page Not Found --> template
ERROR - 2015-03-04 18:12:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-04 18:12:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-04 18:12:04 --> 404 Page Not Found --> template
ERROR - 2015-03-04 18:12:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-04 18:12:25 --> Severity: Notice  --> Undefined variable: percent_ppn /Applications/MAMP/htdocs/Esgotado/application/views/cart.php 137
ERROR - 2015-03-04 18:12:25 --> Severity: Notice  --> Undefined variable: ppn /Applications/MAMP/htdocs/Esgotado/application/views/cart.php 137
ERROR - 2015-03-04 18:12:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-04 18:12:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-04 18:12:34 --> 404 Page Not Found --> template
ERROR - 2015-03-04 18:12:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-04 18:12:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-04 18:12:41 --> Severity: Notice  --> Undefined variable: percent_ppn /Applications/MAMP/htdocs/Esgotado/application/views/cart.php 137
ERROR - 2015-03-04 18:12:41 --> Severity: Notice  --> Undefined variable: ppn /Applications/MAMP/htdocs/Esgotado/application/views/cart.php 137
ERROR - 2015-03-04 18:12:41 --> 404 Page Not Found --> template
ERROR - 2015-03-04 18:12:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-04 18:12:49 --> 404 Page Not Found --> template
ERROR - 2015-03-04 18:12:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-04 18:12:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
