<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-12-13 08:13:32 --> Severity: Notice  --> Undefined variable: max C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\slidecollection\slidecollection.php 50
ERROR - 2015-12-13 08:13:32 --> Severity: Notice  --> Undefined variable: max C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\slidecollection\slidecollection.php 51
ERROR - 2015-12-13 08:13:32 --> Severity: Notice  --> Undefined variable: max C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\slidecollection\slidecollection.php 52
ERROR - 2015-12-13 08:13:32 --> Severity: Notice  --> Undefined variable: max C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\slidecollection\slidecollection.php 53
ERROR - 2015-12-13 08:13:32 --> Severity: Notice  --> Undefined variable: max C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\slidecollection\slidecollection.php 54
ERROR - 2015-12-13 08:13:32 --> Severity: Notice  --> Undefined variable: search C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\slidecollection\slidecollection.php 59
ERROR - 2015-12-13 08:13:32 --> Severity: Notice  --> Undefined variable: page C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\slidecollection\slidecollection.php 207
ERROR - 2015-12-13 08:13:32 --> Severity: Notice  --> Undefined variable: order C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\slidecollection\slidecollection.php 208
ERROR - 2015-12-13 11:34:00 --> Severity: Notice  --> Undefined variable: max C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\slidecollection\slidecollection.php 50
ERROR - 2015-12-13 11:34:00 --> Severity: Notice  --> Undefined variable: max C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\slidecollection\slidecollection.php 51
ERROR - 2015-12-13 11:34:00 --> Severity: Notice  --> Undefined variable: max C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\slidecollection\slidecollection.php 52
ERROR - 2015-12-13 11:34:00 --> Severity: Notice  --> Undefined variable: max C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\slidecollection\slidecollection.php 53
ERROR - 2015-12-13 11:34:00 --> Severity: Notice  --> Undefined variable: max C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\slidecollection\slidecollection.php 54
ERROR - 2015-12-13 11:34:00 --> Severity: Notice  --> Undefined variable: search C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\slidecollection\slidecollection.php 59
ERROR - 2015-12-13 11:34:00 --> Severity: Notice  --> Undefined variable: page C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\slidecollection\slidecollection.php 207
ERROR - 2015-12-13 11:34:00 --> Severity: Notice  --> Undefined variable: order C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\slidecollection\slidecollection.php 208
