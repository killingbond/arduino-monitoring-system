<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-04-07 04:39:02 --> 404 Page Not Found --> template
ERROR - 2015-04-07 04:39:05 --> 404 Page Not Found --> template
ERROR - 2015-04-07 04:39:07 --> 404 Page Not Found --> template
