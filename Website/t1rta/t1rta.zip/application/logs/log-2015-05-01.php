<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-05-01 03:44:30 --> 404 Page Not Found --> template
