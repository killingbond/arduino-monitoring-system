<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-04-04 05:41:22 --> 404 Page Not Found --> template
ERROR - 2015-04-04 05:42:10 --> 404 Page Not Found --> template
ERROR - 2015-04-04 05:42:15 --> 404 Page Not Found --> template
