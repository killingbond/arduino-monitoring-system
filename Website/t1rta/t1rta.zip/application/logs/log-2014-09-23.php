<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2014-09-23 23:41:47 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-09-23 23:41:47 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-09-23 23:41:47 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-09-23 23:41:47 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-09-23 23:41:51 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-09-23 23:41:51 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-09-23 23:41:51 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-09-23 23:41:51 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-09-23 23:42:14 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-09-23 23:42:14 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-09-23 23:42:14 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-09-23 23:42:14 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-09-23 23:43:25 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Galaxia-Store\application\models\cart_m.php 401
ERROR - 2014-09-23 23:43:25 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Galaxia-Store\application\models\cart_m.php 413
ERROR - 2014-09-23 23:43:25 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Galaxia-Store\application\models\cart_m.php 415
ERROR - 2014-09-23 23:43:25 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Galaxia-Store\application\models\cart_m.php 416
ERROR - 2014-09-23 23:43:25 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Galaxia-Store\application\models\cart_m.php 417
ERROR - 2014-09-23 23:43:25 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Galaxia-Store\application\models\cart_m.php 418
ERROR - 2014-09-23 23:43:25 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Galaxia-Store\application\models\cart_m.php 419
ERROR - 2014-09-23 23:43:25 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Galaxia-Store\application\models\cart_m.php 422
ERROR - 2014-09-23 23:43:25 --> Query error: Column 'courier_id' cannot be null
ERROR - 2014-09-23 23:43:37 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-09-23 23:43:37 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-09-23 23:43:37 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-09-23 23:43:37 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-09-23 23:43:44 --> Severity: Warning  --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\wamp\www\Galaxia-Store\system\libraries\Email.php 1553
