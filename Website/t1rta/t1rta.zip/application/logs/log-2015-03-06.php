<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-03-06 01:44:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 01:44:11 --> 404 Page Not Found --> template
ERROR - 2015-03-06 01:44:11 --> 404 Page Not Found --> template
ERROR - 2015-03-06 01:44:11 --> 404 Page Not Found --> template
ERROR - 2015-03-06 01:44:11 --> 404 Page Not Found --> template
ERROR - 2015-03-06 01:44:11 --> 404 Page Not Found --> template
ERROR - 2015-03-06 01:44:11 --> 404 Page Not Found --> template
ERROR - 2015-03-06 01:44:11 --> 404 Page Not Found --> template
ERROR - 2015-03-06 01:44:11 --> 404 Page Not Found --> template
ERROR - 2015-03-06 01:44:11 --> 404 Page Not Found --> template
ERROR - 2015-03-06 01:44:11 --> 404 Page Not Found --> template
ERROR - 2015-03-06 01:44:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 01:44:18 --> 404 Page Not Found --> template
ERROR - 2015-03-06 01:44:18 --> 404 Page Not Found --> template
ERROR - 2015-03-06 01:44:18 --> 404 Page Not Found --> template
ERROR - 2015-03-06 01:44:18 --> 404 Page Not Found --> template
ERROR - 2015-03-06 01:44:18 --> 404 Page Not Found --> template
ERROR - 2015-03-06 01:44:18 --> 404 Page Not Found --> template
ERROR - 2015-03-06 01:44:18 --> 404 Page Not Found --> template
ERROR - 2015-03-06 01:44:18 --> 404 Page Not Found --> template
ERROR - 2015-03-06 01:44:18 --> 404 Page Not Found --> template
ERROR - 2015-03-06 01:44:18 --> 404 Page Not Found --> template
ERROR - 2015-03-06 01:44:18 --> 404 Page Not Found --> template
ERROR - 2015-03-06 01:44:18 --> 404 Page Not Found --> template
ERROR - 2015-03-06 01:44:18 --> 404 Page Not Found --> template
ERROR - 2015-03-06 01:44:18 --> 404 Page Not Found --> template
ERROR - 2015-03-06 01:44:18 --> 404 Page Not Found --> template
ERROR - 2015-03-06 01:44:18 --> 404 Page Not Found --> template
ERROR - 2015-03-06 01:44:18 --> 404 Page Not Found --> template
ERROR - 2015-03-06 01:44:18 --> 404 Page Not Found --> template
ERROR - 2015-03-06 01:44:18 --> 404 Page Not Found --> template
ERROR - 2015-03-06 01:45:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 01:45:19 --> 404 Page Not Found --> template
ERROR - 2015-03-06 01:45:19 --> 404 Page Not Found --> template
ERROR - 2015-03-06 01:45:19 --> 404 Page Not Found --> template
ERROR - 2015-03-06 01:45:19 --> 404 Page Not Found --> template
ERROR - 2015-03-06 01:45:19 --> 404 Page Not Found --> template
ERROR - 2015-03-06 01:45:19 --> 404 Page Not Found --> template
ERROR - 2015-03-06 01:45:19 --> 404 Page Not Found --> template
ERROR - 2015-03-06 01:45:19 --> 404 Page Not Found --> template
ERROR - 2015-03-06 01:45:19 --> 404 Page Not Found --> template
ERROR - 2015-03-06 01:45:19 --> 404 Page Not Found --> template
ERROR - 2015-03-06 01:47:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 01:47:40 --> 404 Page Not Found --> template
ERROR - 2015-03-06 01:47:40 --> 404 Page Not Found --> template
ERROR - 2015-03-06 01:47:40 --> 404 Page Not Found --> template
ERROR - 2015-03-06 01:47:40 --> 404 Page Not Found --> template
ERROR - 2015-03-06 01:47:40 --> 404 Page Not Found --> template
ERROR - 2015-03-06 01:47:40 --> 404 Page Not Found --> template
ERROR - 2015-03-06 01:47:40 --> 404 Page Not Found --> template
ERROR - 2015-03-06 01:47:40 --> 404 Page Not Found --> template
ERROR - 2015-03-06 01:47:40 --> 404 Page Not Found --> template
ERROR - 2015-03-06 01:48:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 01:48:10 --> 404 Page Not Found --> template
ERROR - 2015-03-06 01:48:10 --> 404 Page Not Found --> template
ERROR - 2015-03-06 01:48:10 --> 404 Page Not Found --> template
ERROR - 2015-03-06 01:48:10 --> 404 Page Not Found --> template
ERROR - 2015-03-06 01:48:10 --> 404 Page Not Found --> template
ERROR - 2015-03-06 01:48:10 --> 404 Page Not Found --> template
ERROR - 2015-03-06 01:48:10 --> 404 Page Not Found --> template
ERROR - 2015-03-06 01:48:10 --> 404 Page Not Found --> template
ERROR - 2015-03-06 01:48:10 --> 404 Page Not Found --> template
ERROR - 2015-03-06 01:48:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 01:48:11 --> 404 Page Not Found --> gallery/Drawings
ERROR - 2015-03-06 01:48:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 01:48:11 --> 404 Page Not Found --> gallery/Illustrations
ERROR - 2015-03-06 01:48:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 01:48:11 --> 404 Page Not Found --> gallery/Photography
ERROR - 2015-03-06 01:48:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 01:48:11 --> 404 Page Not Found --> gallery/Drawings
ERROR - 2015-03-06 01:48:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 01:48:11 --> 404 Page Not Found --> gallery/Illustrations
ERROR - 2015-03-06 01:48:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 01:48:11 --> 404 Page Not Found --> gallery/Photography
ERROR - 2015-03-06 01:48:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 01:48:11 --> 404 Page Not Found --> gallery/Drawings
ERROR - 2015-03-06 01:48:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 01:48:11 --> 404 Page Not Found --> gallery/Illustrations
ERROR - 2015-03-06 01:48:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 01:48:11 --> 404 Page Not Found --> gallery/Photography
ERROR - 2015-03-06 01:48:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 01:48:11 --> 404 Page Not Found --> gallery/Drawings
ERROR - 2015-03-06 01:48:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 01:48:11 --> 404 Page Not Found --> gallery/Illustrations
ERROR - 2015-03-06 01:48:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 01:48:11 --> 404 Page Not Found --> gallery/Photography
ERROR - 2015-03-06 01:48:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 01:48:11 --> 404 Page Not Found --> gallery/Drawings
ERROR - 2015-03-06 01:48:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 01:48:11 --> 404 Page Not Found --> gallery/Illustrations
ERROR - 2015-03-06 01:48:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 01:48:11 --> 404 Page Not Found --> gallery/Photography
ERROR - 2015-03-06 01:50:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 01:50:43 --> 404 Page Not Found --> template
ERROR - 2015-03-06 01:50:43 --> 404 Page Not Found --> template
ERROR - 2015-03-06 01:50:43 --> 404 Page Not Found --> template
ERROR - 2015-03-06 01:50:43 --> 404 Page Not Found --> template
ERROR - 2015-03-06 01:50:43 --> 404 Page Not Found --> template
ERROR - 2015-03-06 01:50:43 --> 404 Page Not Found --> template
ERROR - 2015-03-06 01:50:43 --> 404 Page Not Found --> template
ERROR - 2015-03-06 01:50:43 --> 404 Page Not Found --> template
ERROR - 2015-03-06 01:50:43 --> 404 Page Not Found --> template
ERROR - 2015-03-06 01:50:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 01:50:43 --> 404 Page Not Found --> gallery/Illustrations
ERROR - 2015-03-06 01:50:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 01:50:44 --> 404 Page Not Found --> gallery/Illustrations
ERROR - 2015-03-06 01:50:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 01:50:44 --> 404 Page Not Found --> gallery/Photography
ERROR - 2015-03-06 01:50:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 01:50:44 --> 404 Page Not Found --> gallery/Drawings
ERROR - 2015-03-06 01:50:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 01:50:44 --> 404 Page Not Found --> gallery/Photography
ERROR - 2015-03-06 01:50:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 01:50:44 --> 404 Page Not Found --> gallery/Drawings
ERROR - 2015-03-06 01:50:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 01:50:44 --> 404 Page Not Found --> gallery/Drawings
ERROR - 2015-03-06 01:50:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 01:50:44 --> 404 Page Not Found --> gallery/Illustrations
ERROR - 2015-03-06 01:50:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 01:50:44 --> 404 Page Not Found --> gallery/Photography
ERROR - 2015-03-06 01:50:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 01:50:44 --> 404 Page Not Found --> gallery/Drawings
ERROR - 2015-03-06 01:50:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 01:50:44 --> 404 Page Not Found --> gallery/Illustrations
ERROR - 2015-03-06 01:50:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 01:50:44 --> 404 Page Not Found --> gallery/Photography
ERROR - 2015-03-06 01:50:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 01:50:44 --> 404 Page Not Found --> gallery/Drawings
ERROR - 2015-03-06 01:50:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 01:50:44 --> 404 Page Not Found --> gallery/Illustrations
ERROR - 2015-03-06 01:50:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 01:50:44 --> 404 Page Not Found --> gallery/Photography
ERROR - 2015-03-06 01:52:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 01:52:16 --> 404 Page Not Found --> template
ERROR - 2015-03-06 01:52:16 --> 404 Page Not Found --> template
ERROR - 2015-03-06 01:52:16 --> 404 Page Not Found --> template
ERROR - 2015-03-06 01:52:16 --> 404 Page Not Found --> template
ERROR - 2015-03-06 01:52:16 --> 404 Page Not Found --> template
ERROR - 2015-03-06 01:52:16 --> 404 Page Not Found --> template
ERROR - 2015-03-06 01:52:16 --> 404 Page Not Found --> template
ERROR - 2015-03-06 01:52:16 --> 404 Page Not Found --> template
ERROR - 2015-03-06 01:52:16 --> 404 Page Not Found --> template
ERROR - 2015-03-06 01:52:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 01:52:17 --> 404 Page Not Found --> gallery/Illustrations
ERROR - 2015-03-06 01:52:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 01:52:17 --> 404 Page Not Found --> gallery/Drawings
ERROR - 2015-03-06 01:52:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 01:52:17 --> 404 Page Not Found --> gallery/Photography
ERROR - 2015-03-06 01:52:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 01:52:17 --> 404 Page Not Found --> gallery/Drawings
ERROR - 2015-03-06 01:52:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 01:52:17 --> 404 Page Not Found --> gallery/Illustrations
ERROR - 2015-03-06 01:52:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 01:52:17 --> 404 Page Not Found --> gallery/Photography
ERROR - 2015-03-06 01:52:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 01:52:17 --> 404 Page Not Found --> gallery/Drawings
ERROR - 2015-03-06 01:52:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 01:52:17 --> 404 Page Not Found --> gallery/Illustrations
ERROR - 2015-03-06 01:52:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 01:52:17 --> 404 Page Not Found --> gallery/Photography
ERROR - 2015-03-06 01:52:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 01:52:17 --> 404 Page Not Found --> gallery/Drawings
ERROR - 2015-03-06 01:52:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 01:52:17 --> 404 Page Not Found --> gallery/Illustrations
ERROR - 2015-03-06 01:52:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 01:52:17 --> 404 Page Not Found --> gallery/Photography
ERROR - 2015-03-06 01:52:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 01:52:17 --> 404 Page Not Found --> gallery/Drawings
ERROR - 2015-03-06 01:52:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 01:52:17 --> 404 Page Not Found --> gallery/Illustrations
ERROR - 2015-03-06 01:52:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 01:52:17 --> 404 Page Not Found --> gallery/Photography
ERROR - 2015-03-06 01:53:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 01:53:44 --> 404 Page Not Found --> template
ERROR - 2015-03-06 01:53:44 --> 404 Page Not Found --> template
ERROR - 2015-03-06 01:53:44 --> 404 Page Not Found --> template
ERROR - 2015-03-06 01:53:44 --> 404 Page Not Found --> template
ERROR - 2015-03-06 01:53:44 --> 404 Page Not Found --> template
ERROR - 2015-03-06 01:53:44 --> 404 Page Not Found --> template
ERROR - 2015-03-06 01:53:44 --> 404 Page Not Found --> template
ERROR - 2015-03-06 01:53:44 --> 404 Page Not Found --> template
ERROR - 2015-03-06 01:53:44 --> 404 Page Not Found --> template
ERROR - 2015-03-06 01:53:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 01:53:44 --> 404 Page Not Found --> gallery/Illustrations
ERROR - 2015-03-06 01:53:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 01:53:44 --> 404 Page Not Found --> gallery/Illustrations
ERROR - 2015-03-06 01:53:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 01:53:44 --> 404 Page Not Found --> gallery/Drawings
ERROR - 2015-03-06 01:53:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 01:53:44 --> 404 Page Not Found --> gallery/Photography
ERROR - 2015-03-06 01:53:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 01:53:44 --> 404 Page Not Found --> gallery/Drawings
ERROR - 2015-03-06 01:54:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 01:54:21 --> 404 Page Not Found --> template
ERROR - 2015-03-06 01:54:21 --> 404 Page Not Found --> template
ERROR - 2015-03-06 01:54:21 --> 404 Page Not Found --> template
ERROR - 2015-03-06 01:54:21 --> 404 Page Not Found --> template
ERROR - 2015-03-06 01:54:21 --> 404 Page Not Found --> template
ERROR - 2015-03-06 01:54:21 --> 404 Page Not Found --> template
ERROR - 2015-03-06 01:54:21 --> 404 Page Not Found --> template
ERROR - 2015-03-06 01:54:21 --> 404 Page Not Found --> template
ERROR - 2015-03-06 01:54:21 --> 404 Page Not Found --> template
ERROR - 2015-03-06 01:54:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 01:54:21 --> 404 Page Not Found --> gallery/Illustrations
ERROR - 2015-03-06 01:54:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 01:54:21 --> 404 Page Not Found --> gallery/Drawings
ERROR - 2015-03-06 01:54:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 01:54:21 --> 404 Page Not Found --> gallery/Photography
ERROR - 2015-03-06 01:54:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 01:54:21 --> 404 Page Not Found --> gallery/Drawings
ERROR - 2015-03-06 01:54:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 01:54:21 --> 404 Page Not Found --> gallery/Illustrations
ERROR - 2015-03-06 01:54:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 01:54:21 --> 404 Page Not Found --> gallery/Photography
ERROR - 2015-03-06 01:54:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 01:54:21 --> 404 Page Not Found --> gallery/Drawings
ERROR - 2015-03-06 01:54:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 01:54:21 --> 404 Page Not Found --> gallery/Illustrations
ERROR - 2015-03-06 01:54:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 01:54:21 --> 404 Page Not Found --> gallery/Photography
ERROR - 2015-03-06 01:54:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 01:54:21 --> 404 Page Not Found --> gallery/Drawings
ERROR - 2015-03-06 01:54:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 01:54:49 --> 404 Page Not Found --> template
ERROR - 2015-03-06 01:54:49 --> 404 Page Not Found --> template
ERROR - 2015-03-06 01:54:49 --> 404 Page Not Found --> template
ERROR - 2015-03-06 01:54:49 --> 404 Page Not Found --> template
ERROR - 2015-03-06 01:54:49 --> 404 Page Not Found --> template
ERROR - 2015-03-06 01:54:49 --> 404 Page Not Found --> template
ERROR - 2015-03-06 01:54:49 --> 404 Page Not Found --> template
ERROR - 2015-03-06 01:54:49 --> 404 Page Not Found --> template
ERROR - 2015-03-06 01:54:49 --> 404 Page Not Found --> template
ERROR - 2015-03-06 01:54:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 01:54:50 --> 404 Page Not Found --> gallery/Illustrations
ERROR - 2015-03-06 01:54:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 01:54:50 --> 404 Page Not Found --> gallery/Drawings
ERROR - 2015-03-06 01:54:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 01:54:50 --> 404 Page Not Found --> gallery/Photography
ERROR - 2015-03-06 01:54:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 01:54:50 --> 404 Page Not Found --> gallery/Illustrations
ERROR - 2015-03-06 01:54:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 01:54:50 --> 404 Page Not Found --> gallery/Photography
ERROR - 2015-03-06 01:54:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 01:54:50 --> 404 Page Not Found --> gallery/Drawings
ERROR - 2015-03-06 01:54:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 01:54:50 --> 404 Page Not Found --> gallery/Drawings
ERROR - 2015-03-06 01:54:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 01:54:50 --> 404 Page Not Found --> gallery/Illustrations
ERROR - 2015-03-06 01:54:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 01:54:50 --> 404 Page Not Found --> gallery/Photography
ERROR - 2015-03-06 01:54:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 01:54:50 --> 404 Page Not Found --> gallery/Drawings
ERROR - 2015-03-06 01:55:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 01:55:26 --> 404 Page Not Found --> template
ERROR - 2015-03-06 01:55:26 --> 404 Page Not Found --> template
ERROR - 2015-03-06 01:55:26 --> 404 Page Not Found --> template
ERROR - 2015-03-06 01:55:26 --> 404 Page Not Found --> template
ERROR - 2015-03-06 01:55:26 --> 404 Page Not Found --> template
ERROR - 2015-03-06 01:55:26 --> 404 Page Not Found --> template
ERROR - 2015-03-06 01:55:26 --> 404 Page Not Found --> template
ERROR - 2015-03-06 01:55:26 --> 404 Page Not Found --> template
ERROR - 2015-03-06 01:55:26 --> 404 Page Not Found --> template
ERROR - 2015-03-06 01:55:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 01:55:27 --> 404 Page Not Found --> gallery/Drawings
ERROR - 2015-03-06 01:55:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 01:55:27 --> 404 Page Not Found --> gallery/Illustrations
ERROR - 2015-03-06 01:55:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 01:55:27 --> 404 Page Not Found --> gallery/Drawings
ERROR - 2015-03-06 01:55:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 01:55:27 --> 404 Page Not Found --> gallery/Illustrations
ERROR - 2015-03-06 01:55:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 01:55:27 --> 404 Page Not Found --> gallery/Photography
ERROR - 2015-03-06 01:55:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 01:55:27 --> 404 Page Not Found --> gallery/Photography
ERROR - 2015-03-06 01:55:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 01:55:27 --> 404 Page Not Found --> gallery/Drawings
ERROR - 2015-03-06 01:55:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 01:55:27 --> 404 Page Not Found --> gallery/Illustrations
ERROR - 2015-03-06 01:55:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 01:55:27 --> 404 Page Not Found --> gallery/Photography
ERROR - 2015-03-06 01:55:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 01:55:27 --> 404 Page Not Found --> gallery/Drawings
ERROR - 2015-03-06 01:57:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 01:57:14 --> 404 Page Not Found --> template
ERROR - 2015-03-06 01:57:14 --> 404 Page Not Found --> template
ERROR - 2015-03-06 01:57:14 --> 404 Page Not Found --> template
ERROR - 2015-03-06 01:57:14 --> 404 Page Not Found --> template
ERROR - 2015-03-06 01:57:14 --> 404 Page Not Found --> template
ERROR - 2015-03-06 01:57:14 --> 404 Page Not Found --> template
ERROR - 2015-03-06 01:57:14 --> 404 Page Not Found --> template
ERROR - 2015-03-06 01:57:14 --> 404 Page Not Found --> template
ERROR - 2015-03-06 01:57:14 --> 404 Page Not Found --> template
ERROR - 2015-03-06 01:57:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 01:57:14 --> 404 Page Not Found --> gallery/Drawings
ERROR - 2015-03-06 01:57:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 01:57:14 --> 404 Page Not Found --> gallery/Illustrations
ERROR - 2015-03-06 01:57:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 01:57:14 --> 404 Page Not Found --> gallery/Drawings
ERROR - 2015-03-06 01:57:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 01:57:14 --> 404 Page Not Found --> gallery/Photography
ERROR - 2015-03-06 01:57:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 01:57:14 --> 404 Page Not Found --> gallery/Illustrations
ERROR - 2015-03-06 01:57:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 01:57:14 --> 404 Page Not Found --> gallery/Photography
ERROR - 2015-03-06 01:57:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 01:57:14 --> 404 Page Not Found --> gallery/Drawings
ERROR - 2015-03-06 01:57:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 01:57:14 --> 404 Page Not Found --> gallery/Illustrations
ERROR - 2015-03-06 01:57:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 01:57:14 --> 404 Page Not Found --> gallery/Photography
ERROR - 2015-03-06 01:57:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 01:57:14 --> 404 Page Not Found --> gallery/Drawings
ERROR - 2015-03-06 01:58:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 01:58:04 --> 404 Page Not Found --> template
ERROR - 2015-03-06 01:58:04 --> 404 Page Not Found --> template
ERROR - 2015-03-06 01:58:04 --> 404 Page Not Found --> template
ERROR - 2015-03-06 01:58:04 --> 404 Page Not Found --> template
ERROR - 2015-03-06 01:58:04 --> 404 Page Not Found --> template
ERROR - 2015-03-06 01:58:04 --> 404 Page Not Found --> template
ERROR - 2015-03-06 01:58:04 --> 404 Page Not Found --> template
ERROR - 2015-03-06 01:58:04 --> 404 Page Not Found --> template
ERROR - 2015-03-06 01:58:04 --> 404 Page Not Found --> template
ERROR - 2015-03-06 01:58:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 01:58:05 --> 404 Page Not Found --> gallery/Drawings
ERROR - 2015-03-06 01:58:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 01:58:05 --> 404 Page Not Found --> gallery/Drawings
ERROR - 2015-03-06 01:58:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 01:58:05 --> 404 Page Not Found --> gallery/Illustrations
ERROR - 2015-03-06 01:58:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 01:58:05 --> 404 Page Not Found --> gallery/Photography
ERROR - 2015-03-06 01:58:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 01:58:05 --> 404 Page Not Found --> gallery/Photography
ERROR - 2015-03-06 01:58:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 01:58:05 --> 404 Page Not Found --> gallery/Illustrations
ERROR - 2015-03-06 01:58:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 01:58:05 --> 404 Page Not Found --> gallery/Drawings
ERROR - 2015-03-06 01:58:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 01:58:05 --> 404 Page Not Found --> gallery/Illustrations
ERROR - 2015-03-06 01:58:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 01:58:05 --> 404 Page Not Found --> gallery/Photography
ERROR - 2015-03-06 01:58:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 01:58:05 --> 404 Page Not Found --> gallery/Drawings
ERROR - 2015-03-06 01:58:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 01:58:24 --> Severity: Warning  --> mysql_query(): Unable to save result set /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 179
ERROR - 2015-03-06 01:58:24 --> Query error: Subquery returns more than 1 row
ERROR - 2015-03-06 01:58:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 01:58:58 --> 404 Page Not Found --> template
ERROR - 2015-03-06 01:58:58 --> 404 Page Not Found --> template
ERROR - 2015-03-06 01:58:58 --> 404 Page Not Found --> template
ERROR - 2015-03-06 01:58:58 --> 404 Page Not Found --> template
ERROR - 2015-03-06 01:58:58 --> 404 Page Not Found --> template
ERROR - 2015-03-06 01:58:58 --> 404 Page Not Found --> template
ERROR - 2015-03-06 01:58:58 --> 404 Page Not Found --> template
ERROR - 2015-03-06 01:58:58 --> 404 Page Not Found --> template
ERROR - 2015-03-06 01:58:58 --> 404 Page Not Found --> template
ERROR - 2015-03-06 01:58:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 01:58:59 --> 404 Page Not Found --> gallery/Photography
ERROR - 2015-03-06 01:58:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 01:58:59 --> 404 Page Not Found --> gallery/Drawings
ERROR - 2015-03-06 01:58:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 01:58:59 --> 404 Page Not Found --> gallery/Illustrations
ERROR - 2015-03-06 01:58:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 01:58:59 --> 404 Page Not Found --> gallery/Drawings
ERROR - 2015-03-06 01:58:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 01:58:59 --> 404 Page Not Found --> gallery/Photography
ERROR - 2015-03-06 01:58:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 01:58:59 --> 404 Page Not Found --> gallery/Illustrations
ERROR - 2015-03-06 01:58:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 01:58:59 --> 404 Page Not Found --> gallery/Drawings
ERROR - 2015-03-06 01:58:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 01:58:59 --> 404 Page Not Found --> gallery/Illustrations
ERROR - 2015-03-06 01:58:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 01:58:59 --> 404 Page Not Found --> gallery/Photography
ERROR - 2015-03-06 01:58:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 01:58:59 --> 404 Page Not Found --> gallery/Drawings
ERROR - 2015-03-06 02:00:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 02:00:35 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:00:35 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:00:35 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:00:35 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:00:35 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:00:35 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:00:35 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:00:35 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:00:35 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:01:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 02:01:09 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:01:09 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:01:09 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:01:09 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:01:09 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:01:09 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:01:09 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:01:09 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:01:09 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:01:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 02:01:52 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:01:52 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:01:52 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:01:52 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:01:52 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:01:52 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:01:52 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:01:52 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:01:52 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:02:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 02:02:48 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:02:48 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:02:48 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:02:48 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:02:48 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:02:48 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:02:48 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:02:48 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:02:48 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:03:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 02:03:03 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:03:03 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:03:03 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:03:03 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:03:03 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:03:03 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:03:03 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:03:03 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:03:03 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:06:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 02:06:37 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:06:37 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:06:37 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:06:37 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:06:37 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:06:37 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:06:37 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:06:37 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:06:37 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:07:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 02:07:02 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:07:02 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:07:02 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:07:02 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:07:02 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:07:02 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:07:02 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:07:02 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:07:02 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:07:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 02:07:14 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:07:14 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:07:14 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:07:14 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:07:14 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:07:14 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:07:14 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:07:14 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:07:14 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:09:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 02:09:59 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:09:59 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:09:59 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:09:59 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:09:59 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:09:59 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:09:59 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:09:59 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:09:59 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:10:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 02:10:15 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:10:15 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:10:15 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:10:15 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:10:15 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:10:15 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:10:15 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:10:15 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:10:15 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:10:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 02:10:47 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:10:47 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:10:47 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:10:47 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:10:47 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:10:47 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:10:47 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:10:47 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:10:47 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:11:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 02:11:16 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:11:16 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:11:16 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:11:16 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:11:16 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:11:16 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:11:16 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:11:16 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:11:16 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:11:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 02:11:32 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:11:32 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:11:32 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:11:32 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:11:32 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:11:32 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:11:32 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:11:32 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:11:32 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:11:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 02:11:52 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:11:52 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:11:52 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:11:52 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:11:52 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:11:52 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:11:52 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:11:52 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:11:52 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:12:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 02:12:41 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:12:41 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:12:41 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:12:41 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:12:41 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:12:41 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:12:41 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:12:41 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:12:41 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:14:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 02:14:13 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:14:13 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:14:13 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:14:13 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:14:13 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:14:13 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:14:13 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:14:13 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:14:13 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:51:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 02:51:12 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:51:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 02:52:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 02:52:21 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:52:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 02:52:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 02:53:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 02:53:02 --> Severity: Notice  --> unserialize(): Error at offset 0 of 413 bytes /Applications/MAMP/htdocs/Esgotado/system/libraries/Session.php 724
ERROR - 2015-03-06 02:53:02 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:53:02 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:53:02 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:53:02 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:53:02 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:53:02 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:53:02 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:53:02 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:53:02 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:53:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 02:53:09 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:53:09 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:53:09 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:53:09 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:53:09 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:53:09 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:53:09 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:53:09 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:53:09 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:53:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 02:53:11 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/Esgotado/application/controllers/autoload.php:35) /Applications/MAMP/htdocs/Esgotado/system/core/Output.php 391
ERROR - 2015-03-06 02:53:11 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/Esgotado/application/controllers/autoload.php:35) /Applications/MAMP/htdocs/Esgotado/system/core/Output.php 391
ERROR - 2015-03-06 02:54:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 02:54:11 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:54:11 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:54:11 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:54:11 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:54:11 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:54:11 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:54:11 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:54:12 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:54:12 --> 404 Page Not Found --> template
ERROR - 2015-03-06 02:54:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 11:37:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 11:37:23 --> 404 Page Not Found --> template
ERROR - 2015-03-06 11:37:23 --> 404 Page Not Found --> template
ERROR - 2015-03-06 11:37:23 --> 404 Page Not Found --> template
ERROR - 2015-03-06 11:37:23 --> 404 Page Not Found --> template
ERROR - 2015-03-06 11:37:23 --> 404 Page Not Found --> template
ERROR - 2015-03-06 11:37:23 --> 404 Page Not Found --> template
ERROR - 2015-03-06 11:37:23 --> 404 Page Not Found --> template
ERROR - 2015-03-06 11:37:23 --> 404 Page Not Found --> template
ERROR - 2015-03-06 11:37:23 --> 404 Page Not Found --> template
ERROR - 2015-03-06 13:20:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 13:20:38 --> 404 Page Not Found --> template
ERROR - 2015-03-06 13:20:38 --> 404 Page Not Found --> template
ERROR - 2015-03-06 13:20:38 --> 404 Page Not Found --> template
ERROR - 2015-03-06 13:20:38 --> 404 Page Not Found --> template
ERROR - 2015-03-06 13:20:38 --> 404 Page Not Found --> template
ERROR - 2015-03-06 13:20:38 --> 404 Page Not Found --> template
ERROR - 2015-03-06 13:20:38 --> 404 Page Not Found --> template
ERROR - 2015-03-06 13:20:38 --> 404 Page Not Found --> template
ERROR - 2015-03-06 13:20:38 --> 404 Page Not Found --> template
ERROR - 2015-03-06 13:20:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 13:20:59 --> 404 Page Not Found --> template
ERROR - 2015-03-06 13:20:59 --> 404 Page Not Found --> template
ERROR - 2015-03-06 13:20:59 --> 404 Page Not Found --> template
ERROR - 2015-03-06 13:20:59 --> 404 Page Not Found --> template
ERROR - 2015-03-06 13:20:59 --> 404 Page Not Found --> template
ERROR - 2015-03-06 13:20:59 --> 404 Page Not Found --> template
ERROR - 2015-03-06 13:20:59 --> 404 Page Not Found --> template
ERROR - 2015-03-06 13:20:59 --> 404 Page Not Found --> template
ERROR - 2015-03-06 13:20:59 --> 404 Page Not Found --> template
ERROR - 2015-03-06 13:23:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 13:23:14 --> 404 Page Not Found --> template
ERROR - 2015-03-06 13:23:14 --> 404 Page Not Found --> template
ERROR - 2015-03-06 13:23:14 --> 404 Page Not Found --> template
ERROR - 2015-03-06 13:23:14 --> 404 Page Not Found --> template
ERROR - 2015-03-06 13:23:14 --> 404 Page Not Found --> template
ERROR - 2015-03-06 13:23:14 --> 404 Page Not Found --> template
ERROR - 2015-03-06 13:23:14 --> 404 Page Not Found --> template
ERROR - 2015-03-06 13:23:14 --> 404 Page Not Found --> template
ERROR - 2015-03-06 13:23:14 --> 404 Page Not Found --> template
ERROR - 2015-03-06 13:24:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 13:24:20 --> 404 Page Not Found --> template
ERROR - 2015-03-06 13:24:20 --> 404 Page Not Found --> template
ERROR - 2015-03-06 13:24:20 --> 404 Page Not Found --> template
ERROR - 2015-03-06 13:24:20 --> 404 Page Not Found --> template
ERROR - 2015-03-06 13:24:20 --> 404 Page Not Found --> template
ERROR - 2015-03-06 13:24:20 --> 404 Page Not Found --> template
ERROR - 2015-03-06 13:24:20 --> 404 Page Not Found --> template
ERROR - 2015-03-06 13:24:20 --> 404 Page Not Found --> template
ERROR - 2015-03-06 13:24:20 --> 404 Page Not Found --> template
ERROR - 2015-03-06 13:28:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 13:28:12 --> 404 Page Not Found --> template
ERROR - 2015-03-06 13:28:12 --> 404 Page Not Found --> template
ERROR - 2015-03-06 13:28:12 --> 404 Page Not Found --> template
ERROR - 2015-03-06 13:28:12 --> 404 Page Not Found --> template
ERROR - 2015-03-06 13:28:12 --> 404 Page Not Found --> template
ERROR - 2015-03-06 13:28:12 --> 404 Page Not Found --> template
ERROR - 2015-03-06 13:28:12 --> 404 Page Not Found --> template
ERROR - 2015-03-06 13:28:12 --> 404 Page Not Found --> template
ERROR - 2015-03-06 13:28:12 --> 404 Page Not Found --> template
ERROR - 2015-03-06 13:29:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 13:29:26 --> 404 Page Not Found --> template
ERROR - 2015-03-06 13:29:26 --> 404 Page Not Found --> template
ERROR - 2015-03-06 13:29:26 --> 404 Page Not Found --> template
ERROR - 2015-03-06 13:29:26 --> 404 Page Not Found --> template
ERROR - 2015-03-06 13:29:26 --> 404 Page Not Found --> template
ERROR - 2015-03-06 13:29:26 --> 404 Page Not Found --> template
ERROR - 2015-03-06 13:29:27 --> 404 Page Not Found --> template
ERROR - 2015-03-06 13:29:27 --> 404 Page Not Found --> template
ERROR - 2015-03-06 13:29:27 --> 404 Page Not Found --> template
ERROR - 2015-03-06 13:30:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 13:30:11 --> 404 Page Not Found --> template
ERROR - 2015-03-06 13:30:11 --> 404 Page Not Found --> template
ERROR - 2015-03-06 13:30:11 --> 404 Page Not Found --> template
ERROR - 2015-03-06 13:30:11 --> 404 Page Not Found --> template
ERROR - 2015-03-06 13:30:12 --> 404 Page Not Found --> template
ERROR - 2015-03-06 13:30:12 --> 404 Page Not Found --> template
ERROR - 2015-03-06 13:30:12 --> 404 Page Not Found --> template
ERROR - 2015-03-06 13:30:12 --> 404 Page Not Found --> template
ERROR - 2015-03-06 13:30:12 --> 404 Page Not Found --> template
ERROR - 2015-03-06 13:30:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 13:30:42 --> 404 Page Not Found --> template
ERROR - 2015-03-06 13:30:42 --> 404 Page Not Found --> template
ERROR - 2015-03-06 13:30:42 --> 404 Page Not Found --> template
ERROR - 2015-03-06 13:30:42 --> 404 Page Not Found --> template
ERROR - 2015-03-06 13:30:42 --> 404 Page Not Found --> template
ERROR - 2015-03-06 13:30:42 --> 404 Page Not Found --> template
ERROR - 2015-03-06 13:30:42 --> 404 Page Not Found --> template
ERROR - 2015-03-06 13:30:42 --> 404 Page Not Found --> template
ERROR - 2015-03-06 13:30:42 --> 404 Page Not Found --> template
ERROR - 2015-03-06 13:31:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 13:31:23 --> 404 Page Not Found --> template
ERROR - 2015-03-06 13:31:23 --> 404 Page Not Found --> template
ERROR - 2015-03-06 13:31:23 --> 404 Page Not Found --> template
ERROR - 2015-03-06 13:31:23 --> 404 Page Not Found --> template
ERROR - 2015-03-06 13:31:23 --> 404 Page Not Found --> template
ERROR - 2015-03-06 13:31:23 --> 404 Page Not Found --> template
ERROR - 2015-03-06 13:31:23 --> 404 Page Not Found --> template
ERROR - 2015-03-06 13:31:23 --> 404 Page Not Found --> template
ERROR - 2015-03-06 13:31:23 --> 404 Page Not Found --> template
ERROR - 2015-03-06 13:31:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 13:31:35 --> 404 Page Not Found --> template
ERROR - 2015-03-06 13:31:35 --> 404 Page Not Found --> template
ERROR - 2015-03-06 13:31:35 --> 404 Page Not Found --> template
ERROR - 2015-03-06 13:31:35 --> 404 Page Not Found --> template
ERROR - 2015-03-06 13:31:35 --> 404 Page Not Found --> template
ERROR - 2015-03-06 13:31:35 --> 404 Page Not Found --> template
ERROR - 2015-03-06 13:31:35 --> 404 Page Not Found --> template
ERROR - 2015-03-06 13:31:35 --> 404 Page Not Found --> template
ERROR - 2015-03-06 13:31:35 --> 404 Page Not Found --> template
ERROR - 2015-03-06 13:31:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 13:32:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 13:32:28 --> 404 Page Not Found --> template
ERROR - 2015-03-06 13:32:28 --> 404 Page Not Found --> template
ERROR - 2015-03-06 13:32:28 --> 404 Page Not Found --> template
ERROR - 2015-03-06 13:32:28 --> 404 Page Not Found --> template
ERROR - 2015-03-06 13:32:28 --> 404 Page Not Found --> template
ERROR - 2015-03-06 13:32:28 --> 404 Page Not Found --> template
ERROR - 2015-03-06 13:32:28 --> 404 Page Not Found --> template
ERROR - 2015-03-06 13:32:28 --> 404 Page Not Found --> template
ERROR - 2015-03-06 13:32:28 --> 404 Page Not Found --> template
ERROR - 2015-03-06 13:39:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 13:39:53 --> 404 Page Not Found --> template
ERROR - 2015-03-06 13:39:53 --> 404 Page Not Found --> template
ERROR - 2015-03-06 13:39:53 --> 404 Page Not Found --> template
ERROR - 2015-03-06 13:39:53 --> 404 Page Not Found --> template
ERROR - 2015-03-06 13:39:53 --> 404 Page Not Found --> template
ERROR - 2015-03-06 13:39:53 --> 404 Page Not Found --> template
ERROR - 2015-03-06 13:39:53 --> 404 Page Not Found --> template
ERROR - 2015-03-06 13:39:53 --> 404 Page Not Found --> template
ERROR - 2015-03-06 13:39:53 --> 404 Page Not Found --> template
ERROR - 2015-03-06 13:40:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 13:40:54 --> 404 Page Not Found --> template
ERROR - 2015-03-06 13:40:54 --> 404 Page Not Found --> template
ERROR - 2015-03-06 13:40:54 --> 404 Page Not Found --> template
ERROR - 2015-03-06 13:40:54 --> 404 Page Not Found --> template
ERROR - 2015-03-06 13:40:54 --> 404 Page Not Found --> template
ERROR - 2015-03-06 13:40:54 --> 404 Page Not Found --> template
ERROR - 2015-03-06 13:40:54 --> 404 Page Not Found --> template
ERROR - 2015-03-06 13:40:54 --> 404 Page Not Found --> template
ERROR - 2015-03-06 13:40:54 --> 404 Page Not Found --> template
ERROR - 2015-03-06 13:40:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 13:40:56 --> 404 Page Not Found --> template
ERROR - 2015-03-06 13:40:56 --> 404 Page Not Found --> template
ERROR - 2015-03-06 13:40:56 --> 404 Page Not Found --> template
ERROR - 2015-03-06 13:40:56 --> 404 Page Not Found --> template
ERROR - 2015-03-06 13:40:56 --> 404 Page Not Found --> template
ERROR - 2015-03-06 13:40:56 --> 404 Page Not Found --> template
ERROR - 2015-03-06 13:40:56 --> 404 Page Not Found --> template
ERROR - 2015-03-06 13:40:56 --> 404 Page Not Found --> template
ERROR - 2015-03-06 13:40:56 --> 404 Page Not Found --> template
ERROR - 2015-03-06 13:41:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /Applications/MAMP/htdocs/Esgotado/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 2015-03-06 13:41:15 --> 404 Page Not Found --> template
ERROR - 2015-03-06 13:41:15 --> 404 Page Not Found --> template
ERROR - 2015-03-06 13:41:15 --> 404 Page Not Found --> template
ERROR - 2015-03-06 13:41:15 --> 404 Page Not Found --> template
ERROR - 2015-03-06 13:41:15 --> 404 Page Not Found --> template
ERROR - 2015-03-06 13:41:15 --> 404 Page Not Found --> template
ERROR - 2015-03-06 13:41:15 --> 404 Page Not Found --> template
ERROR - 2015-03-06 13:41:15 --> 404 Page Not Found --> template
ERROR - 2015-03-06 13:41:15 --> 404 Page Not Found --> template
