<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-11-15 07:18:22 --> Severity: Warning  --> mysqli_connect(): (HY000/1045): Access denied for user 'ozantcom_wassup'@'localhost' (using password: YES) C:\xampp\htdocs\wassuphaters.com\w4zzup\system\database\drivers\mysqli\mysqli_driver.php 76
ERROR - 2015-11-15 07:18:22 --> Unable to connect to the database
