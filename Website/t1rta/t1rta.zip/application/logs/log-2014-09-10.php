<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2014-09-10 00:01:33 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '(SELECT name FROM gxa_product_category PC WHERE PC.catpro_id = PL.catpro_id) AS ' at line 1
ERROR - 2014-09-10 00:01:48 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '(SELECT name FROM gxa_product_category PC WHERE PC.catpro_id = PL.catpro_id) AS ' at line 1
ERROR - 2014-09-10 00:01:55 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '(SELECT name FROM gxa_product_category PC WHERE PC.catpro_id = PL.catpro_id) AS ' at line 1
ERROR - 2014-09-10 00:02:19 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '(SELECT name FROM gxa_product_category PC WHERE PC.catpro_id = PL.catpro_id) AS ' at line 1
ERROR - 2014-09-10 00:04:45 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '(SELECT name FROM gxa_product_category PC WHERE PC.catpro_id = PL.catpro_id) AS ' at line 1
ERROR - 2014-09-10 00:05:04 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '(SELECT * FROM gxa_product_category PC WHERE PC.catpro_id = PL.catpro_id) AS cat' at line 1
ERROR - 2014-09-10 00:05:17 --> Query error: Operand should contain 1 column(s)
ERROR - 2014-09-10 00:05:23 --> Query error: Operand should contain 1 column(s)
ERROR - 2014-09-10 00:05:30 --> Query error: Operand should contain 1 column(s)
ERROR - 2014-09-10 00:08:08 --> Severity: Notice  --> Undefined variable: product C:\wamp\www\Galaxia-Store\application\views\search.php 52
ERROR - 2014-09-10 00:08:19 --> Severity: Notice  --> Undefined property: stdClass::$image C:\wamp\www\Galaxia-Store\application\views\search.php 57
ERROR - 2014-09-10 00:08:19 --> Severity: Notice  --> Undefined property: stdClass::$total_stock C:\wamp\www\Galaxia-Store\application\views\search.php 70
ERROR - 2014-09-10 00:08:19 --> Severity: Notice  --> Undefined property: stdClass::$image C:\wamp\www\Galaxia-Store\application\views\search.php 57
ERROR - 2014-09-10 00:08:19 --> Severity: Notice  --> Undefined property: stdClass::$total_stock C:\wamp\www\Galaxia-Store\application\views\search.php 70
ERROR - 2014-09-10 00:08:19 --> Severity: Notice  --> Undefined property: stdClass::$image C:\wamp\www\Galaxia-Store\application\views\search.php 57
ERROR - 2014-09-10 00:08:19 --> Severity: Notice  --> Undefined property: stdClass::$total_stock C:\wamp\www\Galaxia-Store\application\views\search.php 70
ERROR - 2014-09-10 00:10:45 --> Severity: Notice  --> Undefined property: stdClass::$image C:\wamp\www\Galaxia-Store\application\views\search.php 53
ERROR - 2014-09-10 00:10:45 --> Severity: Notice  --> Undefined property: stdClass::$total_stock C:\wamp\www\Galaxia-Store\application\views\search.php 66
ERROR - 2014-09-10 00:10:45 --> Severity: Notice  --> Undefined property: stdClass::$image C:\wamp\www\Galaxia-Store\application\views\search.php 53
ERROR - 2014-09-10 00:10:45 --> Severity: Notice  --> Undefined property: stdClass::$total_stock C:\wamp\www\Galaxia-Store\application\views\search.php 66
ERROR - 2014-09-10 00:10:45 --> Severity: Notice  --> Undefined property: stdClass::$image C:\wamp\www\Galaxia-Store\application\views\search.php 53
ERROR - 2014-09-10 00:10:45 --> Severity: Notice  --> Undefined property: stdClass::$total_stock C:\wamp\www\Galaxia-Store\application\views\search.php 66
ERROR - 2014-09-10 01:06:24 --> Severity: Warning  --> Missing argument 2 for Search_m::get_product(), called in C:\wamp\www\Galaxia-Store\application\controllers\search.php on line 30 and defined C:\wamp\www\Galaxia-Store\application\models\search_m.php 12
ERROR - 2014-09-10 01:06:24 --> Severity: Warning  --> Missing argument 3 for Search_m::get_product(), called in C:\wamp\www\Galaxia-Store\application\controllers\search.php on line 30 and defined C:\wamp\www\Galaxia-Store\application\models\search_m.php 12
ERROR - 2014-09-10 01:06:24 --> Severity: Warning  --> Missing argument 4 for Search_m::get_product(), called in C:\wamp\www\Galaxia-Store\application\controllers\search.php on line 30 and defined C:\wamp\www\Galaxia-Store\application\models\search_m.php 12
ERROR - 2014-09-10 01:06:24 --> Severity: Notice  --> Undefined variable: name C:\wamp\www\Galaxia-Store\application\models\search_m.php 13
ERROR - 2014-09-10 01:06:24 --> Severity: Notice  --> Undefined variable: stop C:\wamp\www\Galaxia-Store\application\models\search_m.php 49
ERROR - 2014-09-10 01:06:24 --> Severity: Notice  --> Undefined variable: stop C:\wamp\www\Galaxia-Store\application\models\search_m.php 49
ERROR - 2014-09-10 01:06:24 --> Severity: Notice  --> Undefined variable: stop C:\wamp\www\Galaxia-Store\application\models\search_m.php 49
ERROR - 2014-09-10 01:06:24 --> Severity: Notice  --> Undefined variable: stop C:\wamp\www\Galaxia-Store\application\models\search_m.php 49
ERROR - 2014-09-10 01:06:24 --> Severity: Notice  --> Undefined variable: stop C:\wamp\www\Galaxia-Store\application\models\search_m.php 49
ERROR - 2014-09-10 01:06:24 --> Severity: Notice  --> Undefined variable: stop C:\wamp\www\Galaxia-Store\application\models\search_m.php 49
ERROR - 2014-09-10 01:06:24 --> Severity: Notice  --> Undefined variable: stop C:\wamp\www\Galaxia-Store\application\models\search_m.php 49
ERROR - 2014-09-10 01:06:24 --> Severity: Notice  --> Undefined variable: stop C:\wamp\www\Galaxia-Store\application\models\search_m.php 49
ERROR - 2014-09-10 01:06:24 --> Severity: Notice  --> Undefined variable: stop C:\wamp\www\Galaxia-Store\application\models\search_m.php 49
ERROR - 2014-09-10 01:06:24 --> Severity: Notice  --> Undefined variable: stop C:\wamp\www\Galaxia-Store\application\models\search_m.php 49
ERROR - 2014-09-10 01:06:24 --> Severity: Notice  --> Undefined variable: stop C:\wamp\www\Galaxia-Store\application\models\search_m.php 49
ERROR - 2014-09-10 01:06:24 --> Severity: Notice  --> Undefined variable: stop C:\wamp\www\Galaxia-Store\application\models\search_m.php 49
ERROR - 2014-09-10 01:06:24 --> Severity: Notice  --> Undefined variable: stop C:\wamp\www\Galaxia-Store\application\models\search_m.php 49
ERROR - 2014-09-10 01:06:24 --> Severity: Notice  --> Undefined variable: stop C:\wamp\www\Galaxia-Store\application\models\search_m.php 49
ERROR - 2014-09-10 01:07:10 --> Severity: Warning  --> Missing argument 2 for Search_m::get_product(), called in C:\wamp\www\Galaxia-Store\application\controllers\search.php on line 30 and defined C:\wamp\www\Galaxia-Store\application\models\search_m.php 12
ERROR - 2014-09-10 01:07:10 --> Severity: Warning  --> Missing argument 3 for Search_m::get_product(), called in C:\wamp\www\Galaxia-Store\application\controllers\search.php on line 30 and defined C:\wamp\www\Galaxia-Store\application\models\search_m.php 12
ERROR - 2014-09-10 01:07:10 --> Severity: Warning  --> Missing argument 4 for Search_m::get_product(), called in C:\wamp\www\Galaxia-Store\application\controllers\search.php on line 30 and defined C:\wamp\www\Galaxia-Store\application\models\search_m.php 12
ERROR - 2014-09-10 01:07:10 --> Severity: Notice  --> Undefined variable: name C:\wamp\www\Galaxia-Store\application\models\search_m.php 13
ERROR - 2014-09-10 01:07:10 --> Severity: Notice  --> Undefined variable: stop C:\wamp\www\Galaxia-Store\application\models\search_m.php 49
ERROR - 2014-09-10 01:07:10 --> Severity: Notice  --> Undefined variable: stop C:\wamp\www\Galaxia-Store\application\models\search_m.php 49
ERROR - 2014-09-10 01:07:10 --> Severity: Notice  --> Undefined variable: stop C:\wamp\www\Galaxia-Store\application\models\search_m.php 49
ERROR - 2014-09-10 01:07:10 --> Severity: Notice  --> Undefined variable: stop C:\wamp\www\Galaxia-Store\application\models\search_m.php 49
ERROR - 2014-09-10 01:07:10 --> Severity: Notice  --> Undefined variable: stop C:\wamp\www\Galaxia-Store\application\models\search_m.php 49
ERROR - 2014-09-10 01:07:10 --> Severity: Notice  --> Undefined variable: stop C:\wamp\www\Galaxia-Store\application\models\search_m.php 49
ERROR - 2014-09-10 01:07:10 --> Severity: Notice  --> Undefined variable: stop C:\wamp\www\Galaxia-Store\application\models\search_m.php 49
ERROR - 2014-09-10 01:07:10 --> Severity: Notice  --> Undefined variable: stop C:\wamp\www\Galaxia-Store\application\models\search_m.php 49
ERROR - 2014-09-10 01:07:10 --> Severity: Notice  --> Undefined variable: stop C:\wamp\www\Galaxia-Store\application\models\search_m.php 49
ERROR - 2014-09-10 01:07:10 --> Severity: Notice  --> Undefined variable: stop C:\wamp\www\Galaxia-Store\application\models\search_m.php 49
ERROR - 2014-09-10 01:07:10 --> Severity: Notice  --> Undefined variable: stop C:\wamp\www\Galaxia-Store\application\models\search_m.php 49
ERROR - 2014-09-10 01:07:10 --> Severity: Notice  --> Undefined variable: stop C:\wamp\www\Galaxia-Store\application\models\search_m.php 49
ERROR - 2014-09-10 01:07:10 --> Severity: Notice  --> Undefined variable: stop C:\wamp\www\Galaxia-Store\application\models\search_m.php 49
ERROR - 2014-09-10 01:07:10 --> Severity: Notice  --> Undefined variable: stop C:\wamp\www\Galaxia-Store\application\models\search_m.php 49
ERROR - 2014-09-10 01:12:12 --> Severity: Notice  --> Array to string conversion C:\wamp\www\Galaxia-Store\application\models\search_m.php 18
ERROR - 2014-09-10 01:12:12 --> Severity: Notice  --> Array to string conversion C:\wamp\www\Galaxia-Store\application\models\search_m.php 18
ERROR - 2014-09-10 10:02:25 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-09-10 10:02:25 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-09-10 10:02:47 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-09-10 10:02:47 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-09-10 10:02:55 --> Severity: Warning  --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\wamp\www\Galaxia-Store\system\libraries\Email.php 1553
