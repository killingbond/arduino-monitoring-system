<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-12-01 06:18:40 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:18:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:18:40 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:18:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:18:40 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:18:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:18:40 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:18:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:18:40 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:18:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:18:40 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:18:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:18:40 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:18:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:18:40 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:18:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:18:40 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:18:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:18:40 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:18:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:18:40 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:18:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:18:40 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:18:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:18:40 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:18:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:18:40 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:18:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:18:40 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:18:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:18:40 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:18:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:18:40 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:18:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:18:40 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:18:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:18:40 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:18:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:18:40 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:18:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:18:40 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:18:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:18:40 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:18:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:18:40 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:18:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:18:40 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:18:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:18:40 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:18:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:18:41 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:18:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:23:37 --> Query error: Table 'ozantcom_wassuphaters.category' doesn't exist
ERROR - 2015-12-01 06:24:09 --> Severity: Notice  --> Undefined variable: kategori C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 68
ERROR - 2015-12-01 06:24:09 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 68
ERROR - 2015-12-01 06:24:09 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:24:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:24:09 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:24:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:24:09 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:24:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:24:09 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:24:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:24:09 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:24:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:24:09 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:24:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:24:09 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:24:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:24:09 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:24:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:24:09 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:24:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:24:09 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:24:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:24:09 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:24:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:24:09 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:24:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:24:09 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:24:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:24:09 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:24:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:24:09 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:24:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:24:09 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:24:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:24:09 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:24:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:24:09 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:24:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:24:09 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:24:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:24:09 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:24:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:24:10 --> Severity: Notice  --> Undefined variable: kategori C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 68
ERROR - 2015-12-01 06:24:10 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 68
ERROR - 2015-12-01 06:24:10 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:24:10 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:24:10 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:24:10 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:24:10 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:24:10 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:24:10 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:24:10 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:24:10 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:24:10 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:24:10 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:24:10 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:24:10 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:24:10 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:24:10 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:24:10 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:24:10 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:24:10 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:24:10 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:24:10 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:24:10 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:24:10 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:24:10 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:24:10 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:24:10 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:24:10 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:24:10 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:24:10 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:24:10 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:24:10 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:24:10 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:24:10 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:24:10 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:24:10 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:24:10 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:24:10 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:24:10 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:24:10 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:24:10 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:24:10 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:25:25 --> Severity: Notice  --> Undefined variable: kategory C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 67
ERROR - 2015-12-01 06:25:25 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 86
ERROR - 2015-12-01 06:25:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 86
ERROR - 2015-12-01 06:25:25 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 86
ERROR - 2015-12-01 06:25:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 86
ERROR - 2015-12-01 06:25:25 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 86
ERROR - 2015-12-01 06:25:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 86
ERROR - 2015-12-01 06:25:25 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 86
ERROR - 2015-12-01 06:25:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 86
ERROR - 2015-12-01 06:25:25 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 86
ERROR - 2015-12-01 06:25:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 86
ERROR - 2015-12-01 06:25:25 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 86
ERROR - 2015-12-01 06:25:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 86
ERROR - 2015-12-01 06:25:25 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 86
ERROR - 2015-12-01 06:25:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 86
ERROR - 2015-12-01 06:25:25 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 86
ERROR - 2015-12-01 06:25:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 86
ERROR - 2015-12-01 06:25:25 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 86
ERROR - 2015-12-01 06:25:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 86
ERROR - 2015-12-01 06:25:25 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 86
ERROR - 2015-12-01 06:25:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 86
ERROR - 2015-12-01 06:25:25 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 86
ERROR - 2015-12-01 06:25:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 86
ERROR - 2015-12-01 06:25:25 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 86
ERROR - 2015-12-01 06:25:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 86
ERROR - 2015-12-01 06:25:25 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 86
ERROR - 2015-12-01 06:25:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 86
ERROR - 2015-12-01 06:25:25 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 86
ERROR - 2015-12-01 06:25:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 86
ERROR - 2015-12-01 06:25:25 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 86
ERROR - 2015-12-01 06:25:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 86
ERROR - 2015-12-01 06:25:25 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 86
ERROR - 2015-12-01 06:25:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 86
ERROR - 2015-12-01 06:25:25 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 86
ERROR - 2015-12-01 06:25:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 86
ERROR - 2015-12-01 06:25:25 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 86
ERROR - 2015-12-01 06:25:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 86
ERROR - 2015-12-01 06:25:25 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 86
ERROR - 2015-12-01 06:25:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 86
ERROR - 2015-12-01 06:25:25 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 86
ERROR - 2015-12-01 06:25:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 86
ERROR - 2015-12-01 06:25:25 --> Severity: Notice  --> Undefined variable: kategory C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 67
ERROR - 2015-12-01 06:25:25 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 86
ERROR - 2015-12-01 06:25:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 86
ERROR - 2015-12-01 06:25:25 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 86
ERROR - 2015-12-01 06:25:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 86
ERROR - 2015-12-01 06:25:25 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 86
ERROR - 2015-12-01 06:25:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 86
ERROR - 2015-12-01 06:25:25 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 86
ERROR - 2015-12-01 06:25:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 86
ERROR - 2015-12-01 06:25:25 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 86
ERROR - 2015-12-01 06:25:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 86
ERROR - 2015-12-01 06:25:25 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 86
ERROR - 2015-12-01 06:25:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 86
ERROR - 2015-12-01 06:25:25 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 86
ERROR - 2015-12-01 06:25:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 86
ERROR - 2015-12-01 06:25:25 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 86
ERROR - 2015-12-01 06:25:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 86
ERROR - 2015-12-01 06:25:26 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 86
ERROR - 2015-12-01 06:25:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 86
ERROR - 2015-12-01 06:25:26 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 86
ERROR - 2015-12-01 06:25:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 86
ERROR - 2015-12-01 06:25:26 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 86
ERROR - 2015-12-01 06:25:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 86
ERROR - 2015-12-01 06:25:26 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 86
ERROR - 2015-12-01 06:25:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 86
ERROR - 2015-12-01 06:25:26 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 86
ERROR - 2015-12-01 06:25:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 86
ERROR - 2015-12-01 06:25:26 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 86
ERROR - 2015-12-01 06:25:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 86
ERROR - 2015-12-01 06:25:26 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 86
ERROR - 2015-12-01 06:25:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 86
ERROR - 2015-12-01 06:25:26 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 86
ERROR - 2015-12-01 06:25:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 86
ERROR - 2015-12-01 06:25:26 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 86
ERROR - 2015-12-01 06:25:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 86
ERROR - 2015-12-01 06:25:26 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 86
ERROR - 2015-12-01 06:25:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 86
ERROR - 2015-12-01 06:25:26 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 86
ERROR - 2015-12-01 06:25:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 86
ERROR - 2015-12-01 06:25:26 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 86
ERROR - 2015-12-01 06:25:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 86
ERROR - 2015-12-01 06:25:48 --> Severity: Notice  --> Undefined variable: kategori C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 67
ERROR - 2015-12-01 06:25:48 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 67
ERROR - 2015-12-01 06:25:48 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:25:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:25:48 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:25:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:25:48 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:25:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:25:48 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:25:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:25:48 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:25:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:25:48 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:25:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:25:48 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:25:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:25:48 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:25:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:25:48 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:25:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:25:48 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:25:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:25:48 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:25:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:25:48 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:25:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:25:48 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:25:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:25:48 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:25:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:25:48 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:25:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:25:48 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:25:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:25:48 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:25:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:25:48 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:25:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:25:48 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:25:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:25:48 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:25:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:25:48 --> Severity: Notice  --> Undefined variable: kategori C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 67
ERROR - 2015-12-01 06:25:48 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 67
ERROR - 2015-12-01 06:25:48 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:25:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:25:48 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:25:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:25:48 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:25:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:25:48 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:25:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:25:48 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:25:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:25:48 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:25:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:25:48 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:25:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:25:48 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:25:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:25:49 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:25:49 --> Severity: Notice  --> Undefined variable: kategori C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 67
ERROR - 2015-12-01 06:25:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:25:49 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 67
ERROR - 2015-12-01 06:25:49 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:25:49 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:25:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:25:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:25:49 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:25:49 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:25:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:25:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:25:49 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:25:49 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:25:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:25:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:25:49 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:25:49 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:25:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:25:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:25:49 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:25:49 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:25:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:25:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:25:49 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:25:49 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:25:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:25:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:25:49 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:25:49 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:25:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:25:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:25:49 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:25:49 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:25:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:25:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:25:49 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:25:49 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:25:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:25:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:25:49 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:25:49 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:25:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:25:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:25:49 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:25:49 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:25:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:25:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:25:49 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:25:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:25:49 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:25:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:25:49 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:25:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:25:49 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:25:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:25:49 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:25:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:25:49 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:25:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:25:49 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:25:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:25:49 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:25:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:25:49 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:25:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:26:32 --> Severity: Notice  --> Undefined variable: kategori C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 67
ERROR - 2015-12-01 06:26:32 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 67
ERROR - 2015-12-01 06:26:32 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:26:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:26:32 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:26:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:26:32 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:26:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:26:32 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:26:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:26:32 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:26:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:26:32 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:26:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:26:32 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:26:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:26:32 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:26:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:26:32 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:26:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:26:32 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:26:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:26:32 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:26:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:26:32 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:26:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:26:32 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:26:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:26:32 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:26:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:26:32 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:26:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:26:32 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:26:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:26:32 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:26:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:26:32 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:26:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:26:32 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:26:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:26:32 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:26:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:27:30 --> Severity: Notice  --> Undefined variable: kategori C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 67
ERROR - 2015-12-01 06:27:30 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 67
ERROR - 2015-12-01 06:27:30 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:27:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:27:30 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:27:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:27:30 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:27:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:27:30 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:27:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:27:30 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:27:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:27:30 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:27:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:27:30 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:27:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:27:30 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:27:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:27:30 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:27:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:27:30 --> Severity: Notice  --> Undefined variable: kategori C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 67
ERROR - 2015-12-01 06:27:30 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:27:30 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 67
ERROR - 2015-12-01 06:27:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:27:30 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:27:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:27:30 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:27:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:27:30 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:27:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:27:30 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:27:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:27:30 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:27:30 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:27:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:27:30 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:27:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:27:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:27:30 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:27:30 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:27:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:27:30 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:27:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:27:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:27:30 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:27:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:27:30 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:27:30 --> Severity: Notice  --> Undefined variable: kategori C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 67
ERROR - 2015-12-01 06:27:30 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:27:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:27:30 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 67
ERROR - 2015-12-01 06:27:30 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:27:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:27:30 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:27:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:27:30 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:27:30 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:27:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:27:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:27:30 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:27:30 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:27:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:27:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:27:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:27:30 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:27:30 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:27:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:27:30 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:27:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:27:30 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:27:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:27:30 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:27:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:27:30 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:27:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:27:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:27:30 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:27:30 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:27:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:27:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:27:30 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:27:30 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:27:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:27:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:27:30 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:27:30 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:27:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:27:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:27:30 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:27:30 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:27:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:27:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:27:30 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:27:30 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:27:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:27:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:27:30 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:27:30 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:27:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:27:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:27:31 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:27:31 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:27:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:27:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:27:31 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:27:31 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:27:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:27:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:27:31 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:27:31 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:27:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:27:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:27:31 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:27:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:27:31 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:27:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:27:31 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:27:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:27:31 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:27:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:27:31 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:27:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:27:31 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:27:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:27:31 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:27:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 85
ERROR - 2015-12-01 06:28:27 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:28:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:28:27 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:28:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:28:27 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:28:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:28:27 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:28:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:28:27 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:28:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:28:27 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:28:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:28:27 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:28:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:28:27 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:28:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:28:27 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:28:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:28:27 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:28:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:28:27 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:28:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:28:27 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:28:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:28:27 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:28:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:28:27 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:28:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:28:27 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:28:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:28:27 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:28:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:28:27 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:28:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:28:27 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:28:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:28:27 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:28:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:28:27 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:28:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:28:27 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:28:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:28:27 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:28:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:28:27 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:28:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:28:27 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:28:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:28:27 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:28:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:28:27 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:28:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:34:48 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:34:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:34:48 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:34:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:34:48 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:34:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:34:48 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:34:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:34:48 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:34:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:34:48 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:34:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:34:48 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:34:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:34:48 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 93
ERROR - 2015-12-01 06:34:48 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:34:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:34:48 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 93
ERROR - 2015-12-01 06:34:48 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:34:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:34:48 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 93
ERROR - 2015-12-01 06:34:48 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:34:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:34:48 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 93
ERROR - 2015-12-01 06:34:48 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:34:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:34:48 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 93
ERROR - 2015-12-01 06:34:48 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:34:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:34:48 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 93
ERROR - 2015-12-01 06:34:48 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:34:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:34:48 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 93
ERROR - 2015-12-01 06:34:48 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:34:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:34:48 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 93
ERROR - 2015-12-01 06:34:48 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:34:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:34:48 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 93
ERROR - 2015-12-01 06:34:48 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:34:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:34:48 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 93
ERROR - 2015-12-01 06:34:48 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:34:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:34:48 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 93
ERROR - 2015-12-01 06:34:48 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:34:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:34:48 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 93
ERROR - 2015-12-01 06:34:48 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:34:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:34:48 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 93
ERROR - 2015-12-01 06:34:48 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:34:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:34:49 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 93
ERROR - 2015-12-01 06:34:49 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:34:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:34:49 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 93
ERROR - 2015-12-01 06:34:49 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:34:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:34:49 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 93
ERROR - 2015-12-01 06:34:49 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:34:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:34:49 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 93
ERROR - 2015-12-01 06:34:49 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:34:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:34:49 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 93
ERROR - 2015-12-01 06:34:49 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:34:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:34:49 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 93
ERROR - 2015-12-01 06:34:49 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:34:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:34:49 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 93
ERROR - 2015-12-01 06:35:04 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:35:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:35:04 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:35:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:35:04 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:35:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:35:04 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:35:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:35:04 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:35:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:35:04 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:35:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:35:04 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:35:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:35:04 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 93
ERROR - 2015-12-01 06:35:04 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:35:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:35:04 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 93
ERROR - 2015-12-01 06:35:04 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:35:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:35:04 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 93
ERROR - 2015-12-01 06:35:04 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:35:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:35:04 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 93
ERROR - 2015-12-01 06:35:04 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:35:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:35:04 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 93
ERROR - 2015-12-01 06:35:04 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:35:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:35:04 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 93
ERROR - 2015-12-01 06:35:04 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:35:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:35:04 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 93
ERROR - 2015-12-01 06:35:04 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:35:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:35:04 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 93
ERROR - 2015-12-01 06:35:04 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:35:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:35:04 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 93
ERROR - 2015-12-01 06:35:04 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:35:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:35:04 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 93
ERROR - 2015-12-01 06:35:04 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:35:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:35:04 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 93
ERROR - 2015-12-01 06:35:04 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:35:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:35:04 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 93
ERROR - 2015-12-01 06:35:04 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:35:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:35:04 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 93
ERROR - 2015-12-01 06:35:04 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:35:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:35:05 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 93
ERROR - 2015-12-01 06:35:05 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:35:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:35:05 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 93
ERROR - 2015-12-01 06:35:05 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:35:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:35:05 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 93
ERROR - 2015-12-01 06:35:05 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:35:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:35:05 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 93
ERROR - 2015-12-01 06:35:05 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:35:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:35:05 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 93
ERROR - 2015-12-01 06:35:05 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:35:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:35:05 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 93
ERROR - 2015-12-01 06:35:05 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:35:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:35:05 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 93
ERROR - 2015-12-01 06:36:06 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:36:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:36:06 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:36:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:36:06 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:36:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:36:06 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:36:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:36:06 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:36:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:36:06 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:36:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:36:06 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:36:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:36:06 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 93
ERROR - 2015-12-01 06:36:06 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:36:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:36:06 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 93
ERROR - 2015-12-01 06:36:06 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:36:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:36:06 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 93
ERROR - 2015-12-01 06:36:06 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:36:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:36:06 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 93
ERROR - 2015-12-01 06:36:06 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:36:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:36:06 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 93
ERROR - 2015-12-01 06:36:06 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:36:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:36:06 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:36:06 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 93
ERROR - 2015-12-01 06:36:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:36:06 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:36:06 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:36:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:36:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:36:06 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 93
ERROR - 2015-12-01 06:36:06 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:36:06 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:36:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:36:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:36:06 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:36:06 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 93
ERROR - 2015-12-01 06:36:06 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:36:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:36:06 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:36:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:36:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:36:06 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 93
ERROR - 2015-12-01 06:36:06 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:36:06 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:36:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:36:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:36:06 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:36:06 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 93
ERROR - 2015-12-01 06:36:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:36:06 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:36:06 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:36:06 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 93
ERROR - 2015-12-01 06:36:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:36:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:36:06 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:36:06 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 93
ERROR - 2015-12-01 06:36:06 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:36:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:36:06 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:36:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:36:06 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 93
ERROR - 2015-12-01 06:36:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:36:06 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:36:06 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:36:06 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 93
ERROR - 2015-12-01 06:36:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:36:07 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:36:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:36:07 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:36:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:36:07 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 93
ERROR - 2015-12-01 06:36:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:36:07 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:36:07 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 93
ERROR - 2015-12-01 06:36:07 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:36:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:36:07 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:36:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:36:07 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 93
ERROR - 2015-12-01 06:36:07 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:36:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:36:07 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 93
ERROR - 2015-12-01 06:36:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:36:07 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:36:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:36:07 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:36:07 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:36:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:36:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:36:07 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 93
ERROR - 2015-12-01 06:36:07 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:36:07 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 93
ERROR - 2015-12-01 06:36:07 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 93
ERROR - 2015-12-01 06:36:07 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:36:07 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:36:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:36:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:36:07 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 93
ERROR - 2015-12-01 06:36:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:36:07 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:36:07 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 93
ERROR - 2015-12-01 06:36:07 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 93
ERROR - 2015-12-01 06:36:07 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:36:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:36:07 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:36:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:36:07 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 93
ERROR - 2015-12-01 06:36:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:36:07 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 93
ERROR - 2015-12-01 06:36:07 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:36:07 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 93
ERROR - 2015-12-01 06:36:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:36:07 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:36:07 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:36:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:36:07 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 93
ERROR - 2015-12-01 06:36:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:36:07 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 93
ERROR - 2015-12-01 06:36:07 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 93
ERROR - 2015-12-01 06:36:07 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:36:07 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:36:07 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:36:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:36:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:36:07 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 93
ERROR - 2015-12-01 06:36:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:36:07 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:36:07 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 93
ERROR - 2015-12-01 06:36:07 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 93
ERROR - 2015-12-01 06:36:07 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:36:07 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:36:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:36:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:36:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:36:07 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 93
ERROR - 2015-12-01 06:36:07 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 93
ERROR - 2015-12-01 06:36:07 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:36:07 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 93
ERROR - 2015-12-01 06:36:07 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:36:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:36:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:36:07 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 93
ERROR - 2015-12-01 06:36:07 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:36:07 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 93
ERROR - 2015-12-01 06:36:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:36:07 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:36:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:36:07 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 93
ERROR - 2015-12-01 06:36:07 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:36:07 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 93
ERROR - 2015-12-01 06:36:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:36:07 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:36:07 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 93
ERROR - 2015-12-01 06:36:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:36:07 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:36:07 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 93
ERROR - 2015-12-01 06:36:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:36:07 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:36:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:36:07 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 93
ERROR - 2015-12-01 06:36:07 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 93
ERROR - 2015-12-01 06:36:07 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:36:07 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:36:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:36:07 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 93
ERROR - 2015-12-01 06:36:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:36:07 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 93
ERROR - 2015-12-01 06:36:07 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:36:07 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:36:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:36:07 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 93
ERROR - 2015-12-01 06:36:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:36:07 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 93
ERROR - 2015-12-01 06:36:07 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:36:07 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:36:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:36:07 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 93
ERROR - 2015-12-01 06:36:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:36:07 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 93
ERROR - 2015-12-01 06:36:07 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:36:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:36:07 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:36:07 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 93
ERROR - 2015-12-01 06:36:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:36:07 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:36:07 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 93
ERROR - 2015-12-01 06:36:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:36:07 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:36:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:36:07 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 93
ERROR - 2015-12-01 06:36:07 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 93
ERROR - 2015-12-01 06:36:07 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:36:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:36:07 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:36:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:36:07 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 93
ERROR - 2015-12-01 06:36:07 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 93
ERROR - 2015-12-01 06:36:07 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:36:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:36:07 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 93
ERROR - 2015-12-01 06:36:07 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:36:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:36:07 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 93
ERROR - 2015-12-01 06:36:07 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:36:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:36:07 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 93
ERROR - 2015-12-01 06:36:07 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:36:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:36:07 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 93
ERROR - 2015-12-01 06:37:14 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 88
ERROR - 2015-12-01 06:37:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 88
ERROR - 2015-12-01 06:37:14 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 91
ERROR - 2015-12-01 06:37:14 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 88
ERROR - 2015-12-01 06:37:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 88
ERROR - 2015-12-01 06:37:14 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 91
ERROR - 2015-12-01 06:37:14 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 88
ERROR - 2015-12-01 06:37:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 88
ERROR - 2015-12-01 06:37:14 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 91
ERROR - 2015-12-01 06:37:14 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 88
ERROR - 2015-12-01 06:37:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 88
ERROR - 2015-12-01 06:37:14 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 91
ERROR - 2015-12-01 06:37:14 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 88
ERROR - 2015-12-01 06:37:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 88
ERROR - 2015-12-01 06:37:14 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 91
ERROR - 2015-12-01 06:37:14 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 88
ERROR - 2015-12-01 06:37:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 88
ERROR - 2015-12-01 06:37:14 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 91
ERROR - 2015-12-01 06:37:14 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 88
ERROR - 2015-12-01 06:37:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 88
ERROR - 2015-12-01 06:37:14 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 91
ERROR - 2015-12-01 06:37:14 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 88
ERROR - 2015-12-01 06:37:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 88
ERROR - 2015-12-01 06:37:14 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 91
ERROR - 2015-12-01 06:37:14 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 88
ERROR - 2015-12-01 06:37:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 88
ERROR - 2015-12-01 06:37:14 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 91
ERROR - 2015-12-01 06:37:14 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 88
ERROR - 2015-12-01 06:37:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 88
ERROR - 2015-12-01 06:37:14 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 91
ERROR - 2015-12-01 06:37:14 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 88
ERROR - 2015-12-01 06:37:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 88
ERROR - 2015-12-01 06:37:14 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 91
ERROR - 2015-12-01 06:37:14 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 88
ERROR - 2015-12-01 06:37:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 88
ERROR - 2015-12-01 06:37:14 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 91
ERROR - 2015-12-01 06:37:14 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 88
ERROR - 2015-12-01 06:37:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 88
ERROR - 2015-12-01 06:37:14 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 91
ERROR - 2015-12-01 06:37:14 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 88
ERROR - 2015-12-01 06:37:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 88
ERROR - 2015-12-01 06:37:14 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 91
ERROR - 2015-12-01 06:37:14 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 88
ERROR - 2015-12-01 06:37:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 88
ERROR - 2015-12-01 06:37:14 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 91
ERROR - 2015-12-01 06:37:14 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 88
ERROR - 2015-12-01 06:37:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 88
ERROR - 2015-12-01 06:37:14 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 91
ERROR - 2015-12-01 06:37:14 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 88
ERROR - 2015-12-01 06:37:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 88
ERROR - 2015-12-01 06:37:14 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 91
ERROR - 2015-12-01 06:37:14 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 88
ERROR - 2015-12-01 06:37:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 88
ERROR - 2015-12-01 06:37:14 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 91
ERROR - 2015-12-01 06:37:14 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 88
ERROR - 2015-12-01 06:37:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 88
ERROR - 2015-12-01 06:37:14 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 91
ERROR - 2015-12-01 06:37:14 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 88
ERROR - 2015-12-01 06:37:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 88
ERROR - 2015-12-01 06:37:14 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 91
ERROR - 2015-12-01 06:38:07 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 83
ERROR - 2015-12-01 06:38:07 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 83
ERROR - 2015-12-01 06:38:07 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 83
ERROR - 2015-12-01 06:38:07 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 83
ERROR - 2015-12-01 06:38:07 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 83
ERROR - 2015-12-01 06:38:07 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 83
ERROR - 2015-12-01 06:38:07 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 83
ERROR - 2015-12-01 06:38:07 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 83
ERROR - 2015-12-01 06:38:07 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 83
ERROR - 2015-12-01 06:38:07 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 83
ERROR - 2015-12-01 06:38:07 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 83
ERROR - 2015-12-01 06:38:07 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 83
ERROR - 2015-12-01 06:38:07 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 83
ERROR - 2015-12-01 06:38:07 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 83
ERROR - 2015-12-01 06:38:07 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 83
ERROR - 2015-12-01 06:38:07 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 83
ERROR - 2015-12-01 06:38:07 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 83
ERROR - 2015-12-01 06:38:07 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 83
ERROR - 2015-12-01 06:38:07 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 83
ERROR - 2015-12-01 06:38:07 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 83
ERROR - 2015-12-01 06:42:00 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 83
ERROR - 2015-12-01 06:42:00 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 83
ERROR - 2015-12-01 06:42:00 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 83
ERROR - 2015-12-01 06:42:00 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 83
ERROR - 2015-12-01 06:42:00 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 83
ERROR - 2015-12-01 06:42:00 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 83
ERROR - 2015-12-01 06:42:00 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 83
ERROR - 2015-12-01 06:42:00 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 83
ERROR - 2015-12-01 06:42:00 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 83
ERROR - 2015-12-01 06:42:00 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 83
ERROR - 2015-12-01 06:42:00 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 83
ERROR - 2015-12-01 06:42:00 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 83
ERROR - 2015-12-01 06:42:00 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 83
ERROR - 2015-12-01 06:42:00 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 83
ERROR - 2015-12-01 06:42:00 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 83
ERROR - 2015-12-01 06:42:00 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 83
ERROR - 2015-12-01 06:42:00 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 83
ERROR - 2015-12-01 06:42:00 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 83
ERROR - 2015-12-01 06:42:00 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 83
ERROR - 2015-12-01 06:42:00 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 83
ERROR - 2015-12-01 06:42:02 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 83
ERROR - 2015-12-01 06:42:02 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 83
ERROR - 2015-12-01 06:42:02 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 83
ERROR - 2015-12-01 06:42:02 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 83
ERROR - 2015-12-01 06:42:02 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 83
ERROR - 2015-12-01 06:42:02 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 83
ERROR - 2015-12-01 06:42:02 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 83
ERROR - 2015-12-01 06:42:02 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 83
ERROR - 2015-12-01 06:42:02 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 83
ERROR - 2015-12-01 06:42:02 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 83
ERROR - 2015-12-01 06:42:02 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 83
ERROR - 2015-12-01 06:42:02 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 83
ERROR - 2015-12-01 06:42:02 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 83
ERROR - 2015-12-01 06:42:02 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 83
ERROR - 2015-12-01 06:42:02 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 83
ERROR - 2015-12-01 06:42:02 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 83
ERROR - 2015-12-01 06:42:02 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 83
ERROR - 2015-12-01 06:42:02 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 83
ERROR - 2015-12-01 06:42:02 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 83
ERROR - 2015-12-01 06:42:02 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 83
ERROR - 2015-12-01 06:44:21 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 83
ERROR - 2015-12-01 06:44:21 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 83
ERROR - 2015-12-01 06:44:21 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 83
ERROR - 2015-12-01 06:44:21 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 83
ERROR - 2015-12-01 06:44:21 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 83
ERROR - 2015-12-01 06:44:21 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 83
ERROR - 2015-12-01 06:44:22 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 83
ERROR - 2015-12-01 06:44:22 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 83
ERROR - 2015-12-01 06:44:22 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 83
ERROR - 2015-12-01 06:44:22 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 83
ERROR - 2015-12-01 06:44:22 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 83
ERROR - 2015-12-01 06:44:22 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 83
ERROR - 2015-12-01 06:44:22 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 83
ERROR - 2015-12-01 06:44:22 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 83
ERROR - 2015-12-01 06:44:22 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 83
ERROR - 2015-12-01 06:44:22 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 83
ERROR - 2015-12-01 06:44:22 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 83
ERROR - 2015-12-01 06:44:22 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 83
ERROR - 2015-12-01 06:44:22 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 83
ERROR - 2015-12-01 06:44:22 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 83
ERROR - 2015-12-01 06:44:22 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 83
ERROR - 2015-12-01 06:44:22 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 83
ERROR - 2015-12-01 06:44:22 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 83
ERROR - 2015-12-01 06:44:22 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 83
ERROR - 2015-12-01 06:44:22 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 83
ERROR - 2015-12-01 06:44:22 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 83
ERROR - 2015-12-01 06:44:22 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 83
ERROR - 2015-12-01 06:44:22 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 83
ERROR - 2015-12-01 06:44:22 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 83
ERROR - 2015-12-01 06:44:22 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 83
ERROR - 2015-12-01 06:44:22 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 83
ERROR - 2015-12-01 06:44:22 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 83
ERROR - 2015-12-01 06:44:22 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 83
ERROR - 2015-12-01 06:44:22 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 83
ERROR - 2015-12-01 06:44:22 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 83
ERROR - 2015-12-01 06:44:22 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 83
ERROR - 2015-12-01 06:44:22 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 83
ERROR - 2015-12-01 06:44:22 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 83
ERROR - 2015-12-01 06:44:22 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 83
ERROR - 2015-12-01 06:44:22 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 83
ERROR - 2015-12-01 06:44:48 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 83
ERROR - 2015-12-01 06:44:48 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 83
ERROR - 2015-12-01 06:44:48 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 83
ERROR - 2015-12-01 06:44:48 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 83
ERROR - 2015-12-01 06:44:48 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 83
ERROR - 2015-12-01 06:44:48 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 83
ERROR - 2015-12-01 06:44:48 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 83
ERROR - 2015-12-01 06:44:48 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 83
ERROR - 2015-12-01 06:44:48 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 83
ERROR - 2015-12-01 06:44:48 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 83
ERROR - 2015-12-01 06:44:48 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 83
ERROR - 2015-12-01 06:44:48 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 83
ERROR - 2015-12-01 06:44:48 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 83
ERROR - 2015-12-01 06:44:48 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 83
ERROR - 2015-12-01 06:44:48 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 83
ERROR - 2015-12-01 06:44:48 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 83
ERROR - 2015-12-01 06:44:48 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 83
ERROR - 2015-12-01 06:44:48 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 83
ERROR - 2015-12-01 06:44:48 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 83
ERROR - 2015-12-01 06:44:48 --> Severity: Notice  --> Undefined property: stdClass::$categori_id C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 83
ERROR - 2015-12-01 06:48:25 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:48:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:48:25 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:48:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:48:25 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:48:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:48:25 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:48:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:48:25 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:48:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:48:25 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:48:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:48:25 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:48:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:48:25 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:48:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:48:25 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:48:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:48:25 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:48:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:48:25 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:48:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:48:25 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:48:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:48:26 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:48:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:48:26 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:48:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:48:26 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:48:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:48:26 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:48:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:48:26 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:48:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:48:26 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:48:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:48:26 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:48:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:48:26 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:48:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:48:26 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:48:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:48:26 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:48:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:48:26 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:48:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:48:26 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:48:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:48:26 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:48:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:48:26 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:48:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:48:29 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:48:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:48:29 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:48:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:48:29 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:48:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:48:29 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:48:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:48:29 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:48:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:48:29 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:48:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:48:29 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:48:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:48:29 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:48:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:48:29 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:48:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:48:29 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:48:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:48:29 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:48:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:48:29 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:48:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:48:29 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:48:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:48:29 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:48:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:48:29 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:48:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:48:29 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:48:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:48:29 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:48:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:48:29 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:48:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:48:29 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:48:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:48:29 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:48:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:48:29 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:48:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:48:29 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:48:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:48:29 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:48:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:48:29 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:48:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:48:29 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:48:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:48:30 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:48:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:48:32 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:48:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:48:32 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:48:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:48:32 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:48:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:48:32 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:48:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:48:32 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:48:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:48:32 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:48:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:48:33 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:48:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:48:33 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:48:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:48:33 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:48:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:48:33 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:48:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:48:33 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:48:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:48:33 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:48:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:48:33 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:48:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:48:33 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:48:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:48:33 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:48:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:48:33 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:48:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:48:33 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:48:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:48:33 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:48:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:48:33 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:48:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:48:33 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:48:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:48:33 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:48:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:48:33 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:48:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:48:33 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:48:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:48:33 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:48:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:48:33 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:48:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:48:33 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:48:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:51:32 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:51:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:51:32 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:51:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:51:32 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:51:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:51:32 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:51:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:51:32 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:51:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:51:32 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:51:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:51:32 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:51:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:51:32 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:51:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:51:32 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:51:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:51:32 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:51:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:51:32 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:51:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:51:32 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:51:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:51:32 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:51:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:51:32 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:51:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:51:32 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:51:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:51:32 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:51:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:51:32 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:51:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:51:32 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:51:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:51:32 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:51:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:51:32 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:51:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:51:33 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:51:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:51:33 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:51:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:51:33 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:51:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:51:33 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:51:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:51:33 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:51:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:51:33 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:51:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:51:38 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:51:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:51:38 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:51:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:51:38 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:51:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:51:38 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:51:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:51:38 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:51:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:51:38 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:51:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:51:39 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:51:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:51:39 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:51:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:51:39 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:51:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:51:39 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:51:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:51:39 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:51:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:51:39 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:51:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:51:39 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:51:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:51:39 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:51:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:51:39 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:51:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:51:39 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:51:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:51:39 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:51:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:51:39 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:51:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:51:39 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:51:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:51:39 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:51:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:51:39 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:51:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:51:39 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:51:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:51:39 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:51:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:51:39 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:51:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:51:39 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:51:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:51:39 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:51:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:52:05 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:52:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:52:05 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:52:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:52:05 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:52:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:52:05 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:52:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:52:05 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:52:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:52:05 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:52:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:52:05 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:52:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:52:05 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:52:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:52:05 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:52:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:52:05 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:52:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:52:05 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:52:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:52:05 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:52:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:52:05 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:52:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:52:05 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:52:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:52:05 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:52:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:52:05 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:52:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:52:05 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:52:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:52:05 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:52:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:52:05 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:52:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:52:05 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:52:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:52:05 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:52:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:52:05 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:52:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:52:05 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:52:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:52:05 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:52:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:52:05 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:52:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:52:05 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:52:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:52:53 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:52:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:52:53 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:52:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:52:53 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:52:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:52:53 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:52:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:52:53 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:52:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:52:53 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:52:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:52:53 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:52:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:52:53 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:52:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:52:53 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:52:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:52:53 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:52:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:52:53 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:52:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:52:53 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:52:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:52:53 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:52:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:52:53 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:52:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:52:53 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:52:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:52:53 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:52:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:52:53 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:52:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:52:53 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:52:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:52:53 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:52:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:52:53 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:52:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:52:53 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:52:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:52:53 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:52:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:52:53 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:52:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:52:53 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:52:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:52:53 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:52:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:52:53 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:52:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:54:09 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:54:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:54:09 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:54:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:54:09 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:54:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:54:09 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:54:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:54:09 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:54:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:54:09 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:54:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:54:09 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:54:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:54:09 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:54:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:54:09 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:54:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:54:09 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:54:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:54:09 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:54:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:54:09 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:54:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:54:09 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:54:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:54:09 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:54:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:54:09 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:54:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:54:09 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:54:10 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:54:10 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:54:10 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:54:10 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:54:10 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:54:10 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:54:10 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:54:10 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:54:10 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:54:10 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:54:10 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:54:10 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:54:10 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:54:10 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:54:10 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:54:10 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:54:10 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:54:10 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:54:10 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:54:10 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:54:10 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:57:30 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:57:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:57:30 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:57:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:57:30 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:57:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:57:30 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:57:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:57:30 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:57:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:57:30 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:57:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:57:30 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:57:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:57:30 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:57:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:57:30 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:57:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:57:30 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:57:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:57:30 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:57:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:57:30 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:57:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:57:30 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:57:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:57:30 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:57:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:57:30 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:57:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:57:30 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:57:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:57:30 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:57:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:57:30 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:57:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:57:30 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:57:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:57:31 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:57:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:57:31 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:57:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:57:31 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:57:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:57:31 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:57:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:57:31 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:57:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:57:31 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:57:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:57:31 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:57:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:58:10 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:58:10 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:58:10 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:58:10 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:58:10 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:58:10 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:58:10 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:58:10 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:58:10 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:58:10 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:58:10 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:58:10 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:58:10 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:58:10 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:58:10 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:58:10 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:58:10 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:58:10 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:58:10 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:58:10 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:58:10 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:58:10 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:58:10 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:58:10 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:58:10 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:58:10 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:58:10 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:58:10 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:58:10 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:58:10 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:58:10 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:58:10 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:58:10 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:58:10 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:58:10 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:58:10 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:58:10 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:58:10 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:58:10 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:58:10 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:58:10 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:58:10 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:58:10 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:58:10 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:58:10 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:58:10 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:58:10 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:58:10 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:58:10 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:58:10 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:58:10 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:58:10 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:58:53 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:58:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:58:53 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:58:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:58:53 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:58:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:58:53 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:58:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:58:53 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:58:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:58:53 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:58:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 06:58:53 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:58:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:58:53 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:58:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:58:53 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:58:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:58:53 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:58:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:58:53 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:58:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:58:53 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:58:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:58:53 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:58:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:58:53 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:58:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:58:53 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:58:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:58:53 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:58:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:58:53 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:58:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:58:53 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:58:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:58:53 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:58:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:58:53 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:58:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:58:53 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:58:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:58:53 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:58:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:58:53 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:58:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:58:53 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:58:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:58:53 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:58:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:58:53 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 06:58:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:00:01 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 07:00:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 07:00:01 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 07:00:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 07:00:01 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 07:00:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 07:00:01 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 07:00:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 07:00:01 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 07:00:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 07:00:01 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 07:00:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 07:00:01 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:00:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:00:01 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:00:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:00:01 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:00:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:00:01 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:00:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:00:01 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:00:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:00:01 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:00:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:00:01 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:00:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:00:01 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:00:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:00:01 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:00:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:00:01 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:00:02 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:00:02 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:00:02 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:00:02 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:00:02 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:00:02 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:00:02 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:00:02 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:00:02 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:00:02 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:00:02 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:00:02 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:00:02 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:00:02 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:00:02 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:00:02 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:00:02 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:00:02 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:00:02 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:00:02 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:00:02 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:00:27 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 07:00:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 07:00:27 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 07:00:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 07:00:27 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 07:00:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 07:00:27 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 07:00:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 07:00:27 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 07:00:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 07:00:27 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 07:00:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 07:00:27 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:00:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:00:27 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:00:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:00:27 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:00:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:00:27 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:00:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:00:27 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:00:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:00:27 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:00:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:00:27 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:00:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:00:27 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:00:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:00:27 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:00:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:00:27 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:00:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:00:27 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:00:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:00:27 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:00:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:00:27 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:00:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:00:27 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:00:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:00:27 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:00:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:00:27 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:00:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:00:27 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:00:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:00:28 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:00:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:00:28 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:00:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:00:28 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:00:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:03:32 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 07:03:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 07:03:32 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 07:03:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 07:03:32 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 07:03:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 07:03:32 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 07:03:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 07:03:32 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 07:03:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 07:03:32 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 07:03:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 07:03:32 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:03:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:03:32 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:03:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:03:32 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:03:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:03:32 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:03:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:03:32 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:03:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:03:33 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:03:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:03:33 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:03:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:03:33 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:03:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:03:33 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:03:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:03:33 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:03:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:03:33 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:03:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:03:33 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:03:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:03:33 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:03:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:03:33 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:03:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:03:33 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:03:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:03:33 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:03:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:03:33 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:03:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:03:33 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:03:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:03:33 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:03:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:03:33 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:03:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:07:02 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 07:07:02 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 07:07:02 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 07:07:02 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 07:07:02 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 07:07:02 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 07:07:02 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 07:07:02 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 07:07:02 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 07:07:02 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 07:07:02 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 07:07:02 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 07:07:02 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:07:02 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:07:02 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:07:02 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:07:02 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:07:02 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:07:02 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:07:02 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:07:02 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:07:02 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:07:02 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:07:02 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:07:02 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:07:02 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:07:02 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:07:02 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:07:02 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:07:02 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:07:02 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:07:02 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:07:02 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:07:02 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:07:02 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:07:02 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:07:02 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:07:02 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:07:02 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:07:02 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:07:02 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:07:02 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:07:02 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:07:02 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:07:02 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:07:02 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:07:03 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:07:03 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:07:03 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:07:03 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:07:03 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:07:03 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:09:01 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 07:09:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 07:09:01 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 07:09:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 07:09:01 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 07:09:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 07:09:01 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 07:09:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 07:09:01 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 07:09:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 07:09:01 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 07:09:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 07:09:01 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:09:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:09:01 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:09:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:09:01 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:09:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:09:01 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:09:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:09:01 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:09:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:09:01 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:09:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:09:01 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:09:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:09:01 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:09:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:09:01 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:09:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:09:01 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:09:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:09:01 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:09:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:09:01 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:09:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:09:01 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:09:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:09:01 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:09:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:09:01 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:09:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:09:01 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:09:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:09:01 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:09:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:09:01 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:09:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:09:01 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:09:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:09:01 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:09:02 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:19:50 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 07:19:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 07:19:50 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 07:19:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 07:19:50 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 07:19:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 07:19:50 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 07:19:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 07:19:50 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 07:19:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 07:19:50 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 07:19:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 69
ERROR - 2015-12-01 07:19:50 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:19:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:19:50 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:19:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:19:50 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:19:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:19:50 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:19:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:19:50 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:19:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:19:50 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:19:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:19:50 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:19:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:19:50 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:19:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:19:50 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:19:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:19:50 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:19:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:19:50 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:19:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:19:50 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:19:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:19:50 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:19:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:19:50 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:19:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:19:50 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:19:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:19:50 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:19:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:19:50 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:19:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:19:50 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:19:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:19:50 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:19:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:19:50 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
ERROR - 2015-12-01 07:19:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 90
