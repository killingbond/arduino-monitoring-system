<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2014-09-07 00:36:12 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
ERROR - 2014-09-07 00:38:04 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-09-07 00:38:04 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-09-07 00:38:05 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-09-07 00:38:05 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-09-07 00:38:16 --> Severity: Warning  --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\wamp\www\Galaxia-Store\system\libraries\Email.php 1553
ERROR - 2014-09-07 00:39:34 --> Severity: Notice  --> Undefined variable: order C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 32
ERROR - 2014-09-07 00:39:34 --> Severity: Notice  --> Undefined variable: member_id C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 33
ERROR - 2014-09-07 00:39:34 --> Severity: Notice  --> Undefined variable: name C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 34
ERROR - 2014-09-07 00:39:34 --> Severity: Notice  --> Undefined variable: order_status C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 35
ERROR - 2014-09-07 00:39:34 --> Severity: Notice  --> Undefined variable: email C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 36
ERROR - 2014-09-07 00:39:34 --> Severity: Notice  --> Undefined variable: name C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 40
ERROR - 2014-09-07 00:39:34 --> Severity: Notice  --> Undefined variable: address C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 41
ERROR - 2014-09-07 00:39:34 --> Severity: Notice  --> Undefined variable: province_selected C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 42
ERROR - 2014-09-07 00:39:34 --> Severity: Notice  --> Undefined variable: city_selected C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 43
ERROR - 2014-09-07 00:39:34 --> Severity: Notice  --> Undefined variable: district_selected C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 44
ERROR - 2014-09-07 00:39:34 --> Severity: Notice  --> Undefined variable: postcode C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 45
ERROR - 2014-09-07 00:39:34 --> Severity: Notice  --> Undefined variable: country_selected C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 46
ERROR - 2014-09-07 00:39:34 --> Severity: Notice  --> Undefined variable: phone C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 47
ERROR - 2014-09-07 00:39:34 --> Severity: Notice  --> Undefined variable: shopping_cart C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 88
ERROR - 2014-09-07 00:39:34 --> Severity: Notice  --> Undefined variable: shipping_cost C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 118
ERROR - 2014-09-07 00:39:34 --> Severity: Notice  --> Undefined variable: order C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 119
ERROR - 2014-09-07 00:39:34 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 119
ERROR - 2014-09-07 00:39:34 --> Severity: Notice  --> Undefined variable: methodcode C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 145
ERROR - 2014-09-07 00:39:34 --> Severity: Notice  --> Undefined variable: methodcode C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 145
ERROR - 2014-09-07 00:39:34 --> Severity: Notice  --> Undefined variable: country_selected C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 151
ERROR - 2014-09-07 00:39:34 --> Severity: Notice  --> Undefined variable: district_selected C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 151
ERROR - 2014-09-07 00:39:34 --> Severity: Notice  --> Undefined variable: methodcode C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 153
ERROR - 2014-09-07 00:39:34 --> Severity: Notice  --> Undefined variable: methodcode C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 153
ERROR - 2014-09-07 00:39:35 --> Severity: Notice  --> Undefined variable: methodcode C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 162
ERROR - 2014-09-07 00:39:35 --> Severity: Notice  --> Undefined variable: methodcode C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 162
ERROR - 2014-09-07 00:39:35 --> Severity: Notice  --> Undefined variable: order C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 172
ERROR - 2014-09-07 00:39:35 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 172
ERROR - 2014-09-07 00:39:35 --> Severity: Notice  --> Undefined variable: order C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 172
ERROR - 2014-09-07 00:39:35 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 172
ERROR - 2014-09-07 00:39:35 --> Severity: Notice  --> Undefined variable: order C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 32
ERROR - 2014-09-07 00:39:35 --> Severity: Notice  --> Undefined variable: member_id C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 33
ERROR - 2014-09-07 00:39:35 --> Severity: Notice  --> Undefined variable: name C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 34
ERROR - 2014-09-07 00:39:35 --> Severity: Notice  --> Undefined variable: order_status C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 35
ERROR - 2014-09-07 00:39:35 --> Severity: Notice  --> Undefined variable: email C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 36
ERROR - 2014-09-07 00:39:35 --> Severity: Notice  --> Undefined variable: name C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 40
ERROR - 2014-09-07 00:39:35 --> Severity: Notice  --> Undefined variable: address C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 41
ERROR - 2014-09-07 00:39:35 --> Severity: Notice  --> Undefined variable: province_selected C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 42
ERROR - 2014-09-07 00:39:35 --> Severity: Notice  --> Undefined variable: city_selected C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 43
ERROR - 2014-09-07 00:39:35 --> Severity: Notice  --> Undefined variable: district_selected C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 44
ERROR - 2014-09-07 00:39:35 --> Severity: Notice  --> Undefined variable: postcode C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 45
ERROR - 2014-09-07 00:39:35 --> Severity: Notice  --> Undefined variable: country_selected C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 46
ERROR - 2014-09-07 00:39:35 --> Severity: Notice  --> Undefined variable: phone C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 47
ERROR - 2014-09-07 00:39:35 --> Severity: Notice  --> Undefined variable: shopping_cart C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 88
ERROR - 2014-09-07 00:39:35 --> Severity: Notice  --> Undefined variable: shipping_cost C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 118
ERROR - 2014-09-07 00:39:35 --> Severity: Notice  --> Undefined variable: order C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 119
ERROR - 2014-09-07 00:39:35 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 119
ERROR - 2014-09-07 00:39:35 --> Severity: Notice  --> Undefined variable: methodcode C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 145
ERROR - 2014-09-07 00:39:35 --> Severity: Notice  --> Undefined variable: methodcode C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 145
ERROR - 2014-09-07 00:39:35 --> Severity: Notice  --> Undefined variable: country_selected C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 151
ERROR - 2014-09-07 00:39:35 --> Severity: Notice  --> Undefined variable: district_selected C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 151
ERROR - 2014-09-07 00:39:35 --> Severity: Notice  --> Undefined variable: methodcode C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 153
ERROR - 2014-09-07 00:39:35 --> Severity: Notice  --> Undefined variable: methodcode C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 153
ERROR - 2014-09-07 00:39:35 --> Severity: Notice  --> Undefined variable: methodcode C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 162
ERROR - 2014-09-07 00:39:35 --> Severity: Notice  --> Undefined variable: methodcode C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 162
ERROR - 2014-09-07 00:39:35 --> Severity: Notice  --> Undefined variable: order C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 172
ERROR - 2014-09-07 00:39:35 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 172
ERROR - 2014-09-07 00:39:35 --> Severity: Notice  --> Undefined variable: order C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 172
ERROR - 2014-09-07 00:39:35 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 172
ERROR - 2014-09-07 00:41:51 --> Severity: Notice  --> Undefined variable: member_id C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 33
ERROR - 2014-09-07 00:41:51 --> Severity: Notice  --> Undefined variable: name C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 34
ERROR - 2014-09-07 00:41:51 --> Severity: Notice  --> Undefined variable: email C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 36
ERROR - 2014-09-07 00:41:51 --> Severity: Notice  --> Undefined variable: name C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 40
ERROR - 2014-09-07 00:41:51 --> Severity: Notice  --> Undefined variable: address C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 41
ERROR - 2014-09-07 00:41:51 --> Severity: Notice  --> Undefined variable: province_selected C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 42
ERROR - 2014-09-07 00:41:51 --> Severity: Notice  --> Undefined variable: city_selected C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 43
ERROR - 2014-09-07 00:41:51 --> Severity: Notice  --> Undefined variable: district_selected C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 44
ERROR - 2014-09-07 00:41:51 --> Severity: Notice  --> Undefined variable: postcode C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 45
ERROR - 2014-09-07 00:41:51 --> Severity: Notice  --> Undefined variable: country_selected C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 46
ERROR - 2014-09-07 00:41:51 --> Severity: Notice  --> Undefined variable: phone C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 47
ERROR - 2014-09-07 00:41:51 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 119
ERROR - 2014-09-07 00:41:51 --> Severity: Notice  --> Undefined variable: methodcode C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 145
ERROR - 2014-09-07 00:41:51 --> Severity: Notice  --> Undefined variable: methodcode C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 145
ERROR - 2014-09-07 00:41:51 --> Severity: Notice  --> Undefined variable: country_selected C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 151
ERROR - 2014-09-07 00:41:51 --> Severity: Notice  --> Undefined variable: district_selected C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 151
ERROR - 2014-09-07 00:41:51 --> Severity: Notice  --> Undefined variable: methodcode C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 153
ERROR - 2014-09-07 00:41:51 --> Severity: Notice  --> Undefined variable: methodcode C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 153
ERROR - 2014-09-07 00:41:51 --> Severity: Notice  --> Undefined variable: methodcode C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 162
ERROR - 2014-09-07 00:41:51 --> Severity: Notice  --> Undefined variable: methodcode C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 162
ERROR - 2014-09-07 00:41:51 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 172
ERROR - 2014-09-07 00:41:51 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 172
ERROR - 2014-09-07 00:41:51 --> Severity: Notice  --> Undefined variable: member_id C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 33
ERROR - 2014-09-07 00:41:51 --> Severity: Notice  --> Undefined variable: name C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 34
ERROR - 2014-09-07 00:41:51 --> Severity: Notice  --> Undefined variable: email C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 36
ERROR - 2014-09-07 00:41:51 --> Severity: Notice  --> Undefined variable: name C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 40
ERROR - 2014-09-07 00:41:51 --> Severity: Notice  --> Undefined variable: address C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 41
ERROR - 2014-09-07 00:41:51 --> Severity: Notice  --> Undefined variable: province_selected C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 42
ERROR - 2014-09-07 00:41:51 --> Severity: Notice  --> Undefined variable: city_selected C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 43
ERROR - 2014-09-07 00:41:51 --> Severity: Notice  --> Undefined variable: district_selected C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 44
ERROR - 2014-09-07 00:41:51 --> Severity: Notice  --> Undefined variable: postcode C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 45
ERROR - 2014-09-07 00:41:51 --> Severity: Notice  --> Undefined variable: country_selected C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 46
ERROR - 2014-09-07 00:41:51 --> Severity: Notice  --> Undefined variable: phone C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 47
ERROR - 2014-09-07 00:41:51 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 119
ERROR - 2014-09-07 00:41:51 --> Severity: Notice  --> Undefined variable: methodcode C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 145
ERROR - 2014-09-07 00:41:51 --> Severity: Notice  --> Undefined variable: methodcode C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 145
ERROR - 2014-09-07 00:41:51 --> Severity: Notice  --> Undefined variable: country_selected C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 151
ERROR - 2014-09-07 00:41:51 --> Severity: Notice  --> Undefined variable: district_selected C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 151
ERROR - 2014-09-07 00:41:51 --> Severity: Notice  --> Undefined variable: methodcode C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 153
ERROR - 2014-09-07 00:41:51 --> Severity: Notice  --> Undefined variable: methodcode C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 153
ERROR - 2014-09-07 00:41:51 --> Severity: Notice  --> Undefined variable: methodcode C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 162
ERROR - 2014-09-07 00:41:51 --> Severity: Notice  --> Undefined variable: methodcode C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 162
ERROR - 2014-09-07 00:41:51 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 172
ERROR - 2014-09-07 00:41:51 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 172
ERROR - 2014-09-07 00:45:20 --> Severity: Notice  --> Undefined variable: province_selected C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 85
ERROR - 2014-09-07 00:45:20 --> Severity: Notice  --> Undefined variable: city_selected C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 86
ERROR - 2014-09-07 00:45:20 --> Severity: Notice  --> Undefined variable: district_selected C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 87
ERROR - 2014-09-07 00:45:20 --> Severity: Notice  --> Undefined variable: country_selected C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 89
ERROR - 2014-09-07 00:45:20 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 162
ERROR - 2014-09-07 00:45:20 --> Severity: Notice  --> Undefined variable: country_selected C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 194
ERROR - 2014-09-07 00:45:20 --> Severity: Notice  --> Undefined variable: district_selected C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 194
ERROR - 2014-09-07 00:45:20 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 198
ERROR - 2014-09-07 00:45:20 --> Severity: Warning  --> Division by zero C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 198
ERROR - 2014-09-07 00:45:20 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 207
ERROR - 2014-09-07 00:45:20 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 215
ERROR - 2014-09-07 00:45:20 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 215
ERROR - 2014-09-07 00:45:20 --> Severity: Notice  --> Undefined variable: province_selected C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 85
ERROR - 2014-09-07 00:45:20 --> Severity: Notice  --> Undefined variable: city_selected C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 86
ERROR - 2014-09-07 00:45:20 --> Severity: Notice  --> Undefined variable: district_selected C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 87
ERROR - 2014-09-07 00:45:20 --> Severity: Notice  --> Undefined variable: country_selected C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 89
ERROR - 2014-09-07 00:45:20 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 162
ERROR - 2014-09-07 00:45:20 --> Severity: Notice  --> Undefined variable: country_selected C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 194
ERROR - 2014-09-07 00:45:20 --> Severity: Notice  --> Undefined variable: district_selected C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 194
ERROR - 2014-09-07 00:45:20 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 198
ERROR - 2014-09-07 00:45:20 --> Severity: Warning  --> Division by zero C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 198
ERROR - 2014-09-07 00:45:20 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 207
ERROR - 2014-09-07 00:45:20 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 215
ERROR - 2014-09-07 00:45:20 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 215
ERROR - 2014-09-07 00:45:41 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 198
ERROR - 2014-09-07 00:45:41 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 234
ERROR - 2014-09-07 00:45:41 --> Severity: Warning  --> Division by zero C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 234
ERROR - 2014-09-07 00:45:41 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 243
ERROR - 2014-09-07 00:45:41 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 251
ERROR - 2014-09-07 00:45:41 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 251
ERROR - 2014-09-07 00:45:42 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 198
ERROR - 2014-09-07 00:45:42 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 234
ERROR - 2014-09-07 00:45:42 --> Severity: Warning  --> Division by zero C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 234
ERROR - 2014-09-07 00:45:42 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 243
ERROR - 2014-09-07 00:45:42 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 251
ERROR - 2014-09-07 00:45:42 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 251
ERROR - 2014-09-07 00:46:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 198
ERROR - 2014-09-07 00:46:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 234
ERROR - 2014-09-07 00:46:29 --> Severity: Warning  --> Division by zero C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 234
ERROR - 2014-09-07 00:46:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 243
ERROR - 2014-09-07 00:46:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 251
ERROR - 2014-09-07 00:46:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 251
ERROR - 2014-09-07 00:46:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 198
ERROR - 2014-09-07 00:46:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 234
ERROR - 2014-09-07 00:46:29 --> Severity: Warning  --> Division by zero C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 234
ERROR - 2014-09-07 00:46:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 243
ERROR - 2014-09-07 00:46:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 251
ERROR - 2014-09-07 00:46:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 251
ERROR - 2014-09-07 00:54:35 --> Severity: Warning  --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\wamp\www\Galaxia-Store\system\libraries\Email.php 1553
ERROR - 2014-09-07 00:54:43 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-09-07 00:54:43 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-09-07 00:54:43 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-09-07 00:54:43 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-09-07 00:55:06 --> Severity: Warning  --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\wamp\www\Galaxia-Store\system\libraries\Email.php 1553
ERROR - 2014-09-07 00:55:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Galaxia-Store\application\controllers\member.php 165
ERROR - 2014-09-07 00:55:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 195
ERROR - 2014-09-07 00:55:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 231
ERROR - 2014-09-07 00:55:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 240
ERROR - 2014-09-07 00:55:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 248
ERROR - 2014-09-07 00:55:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 248
ERROR - 2014-09-07 00:55:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Galaxia-Store\application\controllers\member.php 165
ERROR - 2014-09-07 00:55:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 195
ERROR - 2014-09-07 00:55:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 231
ERROR - 2014-09-07 00:55:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 240
ERROR - 2014-09-07 00:55:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 248
ERROR - 2014-09-07 00:55:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 248
ERROR - 2014-09-07 00:56:00 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 195
ERROR - 2014-09-07 00:56:00 --> Severity: Notice  --> Undefined variable: shipping_service_name C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 223
ERROR - 2014-09-07 00:56:00 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 231
ERROR - 2014-09-07 00:56:00 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 240
ERROR - 2014-09-07 00:56:00 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 248
ERROR - 2014-09-07 00:56:00 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 248
ERROR - 2014-09-07 00:56:00 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 195
ERROR - 2014-09-07 00:56:00 --> Severity: Notice  --> Undefined variable: shipping_service_name C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 223
ERROR - 2014-09-07 00:56:00 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 231
ERROR - 2014-09-07 00:56:00 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 240
ERROR - 2014-09-07 00:56:00 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 248
ERROR - 2014-09-07 00:56:00 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Galaxia-Store\application\views\member\invoice.php 248
ERROR - 2014-09-07 01:11:26 --> 404 Page Not Found --> template
ERROR - 2014-09-07 01:11:27 --> 404 Page Not Found --> template
ERROR - 2014-09-07 01:12:04 --> 404 Page Not Found --> template
ERROR - 2014-09-07 01:12:04 --> 404 Page Not Found --> template
ERROR - 2014-09-07 01:12:53 --> 404 Page Not Found --> template
ERROR - 2014-09-07 01:12:53 --> 404 Page Not Found --> template
ERROR - 2014-09-07 01:13:07 --> 404 Page Not Found --> template
ERROR - 2014-09-07 01:13:36 --> 404 Page Not Found --> template
ERROR - 2014-09-07 01:13:36 --> 404 Page Not Found --> template
ERROR - 2014-09-07 01:13:36 --> 404 Page Not Found --> template
ERROR - 2014-09-07 01:13:36 --> 404 Page Not Found --> template
ERROR - 2014-09-07 01:13:36 --> 404 Page Not Found --> template
ERROR - 2014-09-07 01:13:36 --> 404 Page Not Found --> template
ERROR - 2014-09-07 01:13:36 --> 404 Page Not Found --> template
ERROR - 2014-09-07 01:13:37 --> 404 Page Not Found --> template
ERROR - 2014-09-07 01:13:37 --> 404 Page Not Found --> template
ERROR - 2014-09-07 01:13:37 --> 404 Page Not Found --> template
ERROR - 2014-09-07 01:13:37 --> 404 Page Not Found --> template
ERROR - 2014-09-07 01:13:37 --> 404 Page Not Found --> template
ERROR - 2014-09-07 01:13:37 --> 404 Page Not Found --> template
ERROR - 2014-09-07 01:13:37 --> 404 Page Not Found --> template
ERROR - 2014-09-07 01:13:37 --> 404 Page Not Found --> template
ERROR - 2014-09-07 01:13:37 --> 404 Page Not Found --> template
ERROR - 2014-09-07 01:13:37 --> 404 Page Not Found --> template
ERROR - 2014-09-07 01:13:37 --> 404 Page Not Found --> template
ERROR - 2014-09-07 01:13:37 --> 404 Page Not Found --> template
ERROR - 2014-09-07 01:13:37 --> 404 Page Not Found --> template
ERROR - 2014-09-07 01:13:37 --> 404 Page Not Found --> template
ERROR - 2014-09-07 01:13:37 --> 404 Page Not Found --> template
ERROR - 2014-09-07 01:13:42 --> 404 Page Not Found --> template
ERROR - 2014-09-07 01:15:36 --> 404 Page Not Found --> template
ERROR - 2014-09-07 01:15:36 --> 404 Page Not Found --> template
ERROR - 2014-09-07 01:15:45 --> 404 Page Not Found --> my_jsk
ERROR - 2014-09-07 01:15:45 --> 404 Page Not Found --> template
ERROR - 2014-09-07 01:15:45 --> 404 Page Not Found --> my_jsk
ERROR - 2014-09-07 01:15:45 --> 404 Page Not Found --> template
ERROR - 2014-09-07 01:16:24 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-09-07 01:16:24 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-09-07 01:16:24 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-09-07 01:16:24 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-09-07 01:16:44 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-09-07 01:16:44 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-09-07 01:16:44 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-09-07 01:16:44 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-09-07 02:00:31 --> 404 Page Not Found --> register
ERROR - 2014-09-07 02:12:07 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-09-07 02:12:07 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-09-07 02:12:08 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-09-07 02:12:08 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-09-07 02:12:12 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-09-07 02:12:12 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-09-07 02:12:12 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-09-07 02:12:12 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-09-07 02:12:18 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-09-07 02:12:18 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-09-07 02:12:18 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-09-07 02:12:18 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-09-07 02:12:34 --> Severity: Warning  --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\wamp\www\Galaxia-Store\system\libraries\Email.php 1553
ERROR - 2014-09-07 02:59:49 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
ERROR - 2014-09-07 02:59:59 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-09-07 02:59:59 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-09-07 02:59:59 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-09-07 02:59:59 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-09-07 03:00:07 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-09-07 03:00:07 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-09-07 03:00:07 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-09-07 03:00:07 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-09-07 03:00:14 --> Severity: Warning  --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\wamp\www\Galaxia-Store\system\libraries\Email.php 1553
ERROR - 2014-09-07 03:04:35 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Galaxia-Store\application\models\cart_m.php 370
ERROR - 2014-09-07 03:04:35 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Galaxia-Store\application\models\cart_m.php 382
ERROR - 2014-09-07 03:04:35 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Galaxia-Store\application\models\cart_m.php 384
ERROR - 2014-09-07 03:04:35 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Galaxia-Store\application\models\cart_m.php 385
ERROR - 2014-09-07 03:04:35 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Galaxia-Store\application\models\cart_m.php 386
ERROR - 2014-09-07 03:04:35 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Galaxia-Store\application\models\cart_m.php 387
ERROR - 2014-09-07 03:04:35 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Galaxia-Store\application\models\cart_m.php 388
ERROR - 2014-09-07 03:04:35 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Galaxia-Store\application\models\cart_m.php 391
ERROR - 2014-09-07 03:04:35 --> Query error: Column 'courier_id' cannot be null
ERROR - 2014-09-07 03:04:47 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-09-07 03:04:47 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-09-07 03:04:47 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-09-07 03:04:47 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Galaxia-Store\application\views\cart.php 138
ERROR - 2014-09-07 03:23:21 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Galaxia-Store\application\models\cart_m.php 370
ERROR - 2014-09-07 03:23:21 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Galaxia-Store\application\models\cart_m.php 382
ERROR - 2014-09-07 03:23:21 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Galaxia-Store\application\models\cart_m.php 384
ERROR - 2014-09-07 03:23:21 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Galaxia-Store\application\models\cart_m.php 385
ERROR - 2014-09-07 03:23:21 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Galaxia-Store\application\models\cart_m.php 386
ERROR - 2014-09-07 03:23:21 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Galaxia-Store\application\models\cart_m.php 387
ERROR - 2014-09-07 03:23:21 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Galaxia-Store\application\models\cart_m.php 388
ERROR - 2014-09-07 03:23:21 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Galaxia-Store\application\models\cart_m.php 391
ERROR - 2014-09-07 03:23:21 --> Query error: Column 'courier_id' cannot be null
