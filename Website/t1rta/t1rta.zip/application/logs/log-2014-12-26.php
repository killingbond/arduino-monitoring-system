<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2014-12-26 03:44:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 03:44:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 03:44:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 03:44:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 03:44:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 03:44:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 03:45:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 03:45:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 03:51:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 03:56:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 03:56:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 03:56:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 03:56:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 03:57:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 04:26:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 04:49:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 04:52:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 04:52:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 04:53:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 04:53:17 --> You did not select a file to upload.
ERROR - 2014-12-26 04:53:18 --> Severity: Warning  --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\wamp\www\Esgotado\system\libraries\Email.php 1553
ERROR - 2014-12-26 04:53:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 04:58:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 04:59:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 04:59:02 --> You did not select a file to upload.
ERROR - 2014-12-26 04:59:02 --> Severity: Notice  --> A non well formed numeric value encountered C:\wamp\www\Esgotado\application\controllers\confirm.php 67
ERROR - 2014-12-26 04:59:03 --> Severity: Warning  --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\wamp\www\Esgotado\system\libraries\Email.php 1553
ERROR - 2014-12-26 04:59:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 05:08:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 05:09:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 05:10:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 05:10:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 05:10:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 07:08:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 07:21:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 07:21:38 --> Severity: Notice  --> unserialize(): Error at offset 0 of 416 bytes C:\wamp\www\Esgotado\system\libraries\Session.php 724
ERROR - 2014-12-26 07:34:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 07:35:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 07:35:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 07:36:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 07:36:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 07:36:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 07:38:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 07:38:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 07:38:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 07:38:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 07:44:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 07:44:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 07:44:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 07:45:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 07:49:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 07:49:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 07:55:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 07:55:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 07:55:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 07:56:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 07:57:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 07:57:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 07:58:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 07:58:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 07:58:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 07:58:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 08:06:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 08:06:38 --> 404 Page Not Found --> img
ERROR - 2014-12-26 08:06:38 --> 404 Page Not Found --> img
ERROR - 2014-12-26 08:06:38 --> 404 Page Not Found --> img
ERROR - 2014-12-26 08:07:09 --> 404 Page Not Found --> img
ERROR - 2014-12-26 08:07:14 --> 404 Page Not Found --> img
ERROR - 2014-12-26 08:07:14 --> 404 Page Not Found --> img
ERROR - 2014-12-26 08:07:15 --> 404 Page Not Found --> img
ERROR - 2014-12-26 08:07:16 --> 404 Page Not Found --> img
ERROR - 2014-12-26 08:07:17 --> 404 Page Not Found --> img
ERROR - 2014-12-26 08:07:18 --> 404 Page Not Found --> img
ERROR - 2014-12-26 08:07:19 --> 404 Page Not Found --> img
ERROR - 2014-12-26 08:07:19 --> 404 Page Not Found --> img
ERROR - 2014-12-26 08:07:20 --> 404 Page Not Found --> img
ERROR - 2014-12-26 08:07:21 --> 404 Page Not Found --> img
ERROR - 2014-12-26 08:13:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 08:13:45 --> 404 Page Not Found --> template
ERROR - 2014-12-26 08:13:45 --> 404 Page Not Found --> template
ERROR - 2014-12-26 08:13:45 --> 404 Page Not Found --> template
ERROR - 2014-12-26 08:13:45 --> 404 Page Not Found --> template
ERROR - 2014-12-26 08:13:45 --> 404 Page Not Found --> template
ERROR - 2014-12-26 08:13:45 --> 404 Page Not Found --> template
ERROR - 2014-12-26 08:13:45 --> 404 Page Not Found --> template
ERROR - 2014-12-26 08:13:45 --> 404 Page Not Found --> template
ERROR - 2014-12-26 08:13:45 --> 404 Page Not Found --> template
ERROR - 2014-12-26 08:13:45 --> 404 Page Not Found --> template
ERROR - 2014-12-26 08:13:45 --> 404 Page Not Found --> template
ERROR - 2014-12-26 08:13:45 --> 404 Page Not Found --> template
ERROR - 2014-12-26 08:13:45 --> 404 Page Not Found --> template
ERROR - 2014-12-26 08:13:45 --> 404 Page Not Found --> template
ERROR - 2014-12-26 08:13:45 --> 404 Page Not Found --> template
ERROR - 2014-12-26 08:13:46 --> 404 Page Not Found --> template
ERROR - 2014-12-26 08:13:46 --> 404 Page Not Found --> template
ERROR - 2014-12-26 08:13:46 --> 404 Page Not Found --> template
ERROR - 2014-12-26 08:13:46 --> 404 Page Not Found --> template
ERROR - 2014-12-26 08:13:46 --> 404 Page Not Found --> template
ERROR - 2014-12-26 08:13:46 --> 404 Page Not Found --> template
ERROR - 2014-12-26 08:13:46 --> 404 Page Not Found --> template
ERROR - 2014-12-26 08:13:46 --> 404 Page Not Found --> template
ERROR - 2014-12-26 08:13:46 --> 404 Page Not Found --> template
ERROR - 2014-12-26 08:13:46 --> 404 Page Not Found --> template
ERROR - 2014-12-26 08:13:46 --> 404 Page Not Found --> template
ERROR - 2014-12-26 08:13:46 --> 404 Page Not Found --> template
ERROR - 2014-12-26 08:13:46 --> 404 Page Not Found --> template
ERROR - 2014-12-26 08:13:46 --> 404 Page Not Found --> template
ERROR - 2014-12-26 08:13:46 --> 404 Page Not Found --> template
ERROR - 2014-12-26 08:13:46 --> 404 Page Not Found --> template
ERROR - 2014-12-26 08:13:46 --> 404 Page Not Found --> template
ERROR - 2014-12-26 08:13:46 --> 404 Page Not Found --> template
ERROR - 2014-12-26 08:13:46 --> 404 Page Not Found --> template
ERROR - 2014-12-26 08:13:46 --> 404 Page Not Found --> template
ERROR - 2014-12-26 08:13:46 --> 404 Page Not Found --> template
ERROR - 2014-12-26 08:13:46 --> 404 Page Not Found --> template
ERROR - 2014-12-26 08:13:46 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 08:13:46 --> 404 Page Not Found --> template
ERROR - 2014-12-26 08:13:46 --> 404 Page Not Found --> template
ERROR - 2014-12-26 08:13:46 --> 404 Page Not Found --> template
ERROR - 2014-12-26 08:13:46 --> 404 Page Not Found --> template
ERROR - 2014-12-26 08:13:46 --> 404 Page Not Found --> template
ERROR - 2014-12-26 08:13:46 --> 404 Page Not Found --> template
ERROR - 2014-12-26 08:13:46 --> 404 Page Not Found --> template
ERROR - 2014-12-26 08:13:46 --> 404 Page Not Found --> template
ERROR - 2014-12-26 08:13:46 --> 404 Page Not Found --> template
ERROR - 2014-12-26 08:13:46 --> 404 Page Not Found --> template
ERROR - 2014-12-26 08:13:46 --> 404 Page Not Found --> template
ERROR - 2014-12-26 08:13:46 --> 404 Page Not Found --> template
ERROR - 2014-12-26 08:13:46 --> 404 Page Not Found --> template
ERROR - 2014-12-26 08:13:46 --> 404 Page Not Found --> template
ERROR - 2014-12-26 08:13:46 --> 404 Page Not Found --> template
ERROR - 2014-12-26 08:13:46 --> 404 Page Not Found --> template
ERROR - 2014-12-26 08:13:46 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 08:14:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 08:14:09 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 08:14:10 --> 404 Page Not Found --> img
ERROR - 2014-12-26 08:14:10 --> 404 Page Not Found --> img
ERROR - 2014-12-26 08:14:10 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 08:14:10 --> 404 Page Not Found --> music
ERROR - 2014-12-26 08:14:10 --> 404 Page Not Found --> music
ERROR - 2014-12-26 08:16:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 08:16:36 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 08:16:37 --> 404 Page Not Found --> img
ERROR - 2014-12-26 08:16:37 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 08:16:37 --> 404 Page Not Found --> music
ERROR - 2014-12-26 08:16:37 --> 404 Page Not Found --> img
ERROR - 2014-12-26 08:16:37 --> 404 Page Not Found --> music
ERROR - 2014-12-26 08:16:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 08:16:55 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 08:16:55 --> 404 Page Not Found --> img
ERROR - 2014-12-26 08:16:55 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 08:16:55 --> 404 Page Not Found --> img
ERROR - 2014-12-26 08:16:55 --> 404 Page Not Found --> music
ERROR - 2014-12-26 08:16:55 --> 404 Page Not Found --> music
ERROR - 2014-12-26 08:17:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 08:17:35 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 08:17:35 --> 404 Page Not Found --> img
ERROR - 2014-12-26 08:17:35 --> 404 Page Not Found --> img
ERROR - 2014-12-26 08:17:35 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 08:17:35 --> 404 Page Not Found --> music
ERROR - 2014-12-26 08:17:36 --> 404 Page Not Found --> music
ERROR - 2014-12-26 08:18:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 08:18:27 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 08:18:28 --> 404 Page Not Found --> img
ERROR - 2014-12-26 08:18:28 --> 404 Page Not Found --> img
ERROR - 2014-12-26 08:18:28 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 08:18:28 --> 404 Page Not Found --> music
ERROR - 2014-12-26 08:18:28 --> 404 Page Not Found --> music
ERROR - 2014-12-26 08:19:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 08:19:15 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 08:19:16 --> 404 Page Not Found --> img
ERROR - 2014-12-26 08:19:16 --> 404 Page Not Found --> music
ERROR - 2014-12-26 08:19:16 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 08:19:16 --> 404 Page Not Found --> img
ERROR - 2014-12-26 08:19:16 --> 404 Page Not Found --> music
ERROR - 2014-12-26 08:19:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 08:19:32 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 08:19:32 --> 404 Page Not Found --> img
ERROR - 2014-12-26 08:19:32 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 08:19:32 --> 404 Page Not Found --> img
ERROR - 2014-12-26 08:19:32 --> 404 Page Not Found --> music
ERROR - 2014-12-26 08:19:32 --> 404 Page Not Found --> music
ERROR - 2014-12-26 08:19:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 08:19:45 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 08:19:46 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 08:19:46 --> 404 Page Not Found --> music
ERROR - 2014-12-26 08:19:46 --> 404 Page Not Found --> img
ERROR - 2014-12-26 08:19:46 --> 404 Page Not Found --> img
ERROR - 2014-12-26 08:19:46 --> 404 Page Not Found --> music
ERROR - 2014-12-26 08:19:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 08:19:56 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 08:19:56 --> 404 Page Not Found --> img
ERROR - 2014-12-26 08:19:56 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 08:19:56 --> 404 Page Not Found --> img
ERROR - 2014-12-26 08:19:56 --> 404 Page Not Found --> music
ERROR - 2014-12-26 08:19:56 --> 404 Page Not Found --> music
ERROR - 2014-12-26 08:20:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 08:20:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 08:20:25 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 08:20:26 --> 404 Page Not Found --> img
ERROR - 2014-12-26 08:20:26 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 08:20:26 --> 404 Page Not Found --> img
ERROR - 2014-12-26 08:20:26 --> 404 Page Not Found --> music
ERROR - 2014-12-26 08:20:26 --> 404 Page Not Found --> music
ERROR - 2014-12-26 08:21:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 08:21:31 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 08:21:31 --> 404 Page Not Found --> img
ERROR - 2014-12-26 08:21:31 --> 404 Page Not Found --> img
ERROR - 2014-12-26 08:21:31 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 08:21:31 --> 404 Page Not Found --> music
ERROR - 2014-12-26 08:21:31 --> 404 Page Not Found --> music
ERROR - 2014-12-26 08:21:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 08:21:41 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 08:21:41 --> 404 Page Not Found --> img
ERROR - 2014-12-26 08:21:41 --> 404 Page Not Found --> img
ERROR - 2014-12-26 08:21:41 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 08:21:41 --> 404 Page Not Found --> music
ERROR - 2014-12-26 08:21:41 --> 404 Page Not Found --> music
ERROR - 2014-12-26 08:22:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 08:22:19 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 08:22:19 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 08:23:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 08:23:06 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 08:23:06 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 08:23:06 --> 404 Page Not Found --> img
ERROR - 2014-12-26 08:23:06 --> 404 Page Not Found --> img
ERROR - 2014-12-26 08:23:06 --> 404 Page Not Found --> music
ERROR - 2014-12-26 08:23:06 --> 404 Page Not Found --> music
ERROR - 2014-12-26 08:23:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 08:23:15 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 08:23:15 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 08:23:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 08:23:20 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 08:23:20 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 08:24:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 08:24:58 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 08:24:58 --> 404 Page Not Found --> img
ERROR - 2014-12-26 08:24:58 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 08:24:58 --> 404 Page Not Found --> img
ERROR - 2014-12-26 08:24:58 --> 404 Page Not Found --> music
ERROR - 2014-12-26 08:24:58 --> 404 Page Not Found --> music
ERROR - 2014-12-26 08:26:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 08:26:34 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 08:26:34 --> 404 Page Not Found --> img
ERROR - 2014-12-26 08:26:34 --> 404 Page Not Found --> img
ERROR - 2014-12-26 08:26:34 --> 404 Page Not Found --> music
ERROR - 2014-12-26 08:26:34 --> 404 Page Not Found --> music
ERROR - 2014-12-26 08:27:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 08:27:09 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 08:27:09 --> 404 Page Not Found --> img
ERROR - 2014-12-26 08:27:09 --> 404 Page Not Found --> music
ERROR - 2014-12-26 08:27:09 --> 404 Page Not Found --> img
ERROR - 2014-12-26 08:27:10 --> 404 Page Not Found --> music
ERROR - 2014-12-26 08:28:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 08:28:46 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 08:28:46 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 08:29:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 08:29:02 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 08:29:02 --> 404 Page Not Found --> img
ERROR - 2014-12-26 08:29:02 --> 404 Page Not Found --> img
ERROR - 2014-12-26 08:29:02 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 08:29:02 --> 404 Page Not Found --> music
ERROR - 2014-12-26 08:29:03 --> 404 Page Not Found --> music
ERROR - 2014-12-26 08:29:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 08:29:48 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 08:29:48 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 08:29:48 --> 404 Page Not Found --> img
ERROR - 2014-12-26 08:29:48 --> 404 Page Not Found --> img
ERROR - 2014-12-26 08:29:48 --> 404 Page Not Found --> music
ERROR - 2014-12-26 08:29:48 --> 404 Page Not Found --> music
ERROR - 2014-12-26 08:30:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 08:30:03 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 08:30:03 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 08:30:03 --> 404 Page Not Found --> music
ERROR - 2014-12-26 08:30:03 --> 404 Page Not Found --> img
ERROR - 2014-12-26 08:30:03 --> 404 Page Not Found --> img
ERROR - 2014-12-26 08:30:03 --> 404 Page Not Found --> music
ERROR - 2014-12-26 08:30:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 08:30:57 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 08:30:59 --> 404 Page Not Found --> music
ERROR - 2014-12-26 08:30:59 --> 404 Page Not Found --> img
ERROR - 2014-12-26 08:30:59 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 08:30:59 --> 404 Page Not Found --> img
ERROR - 2014-12-26 08:30:59 --> 404 Page Not Found --> music
ERROR - 2014-12-26 08:31:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 08:31:07 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 08:31:08 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 08:31:08 --> 404 Page Not Found --> img
ERROR - 2014-12-26 08:31:08 --> 404 Page Not Found --> img
ERROR - 2014-12-26 08:31:08 --> 404 Page Not Found --> music
ERROR - 2014-12-26 08:31:08 --> 404 Page Not Found --> music
ERROR - 2014-12-26 08:31:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 08:31:32 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 08:31:34 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 08:31:34 --> 404 Page Not Found --> img
ERROR - 2014-12-26 08:31:34 --> 404 Page Not Found --> img
ERROR - 2014-12-26 08:31:34 --> 404 Page Not Found --> music
ERROR - 2014-12-26 08:31:34 --> 404 Page Not Found --> music
ERROR - 2014-12-26 08:32:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 08:32:06 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 08:32:07 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 08:32:07 --> 404 Page Not Found --> img
ERROR - 2014-12-26 08:32:07 --> 404 Page Not Found --> img
ERROR - 2014-12-26 08:32:07 --> 404 Page Not Found --> music
ERROR - 2014-12-26 08:32:08 --> 404 Page Not Found --> music
ERROR - 2014-12-26 08:33:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 08:33:46 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 08:33:48 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 08:33:48 --> 404 Page Not Found --> music
ERROR - 2014-12-26 08:33:48 --> 404 Page Not Found --> img
ERROR - 2014-12-26 08:33:48 --> 404 Page Not Found --> img
ERROR - 2014-12-26 08:33:48 --> 404 Page Not Found --> music
ERROR - 2014-12-26 08:33:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 08:33:54 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 08:33:55 --> 404 Page Not Found --> music
ERROR - 2014-12-26 08:33:55 --> 404 Page Not Found --> img
ERROR - 2014-12-26 08:33:55 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 08:33:55 --> 404 Page Not Found --> img
ERROR - 2014-12-26 08:33:55 --> 404 Page Not Found --> music
ERROR - 2014-12-26 08:34:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 08:34:20 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 08:34:29 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 08:34:29 --> 404 Page Not Found --> music
ERROR - 2014-12-26 08:34:29 --> 404 Page Not Found --> img
ERROR - 2014-12-26 08:34:29 --> 404 Page Not Found --> img
ERROR - 2014-12-26 08:34:29 --> 404 Page Not Found --> music
ERROR - 2014-12-26 08:37:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 08:37:25 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 08:37:25 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 08:37:25 --> 404 Page Not Found --> music
ERROR - 2014-12-26 08:37:25 --> 404 Page Not Found --> img
ERROR - 2014-12-26 08:37:25 --> 404 Page Not Found --> img
ERROR - 2014-12-26 08:37:25 --> 404 Page Not Found --> music
ERROR - 2014-12-26 08:37:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 08:37:37 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 08:37:37 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 08:37:37 --> 404 Page Not Found --> img
ERROR - 2014-12-26 08:37:37 --> 404 Page Not Found --> music
ERROR - 2014-12-26 08:37:37 --> 404 Page Not Found --> img
ERROR - 2014-12-26 08:37:37 --> 404 Page Not Found --> music
ERROR - 2014-12-26 08:37:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 08:37:55 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 08:37:56 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 08:37:56 --> 404 Page Not Found --> img
ERROR - 2014-12-26 08:37:56 --> 404 Page Not Found --> music
ERROR - 2014-12-26 08:37:56 --> 404 Page Not Found --> img
ERROR - 2014-12-26 08:37:56 --> 404 Page Not Found --> music
ERROR - 2014-12-26 08:37:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 08:37:59 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 08:37:59 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 08:37:59 --> 404 Page Not Found --> img
ERROR - 2014-12-26 08:37:59 --> 404 Page Not Found --> music
ERROR - 2014-12-26 08:37:59 --> 404 Page Not Found --> img
ERROR - 2014-12-26 08:37:59 --> 404 Page Not Found --> music
ERROR - 2014-12-26 08:38:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 08:38:11 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 08:38:12 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 08:38:12 --> 404 Page Not Found --> img
ERROR - 2014-12-26 08:38:12 --> 404 Page Not Found --> img
ERROR - 2014-12-26 08:38:12 --> 404 Page Not Found --> music
ERROR - 2014-12-26 08:38:12 --> 404 Page Not Found --> music
ERROR - 2014-12-26 08:38:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 08:38:15 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 08:38:16 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 08:38:16 --> 404 Page Not Found --> img
ERROR - 2014-12-26 08:38:16 --> 404 Page Not Found --> music
ERROR - 2014-12-26 08:38:16 --> 404 Page Not Found --> img
ERROR - 2014-12-26 08:38:16 --> 404 Page Not Found --> music
ERROR - 2014-12-26 08:39:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 08:39:34 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 08:39:34 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 08:39:34 --> 404 Page Not Found --> img
ERROR - 2014-12-26 08:39:34 --> 404 Page Not Found --> img
ERROR - 2014-12-26 08:39:34 --> 404 Page Not Found --> music
ERROR - 2014-12-26 08:39:34 --> 404 Page Not Found --> music
ERROR - 2014-12-26 08:40:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 08:40:09 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 08:40:11 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 08:40:11 --> 404 Page Not Found --> img
ERROR - 2014-12-26 08:40:11 --> 404 Page Not Found --> music
ERROR - 2014-12-26 08:40:11 --> 404 Page Not Found --> img
ERROR - 2014-12-26 08:40:11 --> 404 Page Not Found --> music
ERROR - 2014-12-26 08:40:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 08:40:29 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 08:40:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 08:40:42 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 08:40:43 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 08:40:43 --> 404 Page Not Found --> img
ERROR - 2014-12-26 08:40:43 --> 404 Page Not Found --> img
ERROR - 2014-12-26 08:40:43 --> 404 Page Not Found --> music
ERROR - 2014-12-26 08:40:43 --> 404 Page Not Found --> music
ERROR - 2014-12-26 08:40:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 08:40:48 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 08:40:49 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 08:40:49 --> 404 Page Not Found --> img
ERROR - 2014-12-26 08:40:49 --> 404 Page Not Found --> img
ERROR - 2014-12-26 08:40:49 --> 404 Page Not Found --> music
ERROR - 2014-12-26 08:40:49 --> 404 Page Not Found --> music
ERROR - 2014-12-26 08:41:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 08:41:34 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 08:41:34 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 08:41:34 --> 404 Page Not Found --> img
ERROR - 2014-12-26 08:41:34 --> 404 Page Not Found --> img
ERROR - 2014-12-26 08:41:34 --> 404 Page Not Found --> music
ERROR - 2014-12-26 08:41:34 --> 404 Page Not Found --> music
ERROR - 2014-12-26 08:41:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 08:41:40 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 08:41:40 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 08:41:40 --> 404 Page Not Found --> img
ERROR - 2014-12-26 08:41:40 --> 404 Page Not Found --> img
ERROR - 2014-12-26 08:41:40 --> 404 Page Not Found --> music
ERROR - 2014-12-26 08:41:40 --> 404 Page Not Found --> music
ERROR - 2014-12-26 08:41:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 08:41:48 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 08:41:48 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 08:41:48 --> 404 Page Not Found --> img
ERROR - 2014-12-26 08:41:48 --> 404 Page Not Found --> img
ERROR - 2014-12-26 08:41:48 --> 404 Page Not Found --> music
ERROR - 2014-12-26 08:41:48 --> 404 Page Not Found --> music
ERROR - 2014-12-26 08:42:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 08:42:15 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 08:42:15 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 08:42:15 --> 404 Page Not Found --> img
ERROR - 2014-12-26 08:42:15 --> 404 Page Not Found --> img
ERROR - 2014-12-26 08:42:15 --> 404 Page Not Found --> music
ERROR - 2014-12-26 08:42:16 --> 404 Page Not Found --> music
ERROR - 2014-12-26 08:42:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 08:42:25 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 08:42:25 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 08:42:25 --> 404 Page Not Found --> img
ERROR - 2014-12-26 08:42:25 --> 404 Page Not Found --> music
ERROR - 2014-12-26 08:42:25 --> 404 Page Not Found --> img
ERROR - 2014-12-26 08:42:25 --> 404 Page Not Found --> music
ERROR - 2014-12-26 08:42:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 08:42:30 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 08:42:30 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 08:42:30 --> 404 Page Not Found --> img
ERROR - 2014-12-26 08:42:30 --> 404 Page Not Found --> music
ERROR - 2014-12-26 08:42:30 --> 404 Page Not Found --> img
ERROR - 2014-12-26 08:42:30 --> 404 Page Not Found --> music
ERROR - 2014-12-26 08:42:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 08:42:34 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 08:42:34 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 08:42:34 --> 404 Page Not Found --> music
ERROR - 2014-12-26 08:42:34 --> 404 Page Not Found --> img
ERROR - 2014-12-26 08:42:34 --> 404 Page Not Found --> img
ERROR - 2014-12-26 08:42:34 --> 404 Page Not Found --> music
ERROR - 2014-12-26 08:42:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 08:42:38 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 08:42:38 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 08:42:38 --> 404 Page Not Found --> img
ERROR - 2014-12-26 08:42:38 --> 404 Page Not Found --> music
ERROR - 2014-12-26 08:42:38 --> 404 Page Not Found --> img
ERROR - 2014-12-26 08:42:38 --> 404 Page Not Found --> music
ERROR - 2014-12-26 08:42:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 08:42:54 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 08:42:54 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 08:42:54 --> 404 Page Not Found --> img
ERROR - 2014-12-26 08:42:54 --> 404 Page Not Found --> img
ERROR - 2014-12-26 08:42:54 --> 404 Page Not Found --> music
ERROR - 2014-12-26 08:42:54 --> 404 Page Not Found --> music
ERROR - 2014-12-26 08:43:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 08:43:05 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 08:43:05 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 08:43:05 --> 404 Page Not Found --> img
ERROR - 2014-12-26 08:43:05 --> 404 Page Not Found --> img
ERROR - 2014-12-26 08:43:05 --> 404 Page Not Found --> music
ERROR - 2014-12-26 08:43:05 --> 404 Page Not Found --> music
ERROR - 2014-12-26 08:43:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 08:43:17 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 08:43:17 --> 404 Page Not Found --> img
ERROR - 2014-12-26 08:43:17 --> 404 Page Not Found --> music
ERROR - 2014-12-26 08:43:17 --> 404 Page Not Found --> img
ERROR - 2014-12-26 08:43:17 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 08:43:17 --> 404 Page Not Found --> music
ERROR - 2014-12-26 08:43:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 08:43:24 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 08:43:24 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 08:43:24 --> 404 Page Not Found --> img
ERROR - 2014-12-26 08:43:24 --> 404 Page Not Found --> img
ERROR - 2014-12-26 08:43:24 --> 404 Page Not Found --> music
ERROR - 2014-12-26 08:43:24 --> 404 Page Not Found --> music
ERROR - 2014-12-26 08:43:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 08:43:29 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 08:43:29 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 08:43:29 --> 404 Page Not Found --> img
ERROR - 2014-12-26 08:43:29 --> 404 Page Not Found --> img
ERROR - 2014-12-26 08:43:29 --> 404 Page Not Found --> music
ERROR - 2014-12-26 08:43:29 --> 404 Page Not Found --> music
ERROR - 2014-12-26 08:43:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 08:43:35 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 08:43:36 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 08:43:36 --> 404 Page Not Found --> music
ERROR - 2014-12-26 08:43:36 --> 404 Page Not Found --> img
ERROR - 2014-12-26 08:43:36 --> 404 Page Not Found --> img
ERROR - 2014-12-26 08:43:36 --> 404 Page Not Found --> music
ERROR - 2014-12-26 08:43:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 08:43:40 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 08:43:40 --> 404 Page Not Found --> img
ERROR - 2014-12-26 08:43:40 --> 404 Page Not Found --> music
ERROR - 2014-12-26 08:43:40 --> 404 Page Not Found --> img
ERROR - 2014-12-26 08:43:40 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 08:43:40 --> 404 Page Not Found --> music
ERROR - 2014-12-26 08:43:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 08:43:54 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 08:43:54 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 08:43:54 --> 404 Page Not Found --> img
ERROR - 2014-12-26 08:43:54 --> 404 Page Not Found --> img
ERROR - 2014-12-26 08:43:54 --> 404 Page Not Found --> music
ERROR - 2014-12-26 08:43:54 --> 404 Page Not Found --> music
ERROR - 2014-12-26 08:43:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 08:43:59 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 08:43:59 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 08:43:59 --> 404 Page Not Found --> img
ERROR - 2014-12-26 08:43:59 --> 404 Page Not Found --> img
ERROR - 2014-12-26 08:43:59 --> 404 Page Not Found --> music
ERROR - 2014-12-26 08:43:59 --> 404 Page Not Found --> music
ERROR - 2014-12-26 08:44:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 08:44:13 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 08:44:13 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 08:44:13 --> 404 Page Not Found --> music
ERROR - 2014-12-26 08:44:13 --> 404 Page Not Found --> img
ERROR - 2014-12-26 08:44:13 --> 404 Page Not Found --> img
ERROR - 2014-12-26 08:44:13 --> 404 Page Not Found --> music
ERROR - 2014-12-26 08:44:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 08:44:21 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 08:44:21 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 08:44:21 --> 404 Page Not Found --> img
ERROR - 2014-12-26 08:44:21 --> 404 Page Not Found --> music
ERROR - 2014-12-26 08:44:21 --> 404 Page Not Found --> img
ERROR - 2014-12-26 08:44:21 --> 404 Page Not Found --> music
ERROR - 2014-12-26 08:44:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 08:44:32 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 08:44:32 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 08:44:32 --> 404 Page Not Found --> music
ERROR - 2014-12-26 08:44:32 --> 404 Page Not Found --> img
ERROR - 2014-12-26 08:44:32 --> 404 Page Not Found --> img
ERROR - 2014-12-26 08:44:32 --> 404 Page Not Found --> music
ERROR - 2014-12-26 08:44:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 08:44:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 08:44:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 08:44:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 08:44:55 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 08:44:55 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 08:44:55 --> 404 Page Not Found --> img
ERROR - 2014-12-26 08:44:55 --> 404 Page Not Found --> img
ERROR - 2014-12-26 08:44:55 --> 404 Page Not Found --> music
ERROR - 2014-12-26 08:44:55 --> 404 Page Not Found --> music
ERROR - 2014-12-26 08:45:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 08:45:05 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 08:45:05 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 08:45:05 --> 404 Page Not Found --> img
ERROR - 2014-12-26 08:45:05 --> 404 Page Not Found --> music
ERROR - 2014-12-26 08:45:05 --> 404 Page Not Found --> img
ERROR - 2014-12-26 08:45:05 --> 404 Page Not Found --> music
ERROR - 2014-12-26 08:45:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 08:45:51 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 08:45:51 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 08:46:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 08:46:08 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 08:46:09 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 08:46:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 08:46:55 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 08:46:55 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 08:47:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 08:47:39 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 08:47:39 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 08:48:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 08:48:05 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 08:48:05 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 08:48:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 08:48:18 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 08:48:18 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 08:48:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 08:48:40 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 08:48:40 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 08:48:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 08:48:59 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 08:48:59 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 08:49:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 08:49:07 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 08:49:07 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 08:50:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 08:50:08 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 08:50:08 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 08:50:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 08:50:21 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 08:50:21 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 08:57:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 08:57:27 --> Severity: Notice  --> Undefined property: Gallery::$page_m C:\wamp\www\Esgotado\application\controllers\gallery.php 13
ERROR - 2014-12-26 08:57:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 08:57:41 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 08:57:41 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 08:58:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 08:58:44 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 08:58:45 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 09:02:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 09:02:05 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 09:02:05 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 09:03:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 09:03:42 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 09:03:42 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 09:04:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 09:04:47 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 09:04:47 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 09:05:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 09:05:43 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 09:05:44 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 09:06:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 09:06:21 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 09:06:21 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 09:06:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 09:06:40 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 09:06:40 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 09:07:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 09:07:29 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 09:07:29 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 09:07:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 09:07:48 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 09:07:48 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 09:08:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 09:08:19 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 09:08:19 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 09:08:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 09:08:32 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 09:08:33 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 09:08:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 09:08:41 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 09:08:41 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 09:09:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 09:09:42 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 09:09:42 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 09:11:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 09:11:22 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 09:11:23 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 09:11:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 09:11:42 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 09:11:42 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 09:12:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 09:12:00 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 09:12:00 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 09:12:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 09:12:08 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 09:12:08 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 09:12:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 09:12:12 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 09:12:12 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 09:12:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 09:12:19 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 09:12:19 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 09:40:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 09:40:40 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 09:40:40 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 09:40:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 09:40:53 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 09:40:53 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 09:48:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 09:48:40 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 09:48:40 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 09:50:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 09:50:38 --> Severity: Notice  --> Undefined property: stdClass::$child C:\wamp\www\Esgotado\application\models\gallery_m.php 17
ERROR - 2014-12-26 09:50:38 --> Severity: Notice  --> Undefined property: stdClass::$child C:\wamp\www\Esgotado\application\models\gallery_m.php 17
ERROR - 2014-12-26 09:50:38 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\Esgotado\application\models\gallery_m.php 20
ERROR - 2014-12-26 09:50:39 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 09:50:39 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 09:50:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 09:50:53 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 09:50:53 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 09:51:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-26 09:51:08 --> 404 Page Not Found --> flash
ERROR - 2014-12-26 09:51:08 --> 404 Page Not Found --> flash
