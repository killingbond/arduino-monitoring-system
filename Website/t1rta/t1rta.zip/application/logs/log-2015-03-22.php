<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-03-22 03:53:29 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-22 03:53:30 --> 404 Page Not Found --> template
ERROR - 2015-03-22 03:53:37 --> 404 Page Not Found --> template
ERROR - 2015-03-22 03:53:42 --> 404 Page Not Found --> template
ERROR - 2015-03-22 03:53:43 --> 404 Page Not Found --> template
ERROR - 2015-03-22 03:53:46 --> 404 Page Not Found --> template
ERROR - 2015-03-22 03:53:46 --> 404 Page Not Found --> my_js
ERROR - 2015-03-22 03:54:09 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2015-03-22 03:54:09 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2015-03-22 03:54:09 --> 404 Page Not Found --> template
ERROR - 2015-03-22 03:54:13 --> 404 Page Not Found --> template
ERROR - 2015-03-22 03:55:27 --> Severity: Notice  --> Undefined variable: is_register C:\wamp\www\Esgotado\application\views\forget_password.php 91
ERROR - 2015-03-22 03:55:28 --> 404 Page Not Found --> template
ERROR - 2015-03-22 03:59:02 --> Severity: Notice  --> Undefined variable: is_register C:\wamp\www\Esgotado\application\views\forget_password.php 91
ERROR - 2015-03-22 03:59:02 --> 404 Page Not Found --> template
ERROR - 2015-03-22 03:59:55 --> 404 Page Not Found --> template
ERROR - 2015-03-22 04:01:00 --> 404 Page Not Found --> template
ERROR - 2015-03-22 04:01:03 --> Severity: Notice  --> Undefined variable: is_register C:\wamp\www\Esgotado\application\views\forget_password.php 91
ERROR - 2015-03-22 04:01:03 --> 404 Page Not Found --> template
ERROR - 2015-03-22 04:01:32 --> Could not find the language line "l_send_password"
ERROR - 2015-03-22 04:01:32 --> Could not find the language line "l_back_to_login"
ERROR - 2015-03-22 04:01:32 --> Severity: Notice  --> Undefined variable: is_register C:\wamp\www\Esgotado\application\views\forget_password.php 91
ERROR - 2015-03-22 04:01:32 --> 404 Page Not Found --> template
ERROR - 2015-03-22 04:01:47 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-22 04:01:47 --> Severity: Notice  --> Undefined variable: is_register C:\wamp\www\Esgotado\application\views\forget_password.php 91
ERROR - 2015-03-22 04:01:47 --> 404 Page Not Found --> template
ERROR - 2015-03-22 04:03:43 --> Severity: Notice  --> Undefined variable: is_register C:\wamp\www\Esgotado\application\views\forget_password.php 91
ERROR - 2015-03-22 04:03:44 --> 404 Page Not Found --> template
ERROR - 2015-03-22 04:03:46 --> Severity: Warning  --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\wamp\www\Esgotado\system\libraries\Email.php 1553
ERROR - 2015-03-22 04:03:46 --> Severity: Notice  --> Undefined variable: is_register C:\wamp\www\Esgotado\application\views\forget_password.php 91
ERROR - 2015-03-22 04:03:46 --> 404 Page Not Found --> template
ERROR - 2015-03-22 04:03:48 --> Severity: Warning  --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\wamp\www\Esgotado\system\libraries\Email.php 1553
ERROR - 2015-03-22 04:03:48 --> Severity: Notice  --> Undefined variable: is_register C:\wamp\www\Esgotado\application\views\forget_password.php 91
ERROR - 2015-03-22 04:03:49 --> 404 Page Not Found --> template
ERROR - 2015-03-22 04:03:52 --> Severity: Warning  --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\wamp\www\Esgotado\system\libraries\Email.php 1553
ERROR - 2015-03-22 04:03:52 --> Severity: Notice  --> Undefined variable: is_register C:\wamp\www\Esgotado\application\views\forget_password.php 91
ERROR - 2015-03-22 04:03:52 --> 404 Page Not Found --> template
ERROR - 2015-03-22 04:04:01 --> 404 Page Not Found --> template
ERROR - 2015-03-22 04:04:03 --> Could not find the language line "l_failed_login"
ERROR - 2015-03-22 04:04:03 --> 404 Page Not Found --> template
ERROR - 2015-03-22 04:04:30 --> 404 Page Not Found --> template
ERROR - 2015-03-22 04:05:03 --> 404 Page Not Found --> template
ERROR - 2015-03-22 04:09:43 --> 404 Page Not Found --> template
ERROR - 2015-03-22 04:09:46 --> 404 Page Not Found --> template
ERROR - 2015-03-22 04:10:07 --> 404 Page Not Found --> template
ERROR - 2015-03-22 04:10:26 --> 404 Page Not Found --> template
ERROR - 2015-03-22 04:10:30 --> 404 Page Not Found --> template
ERROR - 2015-03-22 04:10:31 --> 404 Page Not Found --> template
ERROR - 2015-03-22 04:11:11 --> 404 Page Not Found --> template
ERROR - 2015-03-22 04:11:49 --> 404 Page Not Found --> template
ERROR - 2015-03-22 04:12:50 --> 404 Page Not Found --> template
ERROR - 2015-03-22 04:14:16 --> Severity: Warning  --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\wamp\www\Esgotado\system\libraries\Email.php 1553
ERROR - 2015-03-22 04:14:17 --> 404 Page Not Found --> template
ERROR - 2015-03-22 04:14:24 --> 404 Page Not Found --> template
ERROR - 2015-03-22 04:14:25 --> 404 Page Not Found --> template
ERROR - 2015-03-22 04:14:51 --> 404 Page Not Found --> template
ERROR - 2015-03-22 04:17:21 --> 404 Page Not Found --> template
ERROR - 2015-03-22 04:20:05 --> 404 Page Not Found --> template
ERROR - 2015-03-22 04:22:13 --> 404 Page Not Found --> template
ERROR - 2015-03-22 04:22:37 --> Severity: Warning  --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\wamp\www\Esgotado\system\libraries\Email.php 1553
ERROR - 2015-03-22 04:22:37 --> 404 Page Not Found --> template
ERROR - 2015-03-22 04:22:42 --> 404 Page Not Found --> template
ERROR - 2015-03-22 04:22:44 --> 404 Page Not Found --> template
ERROR - 2015-03-22 04:23:13 --> 404 Page Not Found --> template
ERROR - 2015-03-22 04:23:40 --> 404 Page Not Found --> template
ERROR - 2015-03-22 04:23:59 --> 404 Page Not Found --> template
ERROR - 2015-03-22 04:24:09 --> 404 Page Not Found --> template
ERROR - 2015-03-22 04:24:42 --> 404 Page Not Found --> template
ERROR - 2015-03-22 04:24:51 --> Severity: Warning  --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\wamp\www\Esgotado\system\libraries\Email.php 1553
ERROR - 2015-03-22 04:24:52 --> 404 Page Not Found --> template
ERROR - 2015-03-22 04:24:56 --> 404 Page Not Found --> template
ERROR - 2015-03-22 04:25:21 --> 404 Page Not Found --> template
ERROR - 2015-03-22 04:25:23 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2015-03-22 04:25:23 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2015-03-22 04:25:23 --> 404 Page Not Found --> template
ERROR - 2015-03-22 04:25:32 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2015-03-22 04:25:32 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2015-03-22 04:25:32 --> 404 Page Not Found --> template
ERROR - 2015-03-22 04:26:01 --> 404 Page Not Found --> template
ERROR - 2015-03-22 04:26:06 --> 404 Page Not Found --> template
ERROR - 2015-03-22 04:26:10 --> 404 Page Not Found --> template
ERROR - 2015-03-22 04:26:15 --> 404 Page Not Found --> template
ERROR - 2015-03-22 04:26:17 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2015-03-22 04:26:17 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2015-03-22 04:26:17 --> 404 Page Not Found --> template
ERROR - 2015-03-22 04:26:24 --> 404 Page Not Found --> template
ERROR - 2015-03-22 04:26:28 --> 404 Page Not Found --> template
ERROR - 2015-03-22 04:26:28 --> 404 Page Not Found --> my_js
ERROR - 2015-03-22 04:26:38 --> 404 Page Not Found --> template
ERROR - 2015-03-22 04:26:50 --> 404 Page Not Found --> template
ERROR - 2015-03-22 04:26:52 --> 404 Page Not Found --> template
ERROR - 2015-03-22 04:26:57 --> 404 Page Not Found --> template
ERROR - 2015-03-22 04:26:59 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2015-03-22 04:26:59 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2015-03-22 04:26:59 --> 404 Page Not Found --> template
ERROR - 2015-03-22 04:27:41 --> 404 Page Not Found --> template
ERROR - 2015-03-22 04:55:13 --> 404 Page Not Found --> Waydee
ERROR - 2015-03-22 05:32:05 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-22 05:32:05 --> 404 Page Not Found --> template
ERROR - 2015-03-22 05:32:27 --> 404 Page Not Found --> template
ERROR - 2015-03-22 05:32:30 --> 404 Page Not Found --> template
ERROR - 2015-03-22 05:33:23 --> 404 Page Not Found --> template
ERROR - 2015-03-22 09:00:37 --> 404 Page Not Found --> template
ERROR - 2015-03-22 14:25:07 --> 404 Page Not Found --> template
ERROR - 2015-03-22 14:54:21 --> 404 Page Not Found --> template
ERROR - 2015-03-22 15:23:11 --> 404 Page Not Found --> template
ERROR - 2015-03-22 15:23:13 --> 404 Page Not Found --> template
ERROR - 2015-03-22 15:23:28 --> Severity: Notice  --> Undefined variable: breadcrumb C:\wamp\www\Esgotado\application\views\cart.php 6
ERROR - 2015-03-22 15:23:28 --> 404 Page Not Found --> template
ERROR - 2015-03-22 15:23:32 --> 404 Page Not Found --> template
ERROR - 2015-03-22 15:23:43 --> 404 Page Not Found --> template
ERROR - 2015-03-22 15:23:44 --> 404 Page Not Found --> template
ERROR - 2015-03-22 15:23:48 --> 404 Page Not Found --> template
ERROR - 2015-03-22 15:25:35 --> 404 Page Not Found --> template
ERROR - 2015-03-22 15:25:40 --> 404 Page Not Found --> template
ERROR - 2015-03-22 15:25:55 --> 404 Page Not Found --> template
ERROR - 2015-03-22 15:26:31 --> 404 Page Not Found --> template
ERROR - 2015-03-22 15:26:33 --> 404 Page Not Found --> template
ERROR - 2015-03-22 15:26:36 --> 404 Page Not Found --> template
ERROR - 2015-03-22 15:26:38 --> 404 Page Not Found --> template
ERROR - 2015-03-22 15:26:38 --> 404 Page Not Found --> my_js
ERROR - 2015-03-22 15:26:45 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2015-03-22 15:26:45 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2015-03-22 15:26:46 --> 404 Page Not Found --> template
ERROR - 2015-03-22 15:26:48 --> 404 Page Not Found --> template
ERROR - 2015-03-22 15:26:49 --> 404 Page Not Found --> template
ERROR - 2015-03-22 15:26:49 --> 404 Page Not Found --> my_js
ERROR - 2015-03-22 15:26:51 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2015-03-22 15:26:51 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2015-03-22 15:26:51 --> 404 Page Not Found --> template
ERROR - 2015-03-22 15:26:56 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2015-03-22 15:26:56 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2015-03-22 15:26:56 --> 404 Page Not Found --> template
ERROR - 2015-03-22 15:27:01 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2015-03-22 15:27:01 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2015-03-22 15:27:01 --> 404 Page Not Found --> template
ERROR - 2015-03-22 15:27:04 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2015-03-22 15:27:04 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2015-03-22 15:27:04 --> 404 Page Not Found --> template
ERROR - 2015-03-22 15:27:07 --> 404 Page Not Found --> template
ERROR - 2015-03-22 15:27:09 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2015-03-22 15:27:09 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2015-03-22 15:27:09 --> 404 Page Not Found --> template
ERROR - 2015-03-22 15:27:16 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2015-03-22 15:27:16 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2015-03-22 15:27:16 --> 404 Page Not Found --> template
ERROR - 2015-03-22 15:27:21 --> 404 Page Not Found --> template
ERROR - 2015-03-22 15:27:23 --> 404 Page Not Found --> template
ERROR - 2015-03-22 15:27:23 --> 404 Page Not Found --> my_js
ERROR - 2015-03-22 15:27:27 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2015-03-22 15:27:27 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2015-03-22 15:27:27 --> 404 Page Not Found --> template
ERROR - 2015-03-22 15:27:30 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2015-03-22 15:27:30 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2015-03-22 15:27:30 --> 404 Page Not Found --> template
ERROR - 2015-03-22 15:27:33 --> 404 Page Not Found --> template
ERROR - 2015-03-22 15:27:39 --> 404 Page Not Found --> template
ERROR - 2015-03-22 15:27:47 --> 404 Page Not Found --> template
ERROR - 2015-03-22 15:28:33 --> 404 Page Not Found --> template
ERROR - 2015-03-22 15:28:42 --> 404 Page Not Found --> template
ERROR - 2015-03-22 15:28:49 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2015-03-22 15:28:49 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2015-03-22 15:28:49 --> 404 Page Not Found --> template
ERROR - 2015-03-22 15:28:55 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2015-03-22 15:28:55 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2015-03-22 15:28:55 --> 404 Page Not Found --> template
ERROR - 2015-03-22 15:28:59 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2015-03-22 15:28:59 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2015-03-22 15:28:59 --> 404 Page Not Found --> template
ERROR - 2015-03-22 15:29:01 --> 404 Page Not Found --> template
ERROR - 2015-03-22 15:29:15 --> 404 Page Not Found --> template
ERROR - 2015-03-22 15:29:33 --> Severity: Warning  --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\wamp\www\Esgotado\system\libraries\Email.php 1553
ERROR - 2015-03-22 15:29:33 --> 404 Page Not Found --> template
ERROR - 2015-03-22 16:18:47 --> 404 Page Not Found --> template
ERROR - 2015-03-22 16:21:49 --> 404 Page Not Found --> template
