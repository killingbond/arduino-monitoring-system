<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2014-10-26 06:39:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:41:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:41:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:43:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:43:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:44:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:44:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:44:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:44:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:44:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:44:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:44:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:44:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:44:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:45:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:45:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:45:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:45:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:45:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:45:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:45:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:45:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:45:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:45:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:45:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:45:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:45:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:45:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:45:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:45:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:45:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:45:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:45:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:45:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:45:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:45:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:45:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:45:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:45:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:45:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:45:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:45:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:45:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:45:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:45:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:45:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:46:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:46:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:46:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:46:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:46:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:46:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:46:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:46:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:46:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:46:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:46:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:46:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:46:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:46:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:46:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:46:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:46:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:46:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:46:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:46:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:46:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:46:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:46:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:46:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:46:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:46:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:46:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:46:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:46:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:46:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:46:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:46:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:46:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:46:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:46:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:46:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:46:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:46:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:46:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:46:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:46:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:46:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:46:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:46:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:46:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:46:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:46:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:46:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:46:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:46:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:46:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:46:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:46:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:46:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:46:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:46:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:46:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:46:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:46:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:46:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:47:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:47:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:47:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:47:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:47:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:47:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:47:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:47:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:47:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:47:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:47:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:47:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:47:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:47:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:47:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:47:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:47:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:47:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:47:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:47:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:47:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:47:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:47:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:47:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:47:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:47:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:47:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:47:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:47:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:47:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:47:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:47:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:47:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:47:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:47:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:47:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:47:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:47:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:47:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:47:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:47:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:47:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:47:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:47:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:47:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:47:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:47:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:47:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:47:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:47:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:47:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:47:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:47:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:47:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:47:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:47:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:47:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:47:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:47:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:47:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:48:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:48:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:48:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:48:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:48:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:48:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:48:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:48:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:48:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:48:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:48:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:48:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:48:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:48:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:48:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:48:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:48:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:48:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:48:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:48:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:48:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:48:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:48:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:48:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:48:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:48:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:48:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:48:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:50:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:50:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:50:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:51:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:52:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:53:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:53:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:54:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:55:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:55:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:55:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:56:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:56:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:57:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:57:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:58:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:58:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:58:39 --> 404 Page Not Found --> template
ERROR - 2014-10-26 06:58:45 --> 404 Page Not Found --> template
ERROR - 2014-10-26 06:58:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:59:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 06:59:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 07:00:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 07:00:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 07:00:43 --> 404 Page Not Found --> my_js
ERROR - 2014-10-26 07:02:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 07:02:09 --> 404 Page Not Found --> my_js
ERROR - 2014-10-26 07:02:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 07:02:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 07:02:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 07:03:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 07:03:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 07:03:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 07:03:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 07:03:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 07:03:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 07:03:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 07:03:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 07:04:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 07:04:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 07:04:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 07:04:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 07:04:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 07:04:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 07:04:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 07:05:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 07:06:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 07:07:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 07:07:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 07:07:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 07:07:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 07:07:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 07:08:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 07:08:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 07:08:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 07:08:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 07:08:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 07:08:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 07:08:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 07:08:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 07:08:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 07:08:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 07:08:57 --> Severity: Notice  --> Undefined variable: coming_soon C:\wamp\www\Esgotado\application\views\block\sidebar.php 17
ERROR - 2014-10-26 07:09:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 07:09:49 --> Severity: Notice  --> Undefined variable: coming_soon C:\wamp\www\Esgotado\application\views\block\sidebar.php 17
ERROR - 2014-10-26 07:10:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 07:10:44 --> Severity: Notice  --> Undefined variable: coming_soon C:\wamp\www\Esgotado\application\views\block\sidebar.php 17
ERROR - 2014-10-26 07:11:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 07:11:25 --> Severity: Notice  --> Undefined variable: coming_soon C:\wamp\www\Esgotado\application\views\block\sidebar.php 17
ERROR - 2014-10-26 07:13:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 07:13:37 --> Severity: Notice  --> Undefined variable: coming_soon C:\wamp\www\Esgotado\application\views\block\sidebar.php 17
ERROR - 2014-10-26 07:13:37 --> Severity: Notice  --> Undefined variable: aaa C:\wamp\www\Esgotado\application\views\block\sidebar.php 20
ERROR - 2014-10-26 07:14:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 07:15:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 07:18:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 07:18:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 07:18:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 07:19:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 07:20:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 07:20:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 07:20:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 07:21:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 07:21:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 07:21:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 07:22:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 07:22:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 07:22:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 07:22:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 07:23:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 07:23:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 07:24:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 07:24:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 07:25:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 07:25:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 07:27:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 07:27:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 07:27:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 275
ERROR - 2014-10-26 07:27:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 284
ERROR - 2014-10-26 07:27:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 292
ERROR - 2014-10-26 07:27:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 304
ERROR - 2014-10-26 07:27:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 312
ERROR - 2014-10-26 07:27:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 320
ERROR - 2014-10-26 07:27:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 322
ERROR - 2014-10-26 07:27:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 323
ERROR - 2014-10-26 07:27:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 275
ERROR - 2014-10-26 07:27:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 284
ERROR - 2014-10-26 07:27:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 292
ERROR - 2014-10-26 07:27:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 304
ERROR - 2014-10-26 07:27:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 312
ERROR - 2014-10-26 07:27:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 320
ERROR - 2014-10-26 07:27:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 322
ERROR - 2014-10-26 07:27:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 323
ERROR - 2014-10-26 07:27:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 275
ERROR - 2014-10-26 07:27:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 284
ERROR - 2014-10-26 07:27:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 292
ERROR - 2014-10-26 07:27:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 304
ERROR - 2014-10-26 07:27:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 312
ERROR - 2014-10-26 07:27:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 320
ERROR - 2014-10-26 07:27:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 322
ERROR - 2014-10-26 07:27:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 323
ERROR - 2014-10-26 07:27:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 275
ERROR - 2014-10-26 07:27:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 284
ERROR - 2014-10-26 07:27:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 292
ERROR - 2014-10-26 07:27:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 304
ERROR - 2014-10-26 07:27:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 312
ERROR - 2014-10-26 07:27:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 320
ERROR - 2014-10-26 07:27:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 322
ERROR - 2014-10-26 07:27:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 323
ERROR - 2014-10-26 07:27:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 275
ERROR - 2014-10-26 07:27:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 284
ERROR - 2014-10-26 07:27:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 292
ERROR - 2014-10-26 07:27:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 304
ERROR - 2014-10-26 07:27:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 312
ERROR - 2014-10-26 07:27:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 320
ERROR - 2014-10-26 07:27:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 322
ERROR - 2014-10-26 07:27:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 323
ERROR - 2014-10-26 07:27:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 275
ERROR - 2014-10-26 07:27:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 284
ERROR - 2014-10-26 07:27:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 292
ERROR - 2014-10-26 07:27:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 304
ERROR - 2014-10-26 07:27:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 312
ERROR - 2014-10-26 07:27:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 320
ERROR - 2014-10-26 07:27:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 322
ERROR - 2014-10-26 07:27:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 323
ERROR - 2014-10-26 07:27:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 275
ERROR - 2014-10-26 07:27:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 284
ERROR - 2014-10-26 07:27:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 292
ERROR - 2014-10-26 07:27:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 304
ERROR - 2014-10-26 07:27:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 312
ERROR - 2014-10-26 07:27:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 320
ERROR - 2014-10-26 07:27:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 322
ERROR - 2014-10-26 07:27:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 323
ERROR - 2014-10-26 07:27:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 275
ERROR - 2014-10-26 07:27:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 284
ERROR - 2014-10-26 07:27:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 292
ERROR - 2014-10-26 07:27:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 304
ERROR - 2014-10-26 07:27:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 312
ERROR - 2014-10-26 07:27:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 320
ERROR - 2014-10-26 07:27:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 322
ERROR - 2014-10-26 07:27:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 323
ERROR - 2014-10-26 07:27:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 275
ERROR - 2014-10-26 07:27:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 284
ERROR - 2014-10-26 07:27:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 292
ERROR - 2014-10-26 07:27:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 304
ERROR - 2014-10-26 07:27:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 312
ERROR - 2014-10-26 07:27:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 320
ERROR - 2014-10-26 07:27:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 322
ERROR - 2014-10-26 07:27:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 323
ERROR - 2014-10-26 07:27:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 275
ERROR - 2014-10-26 07:27:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 284
ERROR - 2014-10-26 07:27:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 292
ERROR - 2014-10-26 07:27:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 304
ERROR - 2014-10-26 07:27:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 312
ERROR - 2014-10-26 07:27:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 320
ERROR - 2014-10-26 07:27:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 322
ERROR - 2014-10-26 07:27:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 323
ERROR - 2014-10-26 07:27:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 275
ERROR - 2014-10-26 07:27:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 284
ERROR - 2014-10-26 07:27:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 292
ERROR - 2014-10-26 07:27:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 304
ERROR - 2014-10-26 07:27:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 312
ERROR - 2014-10-26 07:27:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 320
ERROR - 2014-10-26 07:27:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 322
ERROR - 2014-10-26 07:27:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 323
ERROR - 2014-10-26 07:27:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 275
ERROR - 2014-10-26 07:27:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 284
ERROR - 2014-10-26 07:27:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 292
ERROR - 2014-10-26 07:27:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 304
ERROR - 2014-10-26 07:27:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 312
ERROR - 2014-10-26 07:27:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 320
ERROR - 2014-10-26 07:27:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 322
ERROR - 2014-10-26 07:27:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 323
ERROR - 2014-10-26 07:27:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 275
ERROR - 2014-10-26 07:27:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 284
ERROR - 2014-10-26 07:27:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 292
ERROR - 2014-10-26 07:27:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 304
ERROR - 2014-10-26 07:27:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 312
ERROR - 2014-10-26 07:27:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 320
ERROR - 2014-10-26 07:27:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 322
ERROR - 2014-10-26 07:27:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 323
ERROR - 2014-10-26 07:27:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 275
ERROR - 2014-10-26 07:27:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 284
ERROR - 2014-10-26 07:27:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 292
ERROR - 2014-10-26 07:27:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 304
ERROR - 2014-10-26 07:27:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 312
ERROR - 2014-10-26 07:27:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 320
ERROR - 2014-10-26 07:27:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 322
ERROR - 2014-10-26 07:27:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 323
ERROR - 2014-10-26 07:27:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 275
ERROR - 2014-10-26 07:27:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 284
ERROR - 2014-10-26 07:27:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 292
ERROR - 2014-10-26 07:27:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 304
ERROR - 2014-10-26 07:27:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 312
ERROR - 2014-10-26 07:27:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 320
ERROR - 2014-10-26 07:27:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 322
ERROR - 2014-10-26 07:27:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 323
ERROR - 2014-10-26 07:27:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 275
ERROR - 2014-10-26 07:27:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 284
ERROR - 2014-10-26 07:27:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 292
ERROR - 2014-10-26 07:27:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 304
ERROR - 2014-10-26 07:27:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 312
ERROR - 2014-10-26 07:27:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 320
ERROR - 2014-10-26 07:27:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 322
ERROR - 2014-10-26 07:27:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 323
ERROR - 2014-10-26 07:27:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 275
ERROR - 2014-10-26 07:27:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 284
ERROR - 2014-10-26 07:27:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 292
ERROR - 2014-10-26 07:27:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 304
ERROR - 2014-10-26 07:27:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 312
ERROR - 2014-10-26 07:27:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 320
ERROR - 2014-10-26 07:27:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 322
ERROR - 2014-10-26 07:27:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 323
ERROR - 2014-10-26 07:27:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 275
ERROR - 2014-10-26 07:27:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 284
ERROR - 2014-10-26 07:27:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 292
ERROR - 2014-10-26 07:27:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 304
ERROR - 2014-10-26 07:27:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 312
ERROR - 2014-10-26 07:27:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 320
ERROR - 2014-10-26 07:27:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 322
ERROR - 2014-10-26 07:27:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 323
ERROR - 2014-10-26 07:27:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 275
ERROR - 2014-10-26 07:27:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 284
ERROR - 2014-10-26 07:27:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 292
ERROR - 2014-10-26 07:27:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 304
ERROR - 2014-10-26 07:27:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 312
ERROR - 2014-10-26 07:27:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 320
ERROR - 2014-10-26 07:27:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 322
ERROR - 2014-10-26 07:27:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 323
ERROR - 2014-10-26 07:27:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 275
ERROR - 2014-10-26 07:27:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 284
ERROR - 2014-10-26 07:27:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 292
ERROR - 2014-10-26 07:27:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 304
ERROR - 2014-10-26 07:27:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 312
ERROR - 2014-10-26 07:27:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 320
ERROR - 2014-10-26 07:27:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 322
ERROR - 2014-10-26 07:27:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 323
ERROR - 2014-10-26 07:27:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 275
ERROR - 2014-10-26 07:27:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 284
ERROR - 2014-10-26 07:27:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 292
ERROR - 2014-10-26 07:27:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 304
ERROR - 2014-10-26 07:27:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 312
ERROR - 2014-10-26 07:27:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 320
ERROR - 2014-10-26 07:27:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 322
ERROR - 2014-10-26 07:27:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 323
ERROR - 2014-10-26 07:27:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 275
ERROR - 2014-10-26 07:27:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 284
ERROR - 2014-10-26 07:27:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 292
ERROR - 2014-10-26 07:27:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 304
ERROR - 2014-10-26 07:27:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 312
ERROR - 2014-10-26 07:27:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 320
ERROR - 2014-10-26 07:27:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 322
ERROR - 2014-10-26 07:27:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 323
ERROR - 2014-10-26 07:27:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 275
ERROR - 2014-10-26 07:27:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 284
ERROR - 2014-10-26 07:27:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 292
ERROR - 2014-10-26 07:27:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 304
ERROR - 2014-10-26 07:27:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 312
ERROR - 2014-10-26 07:27:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 320
ERROR - 2014-10-26 07:27:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 322
ERROR - 2014-10-26 07:27:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 323
ERROR - 2014-10-26 07:27:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 275
ERROR - 2014-10-26 07:27:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 284
ERROR - 2014-10-26 07:27:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 292
ERROR - 2014-10-26 07:27:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 304
ERROR - 2014-10-26 07:27:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 312
ERROR - 2014-10-26 07:27:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 320
ERROR - 2014-10-26 07:27:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 322
ERROR - 2014-10-26 07:27:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 323
ERROR - 2014-10-26 07:27:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 275
ERROR - 2014-10-26 07:27:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 284
ERROR - 2014-10-26 07:27:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 292
ERROR - 2014-10-26 07:27:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 304
ERROR - 2014-10-26 07:27:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 312
ERROR - 2014-10-26 07:27:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 320
ERROR - 2014-10-26 07:27:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 322
ERROR - 2014-10-26 07:27:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 323
ERROR - 2014-10-26 07:27:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 275
ERROR - 2014-10-26 07:27:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 284
ERROR - 2014-10-26 07:27:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 292
ERROR - 2014-10-26 07:27:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 304
ERROR - 2014-10-26 07:27:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 312
ERROR - 2014-10-26 07:27:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 320
ERROR - 2014-10-26 07:27:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 322
ERROR - 2014-10-26 07:27:39 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 323
ERROR - 2014-10-26 07:27:39 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 275
ERROR - 2014-10-26 07:27:39 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 284
ERROR - 2014-10-26 07:27:39 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 292
ERROR - 2014-10-26 07:27:39 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 304
ERROR - 2014-10-26 07:27:39 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 312
ERROR - 2014-10-26 07:27:39 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 320
ERROR - 2014-10-26 07:27:39 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 322
ERROR - 2014-10-26 07:27:39 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 323
ERROR - 2014-10-26 07:27:39 --> 404 Page Not Found --> my_js
ERROR - 2014-10-26 07:27:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 07:27:48 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 275
ERROR - 2014-10-26 07:27:48 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 284
ERROR - 2014-10-26 07:27:48 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 292
ERROR - 2014-10-26 07:27:48 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 304
ERROR - 2014-10-26 07:27:48 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 312
ERROR - 2014-10-26 07:27:48 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 320
ERROR - 2014-10-26 07:27:48 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 322
ERROR - 2014-10-26 07:27:48 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 323
ERROR - 2014-10-26 07:27:48 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 275
ERROR - 2014-10-26 07:27:48 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 284
ERROR - 2014-10-26 07:27:48 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 292
ERROR - 2014-10-26 07:27:48 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 304
ERROR - 2014-10-26 07:27:48 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 312
ERROR - 2014-10-26 07:27:48 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 320
ERROR - 2014-10-26 07:27:48 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 322
ERROR - 2014-10-26 07:27:48 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 323
ERROR - 2014-10-26 07:27:48 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 275
ERROR - 2014-10-26 07:27:48 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 284
ERROR - 2014-10-26 07:27:48 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 292
ERROR - 2014-10-26 07:27:48 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 304
ERROR - 2014-10-26 07:27:48 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 312
ERROR - 2014-10-26 07:27:48 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 320
ERROR - 2014-10-26 07:27:48 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 322
ERROR - 2014-10-26 07:27:48 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 323
ERROR - 2014-10-26 07:27:48 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 275
ERROR - 2014-10-26 07:27:48 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 284
ERROR - 2014-10-26 07:27:48 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 292
ERROR - 2014-10-26 07:27:48 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 304
ERROR - 2014-10-26 07:27:48 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 312
ERROR - 2014-10-26 07:27:48 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 320
ERROR - 2014-10-26 07:27:48 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 322
ERROR - 2014-10-26 07:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 323
ERROR - 2014-10-26 07:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 275
ERROR - 2014-10-26 07:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 284
ERROR - 2014-10-26 07:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 292
ERROR - 2014-10-26 07:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 304
ERROR - 2014-10-26 07:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 312
ERROR - 2014-10-26 07:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 320
ERROR - 2014-10-26 07:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 322
ERROR - 2014-10-26 07:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 323
ERROR - 2014-10-26 07:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 275
ERROR - 2014-10-26 07:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 284
ERROR - 2014-10-26 07:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 292
ERROR - 2014-10-26 07:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 304
ERROR - 2014-10-26 07:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 312
ERROR - 2014-10-26 07:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 320
ERROR - 2014-10-26 07:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 322
ERROR - 2014-10-26 07:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 323
ERROR - 2014-10-26 07:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 275
ERROR - 2014-10-26 07:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 284
ERROR - 2014-10-26 07:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 292
ERROR - 2014-10-26 07:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 304
ERROR - 2014-10-26 07:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 312
ERROR - 2014-10-26 07:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 320
ERROR - 2014-10-26 07:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 322
ERROR - 2014-10-26 07:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 323
ERROR - 2014-10-26 07:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 275
ERROR - 2014-10-26 07:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 284
ERROR - 2014-10-26 07:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 292
ERROR - 2014-10-26 07:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 304
ERROR - 2014-10-26 07:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 312
ERROR - 2014-10-26 07:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 320
ERROR - 2014-10-26 07:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 322
ERROR - 2014-10-26 07:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 323
ERROR - 2014-10-26 07:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 275
ERROR - 2014-10-26 07:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 284
ERROR - 2014-10-26 07:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 292
ERROR - 2014-10-26 07:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 304
ERROR - 2014-10-26 07:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 312
ERROR - 2014-10-26 07:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 320
ERROR - 2014-10-26 07:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 322
ERROR - 2014-10-26 07:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 323
ERROR - 2014-10-26 07:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 275
ERROR - 2014-10-26 07:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 284
ERROR - 2014-10-26 07:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 292
ERROR - 2014-10-26 07:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 304
ERROR - 2014-10-26 07:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 312
ERROR - 2014-10-26 07:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 320
ERROR - 2014-10-26 07:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 322
ERROR - 2014-10-26 07:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 323
ERROR - 2014-10-26 07:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 275
ERROR - 2014-10-26 07:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 284
ERROR - 2014-10-26 07:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 292
ERROR - 2014-10-26 07:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 304
ERROR - 2014-10-26 07:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 312
ERROR - 2014-10-26 07:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 320
ERROR - 2014-10-26 07:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 322
ERROR - 2014-10-26 07:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 323
ERROR - 2014-10-26 07:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 275
ERROR - 2014-10-26 07:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 284
ERROR - 2014-10-26 07:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 292
ERROR - 2014-10-26 07:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 304
ERROR - 2014-10-26 07:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 312
ERROR - 2014-10-26 07:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 320
ERROR - 2014-10-26 07:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 322
ERROR - 2014-10-26 07:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 323
ERROR - 2014-10-26 07:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 275
ERROR - 2014-10-26 07:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 284
ERROR - 2014-10-26 07:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 292
ERROR - 2014-10-26 07:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 304
ERROR - 2014-10-26 07:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 312
ERROR - 2014-10-26 07:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 320
ERROR - 2014-10-26 07:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 322
ERROR - 2014-10-26 07:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 323
ERROR - 2014-10-26 07:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 275
ERROR - 2014-10-26 07:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 284
ERROR - 2014-10-26 07:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 292
ERROR - 2014-10-26 07:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 304
ERROR - 2014-10-26 07:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 312
ERROR - 2014-10-26 07:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 320
ERROR - 2014-10-26 07:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 322
ERROR - 2014-10-26 07:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 323
ERROR - 2014-10-26 07:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 275
ERROR - 2014-10-26 07:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 284
ERROR - 2014-10-26 07:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 292
ERROR - 2014-10-26 07:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 304
ERROR - 2014-10-26 07:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 312
ERROR - 2014-10-26 07:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 320
ERROR - 2014-10-26 07:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 322
ERROR - 2014-10-26 07:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 323
ERROR - 2014-10-26 07:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 275
ERROR - 2014-10-26 07:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 284
ERROR - 2014-10-26 07:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 292
ERROR - 2014-10-26 07:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 304
ERROR - 2014-10-26 07:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 312
ERROR - 2014-10-26 07:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 320
ERROR - 2014-10-26 07:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 322
ERROR - 2014-10-26 07:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 323
ERROR - 2014-10-26 07:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 275
ERROR - 2014-10-26 07:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 284
ERROR - 2014-10-26 07:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 292
ERROR - 2014-10-26 07:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 304
ERROR - 2014-10-26 07:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 312
ERROR - 2014-10-26 07:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 320
ERROR - 2014-10-26 07:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 322
ERROR - 2014-10-26 07:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 323
ERROR - 2014-10-26 07:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 275
ERROR - 2014-10-26 07:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 284
ERROR - 2014-10-26 07:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 292
ERROR - 2014-10-26 07:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 304
ERROR - 2014-10-26 07:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 312
ERROR - 2014-10-26 07:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 320
ERROR - 2014-10-26 07:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 322
ERROR - 2014-10-26 07:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 323
ERROR - 2014-10-26 07:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 275
ERROR - 2014-10-26 07:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 284
ERROR - 2014-10-26 07:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 292
ERROR - 2014-10-26 07:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 304
ERROR - 2014-10-26 07:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 312
ERROR - 2014-10-26 07:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 320
ERROR - 2014-10-26 07:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 322
ERROR - 2014-10-26 07:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 323
ERROR - 2014-10-26 07:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 275
ERROR - 2014-10-26 07:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 284
ERROR - 2014-10-26 07:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 292
ERROR - 2014-10-26 07:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 304
ERROR - 2014-10-26 07:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 312
ERROR - 2014-10-26 07:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 320
ERROR - 2014-10-26 07:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 322
ERROR - 2014-10-26 07:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 323
ERROR - 2014-10-26 07:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 275
ERROR - 2014-10-26 07:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 284
ERROR - 2014-10-26 07:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 292
ERROR - 2014-10-26 07:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 304
ERROR - 2014-10-26 07:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 312
ERROR - 2014-10-26 07:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 320
ERROR - 2014-10-26 07:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 322
ERROR - 2014-10-26 07:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 323
ERROR - 2014-10-26 07:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 275
ERROR - 2014-10-26 07:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 284
ERROR - 2014-10-26 07:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 292
ERROR - 2014-10-26 07:27:49 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 304
ERROR - 2014-10-26 07:27:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 312
ERROR - 2014-10-26 07:27:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 320
ERROR - 2014-10-26 07:27:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 322
ERROR - 2014-10-26 07:27:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 323
ERROR - 2014-10-26 07:27:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 275
ERROR - 2014-10-26 07:27:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 284
ERROR - 2014-10-26 07:27:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 292
ERROR - 2014-10-26 07:27:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 304
ERROR - 2014-10-26 07:27:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 312
ERROR - 2014-10-26 07:27:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 320
ERROR - 2014-10-26 07:27:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 322
ERROR - 2014-10-26 07:27:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 323
ERROR - 2014-10-26 07:27:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 275
ERROR - 2014-10-26 07:27:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 284
ERROR - 2014-10-26 07:27:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 292
ERROR - 2014-10-26 07:27:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 304
ERROR - 2014-10-26 07:27:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 312
ERROR - 2014-10-26 07:27:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 320
ERROR - 2014-10-26 07:27:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 322
ERROR - 2014-10-26 07:27:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 323
ERROR - 2014-10-26 07:27:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 275
ERROR - 2014-10-26 07:27:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 284
ERROR - 2014-10-26 07:27:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 292
ERROR - 2014-10-26 07:27:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 304
ERROR - 2014-10-26 07:27:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 312
ERROR - 2014-10-26 07:27:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 320
ERROR - 2014-10-26 07:27:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 322
ERROR - 2014-10-26 07:27:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 323
ERROR - 2014-10-26 07:27:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 275
ERROR - 2014-10-26 07:27:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 284
ERROR - 2014-10-26 07:27:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 292
ERROR - 2014-10-26 07:27:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 304
ERROR - 2014-10-26 07:27:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 312
ERROR - 2014-10-26 07:27:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 320
ERROR - 2014-10-26 07:27:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 322
ERROR - 2014-10-26 07:27:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 323
ERROR - 2014-10-26 07:27:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 275
ERROR - 2014-10-26 07:27:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 284
ERROR - 2014-10-26 07:27:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 292
ERROR - 2014-10-26 07:27:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 304
ERROR - 2014-10-26 07:27:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 312
ERROR - 2014-10-26 07:27:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 320
ERROR - 2014-10-26 07:27:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 322
ERROR - 2014-10-26 07:27:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\views\product_detail.php 323
ERROR - 2014-10-26 07:28:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 07:28:50 --> 404 Page Not Found --> my_js
ERROR - 2014-10-26 07:29:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 07:29:39 --> 404 Page Not Found --> my_js
ERROR - 2014-10-26 07:29:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-26 07:29:58 --> 404 Page Not Found --> my_js
