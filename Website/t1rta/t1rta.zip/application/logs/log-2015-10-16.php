<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-10-16 19:52:02 --> Severity: Warning  --> escapeshellarg() has been disabled for security reasons /home/ozantcom/public_html/wassuphaters.com/w4zzup/system/libraries/Upload.php 1066
ERROR - 2015-10-16 19:57:15 --> Severity: Warning  --> escapeshellarg() has been disabled for security reasons /home/ozantcom/public_html/wassuphaters.com/w4zzup/system/libraries/Upload.php 1066
ERROR - 2015-10-16 19:58:07 --> Severity: Warning  --> escapeshellarg() has been disabled for security reasons /home/ozantcom/public_html/wassuphaters.com/w4zzup/system/libraries/Upload.php 1066
ERROR - 2015-10-16 20:01:01 --> Severity: Warning  --> escapeshellarg() has been disabled for security reasons /home/ozantcom/public_html/wassuphaters.com/w4zzup/system/libraries/Upload.php 1066
ERROR - 2015-10-16 20:01:13 --> Severity: Warning  --> escapeshellarg() has been disabled for security reasons /home/ozantcom/public_html/wassuphaters.com/w4zzup/system/libraries/Upload.php 1066
ERROR - 2015-10-16 20:02:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/ozantcom/public_html/wassuphaters.com/w4zzup/application/models/product_m.php 27
ERROR - 2015-10-16 20:02:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/ozantcom/public_html/wassuphaters.com/w4zzup/application/models/product_m.php 27
ERROR - 2015-10-16 20:04:36 --> You did not select a file to upload.
ERROR - 2015-10-16 20:04:56 --> You did not select a file to upload.
ERROR - 2015-10-16 20:08:37 --> Severity: Warning  --> escapeshellarg() has been disabled for security reasons /home/ozantcom/public_html/wassuphaters.com/w4zzup/system/libraries/Upload.php 1066
