<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-11-21 12:01:46 --> The path to the image is not correct.
ERROR - 2015-11-21 12:01:46 --> Your server does not support the GD function required to process this type of image.
ERROR - 2015-11-21 12:01:46 --> The path to the image is not correct.
ERROR - 2015-11-21 12:01:46 --> Your server does not support the GD function required to process this type of image.
ERROR - 2015-11-21 12:09:04 --> Severity: Notice  --> Undefined property: stdClass::$description C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\slide\edit_slide.php 49
ERROR - 2015-11-21 18:22:54 --> Severity: Notice  --> Undefined property: stdClass::$pimage_id C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 145
ERROR - 2015-11-21 18:22:54 --> Severity: Notice  --> Undefined property: stdClass::$pimage_id C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 145
ERROR - 2015-11-21 18:22:54 --> Severity: Notice  --> Undefined property: stdClass::$image2 C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 168
ERROR - 2015-11-21 18:22:54 --> Severity: Notice  --> Undefined property: stdClass::$pimage_id C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 169
ERROR - 2015-11-21 18:22:54 --> Severity: Notice  --> Undefined property: stdClass::$image2 C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 168
ERROR - 2015-11-21 18:22:54 --> Severity: Notice  --> Undefined property: stdClass::$pimage_id C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 169
ERROR - 2015-11-21 18:23:31 --> Severity: Notice  --> Undefined property: stdClass::$pimage_id C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 145
ERROR - 2015-11-21 18:23:31 --> Severity: Notice  --> Undefined property: stdClass::$pimage_id C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 145
ERROR - 2015-11-21 18:23:31 --> Severity: Notice  --> Undefined property: stdClass::$image2 C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 168
ERROR - 2015-11-21 18:23:31 --> Severity: Notice  --> Undefined property: stdClass::$pimage_id C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 169
ERROR - 2015-11-21 18:23:31 --> Severity: Notice  --> Undefined property: stdClass::$image2 C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 168
ERROR - 2015-11-21 18:23:31 --> Severity: Notice  --> Undefined property: stdClass::$pimage_id C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 169
ERROR - 2015-11-21 18:24:20 --> Severity: Notice  --> Undefined property: stdClass::$pimage_id C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 145
ERROR - 2015-11-21 18:24:20 --> Severity: Notice  --> Undefined property: stdClass::$pimage_id C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 145
ERROR - 2015-11-21 18:24:20 --> Severity: Notice  --> Undefined property: stdClass::$pimage_id C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 169
ERROR - 2015-11-21 18:24:20 --> Severity: Notice  --> Undefined property: stdClass::$pimage_id C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 169
ERROR - 2015-11-21 18:24:38 --> Severity: Notice  --> Undefined property: stdClass::$pimage_id C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 141
ERROR - 2015-11-21 18:24:38 --> Severity: Notice  --> Undefined property: stdClass::$pimage_id C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 141
ERROR - 2015-11-21 18:44:18 --> Severity: Notice  --> Undefined property: stdClass::$pimage_id C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 141
ERROR - 2015-11-21 18:44:18 --> Severity: Notice  --> Undefined property: stdClass::$pimage_id C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 166
ERROR - 2015-11-21 19:04:26 --> You did not select a file to upload.
