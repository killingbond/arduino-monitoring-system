<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-03-10 03:34:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-10 03:34:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-10 03:37:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-10 03:37:57 --> 404 Page Not Found --> template
ERROR - 2015-03-10 03:38:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-10 03:38:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-10 03:38:27 --> 404 Page Not Found --> template
ERROR - 2015-03-10 03:38:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-10 03:38:45 --> 404 Page Not Found --> template
ERROR - 2015-03-10 03:39:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-10 03:39:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-10 03:39:41 --> 404 Page Not Found --> template
ERROR - 2015-03-10 03:40:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-10 03:40:02 --> 404 Page Not Found --> template
ERROR - 2015-03-10 03:40:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-10 03:40:21 --> 404 Page Not Found --> template
ERROR - 2015-03-10 07:00:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-10 07:00:10 --> 404 Page Not Found --> template
ERROR - 2015-03-10 07:00:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-10 07:00:16 --> 404 Page Not Found --> template
ERROR - 2015-03-10 07:00:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-10 07:00:21 --> 404 Page Not Found --> template
ERROR - 2015-03-10 07:00:21 --> 404 Page Not Found --> my_js
ERROR - 2015-03-10 07:00:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-10 07:00:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-10 07:00:42 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2015-03-10 07:00:42 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2015-03-10 07:00:42 --> 404 Page Not Found --> template
ERROR - 2015-03-10 07:00:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-10 07:00:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-10 07:00:44 --> 404 Page Not Found --> template
ERROR - 2015-03-10 07:00:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-10 07:00:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-10 07:00:54 --> 404 Page Not Found --> template
ERROR - 2015-03-10 07:00:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-10 07:00:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-10 07:03:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-10 07:03:22 --> 404 Page Not Found --> template
ERROR - 2015-03-10 07:03:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-10 07:03:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-10 07:03:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-10 07:03:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-10 07:04:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-10 07:04:24 --> 404 Page Not Found --> template
ERROR - 2015-03-10 07:04:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-10 07:04:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-10 07:04:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-10 07:04:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-10 07:04:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-10 07:04:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-10 07:04:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-10 07:04:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-10 07:04:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-10 07:04:59 --> 404 Page Not Found --> template
ERROR - 2015-03-10 07:04:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-10 07:04:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-10 07:05:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-10 07:05:28 --> 404 Page Not Found --> template
ERROR - 2015-03-10 07:05:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-10 07:05:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-10 07:06:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-10 07:06:22 --> 404 Page Not Found --> template
ERROR - 2015-03-10 18:39:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-10 18:39:18 --> 404 Page Not Found --> template
ERROR - 2015-03-10 18:40:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-10 18:40:37 --> 404 Page Not Found --> template
ERROR - 2015-03-10 18:40:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-10 18:40:53 --> 404 Page Not Found --> template
ERROR - 2015-03-10 18:43:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-10 18:43:27 --> 404 Page Not Found --> template
ERROR - 2015-03-10 18:43:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-10 18:43:49 --> 404 Page Not Found --> template
ERROR - 2015-03-10 18:43:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-10 18:44:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-10 18:44:39 --> 404 Page Not Found --> template
ERROR - 2015-03-10 18:45:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-10 18:45:12 --> 404 Page Not Found --> template
ERROR - 2015-03-10 18:45:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-10 18:45:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-10 18:46:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-10 18:47:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-10 18:49:18 --> 404 Page Not Found --> flat-visual-cha
ERROR - 2015-03-10 18:49:39 --> 404 Page Not Found --> flat-visual-cha
ERROR - 2015-03-10 18:49:44 --> 404 Page Not Found --> flat-visual-chat
ERROR - 2015-03-10 18:49:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-10 18:50:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-10 18:50:13 --> 404 Page Not Found --> template
ERROR - 2015-03-10 18:50:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-10 18:52:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-10 18:52:12 --> 404 Page Not Found --> template
ERROR - 2015-03-10 18:55:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-10 18:55:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-10 18:55:35 --> 404 Page Not Found --> template
ERROR - 2015-03-10 18:56:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-10 18:56:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-03-10 18:56:33 --> 404 Page Not Found --> template
ERROR - 2015-03-10 18:58:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
