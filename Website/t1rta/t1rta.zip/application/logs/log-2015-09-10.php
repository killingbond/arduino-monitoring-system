<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-09-10 11:54:24 --> 404 Page Not Found --> files
ERROR - 2015-09-10 11:54:24 --> 404 Page Not Found --> files
ERROR - 2015-09-10 12:28:14 --> 404 Page Not Found --> product/add_image
ERROR - 2015-09-10 12:45:56 --> 404 Page Not Found --> contact
ERROR - 2015-09-10 12:49:48 --> Severity: Notice  --> Undefined property: stdClass::$contact_id /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/contact/contact.php 85
ERROR - 2015-09-10 12:49:48 --> Severity: Notice  --> Undefined property: stdClass::$contact_id /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/contact/contact.php 87
ERROR - 2015-09-10 12:49:48 --> Severity: Notice  --> Undefined property: stdClass::$name /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/contact/contact.php 87
ERROR - 2015-09-10 12:49:48 --> Severity: Notice  --> Undefined property: stdClass::$email /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/contact/contact.php 88
ERROR - 2015-09-10 12:49:48 --> Severity: Notice  --> Undefined property: stdClass::$message /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/contact/contact.php 89
ERROR - 2015-09-10 12:49:48 --> Severity: Notice  --> Undefined property: stdClass::$contact_id /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/contact/contact.php 85
ERROR - 2015-09-10 12:49:48 --> Severity: Notice  --> Undefined property: stdClass::$contact_id /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/contact/contact.php 87
ERROR - 2015-09-10 12:49:48 --> Severity: Notice  --> Undefined property: stdClass::$name /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/contact/contact.php 87
ERROR - 2015-09-10 12:49:48 --> Severity: Notice  --> Undefined property: stdClass::$email /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/contact/contact.php 88
ERROR - 2015-09-10 12:49:48 --> Severity: Notice  --> Undefined property: stdClass::$message /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/contact/contact.php 89
ERROR - 2015-09-10 12:49:48 --> Severity: Notice  --> Undefined property: stdClass::$contact_id /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/contact/contact.php 85
ERROR - 2015-09-10 12:49:48 --> Severity: Notice  --> Undefined property: stdClass::$contact_id /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/contact/contact.php 87
ERROR - 2015-09-10 12:49:48 --> Severity: Notice  --> Undefined property: stdClass::$name /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/contact/contact.php 87
ERROR - 2015-09-10 12:49:48 --> Severity: Notice  --> Undefined property: stdClass::$email /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/contact/contact.php 88
ERROR - 2015-09-10 12:49:48 --> Severity: Notice  --> Undefined property: stdClass::$message /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/contact/contact.php 89
ERROR - 2015-09-10 12:49:48 --> Severity: Notice  --> Undefined property: stdClass::$contact_id /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/contact/contact.php 85
ERROR - 2015-09-10 12:49:48 --> Severity: Notice  --> Undefined property: stdClass::$contact_id /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/contact/contact.php 87
ERROR - 2015-09-10 12:49:48 --> Severity: Notice  --> Undefined property: stdClass::$name /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/contact/contact.php 87
ERROR - 2015-09-10 12:49:48 --> Severity: Notice  --> Undefined property: stdClass::$email /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/contact/contact.php 88
ERROR - 2015-09-10 12:49:48 --> Severity: Notice  --> Undefined property: stdClass::$message /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/contact/contact.php 89
ERROR - 2015-09-10 12:49:48 --> Severity: Notice  --> Undefined property: stdClass::$contact_id /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/contact/contact.php 85
ERROR - 2015-09-10 12:49:48 --> Severity: Notice  --> Undefined property: stdClass::$contact_id /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/contact/contact.php 87
ERROR - 2015-09-10 12:49:48 --> Severity: Notice  --> Undefined property: stdClass::$name /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/contact/contact.php 87
ERROR - 2015-09-10 12:49:48 --> Severity: Notice  --> Undefined property: stdClass::$email /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/contact/contact.php 88
ERROR - 2015-09-10 12:49:48 --> Severity: Notice  --> Undefined property: stdClass::$message /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/contact/contact.php 89
ERROR - 2015-09-10 12:49:48 --> Severity: Notice  --> Undefined property: stdClass::$contact_id /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/contact/contact.php 85
ERROR - 2015-09-10 12:49:48 --> Severity: Notice  --> Undefined property: stdClass::$contact_id /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/contact/contact.php 87
ERROR - 2015-09-10 12:49:48 --> Severity: Notice  --> Undefined property: stdClass::$name /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/contact/contact.php 87
ERROR - 2015-09-10 12:49:48 --> Severity: Notice  --> Undefined property: stdClass::$email /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/contact/contact.php 88
ERROR - 2015-09-10 12:49:48 --> Severity: Notice  --> Undefined property: stdClass::$message /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/contact/contact.php 89
ERROR - 2015-09-10 12:49:48 --> Severity: Notice  --> Undefined property: stdClass::$contact_id /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/contact/contact.php 85
ERROR - 2015-09-10 12:49:48 --> Severity: Notice  --> Undefined property: stdClass::$contact_id /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/contact/contact.php 87
ERROR - 2015-09-10 12:49:48 --> Severity: Notice  --> Undefined property: stdClass::$name /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/contact/contact.php 87
ERROR - 2015-09-10 12:49:48 --> Severity: Notice  --> Undefined property: stdClass::$email /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/contact/contact.php 88
ERROR - 2015-09-10 12:49:48 --> Severity: Notice  --> Undefined property: stdClass::$message /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/contact/contact.php 89
ERROR - 2015-09-10 12:49:48 --> Severity: Notice  --> Undefined property: stdClass::$contact_id /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/contact/contact.php 85
ERROR - 2015-09-10 12:49:48 --> Severity: Notice  --> Undefined property: stdClass::$contact_id /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/contact/contact.php 87
ERROR - 2015-09-10 12:49:48 --> Severity: Notice  --> Undefined property: stdClass::$name /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/contact/contact.php 87
ERROR - 2015-09-10 12:49:48 --> Severity: Notice  --> Undefined property: stdClass::$email /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/contact/contact.php 88
ERROR - 2015-09-10 12:49:48 --> Severity: Notice  --> Undefined property: stdClass::$message /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/contact/contact.php 89
ERROR - 2015-09-10 12:49:48 --> Severity: Notice  --> Undefined property: stdClass::$contact_id /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/contact/contact.php 85
ERROR - 2015-09-10 12:49:48 --> Severity: Notice  --> Undefined property: stdClass::$contact_id /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/contact/contact.php 87
ERROR - 2015-09-10 12:49:48 --> Severity: Notice  --> Undefined property: stdClass::$name /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/contact/contact.php 87
ERROR - 2015-09-10 12:49:48 --> Severity: Notice  --> Undefined property: stdClass::$email /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/contact/contact.php 88
ERROR - 2015-09-10 12:49:48 --> Severity: Notice  --> Undefined property: stdClass::$message /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/contact/contact.php 89
ERROR - 2015-09-10 12:49:48 --> Severity: Notice  --> Undefined property: stdClass::$contact_id /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/contact/contact.php 85
ERROR - 2015-09-10 12:49:48 --> Severity: Notice  --> Undefined property: stdClass::$contact_id /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/contact/contact.php 87
ERROR - 2015-09-10 12:49:48 --> Severity: Notice  --> Undefined property: stdClass::$name /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/contact/contact.php 87
ERROR - 2015-09-10 12:49:48 --> Severity: Notice  --> Undefined property: stdClass::$email /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/contact/contact.php 88
ERROR - 2015-09-10 12:49:48 --> Severity: Notice  --> Undefined property: stdClass::$message /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/contact/contact.php 89
ERROR - 2015-09-10 12:50:08 --> Query error: Unknown column 'contact' in 'where clause'
ERROR - 2015-09-10 12:50:16 --> Query error: Unknown column 'contact' in 'where clause'
ERROR - 2015-09-10 12:52:05 --> 404 Page Not Found --> contact/detail
ERROR - 2015-09-10 12:52:36 --> Severity: Notice  --> Undefined property: stdClass::$size_id /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/contact/detail_contact.php 37
ERROR - 2015-09-10 12:52:36 --> Severity: Notice  --> Undefined property: stdClass::$size /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/contact/detail_contact.php 43
ERROR - 2015-09-10 12:53:37 --> Severity: Notice  --> Undefined property: stdClass::$contact /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/contact/detail_contact.php 41
ERROR - 2015-09-10 12:53:37 --> Severity: Notice  --> Undefined property: stdClass::$contact /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/contact/detail_contact.php 48
ERROR - 2015-09-10 12:53:44 --> Severity: Notice  --> Undefined property: stdClass::$contact /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/contact/detail_contact.php 48
ERROR - 2015-09-10 12:53:54 --> Severity: Notice  --> Undefined property: stdClass::$contact /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/contact/detail_contact.php 48
ERROR - 2015-09-10 12:56:53 --> Query error: Unknown column 'article' in 'where clause'
ERROR - 2015-09-10 13:48:47 --> 404 Page Not Found --> journal/detail
ERROR - 2015-09-10 13:50:56 --> 404 Page Not Found --> journal/detail
ERROR - 2015-09-10 13:52:40 --> Severity: Notice  --> Undefined property: stdClass::$journal_id /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/journal/edit_journal.php 37
ERROR - 2015-09-10 13:52:40 --> Severity: Notice  --> Undefined property: stdClass::$journal_id /Applications/MAMP/htdocs/Wassuphaters/admin/application/views/journal/edit_journal.php 43
ERROR - 2015-09-10 13:56:59 --> 404 Page Not Found --> pages
ERROR - 2015-09-10 14:34:37 --> You did not select a file to upload.
ERROR - 2015-09-10 14:34:45 --> You did not select a file to upload.
ERROR - 2015-09-10 14:35:33 --> You did not select a file to upload.
