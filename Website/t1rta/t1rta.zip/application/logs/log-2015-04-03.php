<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-04-03 03:14:50 --> 404 Page Not Found --> template
