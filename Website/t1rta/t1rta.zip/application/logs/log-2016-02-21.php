<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2016-02-21 07:12:46 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-21 07:12:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-21 07:12:46 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-21 07:12:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-21 07:12:46 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-21 07:12:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-21 07:12:46 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-21 07:12:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-21 07:12:46 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-21 07:12:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-21 07:12:46 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:12:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:12:46 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:12:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:12:46 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:12:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:12:47 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:12:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:12:47 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:12:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:12:47 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:12:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:12:47 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:12:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:12:47 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:12:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:12:47 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:12:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:12:47 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:12:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:12:47 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:12:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:12:47 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:12:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:12:47 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:12:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:12:47 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:12:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:12:47 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:12:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:12:47 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:12:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:12:47 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:12:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:12:47 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:12:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:12:47 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:12:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:12:47 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:12:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:12:47 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:12:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:12:59 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-21 07:12:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-21 07:12:59 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-21 07:12:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-21 07:12:59 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-21 07:12:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-21 07:12:59 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-21 07:12:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-21 07:12:59 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-21 07:12:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-21 07:12:59 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:12:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:12:59 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:12:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:12:59 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:12:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:12:59 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:12:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:12:59 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:12:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:12:59 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:12:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:12:59 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:12:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:12:59 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:12:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:12:59 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:12:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:12:59 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:12:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:12:59 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:12:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:12:59 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:12:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:12:59 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:12:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:12:59 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:12:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:12:59 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:12:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:12:59 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:12:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:12:59 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:12:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:12:59 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:12:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:12:59 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:12:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:12:59 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:12:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:12:59 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:12:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:09 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-21 07:13:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-21 07:13:09 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-21 07:13:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-21 07:13:09 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-21 07:13:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-21 07:13:09 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-21 07:13:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-21 07:13:09 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-21 07:13:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-21 07:13:09 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:09 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:09 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:09 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:09 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:09 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:09 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:09 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:09 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:09 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:09 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:09 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:09 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:09 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:09 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:09 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:09 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:09 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:09 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:09 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:09 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:19 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-21 07:13:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-21 07:13:19 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-21 07:13:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-21 07:13:19 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-21 07:13:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-21 07:13:19 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-21 07:13:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-21 07:13:19 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-21 07:13:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-21 07:13:19 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:19 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:19 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:19 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:19 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:19 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:19 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:19 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:19 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:19 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:19 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:19 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:19 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:19 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:19 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:19 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:19 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:19 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:19 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:19 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:19 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:35 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-21 07:13:35 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-21 07:13:35 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-21 07:13:35 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-21 07:13:35 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-21 07:13:35 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-21 07:13:35 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-21 07:13:35 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-21 07:13:35 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-21 07:13:35 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-21 07:13:35 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:35 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:35 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:35 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:35 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:35 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:35 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:35 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:35 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:35 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:35 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:35 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:35 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:35 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:35 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:35 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:35 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:35 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:35 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:35 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:35 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:35 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:35 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:35 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:35 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:35 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:35 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:35 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:35 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:35 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:35 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:35 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:35 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:35 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:35 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:35 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:35 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:35 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:35 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:35 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:35 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:35 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:48 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-21 07:13:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-21 07:13:48 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-21 07:13:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-21 07:13:48 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-21 07:13:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-21 07:13:48 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-21 07:13:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-21 07:13:48 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-21 07:13:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-21 07:13:48 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:48 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:48 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:48 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:48 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:48 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:48 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:48 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:48 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:48 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:48 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:48 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:48 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:48 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:48 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:48 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:48 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:48 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:48 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:48 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:48 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:13:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:01 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-21 07:14:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-21 07:14:01 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-21 07:14:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-21 07:14:01 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-21 07:14:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-21 07:14:01 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-21 07:14:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-21 07:14:01 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-21 07:14:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-21 07:14:01 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:01 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:01 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:01 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:01 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:01 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:01 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:02 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:02 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:02 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:02 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:02 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:02 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:02 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:02 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:02 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:02 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:02 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:02 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:02 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:02 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:02 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:02 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:02 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:02 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:02 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:02 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:02 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:02 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:02 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:02 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:02 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:02 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:02 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:02 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:19 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-21 07:14:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-21 07:14:19 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-21 07:14:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-21 07:14:19 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-21 07:14:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-21 07:14:19 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-21 07:14:20 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-21 07:14:20 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-21 07:14:20 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-21 07:14:20 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:20 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:20 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:20 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:20 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:20 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:20 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:20 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:20 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:20 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:20 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:20 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:20 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:20 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:20 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:20 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:20 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:20 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:20 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:20 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:20 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:20 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:20 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:20 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:20 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:20 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:20 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:20 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:20 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:20 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:20 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:20 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:20 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:20 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:20 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:20 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:20 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:20 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:20 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:20 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:20 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:20 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:30 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-21 07:14:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-21 07:14:30 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-21 07:14:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-21 07:14:30 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-21 07:14:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-21 07:14:30 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-21 07:14:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-21 07:14:30 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-21 07:14:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-21 07:14:30 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:30 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:30 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:30 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:30 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:30 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:30 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:30 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:30 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:30 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:30 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:30 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:30 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:30 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:30 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:30 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:30 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:30 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:30 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:30 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:30 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:41 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-21 07:14:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-21 07:14:41 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-21 07:14:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-21 07:14:41 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-21 07:14:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-21 07:14:41 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-21 07:14:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-21 07:14:41 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-21 07:14:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-21 07:14:41 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:41 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:41 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:41 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:41 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:41 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:41 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:41 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:41 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:41 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:41 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:41 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:41 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:41 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:41 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:41 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:41 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:41 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:41 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:41 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:41 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:14:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:22:26 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-21 07:22:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-21 07:22:26 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-21 07:22:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-21 07:22:26 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-21 07:22:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-21 07:22:26 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-21 07:22:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-21 07:22:26 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-21 07:22:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-21 07:22:26 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:22:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:22:26 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:22:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:22:26 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:22:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:22:26 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:22:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:22:26 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:22:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:22:26 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:22:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:22:26 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:22:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:22:26 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:22:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:22:26 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:22:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:22:26 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:22:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:22:26 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:22:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:22:26 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:22:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:22:26 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:22:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:22:26 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:22:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:22:26 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:22:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:22:26 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:22:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:22:26 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:22:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:22:26 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:22:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:22:26 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:22:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:22:26 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:22:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:22:26 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:22:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:23:19 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-21 07:23:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-21 07:23:19 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-21 07:23:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-21 07:23:19 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-21 07:23:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-21 07:23:19 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-21 07:23:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-21 07:23:19 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-21 07:23:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 80
ERROR - 2016-02-21 07:23:19 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:23:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:23:19 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:23:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:23:19 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:23:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:23:19 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:23:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:23:19 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:23:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:23:19 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:23:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:23:19 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:23:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:23:19 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:23:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:23:19 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:23:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:23:19 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:23:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:23:19 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:23:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:23:19 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:23:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:23:19 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:23:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:23:19 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:23:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:23:19 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:23:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:23:19 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:23:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:23:19 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:23:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:23:19 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:23:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:23:19 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:23:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:23:19 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:23:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:23:19 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
ERROR - 2016-02-21 07:23:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\revisi\1\wassuphaters.com\r4dusa\application\views\product\add_product.php 101
