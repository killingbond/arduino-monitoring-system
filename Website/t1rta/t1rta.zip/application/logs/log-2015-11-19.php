<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-11-19 09:12:27 --> 404 Page Not Found --> accessories
ERROR - 2015-11-19 09:13:34 --> 404 Page Not Found --> accessories
ERROR - 2015-11-19 09:19:32 --> 404 Page Not Found --> accessories
ERROR - 2015-11-19 09:19:34 --> 404 Page Not Found --> accessories
ERROR - 2015-11-19 09:19:42 --> 404 Page Not Found --> accessories
ERROR - 2015-11-19 09:20:56 --> Query error: Table 'ozantcom_wassuphaters.product_accessories' doesn't exist
ERROR - 2015-11-19 09:27:32 --> Query error: Unknown column 'collaboration' in 'where clause'
ERROR - 2015-11-19 09:27:34 --> Query error: Unknown column 'collaboration' in 'where clause'
ERROR - 2015-11-19 09:27:46 --> Query error: Unknown column 'collaboration' in 'where clause'
ERROR - 2015-11-19 09:34:43 --> 404 Page Not Found --> swimwear
ERROR - 2015-11-19 09:35:12 --> Query error: Table 'ozantcom_wassuphaters.product_swimwear' doesn't exist
ERROR - 2015-11-19 09:41:28 --> Severity: Notice  --> Undefined property: stdClass::$type C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\apparel.php 214
ERROR - 2015-11-19 09:41:28 --> Severity: Notice  --> Undefined property: stdClass::$type C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\apparel.php 216
ERROR - 2015-11-19 09:41:28 --> Severity: Notice  --> Undefined property: stdClass::$product_id C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\apparel.php 221
ERROR - 2015-11-19 09:41:28 --> Severity: Notice  --> Undefined property: stdClass::$product_id C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\apparel.php 223
ERROR - 2015-11-19 09:41:28 --> Severity: Notice  --> Undefined property: stdClass::$name C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\apparel.php 223
ERROR - 2015-11-19 09:41:28 --> Severity: Notice  --> Undefined property: stdClass::$special_price C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\apparel.php 226
ERROR - 2015-11-19 09:41:28 --> Severity: Notice  --> Undefined property: stdClass::$price C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\apparel.php 227
ERROR - 2015-11-19 09:41:28 --> Severity: Notice  --> Undefined property: stdClass::$category C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\apparel.php 235
ERROR - 2015-11-19 09:41:28 --> Severity: Notice  --> Undefined property: stdClass::$stock C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\apparel.php 238
ERROR - 2015-11-19 09:41:28 --> Severity: Notice  --> Undefined property: stdClass::$type C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\apparel.php 214
ERROR - 2015-11-19 09:41:28 --> Severity: Notice  --> Undefined property: stdClass::$type C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\apparel.php 216
ERROR - 2015-11-19 09:41:28 --> Severity: Notice  --> Undefined property: stdClass::$product_id C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\apparel.php 221
ERROR - 2015-11-19 09:41:28 --> Severity: Notice  --> Undefined property: stdClass::$product_id C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\apparel.php 223
ERROR - 2015-11-19 09:41:28 --> Severity: Notice  --> Undefined property: stdClass::$name C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\apparel.php 223
ERROR - 2015-11-19 09:41:28 --> Severity: Notice  --> Undefined property: stdClass::$special_price C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\apparel.php 226
ERROR - 2015-11-19 09:41:28 --> Severity: Notice  --> Undefined property: stdClass::$price C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\apparel.php 227
ERROR - 2015-11-19 09:41:28 --> Severity: Notice  --> Undefined property: stdClass::$category C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\apparel.php 235
ERROR - 2015-11-19 09:41:28 --> Severity: Notice  --> Undefined property: stdClass::$stock C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\apparel.php 238
ERROR - 2015-11-19 10:16:54 --> Query error: Unknown column 'apparel' in 'field list'
ERROR - 2015-11-19 10:19:02 --> Severity: Notice  --> Undefined property: Product_apparel::$form_validation C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_apparel.php 74
ERROR - 2015-11-19 10:20:03 --> Severity: Notice  --> Undefined property: Product_apparel::$form_validation C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_apparel.php 57
ERROR - 2015-11-19 10:20:04 --> Severity: Notice  --> Undefined property: Product_apparel::$form_validation C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_apparel.php 57
ERROR - 2015-11-19 10:20:05 --> Severity: Notice  --> Undefined property: Product_apparel::$form_validation C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_apparel.php 57
ERROR - 2015-11-19 10:20:05 --> Severity: Notice  --> Undefined property: Product_apparel::$form_validation C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_apparel.php 57
ERROR - 2015-11-19 10:20:31 --> Severity: Notice  --> Undefined property: Product_apparel::$form_validation C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_apparel.php 57
ERROR - 2015-11-19 10:20:32 --> Severity: Notice  --> Undefined property: Product_apparel::$form_validation C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_apparel.php 57
ERROR - 2015-11-19 10:20:59 --> Severity: Notice  --> Undefined property: Product_apparel::$form_validation C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_apparel.php 57
ERROR - 2015-11-19 10:21:01 --> Severity: Notice  --> Undefined property: Product_apparel::$form_validation C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_apparel.php 57
ERROR - 2015-11-19 10:21:01 --> Severity: Notice  --> Undefined property: Product_apparel::$form_validation C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_apparel.php 57
ERROR - 2015-11-19 10:21:01 --> Severity: Notice  --> Undefined property: Product_apparel::$form_validation C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_apparel.php 57
ERROR - 2015-11-19 10:21:01 --> Severity: Notice  --> Undefined property: Product_apparel::$form_validation C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_apparel.php 57
ERROR - 2015-11-19 10:24:14 --> Severity: Notice  --> Undefined property: stdClass::$apparel_id C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\apparel.php 83
ERROR - 2015-11-19 10:24:14 --> Severity: Notice  --> Undefined property: stdClass::$apparel_id C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\apparel.php 85
ERROR - 2015-11-19 10:24:14 --> Severity: Notice  --> Undefined property: stdClass::$apparel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\apparel.php 85
ERROR - 2015-11-19 10:24:14 --> Severity: Notice  --> Undefined property: stdClass::$apparel_id C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\apparel.php 83
ERROR - 2015-11-19 10:24:14 --> Severity: Notice  --> Undefined property: stdClass::$apparel_id C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\apparel.php 85
ERROR - 2015-11-19 10:24:14 --> Severity: Notice  --> Undefined property: stdClass::$apparel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\apparel.php 85
ERROR - 2015-11-19 10:33:02 --> Severity: Notice  --> Undefined property: stdClass::$apparel_id C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\edit_apparel.php 37
ERROR - 2015-11-19 10:33:02 --> Severity: Notice  --> Undefined property: stdClass::$apparel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\edit_apparel.php 43
ERROR - 2015-11-19 10:33:20 --> Severity: Notice  --> Undefined property: stdClass::$apparel_id C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\edit_apparel.php 37
ERROR - 2015-11-19 10:33:20 --> Severity: Notice  --> Undefined property: stdClass::$apparel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\edit_apparel.php 43
ERROR - 2015-11-19 10:34:23 --> Severity: Notice  --> Undefined property: stdClass::$apparel C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\edit_apparel.php 43
ERROR - 2015-11-19 10:46:51 --> Query error: Unknown column 'apparel' in 'field list'
ERROR - 2015-11-19 10:47:47 --> Query error: Unknown column 'apparel' in 'field list'
ERROR - 2015-11-19 10:49:20 --> Query error: Table 'ozantcom_wassuphaters.sub_category_id' doesn't exist
ERROR - 2015-11-19 10:55:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\edit_apparel.php 37
ERROR - 2015-11-19 10:55:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\edit_apparel.php 43
ERROR - 2015-11-19 10:55:36 --> 404 Page Not Found --> product_apparel/e
ERROR - 2015-11-19 10:55:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\edit_apparel.php 37
ERROR - 2015-11-19 10:55:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\edit_apparel.php 43
ERROR - 2015-11-19 10:59:16 --> Query error: Unknown column 'apparel' in 'field list'
ERROR - 2015-11-19 11:00:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\edit_apparel.php 37
ERROR - 2015-11-19 11:00:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_apparel\edit_apparel.php 43
ERROR - 2015-11-19 11:05:39 --> Severity: Notice  --> Undefined property: stdClass::$bag_collection_id C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_bag\collection.php 83
ERROR - 2015-11-19 11:05:39 --> Severity: Notice  --> Undefined property: stdClass::$bag_collection_id C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_bag\collection.php 85
ERROR - 2015-11-19 11:05:39 --> Severity: Notice  --> Undefined property: stdClass::$bag_collection C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_bag\collection.php 85
ERROR - 2015-11-19 11:05:39 --> Severity: Notice  --> Undefined property: stdClass::$bag_collection_id C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_bag\collection.php 83
ERROR - 2015-11-19 11:05:39 --> Severity: Notice  --> Undefined property: stdClass::$bag_collection_id C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_bag\collection.php 85
ERROR - 2015-11-19 11:05:39 --> Severity: Notice  --> Undefined property: stdClass::$bag_collection C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_bag\collection.php 85
ERROR - 2015-11-19 11:08:58 --> Severity: Notice  --> Undefined property: stdClass::$bag_collection_id C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_bag\edit_collection.php 37
ERROR - 2015-11-19 11:08:58 --> Severity: Notice  --> Undefined property: stdClass::$bag_collection C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_bag\edit_collection.php 43
ERROR - 2015-11-19 11:09:28 --> Severity: Notice  --> Undefined property: stdClass::$bag_collection C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_bag\edit_collection.php 43
ERROR - 2015-11-19 11:11:06 --> Query error: Unknown column 'bag_collection' in 'field list'
ERROR - 2015-11-19 11:21:25 --> Severity: Notice  --> Undefined property: stdClass::$bag_type_id C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_bag\edit_type.php 37
ERROR - 2015-11-19 11:21:25 --> Severity: Notice  --> Undefined property: stdClass::$bag_type C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_bag\edit_type.php 43
ERROR - 2015-11-19 11:29:36 --> Query error: Unknown column 'bag_collection' in 'field list'
ERROR - 2015-11-19 11:38:10 --> Query error: Table 'ozantcom_wassuphaters.product_accessories' doesn't exist
ERROR - 2015-11-19 11:38:12 --> Query error: Table 'ozantcom_wassuphaters.product_accessories' doesn't exist
ERROR - 2015-11-19 11:38:14 --> Query error: Table 'ozantcom_wassuphaters.product_collaboration' doesn't exist
ERROR - 2015-11-19 11:38:16 --> Query error: Table 'ozantcom_wassuphaters.product_swimwear' doesn't exist
ERROR - 2015-11-19 11:38:26 --> Query error: Table 'ozantcom_wassuphaters.product_accessories' doesn't exist
ERROR - 2015-11-19 11:40:02 --> Query error: Table 'ozantcom_wassuphaters.product_accessories' doesn't exist
ERROR - 2015-11-19 11:43:32 --> Query error: Unknown column 'accessories' in 'field list'
ERROR - 2015-11-19 11:50:05 --> Severity: Notice  --> Undefined property: stdClass::$collaboration_id C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_collaboration\collaboration.php 83
ERROR - 2015-11-19 11:50:05 --> Severity: Notice  --> Undefined property: stdClass::$collaboration_id C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_collaboration\collaboration.php 85
ERROR - 2015-11-19 11:50:05 --> Severity: Notice  --> Undefined property: stdClass::$collaboration C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_collaboration\collaboration.php 85
ERROR - 2015-11-19 11:54:00 --> Severity: Warning  --> Missing argument 5 for Product_sub_category_m::get_all(), called in C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collaboration.php on line 36 and defined C:\xampp\htdocs\wassuphaters.com\w4zzup\application\models\product_sub_category_m.php 5
ERROR - 2015-11-19 11:54:00 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\wassuphaters.com\w4zzup\application\models\product_sub_category_m.php 16
ERROR - 2015-11-19 11:54:00 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AND sub_category LIKE '%%'  ORDER BY sub_category_id ASC LIMIT 0, 10' at line 1
ERROR - 2015-11-19 11:54:22 --> Severity: Warning  --> Missing argument 5 for Product_sub_category_m::get_all(), called in C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collaboration.php on line 37 and defined C:\xampp\htdocs\wassuphaters.com\w4zzup\application\models\product_sub_category_m.php 5
ERROR - 2015-11-19 11:54:22 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\wassuphaters.com\w4zzup\application\models\product_sub_category_m.php 16
ERROR - 2015-11-19 11:54:22 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AND sub_category LIKE '%%'  ORDER BY sub_category_id ASC LIMIT 0, 10' at line 1
ERROR - 2015-11-19 11:54:25 --> Severity: Warning  --> Missing argument 5 for Product_sub_category_m::get_all(), called in C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collaboration.php on line 37 and defined C:\xampp\htdocs\wassuphaters.com\w4zzup\application\models\product_sub_category_m.php 5
ERROR - 2015-11-19 11:54:25 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\wassuphaters.com\w4zzup\application\models\product_sub_category_m.php 16
ERROR - 2015-11-19 11:54:25 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AND sub_category LIKE '%%'  ORDER BY sub_category_id ASC LIMIT 0, 10' at line 1
ERROR - 2015-11-19 11:55:38 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\wassuphaters.com\w4zzup\application\models\product_collaboration_m.php 16
ERROR - 2015-11-19 11:55:38 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AND sub_category LIKE '%%'  ORDER BY sub_category_id ASC LIMIT 0, 10' at line 1
ERROR - 2015-11-19 11:55:44 --> Severity: Warning  --> Missing argument 5 for Product_collaboration_m::get_all(), called in C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collaboration.php on line 37 and defined C:\xampp\htdocs\wassuphaters.com\w4zzup\application\models\product_collaboration_m.php 5
ERROR - 2015-11-19 11:55:44 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\wassuphaters.com\w4zzup\application\models\product_collaboration_m.php 16
ERROR - 2015-11-19 11:55:44 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AND sub_category LIKE '%%'  ORDER BY sub_category_id ASC LIMIT 0, 10' at line 1
ERROR - 2015-11-19 11:56:20 --> Severity: Warning  --> Missing argument 5 for Product_collaboration_m::get_all(), called in C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collaboration.php on line 37 and defined C:\xampp\htdocs\wassuphaters.com\w4zzup\application\models\product_collaboration_m.php 5
ERROR - 2015-11-19 11:56:20 --> Query error: Unknown column '$id' in 'where clause'
ERROR - 2015-11-19 11:56:21 --> Severity: Warning  --> Missing argument 5 for Product_collaboration_m::get_all(), called in C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collaboration.php on line 37 and defined C:\xampp\htdocs\wassuphaters.com\w4zzup\application\models\product_collaboration_m.php 5
ERROR - 2015-11-19 11:56:21 --> Query error: Unknown column '$id' in 'where clause'
ERROR - 2015-11-19 11:56:21 --> Severity: Warning  --> Missing argument 5 for Product_collaboration_m::get_all(), called in C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collaboration.php on line 37 and defined C:\xampp\htdocs\wassuphaters.com\w4zzup\application\models\product_collaboration_m.php 5
ERROR - 2015-11-19 11:56:21 --> Query error: Unknown column '$id' in 'where clause'
ERROR - 2015-11-19 11:56:22 --> Severity: Warning  --> Missing argument 5 for Product_collaboration_m::get_all(), called in C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collaboration.php on line 37 and defined C:\xampp\htdocs\wassuphaters.com\w4zzup\application\models\product_collaboration_m.php 5
ERROR - 2015-11-19 11:56:22 --> Query error: Unknown column '$id' in 'where clause'
ERROR - 2015-11-19 11:56:22 --> Severity: Warning  --> Missing argument 5 for Product_collaboration_m::get_all(), called in C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collaboration.php on line 37 and defined C:\xampp\htdocs\wassuphaters.com\w4zzup\application\models\product_collaboration_m.php 5
ERROR - 2015-11-19 11:56:22 --> Query error: Unknown column '$id' in 'where clause'
ERROR - 2015-11-19 11:56:22 --> Severity: Warning  --> Missing argument 5 for Product_collaboration_m::get_all(), called in C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collaboration.php on line 37 and defined C:\xampp\htdocs\wassuphaters.com\w4zzup\application\models\product_collaboration_m.php 5
ERROR - 2015-11-19 11:56:22 --> Query error: Unknown column '$id' in 'where clause'
ERROR - 2015-11-19 11:56:22 --> Severity: Warning  --> Missing argument 5 for Product_collaboration_m::get_all(), called in C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collaboration.php on line 37 and defined C:\xampp\htdocs\wassuphaters.com\w4zzup\application\models\product_collaboration_m.php 5
ERROR - 2015-11-19 11:56:22 --> Query error: Unknown column '$id' in 'where clause'
ERROR - 2015-11-19 11:56:22 --> Severity: Warning  --> Missing argument 5 for Product_collaboration_m::get_all(), called in C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collaboration.php on line 37 and defined C:\xampp\htdocs\wassuphaters.com\w4zzup\application\models\product_collaboration_m.php 5
ERROR - 2015-11-19 11:56:22 --> Query error: Unknown column '$id' in 'where clause'
ERROR - 2015-11-19 11:56:23 --> Severity: Warning  --> Missing argument 5 for Product_collaboration_m::get_all(), called in C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collaboration.php on line 37 and defined C:\xampp\htdocs\wassuphaters.com\w4zzup\application\models\product_collaboration_m.php 5
ERROR - 2015-11-19 11:56:23 --> Query error: Unknown column '$id' in 'where clause'
ERROR - 2015-11-19 11:56:23 --> Severity: Warning  --> Missing argument 5 for Product_collaboration_m::get_all(), called in C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collaboration.php on line 37 and defined C:\xampp\htdocs\wassuphaters.com\w4zzup\application\models\product_collaboration_m.php 5
ERROR - 2015-11-19 11:56:23 --> Query error: Unknown column '$id' in 'where clause'
ERROR - 2015-11-19 11:56:23 --> Severity: Warning  --> Missing argument 5 for Product_collaboration_m::get_all(), called in C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collaboration.php on line 37 and defined C:\xampp\htdocs\wassuphaters.com\w4zzup\application\models\product_collaboration_m.php 5
ERROR - 2015-11-19 11:56:23 --> Query error: Unknown column '$id' in 'where clause'
ERROR - 2015-11-19 11:56:23 --> Severity: Warning  --> Missing argument 5 for Product_collaboration_m::get_all(), called in C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collaboration.php on line 37 and defined C:\xampp\htdocs\wassuphaters.com\w4zzup\application\models\product_collaboration_m.php 5
ERROR - 2015-11-19 11:56:23 --> Query error: Unknown column '$id' in 'where clause'
ERROR - 2015-11-19 11:56:23 --> Severity: Warning  --> Missing argument 5 for Product_collaboration_m::get_all(), called in C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collaboration.php on line 37 and defined C:\xampp\htdocs\wassuphaters.com\w4zzup\application\models\product_collaboration_m.php 5
ERROR - 2015-11-19 11:56:23 --> Query error: Unknown column '$id' in 'where clause'
ERROR - 2015-11-19 11:56:23 --> Severity: Warning  --> Missing argument 5 for Product_collaboration_m::get_all(), called in C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collaboration.php on line 37 and defined C:\xampp\htdocs\wassuphaters.com\w4zzup\application\models\product_collaboration_m.php 5
ERROR - 2015-11-19 11:56:23 --> Query error: Unknown column '$id' in 'where clause'
ERROR - 2015-11-19 11:56:24 --> Severity: Warning  --> Missing argument 5 for Product_collaboration_m::get_all(), called in C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collaboration.php on line 37 and defined C:\xampp\htdocs\wassuphaters.com\w4zzup\application\models\product_collaboration_m.php 5
ERROR - 2015-11-19 11:56:24 --> Query error: Unknown column '$id' in 'where clause'
ERROR - 2015-11-19 11:56:24 --> Severity: Warning  --> Missing argument 5 for Product_collaboration_m::get_all(), called in C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collaboration.php on line 37 and defined C:\xampp\htdocs\wassuphaters.com\w4zzup\application\models\product_collaboration_m.php 5
ERROR - 2015-11-19 11:56:24 --> Query error: Unknown column '$id' in 'where clause'
ERROR - 2015-11-19 11:56:24 --> Severity: Warning  --> Missing argument 5 for Product_collaboration_m::get_all(), called in C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collaboration.php on line 37 and defined C:\xampp\htdocs\wassuphaters.com\w4zzup\application\models\product_collaboration_m.php 5
ERROR - 2015-11-19 11:56:24 --> Query error: Unknown column '$id' in 'where clause'
ERROR - 2015-11-19 11:56:25 --> Severity: Warning  --> Missing argument 5 for Product_collaboration_m::get_all(), called in C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collaboration.php on line 37 and defined C:\xampp\htdocs\wassuphaters.com\w4zzup\application\models\product_collaboration_m.php 5
ERROR - 2015-11-19 11:56:25 --> Query error: Unknown column '$id' in 'where clause'
ERROR - 2015-11-19 11:56:25 --> Severity: Warning  --> Missing argument 5 for Product_collaboration_m::get_all(), called in C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collaboration.php on line 37 and defined C:\xampp\htdocs\wassuphaters.com\w4zzup\application\models\product_collaboration_m.php 5
ERROR - 2015-11-19 11:56:25 --> Query error: Unknown column '$id' in 'where clause'
ERROR - 2015-11-19 11:56:25 --> Severity: Warning  --> Missing argument 5 for Product_collaboration_m::get_all(), called in C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collaboration.php on line 37 and defined C:\xampp\htdocs\wassuphaters.com\w4zzup\application\models\product_collaboration_m.php 5
ERROR - 2015-11-19 11:56:25 --> Query error: Unknown column '$id' in 'where clause'
ERROR - 2015-11-19 11:56:52 --> Severity: Warning  --> Missing argument 5 for Product_collaboration_m::get_all(), called in C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collaboration.php on line 37 and defined C:\xampp\htdocs\wassuphaters.com\w4zzup\application\models\product_collaboration_m.php 5
ERROR - 2015-11-19 11:56:52 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '}  AND sub_category LIKE '%%'  ORDER BY sub_category_id ASC LIMIT 0, 10' at line 1
ERROR - 2015-11-19 11:56:53 --> Severity: Warning  --> Missing argument 5 for Product_collaboration_m::get_all(), called in C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collaboration.php on line 37 and defined C:\xampp\htdocs\wassuphaters.com\w4zzup\application\models\product_collaboration_m.php 5
ERROR - 2015-11-19 11:56:53 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '}  AND sub_category LIKE '%%'  ORDER BY sub_category_id ASC LIMIT 0, 10' at line 1
ERROR - 2015-11-19 11:56:53 --> Severity: Warning  --> Missing argument 5 for Product_collaboration_m::get_all(), called in C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collaboration.php on line 37 and defined C:\xampp\htdocs\wassuphaters.com\w4zzup\application\models\product_collaboration_m.php 5
ERROR - 2015-11-19 11:56:53 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '}  AND sub_category LIKE '%%'  ORDER BY sub_category_id ASC LIMIT 0, 10' at line 1
ERROR - 2015-11-19 11:56:54 --> Severity: Warning  --> Missing argument 5 for Product_collaboration_m::get_all(), called in C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collaboration.php on line 37 and defined C:\xampp\htdocs\wassuphaters.com\w4zzup\application\models\product_collaboration_m.php 5
ERROR - 2015-11-19 11:56:54 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '}  AND sub_category LIKE '%%'  ORDER BY sub_category_id ASC LIMIT 0, 10' at line 1
ERROR - 2015-11-19 11:56:54 --> Severity: Warning  --> Missing argument 5 for Product_collaboration_m::get_all(), called in C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collaboration.php on line 37 and defined C:\xampp\htdocs\wassuphaters.com\w4zzup\application\models\product_collaboration_m.php 5
ERROR - 2015-11-19 11:56:54 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '}  AND sub_category LIKE '%%'  ORDER BY sub_category_id ASC LIMIT 0, 10' at line 1
ERROR - 2015-11-19 11:56:54 --> Severity: Warning  --> Missing argument 5 for Product_collaboration_m::get_all(), called in C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collaboration.php on line 37 and defined C:\xampp\htdocs\wassuphaters.com\w4zzup\application\models\product_collaboration_m.php 5
ERROR - 2015-11-19 11:56:54 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '}  AND sub_category LIKE '%%'  ORDER BY sub_category_id ASC LIMIT 0, 10' at line 1
ERROR - 2015-11-19 11:56:55 --> Severity: Warning  --> Missing argument 5 for Product_collaboration_m::get_all(), called in C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collaboration.php on line 37 and defined C:\xampp\htdocs\wassuphaters.com\w4zzup\application\models\product_collaboration_m.php 5
ERROR - 2015-11-19 11:56:55 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '}  AND sub_category LIKE '%%'  ORDER BY sub_category_id ASC LIMIT 0, 10' at line 1
ERROR - 2015-11-19 11:57:07 --> Severity: Warning  --> Missing argument 5 for Product_collaboration_m::get_all(), called in C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_collaboration.php on line 37 and defined C:\xampp\htdocs\wassuphaters.com\w4zzup\application\models\product_collaboration_m.php 5
ERROR - 2015-11-19 11:57:07 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\wassuphaters.com\w4zzup\application\models\product_collaboration_m.php 16
ERROR - 2015-11-19 11:57:07 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AND sub_category LIKE '%%'  ORDER BY sub_category_id ASC LIMIT 0, 10' at line 1
ERROR - 2015-11-19 11:59:33 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\wassuphaters.com\w4zzup\application\models\product_collaboration_m.php 26
ERROR - 2015-11-19 12:04:21 --> Severity: Notice  --> Undefined property: stdClass::$collaboration_id C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_collaboration\edit_collaboration.php 37
ERROR - 2015-11-19 12:04:21 --> Severity: Notice  --> Undefined property: stdClass::$collaboration C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_collaboration\edit_collaboration.php 43
ERROR - 2015-11-19 12:09:32 --> Severity: Notice  --> Undefined variable: id C:\xampp\htdocs\wassuphaters.com\w4zzup\application\controllers\product_accessories.php 36
ERROR - 2015-11-19 12:09:32 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AND sub_category LIKE '%%'  ORDER BY sub_category_id ASC LIMIT 0, 10' at line 1
ERROR - 2015-11-19 12:13:00 --> Query error: Table 'ozantcom_wassuphaters.product_swimwear' doesn't exist
ERROR - 2015-11-19 12:14:09 --> Query error: Unknown column 'swimwear' in 'field list'
ERROR - 2015-11-19 12:15:14 --> Query error: Unknown column 'swimwear' in 'field list'
ERROR - 2015-11-19 12:15:50 --> Query error: Unknown column 'swimwear' in 'field list'
ERROR - 2015-11-19 12:16:24 --> Severity: Notice  --> Undefined property: stdClass::$swimwear_id C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_swimwear\swimwear.php 83
ERROR - 2015-11-19 12:16:24 --> Severity: Notice  --> Undefined property: stdClass::$swimwear_id C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_swimwear\swimwear.php 85
ERROR - 2015-11-19 12:16:24 --> Severity: Notice  --> Undefined property: stdClass::$swimwear C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product_swimwear\swimwear.php 85
ERROR - 2015-11-19 13:15:36 --> Severity: Notice  --> Undefined variable: type C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\product.php 101
ERROR - 2015-11-19 13:15:36 --> Severity: Notice  --> Undefined property: stdClass::$category C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\product.php 102
ERROR - 2015-11-19 13:15:36 --> Severity: Notice  --> Undefined variable: type C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\product.php 101
ERROR - 2015-11-19 13:15:36 --> Severity: Notice  --> Undefined property: stdClass::$category C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\product.php 102
ERROR - 2015-11-19 13:17:14 --> Severity: Notice  --> Undefined variable: type C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\product.php 101
ERROR - 2015-11-19 13:17:14 --> Severity: Notice  --> Undefined property: stdClass::$category C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\product.php 102
ERROR - 2015-11-19 13:17:32 --> Severity: Notice  --> Undefined variable: type C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\product.php 101
ERROR - 2015-11-19 13:18:54 --> Severity: Notice  --> Undefined variable: type C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\product.php 101
ERROR - 2015-11-19 13:18:54 --> Severity: Notice  --> Undefined variable: type C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\product.php 101
ERROR - 2015-11-19 13:19:26 --> Severity: Notice  --> Undefined variable: type C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\product.php 101
ERROR - 2015-11-19 13:19:26 --> Severity: Notice  --> Undefined variable: type C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\product.php 101
ERROR - 2015-11-19 13:19:28 --> Severity: Notice  --> Undefined variable: type C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\product.php 101
ERROR - 2015-11-19 13:19:28 --> Severity: Notice  --> Undefined variable: type C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\product.php 101
ERROR - 2015-11-19 13:19:29 --> Severity: Notice  --> Undefined variable: type C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\product.php 101
ERROR - 2015-11-19 13:19:29 --> Severity: Notice  --> Undefined variable: type C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\product.php 101
ERROR - 2015-11-19 13:20:22 --> Severity: Notice  --> Undefined property: stdClass::$type C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 66
ERROR - 2015-11-19 13:20:22 --> Severity: Notice  --> Undefined property: stdClass::$type C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 67
ERROR - 2015-11-19 13:20:22 --> Severity: Notice  --> Undefined property: stdClass::$type C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 68
ERROR - 2015-11-19 13:23:30 --> Severity: Notice  --> Undefined variable: sub_category C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 91
ERROR - 2015-11-19 13:23:30 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 91
ERROR - 2015-11-19 13:23:56 --> Severity: Notice  --> Undefined variable: sub_category C:\xampp\htdocs\wassuphaters.com\w4zzup\application\views\product\edit_product.php 90
ERROR - 2015-11-19 13:25:57 --> Query error: Unknown column 'type' in 'field list'
