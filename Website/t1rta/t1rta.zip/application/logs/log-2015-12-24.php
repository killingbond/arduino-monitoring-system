<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-12-24 05:55:59 --> Severity: Notice  --> Undefined variable: orders C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\order\order_detail.php 190
ERROR - 2015-12-24 05:55:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\order\order_detail.php 190
ERROR - 2015-12-24 05:55:59 --> Severity: Notice  --> Undefined variable: orders C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\order\order_detail.php 190
ERROR - 2015-12-24 05:55:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\order\order_detail.php 190
ERROR - 2015-12-24 06:19:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\order\order.php 101
ERROR - 2015-12-24 06:19:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\order\order.php 101
ERROR - 2015-12-24 06:19:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\order\order.php 101
ERROR - 2015-12-24 06:19:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\order\order.php 101
ERROR - 2015-12-24 06:19:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\order\order.php 101
ERROR - 2015-12-24 06:19:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\order\order.php 101
ERROR - 2015-12-24 06:19:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\order\order.php 101
ERROR - 2015-12-24 06:19:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\order\order.php 101
ERROR - 2015-12-24 06:19:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\order\order.php 101
ERROR - 2015-12-24 06:19:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\order\order.php 101
ERROR - 2015-12-24 06:19:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\order\order.php 101
ERROR - 2015-12-24 06:19:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\order\order.php 101
ERROR - 2015-12-24 06:19:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\order\order.php 101
ERROR - 2015-12-24 06:19:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\order\order.php 101
ERROR - 2015-12-24 06:19:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\order\order.php 101
ERROR - 2015-12-24 06:19:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\order\order.php 101
ERROR - 2015-12-24 06:19:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\order\order.php 101
ERROR - 2015-12-24 06:19:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\order\order.php 101
ERROR - 2015-12-24 06:19:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\order\order.php 101
ERROR - 2015-12-24 06:19:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\order\order.php 101
ERROR - 2015-12-24 06:19:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\order\order.php 101
ERROR - 2015-12-24 06:19:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\order\order.php 101
ERROR - 2015-12-24 06:19:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\order\order.php 101
ERROR - 2015-12-24 06:19:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\order\order.php 101
ERROR - 2015-12-24 06:19:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\order\order.php 101
ERROR - 2015-12-24 06:19:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\order\order.php 101
ERROR - 2015-12-24 06:19:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\order\order.php 101
ERROR - 2015-12-24 06:19:35 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\order\order.php 101
ERROR - 2015-12-24 06:19:35 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\order\order.php 101
ERROR - 2015-12-24 06:19:35 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\order\order.php 101
ERROR - 2015-12-24 06:19:35 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\order\order.php 101
ERROR - 2015-12-24 06:19:35 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\order\order.php 101
ERROR - 2015-12-24 06:19:35 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\order\order.php 101
ERROR - 2015-12-24 06:19:35 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\order\order.php 101
ERROR - 2015-12-24 06:19:35 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\order\order.php 101
ERROR - 2015-12-24 06:19:35 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\order\order.php 101
ERROR - 2015-12-24 09:43:06 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-24 09:43:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-24 09:43:06 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-24 09:43:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-24 09:43:06 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-24 09:43:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-24 09:43:06 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-24 09:43:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-24 09:43:06 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-24 09:43:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-24 09:43:06 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-24 09:43:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-24 09:43:06 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-24 09:43:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-24 09:43:06 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-24 09:43:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-24 09:43:06 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-24 09:43:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-24 09:43:06 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-24 09:43:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-24 09:43:06 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-24 09:43:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-24 09:43:06 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-24 09:43:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-24 09:43:06 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-24 09:43:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-24 09:43:06 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-24 09:43:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-24 09:43:06 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-24 09:43:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-24 09:43:06 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-24 09:43:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-24 09:43:06 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-24 09:43:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-24 09:43:06 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-24 09:43:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-24 09:43:06 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-24 09:43:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-24 09:43:06 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-24 09:43:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-24 09:43:07 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-24 09:43:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-24 09:43:07 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-24 09:43:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-24 09:43:07 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-24 09:43:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-24 09:43:07 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-24 09:43:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-24 09:43:07 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-24 09:43:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-24 09:43:07 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-24 09:43:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-24 09:43:59 --> The uploaded file exceeds the maximum allowed size in your PHP configuration file.
ERROR - 2015-12-24 09:51:37 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-24 09:51:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-24 09:51:37 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-24 09:51:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-24 09:51:37 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-24 09:51:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-24 09:51:37 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-24 09:51:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-24 09:51:37 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-24 09:51:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 79
ERROR - 2015-12-24 09:51:37 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-24 09:51:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-24 09:51:37 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-24 09:51:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-24 09:51:37 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-24 09:51:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-24 09:51:38 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-24 09:51:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-24 09:51:38 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-24 09:51:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-24 09:51:38 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-24 09:51:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-24 09:51:38 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-24 09:51:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-24 09:51:38 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-24 09:51:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-24 09:51:38 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-24 09:51:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-24 09:51:38 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-24 09:51:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-24 09:51:38 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-24 09:51:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-24 09:51:38 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-24 09:51:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-24 09:51:38 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-24 09:51:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-24 09:51:38 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-24 09:51:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-24 09:51:38 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-24 09:51:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-24 09:51:38 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-24 09:51:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-24 09:51:38 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-24 09:51:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-24 09:51:38 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-24 09:51:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-24 09:51:38 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-24 09:51:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-24 09:51:38 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-24 09:51:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-24 09:51:38 --> Severity: Notice  --> Undefined variable: data_update C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-24 09:51:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\product\add_product.php 100
ERROR - 2015-12-24 09:52:14 --> Severity: Notice  --> Undefined variable: max C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\slidecollection\slidecollection.php 50
ERROR - 2015-12-24 09:52:14 --> Severity: Notice  --> Undefined variable: max C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\slidecollection\slidecollection.php 51
ERROR - 2015-12-24 09:52:14 --> Severity: Notice  --> Undefined variable: max C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\slidecollection\slidecollection.php 52
ERROR - 2015-12-24 09:52:14 --> Severity: Notice  --> Undefined variable: max C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\slidecollection\slidecollection.php 53
ERROR - 2015-12-24 09:52:14 --> Severity: Notice  --> Undefined variable: max C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\slidecollection\slidecollection.php 54
ERROR - 2015-12-24 09:52:14 --> Severity: Notice  --> Undefined variable: search C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\slidecollection\slidecollection.php 59
ERROR - 2015-12-24 09:52:14 --> Severity: Notice  --> Undefined variable: page C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\slidecollection\slidecollection.php 207
ERROR - 2015-12-24 09:52:14 --> Severity: Notice  --> Undefined variable: order C:\xampp\htdocs\wassuphaters.com\r4dusa\application\views\slidecollection\slidecollection.php 208
