<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-03-24 13:17:36 --> 404 Page Not Found --> template
ERROR - 2015-03-24 13:18:02 --> 404 Page Not Found --> template
ERROR - 2015-03-24 13:18:08 --> 404 Page Not Found --> template
ERROR - 2015-03-24 13:18:13 --> 404 Page Not Found --> template
ERROR - 2015-03-24 13:18:16 --> 404 Page Not Found --> template
ERROR - 2015-03-24 13:18:17 --> 404 Page Not Found --> my_js
ERROR - 2015-03-24 13:18:21 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2015-03-24 13:18:21 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2015-03-24 13:18:21 --> 404 Page Not Found --> template
ERROR - 2015-03-24 13:18:23 --> 404 Page Not Found --> template
ERROR - 2015-03-24 13:18:27 --> 404 Page Not Found --> template
ERROR - 2015-03-24 13:18:32 --> Severity: Warning  --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\wamp\www\Esgotado\system\libraries\Email.php 1553
ERROR - 2015-03-24 13:18:32 --> 404 Page Not Found --> template
ERROR - 2015-03-24 13:19:15 --> 404 Page Not Found --> template
ERROR - 2015-03-24 13:19:19 --> 404 Page Not Found --> template
ERROR - 2015-03-24 13:19:25 --> 404 Page Not Found --> template
ERROR - 2015-03-24 13:19:29 --> 404 Page Not Found --> template
ERROR - 2015-03-24 13:19:29 --> 404 Page Not Found --> my_js
ERROR - 2015-03-24 13:19:31 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2015-03-24 13:19:31 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2015-03-24 13:19:31 --> 404 Page Not Found --> template
ERROR - 2015-03-24 13:19:33 --> 404 Page Not Found --> template
ERROR - 2015-03-24 13:19:43 --> 404 Page Not Found --> template
ERROR - 2015-03-24 13:19:51 --> 404 Page Not Found --> template
ERROR - 2015-03-24 13:19:57 --> 404 Page Not Found --> template
ERROR - 2015-03-24 13:20:01 --> Severity: Warning  --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\wamp\www\Esgotado\system\libraries\Email.php 1553
ERROR - 2015-03-24 13:20:01 --> 404 Page Not Found --> template
ERROR - 2015-03-24 13:20:04 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\models\cart_m.php 328
ERROR - 2015-03-24 13:20:04 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\models\cart_m.php 340
ERROR - 2015-03-24 13:20:04 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\models\cart_m.php 341
ERROR - 2015-03-24 13:20:04 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\models\cart_m.php 343
ERROR - 2015-03-24 13:20:04 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\models\cart_m.php 344
ERROR - 2015-03-24 13:20:04 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\models\cart_m.php 345
ERROR - 2015-03-24 13:20:04 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\models\cart_m.php 346
ERROR - 2015-03-24 13:20:04 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\models\cart_m.php 347
ERROR - 2015-03-24 13:20:04 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\models\cart_m.php 348
ERROR - 2015-03-24 13:20:04 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\models\cart_m.php 351
ERROR - 2015-03-24 13:20:04 --> Query error: Column 'courier_id' cannot be null
ERROR - 2015-03-24 13:21:40 --> 404 Page Not Found --> template
ERROR - 2015-03-24 13:22:16 --> 404 Page Not Found --> template
ERROR - 2015-03-24 13:22:19 --> 404 Page Not Found --> template
ERROR - 2015-03-24 13:22:19 --> 404 Page Not Found --> my_js
ERROR - 2015-03-24 13:22:22 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2015-03-24 13:22:22 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2015-03-24 13:22:22 --> 404 Page Not Found --> template
ERROR - 2015-03-24 13:22:27 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2015-03-24 13:22:27 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2015-03-24 13:22:27 --> 404 Page Not Found --> template
ERROR - 2015-03-24 13:22:29 --> 404 Page Not Found --> template
ERROR - 2015-03-24 13:22:33 --> 404 Page Not Found --> template
ERROR - 2015-03-24 13:22:40 --> 404 Page Not Found --> template
ERROR - 2015-03-24 13:22:43 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\Esgotado\application\models\cart_m.php 398
ERROR - 2015-03-24 13:22:43 --> Severity: Notice  --> Undefined variable: data_detail C:\wamp\www\Esgotado\application\models\cart_m.php 506
ERROR - 2015-03-24 13:22:43 --> 404 Page Not Found --> template
ERROR - 2015-03-24 13:23:47 --> 404 Page Not Found --> template
ERROR - 2015-03-24 13:23:51 --> 404 Page Not Found --> my_js
ERROR - 2015-03-24 13:23:51 --> 404 Page Not Found --> template
ERROR - 2015-03-24 13:23:53 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2015-03-24 13:23:53 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2015-03-24 13:23:53 --> 404 Page Not Found --> template
ERROR - 2015-03-24 13:23:56 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2015-03-24 13:23:56 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2015-03-24 13:23:56 --> 404 Page Not Found --> template
ERROR - 2015-03-24 13:23:58 --> 404 Page Not Found --> template
ERROR - 2015-03-24 13:24:01 --> 404 Page Not Found --> template
ERROR - 2015-03-24 13:24:04 --> 404 Page Not Found --> template
ERROR - 2015-03-24 13:24:06 --> 404 Page Not Found --> template
ERROR - 2015-03-24 13:24:16 --> Severity: Warning  --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\wamp\www\Esgotado\system\libraries\Email.php 1553
ERROR - 2015-03-24 13:24:17 --> 404 Page Not Found --> template
ERROR - 2015-03-24 13:24:21 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\models\cart_m.php 328
ERROR - 2015-03-24 13:24:21 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\models\cart_m.php 340
ERROR - 2015-03-24 13:24:21 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\models\cart_m.php 341
ERROR - 2015-03-24 13:24:21 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\models\cart_m.php 343
ERROR - 2015-03-24 13:24:21 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\models\cart_m.php 344
ERROR - 2015-03-24 13:24:21 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\models\cart_m.php 345
ERROR - 2015-03-24 13:24:21 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\models\cart_m.php 346
ERROR - 2015-03-24 13:24:21 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\models\cart_m.php 347
ERROR - 2015-03-24 13:24:21 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\models\cart_m.php 348
ERROR - 2015-03-24 13:24:21 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\models\cart_m.php 351
ERROR - 2015-03-24 13:24:21 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\Esgotado\application\models\cart_m.php 398
ERROR - 2015-03-24 13:24:21 --> 404 Page Not Found --> template
ERROR - 2015-03-24 23:49:39 --> 404 Page Not Found --> template
ERROR - 2015-03-24 23:49:44 --> 404 Page Not Found --> template
ERROR - 2015-03-24 23:49:55 --> 404 Page Not Found --> template
ERROR - 2015-03-24 23:51:15 --> 404 Page Not Found --> template
ERROR - 2015-03-24 23:52:50 --> 404 Page Not Found --> template
ERROR - 2015-03-24 23:52:54 --> 404 Page Not Found --> template
ERROR - 2015-03-24 23:52:57 --> 404 Page Not Found --> template
ERROR - 2015-03-24 23:52:57 --> 404 Page Not Found --> my_js
ERROR - 2015-03-24 23:53:04 --> 404 Page Not Found --> template
ERROR - 2015-03-24 23:53:12 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2015-03-24 23:53:12 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2015-03-24 23:53:12 --> 404 Page Not Found --> template
ERROR - 2015-03-24 23:53:14 --> 404 Page Not Found --> template
ERROR - 2015-03-24 23:53:19 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2015-03-24 23:53:19 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 138
ERROR - 2015-03-24 23:53:19 --> 404 Page Not Found --> template
ERROR - 2015-03-24 23:53:22 --> 404 Page Not Found --> template
ERROR - 2015-03-24 23:55:38 --> 404 Page Not Found --> template
ERROR - 2015-03-24 23:55:44 --> 404 Page Not Found --> template
ERROR - 2015-03-24 23:57:35 --> 404 Page Not Found --> template
ERROR - 2015-03-24 23:58:04 --> 404 Page Not Found --> template
ERROR - 2015-03-24 23:58:27 --> 404 Page Not Found --> template
ERROR - 2015-03-24 23:58:57 --> Severity: Warning  --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\wamp\www\Esgotado\system\libraries\Email.php 1553
ERROR - 2015-03-24 23:58:58 --> 404 Page Not Found --> template
