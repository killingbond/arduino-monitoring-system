<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2016-11-19 00:07:19 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 85
ERROR - 2016-11-19 00:07:19 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 98
ERROR - 2016-11-19 00:25:52 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 85
ERROR - 2016-11-19 00:25:52 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 98
ERROR - 2016-11-19 00:25:54 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 85
ERROR - 2016-11-19 00:25:54 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 98
ERROR - 2016-11-19 00:25:54 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 85
ERROR - 2016-11-19 00:25:54 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 98
ERROR - 2016-11-19 00:25:59 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 85
ERROR - 2016-11-19 00:25:59 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 98
ERROR - 2016-11-19 00:25:59 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 85
ERROR - 2016-11-19 00:25:59 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 98
ERROR - 2016-11-19 00:25:59 --> Severity: Notice  --> Undefined variable: chart_delivered C:\xampp\htdocs\tirta_dahaga\application\views\home.php 112
ERROR - 2016-11-19 00:25:59 --> Severity: Notice  --> Undefined variable: chart_canceled C:\xampp\htdocs\tirta_dahaga\application\views\home.php 131
ERROR - 2016-11-19 00:26:04 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 85
ERROR - 2016-11-19 00:26:04 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 98
ERROR - 2016-11-19 00:26:04 --> Severity: Notice  --> Undefined variable: chart_delivered C:\xampp\htdocs\tirta_dahaga\application\views\home.php 112
ERROR - 2016-11-19 00:26:04 --> Severity: Notice  --> Undefined variable: chart_canceled C:\xampp\htdocs\tirta_dahaga\application\views\home.php 131
ERROR - 2016-11-19 00:32:16 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 85
ERROR - 2016-11-19 00:32:16 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 98
ERROR - 2016-11-19 00:32:16 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 85
ERROR - 2016-11-19 00:32:16 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 98
ERROR - 2016-11-19 00:32:25 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 85
ERROR - 2016-11-19 00:32:25 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 98
ERROR - 2016-11-19 00:32:25 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 85
ERROR - 2016-11-19 00:32:25 --> Severity: Notice  --> Undefined variable: notification_order C:\xampp\htdocs\tirta_dahaga\application\views\slices\sidebar.php 98
