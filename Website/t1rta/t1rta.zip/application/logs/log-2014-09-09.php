<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2014-09-09 08:29:41 --> Severity: Warning  --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\wamp\www\Galaxia-Store\system\libraries\Email.php 1553
ERROR - 2014-09-09 09:55:16 --> Severity: Warning  --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\wamp\www\Galaxia-Store\system\libraries\Email.php 1553
ERROR - 2014-09-09 23:27:01 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\Galaxia-Store\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-09-09 23:27:39 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\Galaxia-Store\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-09-09 23:28:21 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\Galaxia-Store\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-09-09 23:28:29 --> 404 Page Not Found --> search/as
ERROR - 2014-09-09 23:30:14 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\Galaxia-Store\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-09-09 23:32:17 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\Galaxia-Store\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-09-09 23:33:48 --> Severity: Notice  --> Undefined variable: blog C:\wamp\www\Galaxia-Store\application\views\search.php 25
ERROR - 2014-09-09 23:34:21 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\Galaxia-Store\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-09-09 23:34:21 --> Severity: Notice  --> Undefined variable: blog C:\wamp\www\Galaxia-Store\application\views\search.php 26
ERROR - 2014-09-09 23:34:21 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Galaxia-Store\application\views\search.php 26
ERROR - 2014-09-09 23:34:21 --> Severity: Notice  --> Undefined variable: blog C:\wamp\www\Galaxia-Store\application\views\search.php 26
ERROR - 2014-09-09 23:34:21 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Galaxia-Store\application\views\search.php 26
ERROR - 2014-09-09 23:34:21 --> Severity: Notice  --> Undefined variable: blog C:\wamp\www\Galaxia-Store\application\views\search.php 27
ERROR - 2014-09-09 23:34:21 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Galaxia-Store\application\views\search.php 27
ERROR - 2014-09-09 23:34:21 --> Severity: Notice  --> Undefined variable: blog C:\wamp\www\Galaxia-Store\application\views\search.php 31
ERROR - 2014-09-09 23:34:21 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Galaxia-Store\application\views\search.php 31
ERROR - 2014-09-09 23:40:31 --> Severity: Notice  --> Undefined variable: is_checkout C:\wamp\www\Galaxia-Store\application\views\search.php 39
ERROR - 2014-09-09 23:59:06 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '(SELECT name FROM gxa_product_category PC WHERE PC.catpro_id = PL.catpro_id) AS ' at line 1
