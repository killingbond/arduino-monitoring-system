<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2014-08-26 03:36:57 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
ERROR - 2014-08-26 03:59:06 --> 404 Page Not Found --> template
ERROR - 2014-08-26 04:17:47 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
ERROR - 2014-08-26 04:17:57 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
ERROR - 2014-08-26 04:27:16 --> 404 Page Not Found --> template
ERROR - 2014-08-26 04:28:23 --> 404 Page Not Found --> template
ERROR - 2014-08-26 04:31:18 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
ERROR - 2014-08-26 04:31:34 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
ERROR - 2014-08-26 04:31:57 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
ERROR - 2014-08-26 04:33:34 --> 404 Page Not Found --> template
ERROR - 2014-08-26 04:34:44 --> 404 Page Not Found --> template
ERROR - 2014-08-26 06:26:02 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
ERROR - 2014-08-26 06:37:37 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
ERROR - 2014-08-26 07:19:07 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
ERROR - 2014-08-26 08:09:37 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
ERROR - 2014-08-26 08:35:20 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
ERROR - 2014-08-26 08:36:13 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
