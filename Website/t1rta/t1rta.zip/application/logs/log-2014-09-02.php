<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2014-09-02 01:10:14 --> You did not select a file to upload.
ERROR - 2014-09-02 01:10:15 --> Severity: Warning  --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\wamp\www\Galaxia-Store\system\libraries\Email.php 1553
ERROR - 2014-09-02 09:52:12 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
