<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2014-10-21 14:40:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 14:40:53 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 14:40:56 --> 404 Page Not Found --> images
ERROR - 2014-10-21 14:40:57 --> 404 Page Not Found --> images
ERROR - 2014-10-21 14:41:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 14:41:00 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 14:41:00 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 14:41:00 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 14:41:00 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 294
ERROR - 2014-10-21 14:41:00 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 294
ERROR - 2014-10-21 14:41:01 --> 404 Page Not Found --> images
ERROR - 2014-10-21 14:41:01 --> 404 Page Not Found --> my_js
ERROR - 2014-10-21 14:41:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 14:41:33 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 14:41:33 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 14:41:33 --> 404 Page Not Found --> my_js
ERROR - 2014-10-21 14:41:36 --> 404 Page Not Found --> images
ERROR - 2014-10-21 14:42:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 14:42:18 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 14:42:18 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 14:42:18 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 14:42:18 --> 404 Page Not Found --> my_js
ERROR - 2014-10-21 14:42:18 --> 404 Page Not Found --> images
ERROR - 2014-10-21 14:42:18 --> 404 Page Not Found --> images
ERROR - 2014-10-21 14:42:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 14:42:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 14:42:26 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 14:42:26 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 14:42:26 --> 404 Page Not Found --> images
ERROR - 2014-10-21 14:42:26 --> 404 Page Not Found --> my_js
ERROR - 2014-10-21 14:42:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 14:42:49 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 14:42:49 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 14:42:49 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 14:42:49 --> 404 Page Not Found --> my_js
ERROR - 2014-10-21 14:42:50 --> 404 Page Not Found --> images
ERROR - 2014-10-21 14:42:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 14:42:52 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 14:42:52 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 14:42:52 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 14:42:52 --> 404 Page Not Found --> my_js
ERROR - 2014-10-21 14:42:52 --> 404 Page Not Found --> images
ERROR - 2014-10-21 14:44:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 14:44:04 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 14:44:04 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 14:44:04 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 14:44:04 --> 404 Page Not Found --> my_js
ERROR - 2014-10-21 14:44:05 --> 404 Page Not Found --> images
ERROR - 2014-10-21 14:45:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 14:45:08 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 14:45:08 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 14:45:09 --> 404 Page Not Found --> my_js
ERROR - 2014-10-21 14:45:09 --> 404 Page Not Found --> images
ERROR - 2014-10-21 14:45:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 14:45:55 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 14:45:55 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 14:45:55 --> 404 Page Not Found --> my_js
ERROR - 2014-10-21 14:45:56 --> 404 Page Not Found --> images
ERROR - 2014-10-21 14:47:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 14:47:16 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 14:47:16 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 14:47:16 --> 404 Page Not Found --> my_js
ERROR - 2014-10-21 14:47:17 --> 404 Page Not Found --> images
ERROR - 2014-10-21 14:47:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 14:47:26 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 14:47:26 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 14:47:26 --> 404 Page Not Found --> my_js
ERROR - 2014-10-21 14:47:26 --> 404 Page Not Found --> images
ERROR - 2014-10-21 14:47:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 14:47:36 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 14:47:36 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 14:47:36 --> 404 Page Not Found --> my_js
ERROR - 2014-10-21 14:47:41 --> 404 Page Not Found --> images
ERROR - 2014-10-21 14:47:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 14:47:59 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 14:47:59 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 14:47:59 --> 404 Page Not Found --> my_js
ERROR - 2014-10-21 14:47:59 --> 404 Page Not Found --> images
ERROR - 2014-10-21 14:48:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 14:48:32 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 14:48:32 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 14:48:32 --> 404 Page Not Found --> my_js
ERROR - 2014-10-21 14:48:32 --> 404 Page Not Found --> images
ERROR - 2014-10-21 14:48:34 --> 404 Page Not Found --> images
ERROR - 2014-10-21 14:48:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 14:48:52 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 14:48:52 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 14:48:52 --> 404 Page Not Found --> my_js
ERROR - 2014-10-21 14:48:53 --> 404 Page Not Found --> images
ERROR - 2014-10-21 14:49:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 14:49:21 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 14:49:21 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 14:49:21 --> 404 Page Not Found --> my_js
ERROR - 2014-10-21 14:49:21 --> 404 Page Not Found --> images
ERROR - 2014-10-21 14:49:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 14:49:29 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 14:49:29 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 14:49:29 --> 404 Page Not Found --> my_js
ERROR - 2014-10-21 14:49:33 --> 404 Page Not Found --> images
ERROR - 2014-10-21 14:49:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 14:49:50 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 14:49:50 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 14:49:50 --> 404 Page Not Found --> my_js
ERROR - 2014-10-21 14:49:56 --> 404 Page Not Found --> images
ERROR - 2014-10-21 14:50:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 14:50:38 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 14:50:38 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 14:50:38 --> 404 Page Not Found --> my_js
ERROR - 2014-10-21 14:50:39 --> 404 Page Not Found --> images
ERROR - 2014-10-21 14:50:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 14:50:53 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 14:50:53 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 14:50:53 --> 404 Page Not Found --> my_js
ERROR - 2014-10-21 14:50:53 --> 404 Page Not Found --> images
ERROR - 2014-10-21 14:51:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 14:51:04 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 14:51:04 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 14:51:04 --> 404 Page Not Found --> my_js
ERROR - 2014-10-21 14:51:05 --> 404 Page Not Found --> images
ERROR - 2014-10-21 14:51:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 14:51:14 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 14:51:14 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 14:51:14 --> 404 Page Not Found --> my_js
ERROR - 2014-10-21 14:51:14 --> 404 Page Not Found --> images
ERROR - 2014-10-21 14:51:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 14:51:24 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 14:51:24 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 14:51:24 --> 404 Page Not Found --> my_js
ERROR - 2014-10-21 14:51:24 --> 404 Page Not Found --> images
ERROR - 2014-10-21 14:51:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 14:51:34 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 14:51:34 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 14:51:34 --> 404 Page Not Found --> my_js
ERROR - 2014-10-21 14:51:34 --> 404 Page Not Found --> images
ERROR - 2014-10-21 14:51:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 14:51:44 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 14:51:44 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 14:51:44 --> 404 Page Not Found --> my_js
ERROR - 2014-10-21 14:51:45 --> 404 Page Not Found --> images
ERROR - 2014-10-21 14:51:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 14:51:50 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 14:51:50 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 14:51:50 --> 404 Page Not Found --> my_js
ERROR - 2014-10-21 14:51:50 --> 404 Page Not Found --> images
ERROR - 2014-10-21 14:52:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 14:52:00 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 14:52:00 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 14:52:00 --> 404 Page Not Found --> my_js
ERROR - 2014-10-21 14:52:00 --> 404 Page Not Found --> images
ERROR - 2014-10-21 14:52:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 14:52:06 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 14:52:06 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 14:52:06 --> 404 Page Not Found --> my_js
ERROR - 2014-10-21 14:52:07 --> 404 Page Not Found --> images
ERROR - 2014-10-21 14:52:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 14:52:20 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 14:52:20 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 14:52:20 --> 404 Page Not Found --> my_js
ERROR - 2014-10-21 14:52:20 --> 404 Page Not Found --> images
ERROR - 2014-10-21 14:52:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 14:52:30 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 14:52:30 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 14:52:30 --> 404 Page Not Found --> my_js
ERROR - 2014-10-21 14:52:30 --> 404 Page Not Found --> images
ERROR - 2014-10-21 14:52:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 14:52:33 --> 404 Page Not Found --> images
ERROR - 2014-10-21 14:52:33 --> 404 Page Not Found --> images
ERROR - 2014-10-21 14:52:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 14:52:35 --> 404 Page Not Found --> my_js
ERROR - 2014-10-21 14:52:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 14:52:35 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-21 14:52:35 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-21 14:52:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 14:52:38 --> 404 Page Not Found --> images
ERROR - 2014-10-21 14:52:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 14:52:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 14:52:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 14:52:43 --> 404 Page Not Found --> my_js
ERROR - 2014-10-21 14:52:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 14:52:43 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 78
ERROR - 2014-10-21 14:52:43 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\Esgotado\application\controllers\product.php 79
ERROR - 2014-10-21 14:52:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 14:52:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 14:52:51 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 14:52:51 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 14:52:51 --> 404 Page Not Found --> my_js
ERROR - 2014-10-21 14:52:51 --> 404 Page Not Found --> images
ERROR - 2014-10-21 14:53:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 14:53:06 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 14:53:06 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 14:53:06 --> 404 Page Not Found --> my_js
ERROR - 2014-10-21 14:53:08 --> 404 Page Not Found --> images
ERROR - 2014-10-21 14:53:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 14:53:56 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 14:53:56 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 14:53:56 --> 404 Page Not Found --> my_js
ERROR - 2014-10-21 14:53:56 --> 404 Page Not Found --> images
ERROR - 2014-10-21 14:53:57 --> 404 Page Not Found --> images
ERROR - 2014-10-21 14:54:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 14:54:24 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 14:54:24 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 14:54:24 --> 404 Page Not Found --> my_js
ERROR - 2014-10-21 14:54:24 --> 404 Page Not Found --> images
ERROR - 2014-10-21 14:54:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 14:54:38 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 14:54:38 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 14:54:38 --> 404 Page Not Found --> my_js
ERROR - 2014-10-21 14:54:38 --> 404 Page Not Found --> images
ERROR - 2014-10-21 14:55:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 14:55:20 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 14:55:20 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 14:55:20 --> 404 Page Not Found --> my_js
ERROR - 2014-10-21 14:55:25 --> 404 Page Not Found --> images
ERROR - 2014-10-21 14:56:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 14:56:09 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 14:56:09 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 14:56:09 --> 404 Page Not Found --> my_js
ERROR - 2014-10-21 14:56:09 --> 404 Page Not Found --> images
ERROR - 2014-10-21 14:56:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 14:56:17 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 14:56:17 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 14:56:17 --> 404 Page Not Found --> my_js
ERROR - 2014-10-21 14:56:19 --> 404 Page Not Found --> images
ERROR - 2014-10-21 14:56:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 14:56:34 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 14:56:34 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 14:56:35 --> 404 Page Not Found --> my_js
ERROR - 2014-10-21 14:56:35 --> 404 Page Not Found --> images
ERROR - 2014-10-21 14:57:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 14:57:51 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 14:57:51 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 14:57:52 --> 404 Page Not Found --> my_js
ERROR - 2014-10-21 14:57:52 --> 404 Page Not Found --> images
ERROR - 2014-10-21 14:58:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 14:58:03 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 14:58:03 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 14:58:03 --> 404 Page Not Found --> my_js
ERROR - 2014-10-21 14:58:05 --> 404 Page Not Found --> images
ERROR - 2014-10-21 14:58:05 --> 404 Page Not Found --> images
ERROR - 2014-10-21 14:58:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 14:58:15 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 14:58:15 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 14:58:15 --> 404 Page Not Found --> my_js
ERROR - 2014-10-21 14:58:16 --> 404 Page Not Found --> images
ERROR - 2014-10-21 14:58:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 14:58:28 --> 404 Page Not Found --> images
ERROR - 2014-10-21 14:58:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 14:58:34 --> 404 Page Not Found --> images
ERROR - 2014-10-21 14:58:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 14:58:38 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 14:58:38 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 14:58:38 --> 404 Page Not Found --> images
ERROR - 2014-10-21 14:58:38 --> 404 Page Not Found --> my_js
ERROR - 2014-10-21 14:58:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 14:58:59 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 14:58:59 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 14:58:59 --> 404 Page Not Found --> my_js
ERROR - 2014-10-21 14:59:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 14:59:49 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 14:59:49 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 14:59:49 --> 404 Page Not Found --> my_js
ERROR - 2014-10-21 15:00:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:00:08 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 15:00:08 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 15:00:08 --> 404 Page Not Found --> my_js
ERROR - 2014-10-21 15:00:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:00:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:00:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:00:21 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 15:00:21 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 15:00:21 --> 404 Page Not Found --> my_js
ERROR - 2014-10-21 15:00:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:00:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:00:25 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 15:00:25 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 15:00:26 --> 404 Page Not Found --> my_js
ERROR - 2014-10-21 15:00:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:00:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:00:32 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 15:00:32 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 15:00:32 --> 404 Page Not Found --> my_js
ERROR - 2014-10-21 15:00:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:00:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:00:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:00:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:00:46 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 15:00:46 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 15:00:46 --> 404 Page Not Found --> my_js
ERROR - 2014-10-21 15:02:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:02:10 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 15:02:10 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 15:02:10 --> 404 Page Not Found --> my_js
ERROR - 2014-10-21 15:02:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:02:18 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 15:02:18 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 15:02:18 --> 404 Page Not Found --> my_js
ERROR - 2014-10-21 15:02:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:02:23 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 15:02:23 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 15:02:23 --> 404 Page Not Found --> my_js
ERROR - 2014-10-21 15:02:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:02:40 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 15:02:40 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 15:02:40 --> 404 Page Not Found --> my_js
ERROR - 2014-10-21 15:03:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:03:36 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 15:03:36 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 15:03:37 --> 404 Page Not Found --> my_js
ERROR - 2014-10-21 15:04:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:04:06 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 15:04:06 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 15:04:06 --> 404 Page Not Found --> my_js
ERROR - 2014-10-21 15:04:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:04:50 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 15:04:50 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 15:04:51 --> 404 Page Not Found --> my_js
ERROR - 2014-10-21 15:07:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:07:07 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 15:07:07 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 15:07:07 --> 404 Page Not Found --> my_js
ERROR - 2014-10-21 15:08:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:08:13 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 15:08:13 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 15:08:13 --> 404 Page Not Found --> my_js
ERROR - 2014-10-21 15:08:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:08:35 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 15:08:35 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 15:08:35 --> 404 Page Not Found --> my_js
ERROR - 2014-10-21 15:10:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:10:53 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 15:10:53 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 15:10:53 --> 404 Page Not Found --> my_js
ERROR - 2014-10-21 15:11:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:11:08 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 15:11:08 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 15:11:08 --> 404 Page Not Found --> my_js
ERROR - 2014-10-21 15:11:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:11:24 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 15:11:24 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 15:11:24 --> 404 Page Not Found --> my_js
ERROR - 2014-10-21 15:11:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:11:59 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 15:11:59 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 15:12:00 --> 404 Page Not Found --> my_js
ERROR - 2014-10-21 15:12:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:12:28 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 15:12:28 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 15:12:28 --> 404 Page Not Found --> my_js
ERROR - 2014-10-21 15:12:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:12:55 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 15:12:55 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 15:12:55 --> 404 Page Not Found --> my_js
ERROR - 2014-10-21 15:13:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:13:22 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 15:13:22 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 15:13:22 --> 404 Page Not Found --> my_js
ERROR - 2014-10-21 15:13:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:13:50 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 15:13:50 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 15:13:50 --> 404 Page Not Found --> my_js
ERROR - 2014-10-21 15:13:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:13:57 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 15:13:57 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 15:13:57 --> 404 Page Not Found --> my_js
ERROR - 2014-10-21 15:14:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:14:51 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 15:14:51 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 15:14:52 --> 404 Page Not Found --> my_js
ERROR - 2014-10-21 15:15:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:15:03 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 15:15:03 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 15:15:03 --> 404 Page Not Found --> my_js
ERROR - 2014-10-21 15:16:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:16:10 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 15:16:10 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 15:16:10 --> 404 Page Not Found --> my_js
ERROR - 2014-10-21 15:17:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:17:29 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 15:17:29 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 15:17:31 --> 404 Page Not Found --> my_js
ERROR - 2014-10-21 15:19:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:19:13 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 15:19:13 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 15:19:13 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:19:13 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:19:13 --> 404 Page Not Found --> my_js
ERROR - 2014-10-21 15:19:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:19:34 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 15:19:34 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 15:19:34 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:19:34 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:19:34 --> 404 Page Not Found --> my_js
ERROR - 2014-10-21 15:19:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:19:47 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 15:19:47 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 15:19:47 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:19:47 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:19:47 --> 404 Page Not Found --> my_js
ERROR - 2014-10-21 15:20:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:20:38 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 15:20:38 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 15:20:41 --> 404 Page Not Found --> my_js
ERROR - 2014-10-21 15:21:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:21:19 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 15:21:19 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 15:21:24 --> 404 Page Not Found --> my_js
ERROR - 2014-10-21 15:21:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:21:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:21:37 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: HTTP request failed!  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:22:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:22:55 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: HTTP request failed!  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:23:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:23:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:23:22 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:23:22 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:23:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:23:35 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 15:23:35 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 15:23:35 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:23:35 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:23:35 --> 404 Page Not Found --> my_js
ERROR - 2014-10-21 15:23:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:23:37 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:23:37 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:23:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:23:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:23:48 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:23:48 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:24:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:24:07 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:24:07 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:25:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:25:31 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 15:25:31 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 15:25:31 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:25:31 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:25:31 --> 404 Page Not Found --> my_js
ERROR - 2014-10-21 15:25:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:25:37 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:25:37 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:25:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:25:57 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 15:25:57 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 15:25:57 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:25:57 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:25:57 --> 404 Page Not Found --> my_js
ERROR - 2014-10-21 15:26:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:26:02 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:26:02 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:26:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:26:41 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:26:41 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:27:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:27:33 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:27:33 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:27:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:27:49 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:27:49 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:28:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:28:04 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:28:04 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:28:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:28:08 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:28:08 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:28:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:28:13 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:28:13 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:28:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:28:39 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:28:39 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:29:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:29:15 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:29:15 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:29:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:29:21 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:29:21 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:30:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:30:16 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:30:16 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:30:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:30:44 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:30:44 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:31:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:31:05 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:31:05 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:31:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:31:17 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:31:17 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:31:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:31:22 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 15:31:22 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 15:31:22 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:31:22 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:31:22 --> 404 Page Not Found --> my_js
ERROR - 2014-10-21 15:31:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:31:25 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:31:26 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:31:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:31:30 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 15:31:30 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 15:31:30 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:31:30 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:31:30 --> 404 Page Not Found --> my_js
ERROR - 2014-10-21 15:31:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:31:37 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:31:37 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:31:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:31:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:31:41 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:31:41 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:32:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:32:12 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:32:12 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:32:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:32:14 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:32:14 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:32:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:32:20 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:32:20 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:32:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:32:20 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:32:20 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:32:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:32:22 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:32:22 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:32:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:32:22 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:32:22 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:32:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:32:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:32:27 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:32:27 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:32:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:32:27 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:32:27 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:32:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:32:29 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:32:29 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:32:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:32:29 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:32:29 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:32:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:32:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:32:38 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:32:38 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:32:38 --> 404 Page Not Found --> my_js
ERROR - 2014-10-21 15:32:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:32:38 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:32:38 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:32:38 --> 404 Page Not Found --> my_js
ERROR - 2014-10-21 15:32:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:32:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:32:41 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:32:41 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:32:41 --> 404 Page Not Found --> my_js
ERROR - 2014-10-21 15:32:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:32:41 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:32:41 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:32:41 --> 404 Page Not Found --> my_js
ERROR - 2014-10-21 15:32:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:32:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:32:47 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:32:47 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:32:47 --> 404 Page Not Found --> my_js
ERROR - 2014-10-21 15:32:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:32:47 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:32:47 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:32:47 --> 404 Page Not Found --> my_js
ERROR - 2014-10-21 15:32:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:32:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:32:51 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:32:51 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:32:51 --> 404 Page Not Found --> my_js
ERROR - 2014-10-21 15:32:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:32:51 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:32:51 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:32:51 --> 404 Page Not Found --> my_js
ERROR - 2014-10-21 15:32:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:32:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:32:54 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:32:54 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:32:54 --> 404 Page Not Found --> my_js
ERROR - 2014-10-21 15:32:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:32:54 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:32:54 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:32:54 --> 404 Page Not Found --> my_js
ERROR - 2014-10-21 15:32:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:32:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:32:57 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:32:57 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:32:57 --> 404 Page Not Found --> my_js
ERROR - 2014-10-21 15:32:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:32:57 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:32:57 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:32:57 --> 404 Page Not Found --> my_js
ERROR - 2014-10-21 15:32:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:32:59 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:32:59 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:33:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:33:00 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:33:00 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:33:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:33:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:33:04 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:33:04 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:33:04 --> 404 Page Not Found --> my_js
ERROR - 2014-10-21 15:33:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:33:04 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:33:04 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:33:04 --> 404 Page Not Found --> my_js
ERROR - 2014-10-21 15:33:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:33:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:33:07 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 15:33:07 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 15:33:07 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:33:07 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:33:07 --> 404 Page Not Found --> my_js
ERROR - 2014-10-21 15:33:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:33:07 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 15:33:07 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 15:33:07 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:33:07 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:33:07 --> 404 Page Not Found --> my_js
ERROR - 2014-10-21 15:33:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:33:24 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:33:25 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:33:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:33:25 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:33:25 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:33:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:33:27 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 15:33:27 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 15:33:27 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:33:27 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:33:27 --> 404 Page Not Found --> my_js
ERROR - 2014-10-21 15:33:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:33:27 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 15:33:27 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 15:33:27 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:33:27 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:33:27 --> 404 Page Not Found --> my_js
ERROR - 2014-10-21 15:33:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:33:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:33:31 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 15:33:31 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 15:33:31 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:33:31 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:33:31 --> 404 Page Not Found --> my_js
ERROR - 2014-10-21 15:33:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:33:31 --> Severity: Notice  --> Undefined variable: percent_ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 15:33:31 --> Severity: Notice  --> Undefined variable: ppn C:\wamp\www\Esgotado\application\views\cart.php 137
ERROR - 2014-10-21 15:33:31 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:33:31 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:33:31 --> 404 Page Not Found --> my_js
ERROR - 2014-10-21 15:33:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:33:34 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:33:34 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:33:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:33:34 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:33:34 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:34:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:34:21 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:34:21 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:34:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:34:22 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:34:22 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:34:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:34:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:34:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:34:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:34:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:34:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:34:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:34:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:34:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:34:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:34:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:34:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:34:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:34:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:35:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:35:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:35:03 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:35:03 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:35:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:35:03 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:35:03 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:35:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:35:28 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:35:28 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:35:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:35:28 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:35:28 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:35:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:35:41 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:35:41 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:35:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:35:42 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:35:42 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:36:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:36:57 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:36:57 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:36:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:36:57 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:36:57 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:38:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:38:15 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:38:15 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:38:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:38:15 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:38:15 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:38:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:38:18 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:38:18 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:38:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:38:19 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:38:19 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:38:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:38:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:38:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:38:55 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:38:55 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:38:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:38:55 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:38:55 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:38:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:38:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:38:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:38:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:38:59 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:38:59 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:38:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:38:59 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:38:59 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:39:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:39:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:39:03 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:39:03 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:39:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:39:03 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:39:03 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:39:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:39:30 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:39:30 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:39:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:39:30 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:39:30 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:39:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:39:45 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:39:45 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:39:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:39:45 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:39:45 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:39:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:39:56 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:39:56 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:39:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:39:56 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:39:56 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:40:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:40:18 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:40:18 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:40:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:40:18 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:40:18 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:40:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:40:36 --> Severity: Warning  --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\wamp\www\Esgotado\system\libraries\Email.php 1553
ERROR - 2014-10-21 15:40:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:40:36 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:40:36 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:40:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:40:36 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:40:36 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:40:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:40:48 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:40:48 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:40:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:40:48 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:40:48 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:40:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:40:58 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:40:58 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:40:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:40:59 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:40:59 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:43:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:43:59 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:43:59 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:43:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:43:59 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:43:59 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:44:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:44:06 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:44:06 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:44:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:44:06 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:44:06 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:44:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:44:09 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:44:09 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:44:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:44:10 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:44:10 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:44:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:44:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:45:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:45:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:48:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:48:04 --> Severity: Notice  --> Undefined variable: coming_soon C:\wamp\www\Esgotado\application\views\block\sidebar.php 17
ERROR - 2014-10-21 15:48:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:48:07 --> Severity: Notice  --> Undefined variable: coming_soon C:\wamp\www\Esgotado\application\views\block\sidebar.php 17
ERROR - 2014-10-21 15:48:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:48:27 --> Severity: Notice  --> Undefined variable: coming_soon C:\wamp\www\Esgotado\application\views\block\sidebar.php 17
ERROR - 2014-10-21 15:48:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:48:35 --> Severity: Notice  --> Undefined variable: coming_soon C:\wamp\www\Esgotado\application\views\block\sidebar.php 17
ERROR - 2014-10-21 15:49:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:49:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:50:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:50:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:50:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:50:59 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:50:59 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:50:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:50:59 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:51:00 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:51:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:51:00 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:51:00 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:51:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:51:00 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:51:00 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:51:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:51:04 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:51:04 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:52:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:52:08 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:52:08 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:52:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:52:08 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:52:08 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:52:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:52:28 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:52:28 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:52:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:52:33 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:52:33 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:52:33 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:52:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:52:34 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:52:34 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:52:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:52:55 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:52:55 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:52:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:52:57 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:52:57 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:52:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:52:57 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:52:57 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:53:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:53:32 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:53:32 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:53:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:53:33 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:53:33 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:54:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:54:00 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:54:00 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:54:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:54:00 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:54:00 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:56:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:56:09 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:56:09 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:56:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:56:09 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:56:09 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:56:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:56:12 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:56:12 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:56:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:56:12 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:56:12 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:56:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:56:16 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:56:17 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:56:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:56:17 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:56:17 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:56:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:56:37 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:56:37 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:56:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:56:37 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:56:37 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:56:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:56:39 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:56:39 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:56:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:56:39 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:56:39 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:56:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:56:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:56:47 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:56:47 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:56:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:56:48 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:56:48 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:56:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:56:54 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:56:54 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:56:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:56:54 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:56:54 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:57:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:57:00 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:57:00 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:57:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:57:00 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:57:00 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:57:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:57:46 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:57:46 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:57:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:57:46 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:57:46 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:58:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:58:27 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:58:27 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:58:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:58:28 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:58:28 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:58:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:58:46 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:58:46 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:58:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:58:46 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:58:46 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:58:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:58:59 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:58:59 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:58:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:58:59 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:58:59 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:59:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:59:05 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:59:05 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:59:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:59:06 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:59:06 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:59:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:59:21 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:59:21 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:59:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:59:21 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:59:21 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:59:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:59:43 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:59:43 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:59:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:59:43 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:59:43 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:59:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:59:55 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:59:55 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:59:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:59:55 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:59:55 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:59:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:59:58 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:59:58 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:59:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 15:59:58 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 15:59:58 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 16:00:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 16:00:42 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 16:00:42 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 16:00:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 16:00:42 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 16:00:42 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 16:00:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 16:00:44 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 16:00:44 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 16:00:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 16:00:44 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 16:00:44 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 16:01:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 16:01:10 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 16:01:10 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 16:01:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 16:01:10 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 16:01:10 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 16:01:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 16:01:18 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 16:01:18 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 16:01:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 16:01:18 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 16:01:18 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 16:01:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 16:01:32 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 16:01:32 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 16:01:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 16:01:33 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 16:01:33 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 16:01:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 16:01:40 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 16:01:40 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 16:01:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-10-21 16:01:40 --> Severity: Warning  --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 16:01:40 --> Severity: Warning  --> file_get_contents(http://opi.yahoo.com/online?u=joko&amp;m=a&amp;t=1): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\wamp\www\Esgotado\application\views\block\footer.php 83
ERROR - 2014-10-21 16:07:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\Esgotado\system\database\drivers\mysql\mysql_driver.php 91
